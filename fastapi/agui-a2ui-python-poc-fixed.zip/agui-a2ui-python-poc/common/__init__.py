"""Shared helpers for the AG-UI / A2UI PoC."""
