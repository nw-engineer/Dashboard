"""Small helpers for extracting user text from AG-UI RunAgentInput."""

from __future__ import annotations

from typing import Any


def latest_user_text(input_data: Any) -> str:
    """Best-effort extraction supporting string and multipart message content."""
    for message in reversed(getattr(input_data, "messages", []) or []):
        if getattr(message, "role", None) != "user":
            continue

        content = getattr(message, "content", None)
        if isinstance(content, str):
            return content

        if isinstance(content, list):
            chunks: list[str] = []
            for part in content:
                text = getattr(part, "text", None)
                if isinstance(text, str):
                    chunks.append(text)
                elif isinstance(part, dict) and isinstance(part.get("text"), str):
                    chunks.append(part["text"])
            if chunks:
                return " ".join(chunks)

    return ""
