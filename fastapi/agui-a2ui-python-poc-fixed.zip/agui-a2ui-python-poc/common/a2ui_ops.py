"""Build a fixed-schema A2UI monitoring surface using the official Python toolkit.

This module intentionally keeps the UI schema deterministic. It is useful for the
first validation step because it lets you verify protocol transport independently
from LLM quality.
"""

from __future__ import annotations

from typing import Any

from ag_ui_a2ui_toolkit import (
    A2UI_OPERATIONS_KEY,
    create_surface,
    update_components,
    update_data_model,
)

SURFACE_ID = "server-monitor"
CATALOG_ID = "https://a2ui.org/specification/v0_9/catalogs/basic/catalog.json"


def monitoring_components() -> list[dict[str, Any]]:
    """Return a small A2UI v0.9 component tree in flat adjacency-list form."""
    return [
        {
            "id": "root",
            "component": "Column",
            "children": ["title", "summary-card", "metrics-card"],
        },
        {
            "id": "title",
            "component": "Text",
            "text": "Server Monitoring",
            "variant": "h1",
        },
        {
            "id": "summary-card",
            "component": "Card",
            "child": "summary-column",
        },
        {
            "id": "summary-column",
            "component": "Column",
            "children": ["host-label", "status-label", "message-label"],
        },
        {
            "id": "host-label",
            "component": "Text",
            "text": {"path": "/host"},
        },
        {
            "id": "status-label",
            "component": "Text",
            "text": {"path": "/status"},
        },
        {
            "id": "message-label",
            "component": "Text",
            "text": {"path": "/message"},
        },
        {
            "id": "metrics-card",
            "component": "Card",
            "child": "metrics-column",
        },
        {
            "id": "metrics-column",
            "component": "Column",
            "children": ["cpu-label", "memory-label", "requests-label"],
        },
        {
            "id": "cpu-label",
            "component": "Text",
            "text": {"path": "/cpuDisplay"},
        },
        {
            "id": "memory-label",
            "component": "Text",
            "text": {"path": "/memoryDisplay"},
        },
        {
            "id": "requests-label",
            "component": "Text",
            "text": {"path": "/requestsDisplay"},
        },
    ]


def monitoring_data(
    *,
    host: str = "web-01",
    cpu: int = 92,
    memory: int = 81,
    requests_per_minute: int = 1240,
) -> dict[str, Any]:
    """Return sample data for the monitoring surface."""
    warning = cpu >= 85 or memory >= 85
    return {
        "host": f"Host: {host}",
        "status": "Status: WARNING" if warning else "Status: OK",
        "message": (
            "CPU or memory usage exceeds the demonstration threshold."
            if warning
            else "No threshold violation detected."
        ),
        "cpu": cpu,
        "memory": memory,
        "requestsPerMinute": requests_per_minute,
        "cpuDisplay": f"CPU: {cpu}%",
        "memoryDisplay": f"Memory: {memory}%",
        "requestsDisplay": f"Requests/min: {requests_per_minute}",
    }


def build_operations(
    *,
    surface_id: str = SURFACE_ID,
    catalog_id: str = CATALOG_ID,
    data: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Build create -> components -> data operations using toolkit helpers."""
    payload = data or monitoring_data()
    return [
        create_surface(surface_id, catalog_id),
        update_components(surface_id, monitoring_components()),
        update_data_model(surface_id, payload),
    ]


def build_operations_envelope(**kwargs: Any) -> dict[str, Any]:
    """Return the structured envelope detected by A2UI middleware/tooling."""
    return {A2UI_OPERATIONS_KEY: build_operations(**kwargs)}
