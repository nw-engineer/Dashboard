# Productionへ進む場合の注意点

## 1. integrated_pocのCUSTOM eventは検証用

`integrated_poc/main.py` はAG-UIの `CUSTOM` eventにA2UI operation envelopeを載せています。
これは「AG-UIがstructured payloadを運べる」ことを短時間で確認するための実装です。

実案件では、AG-UIのA2UI middleware/runtimeとA2UI対応Rendererを使用してください。

## 2. fixed schemaとdynamic schemaを分ける

最初はfixed schemaがおすすめです。

- component treeはアプリ側で固定
- Agent/toolはdataだけ更新
- UIの崩れが少ない
- schema validationが容易

Dynamic schemaへ進む場合は、LLMにcomponent catalogを渡し、生成結果を必ずvalidationしてからclientへ送ります。

## 3. Catalog IDをホスト側で管理する

LLMに任意のcatalogIdを生成させない方が安全です。Frontendに登録したCatalog IDとBackendが付与するCatalog IDを一致させます。

## 4. UI payloadを信頼しない

外部AgentやLLMから得たA2UI payloadはuntrusted inputとして扱います。
Renderer側では許可済みcomponentのみを使用し、URL/action/HTML相当の入力はapplication側のpolicyで制限してください。

## 5. 次の検証候補

- official A2UI React/Lit Rendererへの接続
- user actionの往復
- shared state
- tool call
- dynamic A2UI generation
- schema validation / retry
- LangGraph / ADK / Strands adapter
- authentication / authorization
- reconnect / error handling
