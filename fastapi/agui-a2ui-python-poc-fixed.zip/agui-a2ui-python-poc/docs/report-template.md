# A2UI / AG-UI 調査・検証報告テンプレート

## 1. 調査目的

AgentとFrontendの連携方式としてA2UI / AG-UIを調査し、Python SDKを用いたPoCで実装可能性を確認する。

## 2. 結論

- AG-UI: Agent実行とFrontend間のevent-based interaction layer
- A2UI: Agentが生成するdeclarative UI format
- 両者は競合ではなく組み合わせ可能
- Python SDKでAG-UI event streamとA2UI operation生成を検証可能
- Webでの本格描画はA2UI対応Renderer / runtimeとの接続が必要

## 3. 検証内容

### AG-UI

- RunAgentInput受信
- SSE event stream
- text streaming
- lifecycle event

### A2UI

- createSurface
- updateComponents
- updateDataModel
- data binding
- Agent SDKによるsystem prompt生成

### 統合

- AG-UI event stream内でA2UI operationを伝送
- Browser diagnostic clientで簡易描画

## 4. 評価

### メリット

- AgentとFrontendの責務分離
- streamingに適する
- UIを宣言形式で制限できる
- framework間の境界を標準化しやすい

### 課題

- Renderer / Catalog設計が必要
- ecosystemが更新中のためversion追従が必要
- dynamic UI生成ではvalidationが必須
- production利用ではaction authorization等の設計が必要

## 5. 次のステップ

1. Official rendererとの接続
2. user action往復
3. 実Agent frameworkとの統合
4. エラー処理・security検証
