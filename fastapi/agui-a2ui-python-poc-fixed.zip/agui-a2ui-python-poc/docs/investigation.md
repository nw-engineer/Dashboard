# 調査メモ: A2UI / AG-UI

## 目的

このPoCは、A2UIとAG-UIの責務を分離して理解し、最後に両者をPython中心で接続することを目的としています。

## AG-UI

AG-UIはAgentとユーザー向けアプリケーションの間で、実行開始・テキスト・ツール・状態・カスタムイベントなどをイベントストリームとしてやり取りするためのプロトコルです。

このリポジトリでは `ag-ui-protocol` のPython SDKを使用し、FastAPIの `StreamingResponse` からSSEを返します。

主に確認するイベント:

- RUN_STARTED
- TEXT_MESSAGE_START
- TEXT_MESSAGE_CONTENT
- TEXT_MESSAGE_END
- CUSTOM
- RUN_FINISHED

## A2UI

A2UIはAgentがUIを宣言的JSONとして表現するためのプロトコルです。v0.9系では、主に以下のメッセージをストリームします。

- createSurface
- updateComponents
- updateDataModel
- deleteSurface

UIの構造はフラットなcomponent listとID参照で表します。アプリケーションデータはcomponent定義とは分離され、JSON Pointer pathでbindingできます。

## 両者の関係

A2UIはUI payload format、AG-UIはAgentとFrontendを結ぶtransport / event layerとして利用できます。

現行のAG-UI側A2UI統合では、`ag-ui-a2ui-toolkit` が `a2ui_operations` envelopeを組み立てるためのPython helperを提供しています。公式のA2UI middleware/runtime経由では、A2UI surfaceはAG-UIのactivity eventsとしてFrontendへ渡されます。

このPoCでは学習目的のため、Pythonだけで内容を追いやすいよう `CUSTOM` event (`a2ui.operations`) に `a2ui_operations` envelopeを載せています。これは診断用bridgeであり、production統合時には公式middleware/runtimeに置き換える前提です。

## 検証観点

1. AG-UI SDKでRunAgentInputを受けられるか
2. AG-UI eventをSSEとしてstreamできるか
3. A2UI operationをPython toolkitで生成できるか
4. A2UI JSONL streamを返せるか
5. AG-UI event内にA2UI operationを載せてclientへ伝達できるか
6. client側でA2UI structure/data separationを再現できるか
7. 本番向けrenderer/middlewareへ置き換える境界が明確か
