from common.a2ui_ops import build_operations, monitoring_components, monitoring_data


def test_root_component_exists():
    components = monitoring_components()
    roots = [c for c in components if c.get("id") == "root"]
    assert len(roots) == 1
    assert roots[0]["component"] == "Column"


def test_operation_sequence():
    operations = build_operations()
    assert len(operations) == 3
    assert "createSurface" in operations[0]
    assert "updateComponents" in operations[1]
    assert "updateDataModel" in operations[2]


def test_warning_threshold():
    data = monitoring_data(cpu=90, memory=40)
    assert data["status"] == "Status: WARNING"


def test_normal_threshold():
    data = monitoring_data(cpu=40, memory=50)
    assert data["status"] == "Status: OK"
