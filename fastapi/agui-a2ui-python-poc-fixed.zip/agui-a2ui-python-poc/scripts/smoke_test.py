"""Small HTTP smoke test for the three PoC servers."""

from __future__ import annotations

import json
import sys

import httpx

AGUI_BODY = {
    "threadId": "thread-smoke",
    "runId": "run-smoke",
    "state": {},
    "messages": [
        {"id": "user-smoke", "role": "user", "content": "Web server status please"}
    ],
    "tools": [],
    "context": [],
    "forwardedProps": {},
}


def test_agui(url: str) -> None:
    print(f"POST {url}")
    with httpx.stream("POST", url, json=AGUI_BODY, timeout=10) as response:
        response.raise_for_status()
        for line in response.iter_lines():
            if line.startswith("data:"):
                event = json.loads(line.removeprefix("data:").strip())
                print(event["type"], event.get("name", ""), event.get("delta", ""))


def test_a2ui(url: str) -> None:
    print(f"GET {url}")
    with httpx.stream("GET", url, timeout=10) as response:
        response.raise_for_status()
        for line in response.iter_lines():
            if line:
                operation = json.loads(line)
                print(next(k for k in operation if k != "version"))


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "integrated"
    if target == "agui":
        test_agui("http://127.0.0.1:8000/agent")
    elif target == "a2ui":
        test_a2ui("http://127.0.0.1:8001/a2ui")
    elif target == "integrated":
        test_agui("http://127.0.0.1:8002/agent")
    else:
        raise SystemExit("usage: python scripts/smoke_test.py [agui|a2ui|integrated]")
