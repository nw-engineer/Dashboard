$ErrorActionPreference = "Stop"
.\.venv\Scripts\Activate.ps1
python -m uvicorn integrated_poc.main:app --host 127.0.0.1 --port 8002 --reload
