#!/usr/bin/env bash
set -eu
. .venv/bin/activate
python -m uvicorn integrated_poc.main:app --host 127.0.0.1 --port 8002 --reload
