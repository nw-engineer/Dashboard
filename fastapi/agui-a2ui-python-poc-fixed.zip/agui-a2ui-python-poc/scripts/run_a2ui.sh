#!/usr/bin/env bash
set -eu
. .venv/bin/activate
python -m uvicorn a2ui_poc.main:app --host 127.0.0.1 --port 8001 --reload
