#!/usr/bin/env bash
set -eu
. .venv/bin/activate
python -m uvicorn agui_poc.main:app --host 127.0.0.1 --port 8000 --reload
