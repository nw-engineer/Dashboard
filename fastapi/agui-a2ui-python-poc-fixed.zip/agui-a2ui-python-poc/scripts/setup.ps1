$ErrorActionPreference = "Stop"
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements-dev.txt
Write-Host "Setup complete."
