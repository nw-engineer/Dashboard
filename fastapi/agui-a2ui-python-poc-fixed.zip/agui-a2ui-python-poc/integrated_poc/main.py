"""Protocol-level AG-UI + A2UI PoC.

The endpoint emits normal AG-UI text events plus a valid AG-UI CUSTOM event whose
value is an ``a2ui_operations`` envelope built by ``ag-ui-a2ui-toolkit``.

This custom-event bridge is intentionally educational: it lets the whole flow run
with Python and a tiny diagnostic browser client. For a production renderer,
replace this custom bridge with the official AG-UI A2UI middleware/runtime path.
"""

from __future__ import annotations

import asyncio
import uuid
from pathlib import Path

from ag_ui.core import (
    CustomEvent,
    EventType,
    RunAgentInput,
    RunFinishedEvent,
    RunStartedEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    TextMessageStartEvent,
)
from ag_ui.encoder import EventEncoder
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, StreamingResponse

from common.a2ui_ops import build_operations_envelope, monitoring_data
from common.agui_input import latest_user_text

app = FastAPI(title="AG-UI + A2UI Python PoC")
CLIENT_HTML = Path(__file__).resolve().parents[1] / "client" / "index.html"


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "poc": "ag-ui+a2ui"}


@app.get("/demo")
def demo() -> FileResponse:
    return FileResponse(CLIENT_HTML)


def _demo_metrics(user_text: str) -> dict:
    """Vary deterministic sample values slightly based on the input text."""
    lowered = user_text.lower()
    if "normal" in lowered or "正常" in user_text:
        return monitoring_data(cpu=37, memory=54, requests_per_minute=810)
    if "critical" in lowered or "重大" in user_text:
        return monitoring_data(cpu=97, memory=94, requests_per_minute=2870)
    return monitoring_data()


@app.post("/agent")
async def agent(input_data: RunAgentInput, request: Request) -> StreamingResponse:
    encoder = EventEncoder(accept=request.headers.get("accept"))
    message_id = str(uuid.uuid4())
    user_text = latest_user_text(input_data) or "server status"
    envelope = build_operations_envelope(data=_demo_metrics(user_text))

    async def event_stream():
        yield encoder.encode(
            RunStartedEvent(
                type=EventType.RUN_STARTED,
                thread_id=input_data.thread_id,
                run_id=input_data.run_id,
            )
        )

        yield encoder.encode(
            TextMessageStartEvent(
                type=EventType.TEXT_MESSAGE_START,
                message_id=message_id,
                role="assistant",
            )
        )

        for chunk in [
            "Server status collected. ",
            "I will also send an A2UI monitoring surface.",
        ]:
            yield encoder.encode(
                TextMessageContentEvent(
                    type=EventType.TEXT_MESSAGE_CONTENT,
                    message_id=message_id,
                    delta=chunk,
                )
            )
            await asyncio.sleep(0.12)

        yield encoder.encode(
            CustomEvent(
                type=EventType.CUSTOM,
                name="a2ui.operations",
                value=envelope,
            )
        )

        yield encoder.encode(
            TextMessageEndEvent(
                type=EventType.TEXT_MESSAGE_END,
                message_id=message_id,
            )
        )

        yield encoder.encode(
            RunFinishedEvent(
                type=EventType.RUN_FINISHED,
                thread_id=input_data.thread_id,
                run_id=input_data.run_id,
                result={"a2uiSurface": "server-monitor"},
            )
        )

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
