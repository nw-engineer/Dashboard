"""AG-UI + A2UI protocol-level integration PoC."""
