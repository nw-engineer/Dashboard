"""Generate an A2UI-aware LLM system prompt with a2ui-agent-sdk.

No LLM API key is required for this file. It only demonstrates how the SDK
assembles protocol/catalog context that can later be passed to an LLM.
"""

from __future__ import annotations

from a2ui.basic_catalog.provider import BasicCatalog
from a2ui.schema.constants import VERSION_0_9
from a2ui.strategies.schema import A2uiSchemaManager

ROLE_DESCRIPTION = """
You are an infrastructure monitoring assistant.
Your final UI output must use A2UI components from the provided catalog.
""".strip()

UI_DESCRIPTION = """
- For a server status request, render a compact monitoring surface.
- Show host, status, CPU, memory, and requests per minute.
- Use data binding for values that may change.
- Prefer Card, Column, and Text from the Basic Catalog.
- Keep the UI small enough for an operations dashboard.
""".strip()


def build_prompt() -> str:
    schema_manager = A2uiSchemaManager(
        version=VERSION_0_9,
        catalogs=[BasicCatalog.get_config(version=VERSION_0_9)],
    )
    return schema_manager.generate_system_prompt(
        role_description=ROLE_DESCRIPTION,
        ui_description=UI_DESCRIPTION,
        include_schema=True,
        # Examples are intentionally disabled to keep this standalone PoC
        # independent from an examples directory on disk.
        include_examples=False,
    )


if __name__ == "__main__":
    print(build_prompt())
