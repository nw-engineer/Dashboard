"""A2UI only PoC."""
