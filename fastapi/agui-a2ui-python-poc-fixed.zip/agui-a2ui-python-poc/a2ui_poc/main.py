"""A2UI-only JSONL stream using fixed sample operations."""

from __future__ import annotations

import asyncio
import json

from fastapi import FastAPI
from fastapi.responses import StreamingResponse

from common.a2ui_ops import build_operations

app = FastAPI(title="A2UI Python PoC")


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "poc": "a2ui"}


@app.get("/a2ui")
async def a2ui_stream() -> StreamingResponse:
    """Stream A2UI messages as one JSON object per line."""

    async def generate():
        for operation in build_operations():
            yield json.dumps(operation, ensure_ascii=False) + "\n"
            await asyncio.sleep(0.2)

    return StreamingResponse(
        generate(),
        media_type="application/a2ui+json",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
