"""Minimal AG-UI server implemented with FastAPI and the Python SDK."""

from __future__ import annotations

import asyncio
import uuid

from ag_ui.core import (
    EventType,
    RunFinishedEvent,
    RunStartedEvent,
    RunAgentInput,
    TextMessageContentEvent,
    TextMessageEndEvent,
    TextMessageStartEvent,
)
from ag_ui.encoder import EventEncoder
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse

from common.agui_input import latest_user_text

app = FastAPI(title="AG-UI Python PoC")


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "poc": "ag-ui"}


@app.post("/agent")
async def agent(input_data: RunAgentInput, request: Request) -> StreamingResponse:
    """Return a valid AG-UI event stream over SSE."""
    encoder = EventEncoder(accept=request.headers.get("accept"))
    message_id = str(uuid.uuid4())
    user_text = latest_user_text(input_data) or "(no user message)"

    async def event_stream():
        yield encoder.encode(
            RunStartedEvent(
                type=EventType.RUN_STARTED,
                thread_id=input_data.thread_id,
                run_id=input_data.run_id,
            )
        )

        yield encoder.encode(
            TextMessageStartEvent(
                type=EventType.TEXT_MESSAGE_START,
                message_id=message_id,
                role="assistant",
            )
        )

        chunks = [
            "AG-UI Python SDK PoC is running. ",
            f"Received: {user_text}. ",
            "This response is being delivered as AG-UI SSE events.",
        ]
        for chunk in chunks:
            yield encoder.encode(
                TextMessageContentEvent(
                    type=EventType.TEXT_MESSAGE_CONTENT,
                    message_id=message_id,
                    delta=chunk,
                )
            )
            await asyncio.sleep(0.15)

        yield encoder.encode(
            TextMessageEndEvent(
                type=EventType.TEXT_MESSAGE_END,
                message_id=message_id,
            )
        )

        yield encoder.encode(
            RunFinishedEvent(
                type=EventType.RUN_FINISHED,
                thread_id=input_data.thread_id,
                run_id=input_data.run_id,
            )
        )

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
