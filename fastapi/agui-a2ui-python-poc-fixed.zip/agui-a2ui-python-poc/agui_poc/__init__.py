"""AG-UI only PoC."""
