from __future__ import annotations

import json
import os
from typing import Any

from openai import OpenAI

from .models import AnalysisResult, IncidentAnalysis


SYSTEM_PROMPT = """\
あなたはSRE / Security Operations向けの分析アシスタントです。
与えられたユーザー要求とサーバメトリクスだけを根拠に分析してください。
観測されていない事実を断定しないでください。

severityの目安:
- OK: CPU/Memory/Error rate に顕著な問題なし
- WARNING: 高負荷またはエラー増加だが即時障害とは言い切れない
- CRITICAL: CPU/Memoryが非常に高い、または5xx/error rateが大きく増加

CRITICAL の場合は、危険な自動変更を勝手に実行せず、
requires_approval=true として Human-in-the-Loop の承認対象を提案してください。
"""


def _mock_analysis(metrics: dict[str, Any]) -> IncidentAnalysis:
    cpu = float(metrics["cpu"])
    memory = float(metrics["memory"])
    error_rate = float(metrics["error_rate"])

    if cpu >= 95 or memory >= 90 or error_rate >= 7:
        return IncidentAnalysis(
            severity="CRITICAL",
            summary=(
                f"{metrics['host']} は高負荷かつエラー率が上昇しています。"
                "即時の状況確認と、変更操作前の承認が必要です。"
            ),
            likely_causes=[
                "急激なリクエスト増加によるアプリケーション負荷",
                "ワーカープロセスまたはバックエンド処理の滞留",
                "メモリ逼迫に伴うレスポンス遅延・5xx増加",
            ],
            recommendations=[
                "直近のアクセスログと5xx発生箇所を確認する",
                "プロセス別CPU/Memoryとバックエンド待ち時間を確認する",
                "復旧操作は承認後に段階的に実施する",
            ],
            requires_approval=True,
            proposed_action="webサービスのワーカープロセスを段階的に再起動する（デモ）",
        )

    if cpu >= 85 or memory >= 80 or error_rate >= 2:
        return IncidentAnalysis(
            severity="WARNING",
            summary=f"{metrics['host']} は高負荷傾向です。継続監視と原因切り分けを推奨します。",
            likely_causes=[
                "トラフィック増加",
                "バックエンド処理時間の増加",
                "一時的なリソース不足",
            ],
            recommendations=[
                "5分から15分の時系列推移を確認する",
                "エンドポイント別レスポンス時間を比較する",
                "必要ならスケールアウトを検討する",
            ],
            requires_approval=False,
            proposed_action="",
        )

    return IncidentAnalysis(
        severity="OK",
        summary=f"{metrics['host']} に重大な異常は見られません。",
        likely_causes=[
            "現在のメトリクスでは異常兆候なし",
        ],
        recommendations=[
            "通常監視を継続する",
        ],
        requires_approval=False,
        proposed_action="",
    )


def _strip_json_fence(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines:
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines)
    return text.strip()


class IncidentAnalyzer:
    def __init__(self) -> None:
        self.provider = os.getenv("LLM_PROVIDER", "mock").lower()
        self.model = os.getenv("OPENAI_MODEL", "gpt-5.6")
        self.allow_fallback = os.getenv("ALLOW_MOCK_FALLBACK", "true").lower() == "true"

    def analyze(self, user_text: str, metrics: dict[str, Any]) -> AnalysisResult:
        if self.provider != "openai":
            return AnalysisResult(
                analysis=_mock_analysis(metrics),
                provider="mock",
            )

        try:
            analysis = self._analyze_openai(user_text, metrics)
            return AnalysisResult(
                analysis=analysis,
                provider=f"openai:{self.model}",
            )
        except Exception as exc:
            if not self.allow_fallback:
                raise
            return AnalysisResult(
                analysis=_mock_analysis(metrics),
                provider="mock-fallback",
                warning=f"OpenAI呼び出しに失敗したためMockへフォールバック: {exc}",
            )

    def _analyze_openai(self, user_text: str, metrics: dict[str, Any]) -> IncidentAnalysis:
        client = OpenAI()
        input_payload = {
            "user_request": user_text,
            "metrics": metrics,
        }
        schema = IncidentAnalysis.model_json_schema()

        # Responses API Structured Outputs。
        # SDK/Model側の差異に備え、失敗時は通常JSON出力へ1回だけフォールバックする。
        try:
            response = client.responses.create(
                model=self.model,
                instructions=SYSTEM_PROMPT,
                input=json.dumps(input_payload, ensure_ascii=False),
                text={
                    "format": {
                        "type": "json_schema",
                        "name": "incident_analysis",
                        "schema": schema,
                        "strict": True,
                    }
                },
            )
            return IncidentAnalysis.model_validate_json(response.output_text)
        except Exception:
            response = client.responses.create(
                model=self.model,
                instructions=SYSTEM_PROMPT
                + "\n出力は必ずJSONオブジェクトのみとし、説明やMarkdownを付けないでください。",
                input=(
                    json.dumps(input_payload, ensure_ascii=False)
                    + "\n\nJSON Schema:\n"
                    + json.dumps(schema, ensure_ascii=False)
                ),
            )
            data = json.loads(_strip_json_fence(response.output_text))
            return IncidentAnalysis.model_validate(data)
