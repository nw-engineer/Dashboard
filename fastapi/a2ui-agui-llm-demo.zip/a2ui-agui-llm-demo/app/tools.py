from __future__ import annotations

from typing import Any


def infer_scenario(user_text: str, forwarded_props: Any) -> str:
    if isinstance(forwarded_props, dict):
        scenario = str(forwarded_props.get("scenario", "")).lower()
        if scenario in {"normal", "warning", "critical"}:
            return scenario

    lowered = user_text.lower()
    if "normal" in lowered or "正常" in user_text:
        return "normal"
    if "warning" in lowered or "warn" in lowered or "警告" in user_text:
        return "warning"
    if "critical" in lowered or "重大" in user_text or "障害" in user_text:
        return "critical"
    return "critical"


def get_server_metrics(host: str = "web-01", scenario: str = "critical") -> dict[str, Any]:
    """外部監視APIの代替となるデモ用Tool。

    実環境では、ここを Zabbix / OpenSearch / CloudWatch / Datadog 等の
    API呼び出しへ置き換える想定です。
    """
    samples = {
        "normal": {
            "cpu": 37,
            "memory": 54,
            "requests_per_minute": 810,
            "error_rate": 0.2,
            "http_5xx": 2,
        },
        "warning": {
            "cpu": 88,
            "memory": 79,
            "requests_per_minute": 1680,
            "error_rate": 2.8,
            "http_5xx": 41,
        },
        "critical": {
            "cpu": 97,
            "memory": 94,
            "requests_per_minute": 2870,
            "error_rate": 8.7,
            "http_5xx": 226,
        },
    }
    data = dict(samples.get(scenario, samples["critical"]))
    data.update(
        {
            "host": host,
            "scenario": scenario,
            "source": "demo-monitoring-tool",
        }
    )
    return data


def apply_remediation(host: str, action: str) -> dict[str, Any]:
    """Human approval 後に実行されるデモ用の変更Tool。"""
    return {
        "success": True,
        "host": host,
        "action": action,
        "message": "デモ用の復旧操作を実行しました。",
        "metrics_after": {
            "cpu": 42,
            "memory": 58,
            "requests_per_minute": 920,
            "error_rate": 0.4,
            "http_5xx": 4,
        },
    }
