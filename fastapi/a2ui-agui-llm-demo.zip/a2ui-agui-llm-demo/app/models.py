from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class IncidentAnalysis(BaseModel):
    """LLMが返す、UIとは独立した業務ドメインの分析結果。

    LLMにA2UIを直接生成させず、一度この型へ落とすことで、
    デモの再現性と安全性を高めています。
    """

    model_config = ConfigDict(extra="forbid")

    severity: Literal["OK", "WARNING", "CRITICAL"]
    summary: str = Field(min_length=1, max_length=500)
    likely_causes: list[str] = Field(min_length=1, max_length=3)
    recommendations: list[str] = Field(min_length=1, max_length=3)
    requires_approval: bool
    proposed_action: str = Field(
        description="承認が必要な場合の操作案。不要な場合は空文字列。"
    )


class AnalysisResult(BaseModel):
    analysis: IncidentAnalysis
    provider: str
    warning: str | None = None
