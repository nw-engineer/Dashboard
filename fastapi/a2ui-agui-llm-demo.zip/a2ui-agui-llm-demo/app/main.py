from __future__ import annotations

import asyncio
import json
import uuid
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

load_dotenv()

from ag_ui.core import (
    CustomEvent,
    EventType,
    RunAgentInput,
    RunErrorEvent,
    RunFinishedEvent,
    RunStartedEvent,
    StateDeltaEvent,
    StateSnapshotEvent,
    StepFinishedEvent,
    StepStartedEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    TextMessageStartEvent,
    ToolCallArgsEvent,
    ToolCallEndEvent,
    ToolCallResultEvent,
    ToolCallStartEvent,
)
from ag_ui.encoder import EventEncoder
from fastapi import Body, FastAPI, Query, Request
from fastapi.responses import FileResponse, StreamingResponse

from .a2ui_builder import build_remediation_update, build_surface_envelope
from .llm import IncidentAnalyzer
from .tools import apply_remediation, get_server_metrics, infer_scenario


app = FastAPI(title="A2UI + AG-UI + LLM Demo", version="1.0")
STATIC_HTML = Path(__file__).resolve().parents[1] / "static" / "index.html"


def latest_user_text(input_data: RunAgentInput) -> str:
    for message in reversed(input_data.messages):
        if getattr(message, "role", None) == "user":
            content = getattr(message, "content", "")
            if isinstance(content, str):
                return content
            return str(content)
    return ""


def chunks(text: str, size: int = 32) -> list[str]:
    return [text[i : i + size] for i in range(0, len(text), size)] or [""]


@app.get("/")
def root() -> FileResponse:
    return FileResponse(STATIC_HTML)


@app.get("/demo")
def demo() -> FileResponse:
    return FileResponse(STATIC_HTML)


@app.get("/health")
def health() -> dict[str, Any]:
    analyzer = IncidentAnalyzer()
    return {
        "status": "ok",
        "llmProvider": analyzer.provider,
        "openaiModel": analyzer.model,
        "flow": "AG-UI -> Tool -> LLM -> A2UI -> Human Approval",
    }


@app.post("/agent")
async def agent(input_data: RunAgentInput, request: Request) -> StreamingResponse:
    encoder = EventEncoder(accept=request.headers.get("accept"))
    user_text = latest_user_text(input_data) or "web-01 の状態を分析して"
    scenario = infer_scenario(user_text, input_data.forwarded_props)
    host = "web-01"

    async def event_stream():
        try:
            yield encoder.encode(
                RunStartedEvent(
                    type=EventType.RUN_STARTED,
                    thread_id=input_data.thread_id,
                    run_id=input_data.run_id,
                )
            )

            yield encoder.encode(
                StateSnapshotEvent(
                    type=EventType.STATE_SNAPSHOT,
                    snapshot={
                        "phase": "started",
                        "scenario": scenario,
                        "host": host,
                    },
                )
            )

            # ---- Step 1: Tool Call ----
            yield encoder.encode(
                StepStartedEvent(
                    type=EventType.STEP_STARTED,
                    step_name="collect_metrics",
                )
            )

            tool_call_id = f"tool-{uuid.uuid4()}"
            tool_result_message_id = f"msg-{uuid.uuid4()}"
            tool_args = {"host": host, "scenario": scenario}

            yield encoder.encode(
                ToolCallStartEvent(
                    type=EventType.TOOL_CALL_START,
                    tool_call_id=tool_call_id,
                    tool_call_name="get_server_metrics",
                )
            )
            yield encoder.encode(
                ToolCallArgsEvent(
                    type=EventType.TOOL_CALL_ARGS,
                    tool_call_id=tool_call_id,
                    delta=json.dumps(tool_args, ensure_ascii=False),
                )
            )
            yield encoder.encode(
                ToolCallEndEvent(
                    type=EventType.TOOL_CALL_END,
                    tool_call_id=tool_call_id,
                )
            )

            metrics = get_server_metrics(**tool_args)

            yield encoder.encode(
                ToolCallResultEvent(
                    type=EventType.TOOL_CALL_RESULT,
                    message_id=tool_result_message_id,
                    tool_call_id=tool_call_id,
                    content=json.dumps(metrics, ensure_ascii=False),
                    role="tool",
                )
            )
            yield encoder.encode(
                StateDeltaEvent(
                    type=EventType.STATE_DELTA,
                    delta=[
                        {"op": "replace", "path": "/phase", "value": "metrics_collected"},
                        {"op": "add", "path": "/metrics", "value": metrics},
                    ],
                )
            )
            yield encoder.encode(
                StepFinishedEvent(
                    type=EventType.STEP_FINISHED,
                    step_name="collect_metrics",
                )
            )

            # ---- Step 2: LLM Analysis ----
            yield encoder.encode(
                StepStartedEvent(
                    type=EventType.STEP_STARTED,
                    step_name="llm_analysis",
                )
            )

            analyzer = IncidentAnalyzer()
            analysis_result = await asyncio.to_thread(
                analyzer.analyze,
                user_text,
                metrics,
            )

            yield encoder.encode(
                StateDeltaEvent(
                    type=EventType.STATE_DELTA,
                    delta=[
                        {"op": "replace", "path": "/phase", "value": "analysis_completed"},
                        {
                            "op": "add",
                            "path": "/analysis",
                            "value": analysis_result.analysis.model_dump(),
                        },
                        {"op": "add", "path": "/llmProvider", "value": analysis_result.provider},
                    ],
                )
            )

            message_id = f"msg-{uuid.uuid4()}"
            yield encoder.encode(
                TextMessageStartEvent(
                    type=EventType.TEXT_MESSAGE_START,
                    message_id=message_id,
                    role="assistant",
                )
            )

            answer = (
                f"[{analysis_result.analysis.severity}] "
                f"{analysis_result.analysis.summary} "
                f"分析結果をA2UIダッシュボードとして表示します。"
            )
            if analysis_result.warning:
                answer += f" 注意: {analysis_result.warning}"

            for part in chunks(answer):
                yield encoder.encode(
                    TextMessageContentEvent(
                        type=EventType.TEXT_MESSAGE_CONTENT,
                        message_id=message_id,
                        delta=part,
                    )
                )
                await asyncio.sleep(0.06)

            yield encoder.encode(
                TextMessageEndEvent(
                    type=EventType.TEXT_MESSAGE_END,
                    message_id=message_id,
                )
            )
            yield encoder.encode(
                StepFinishedEvent(
                    type=EventType.STEP_FINISHED,
                    step_name="llm_analysis",
                )
            )

            # ---- Step 3: A2UI ----
            yield encoder.encode(
                StepStartedEvent(
                    type=EventType.STEP_STARTED,
                    step_name="render_a2ui",
                )
            )
            envelope = build_surface_envelope(metrics, analysis_result)
            yield encoder.encode(
                CustomEvent(
                    type=EventType.CUSTOM,
                    name="a2ui.operations",
                    value=envelope,
                )
            )
            yield encoder.encode(
                StepFinishedEvent(
                    type=EventType.STEP_FINISHED,
                    step_name="render_a2ui",
                )
            )

            yield encoder.encode(
                RunFinishedEvent(
                    type=EventType.RUN_FINISHED,
                    thread_id=input_data.thread_id,
                    run_id=input_data.run_id,
                    result={
                        "severity": analysis_result.analysis.severity,
                        "llmProvider": analysis_result.provider,
                        "a2uiSurface": "incident-dashboard",
                    },
                )
            )
        except Exception as exc:
            yield encoder.encode(
                RunErrorEvent(
                    type=EventType.RUN_ERROR,
                    message=str(exc),
                    code="DEMO_ERROR",
                )
            )

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.post("/a2ui/action")
async def a2ui_action(
    request: Request,
    body: dict[str, Any] = Body(...),
    thread_id: str = Query(...),
) -> StreamingResponse:
    """A2UI v0.9 Action を受け、承認後Tool実行を AG-UI Events で返す。"""
    encoder = EventEncoder(accept=request.headers.get("accept"))
    action = body.get("action", {})
    action_name = action.get("name", "")
    context = action.get("context", {})
    run_id = f"run-{uuid.uuid4()}"

    async def event_stream():
        try:
            yield encoder.encode(
                RunStartedEvent(
                    type=EventType.RUN_STARTED,
                    thread_id=thread_id,
                    run_id=run_id,
                )
            )

            if action_name != "approve_remediation":
                raise ValueError(f"Unsupported A2UI action: {action_name}")

            host = str(context.get("host", "web-01"))
            proposed_action = str(context.get("action", "demo remediation"))

            tool_call_id = f"tool-{uuid.uuid4()}"
            yield encoder.encode(
                ToolCallStartEvent(
                    type=EventType.TOOL_CALL_START,
                    tool_call_id=tool_call_id,
                    tool_call_name="apply_remediation",
                )
            )
            yield encoder.encode(
                ToolCallArgsEvent(
                    type=EventType.TOOL_CALL_ARGS,
                    tool_call_id=tool_call_id,
                    delta=json.dumps(
                        {"host": host, "action": proposed_action},
                        ensure_ascii=False,
                    ),
                )
            )
            yield encoder.encode(
                ToolCallEndEvent(
                    type=EventType.TOOL_CALL_END,
                    tool_call_id=tool_call_id,
                )
            )

            result = apply_remediation(host, proposed_action)

            yield encoder.encode(
                ToolCallResultEvent(
                    type=EventType.TOOL_CALL_RESULT,
                    message_id=f"msg-{uuid.uuid4()}",
                    tool_call_id=tool_call_id,
                    content=json.dumps(result, ensure_ascii=False),
                    role="tool",
                )
            )

            yield encoder.encode(
                StateDeltaEvent(
                    type=EventType.STATE_DELTA,
                    delta=[
                        {"op": "replace", "path": "/phase", "value": "remediation_completed"},
                        {"op": "add", "path": "/remediation", "value": result},
                    ],
                )
            )

            yield encoder.encode(
                CustomEvent(
                    type=EventType.CUSTOM,
                    name="a2ui.operations",
                    value=build_remediation_update(
                        host=host,
                        action=proposed_action,
                        metrics_after=result["metrics_after"],
                    ),
                )
            )

            msg_id = f"msg-{uuid.uuid4()}"
            yield encoder.encode(
                TextMessageStartEvent(
                    type=EventType.TEXT_MESSAGE_START,
                    message_id=msg_id,
                    role="assistant",
                )
            )
            yield encoder.encode(
                TextMessageContentEvent(
                    type=EventType.TEXT_MESSAGE_CONTENT,
                    message_id=msg_id,
                    delta="Human Approval を受け、デモ復旧Toolを実行しました。",
                )
            )
            yield encoder.encode(
                TextMessageEndEvent(
                    type=EventType.TEXT_MESSAGE_END,
                    message_id=msg_id,
                )
            )

            yield encoder.encode(
                RunFinishedEvent(
                    type=EventType.RUN_FINISHED,
                    thread_id=thread_id,
                    run_id=run_id,
                    result={"approved": True, "toolResult": result},
                )
            )
        except Exception as exc:
            yield encoder.encode(
                RunErrorEvent(
                    type=EventType.RUN_ERROR,
                    message=str(exc),
                    code="ACTION_ERROR",
                )
            )

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
