from __future__ import annotations

from typing import Any

from ag_ui_a2ui_toolkit import (
    A2UI_OPERATIONS_KEY,
    create_surface,
    update_components,
    update_data_model,
)

from .models import AnalysisResult


SURFACE_ID = "incident-dashboard"
CATALOG_ID = "https://a2ui.org/specification/v0_9_1/catalogs/basic/catalog.json"


def _pad(values: list[str], size: int = 3) -> list[str]:
    values = list(values[:size])
    while len(values) < size:
        values.append("")
    return values


def build_data(
    metrics: dict[str, Any],
    result: AnalysisResult,
) -> dict[str, Any]:
    a = result.analysis
    causes = _pad(a.likely_causes)
    recommendations = _pad(a.recommendations)
    return {
        "hostRaw": metrics["host"],
        "host": f"Host: {metrics['host']}",
        "severity": f"Severity: {a.severity}",
        "summary": a.summary,
        "provider": f"LLM: {result.provider}",
        "warning": result.warning or "",
        "cpu": f"CPU: {metrics['cpu']}%",
        "memory": f"Memory: {metrics['memory']}%",
        "rpm": f"Requests/min: {metrics['requests_per_minute']}",
        "errorRate": f"Error rate: {metrics['error_rate']}%",
        "http5xx": f"HTTP 5xx: {metrics['http_5xx']}",
        "cause1": causes[0],
        "cause2": causes[1],
        "cause3": causes[2],
        "recommendation1": recommendations[0],
        "recommendation2": recommendations[1],
        "recommendation3": recommendations[2],
        "approvalMessage": (
            "変更操作にはHuman Approvalが必要です。"
            if a.requires_approval
            else "現在、承認が必要な変更操作はありません。"
        ),
        "proposedAction": a.proposed_action,
    }


def build_components(requires_approval: bool) -> list[dict[str, Any]]:
    components: list[dict[str, Any]] = [
        {
            "id": "root",
            "component": "Column",
            "children": [
                "title",
                "summary-card",
                "metrics-card",
                "causes-card",
                "recommendations-card",
                "approval-card",
            ],
        },
        {
            "id": "title",
            "component": "Text",
            "text": "Incident Analysis Dashboard",
            "variant": "h1",
        },
        {
            "id": "summary-card",
            "component": "Card",
            "child": "summary-column",
        },
        {
            "id": "summary-column",
            "component": "Column",
            "children": ["host", "severity", "summary", "provider", "warning"],
        },
        {"id": "host", "component": "Text", "text": {"path": "/host"}},
        {"id": "severity", "component": "Text", "text": {"path": "/severity"}},
        {"id": "summary", "component": "Text", "text": {"path": "/summary"}},
        {"id": "provider", "component": "Text", "text": {"path": "/provider"}},
        {"id": "warning", "component": "Text", "text": {"path": "/warning"}},
        {
            "id": "metrics-card",
            "component": "Card",
            "child": "metrics-column",
        },
        {
            "id": "metrics-column",
            "component": "Column",
            "children": ["metrics-title", "cpu", "memory", "rpm", "error-rate", "http-5xx"],
        },
        {"id": "metrics-title", "component": "Text", "text": "Monitoring Metrics", "variant": "h2"},
        {"id": "cpu", "component": "Text", "text": {"path": "/cpu"}},
        {"id": "memory", "component": "Text", "text": {"path": "/memory"}},
        {"id": "rpm", "component": "Text", "text": {"path": "/rpm"}},
        {"id": "error-rate", "component": "Text", "text": {"path": "/errorRate"}},
        {"id": "http-5xx", "component": "Text", "text": {"path": "/http5xx"}},
        {
            "id": "causes-card",
            "component": "Card",
            "child": "causes-column",
        },
        {
            "id": "causes-column",
            "component": "Column",
            "children": ["causes-title", "cause1", "cause2", "cause3"],
        },
        {"id": "causes-title", "component": "Text", "text": "Likely Causes", "variant": "h2"},
        {"id": "cause1", "component": "Text", "text": {"path": "/cause1"}},
        {"id": "cause2", "component": "Text", "text": {"path": "/cause2"}},
        {"id": "cause3", "component": "Text", "text": {"path": "/cause3"}},
        {
            "id": "recommendations-card",
            "component": "Card",
            "child": "recommendations-column",
        },
        {
            "id": "recommendations-column",
            "component": "Column",
            "children": ["recommendations-title", "rec1", "rec2", "rec3"],
        },
        {"id": "recommendations-title", "component": "Text", "text": "Recommendations", "variant": "h2"},
        {"id": "rec1", "component": "Text", "text": {"path": "/recommendation1"}},
        {"id": "rec2", "component": "Text", "text": {"path": "/recommendation2"}},
        {"id": "rec3", "component": "Text", "text": {"path": "/recommendation3"}},
        {
            "id": "approval-card",
            "component": "Card",
            "child": "approval-column",
        },
        {
            "id": "approval-column",
            "component": "Column",
            "children": ["approval-title", "approval-message", "proposed-action"],
        },
        {"id": "approval-title", "component": "Text", "text": "Human in the Loop", "variant": "h2"},
        {"id": "approval-message", "component": "Text", "text": {"path": "/approvalMessage"}},
        {"id": "proposed-action", "component": "Text", "text": {"path": "/proposedAction"}},
    ]

    if requires_approval:
        components.extend(
            [
                {
                    "id": "approval-button-text",
                    "component": "Text",
                    "text": "対応を承認して実行",
                },
                {
                    "id": "approval-button",
                    "component": "Button",
                    "child": "approval-button-text",
                    "variant": "primary",
                    "action": {
                        "event": {
                            "name": "approve_remediation",
                            "context": {
                                "host": {"path": "/hostRaw"},
                                "action": {"path": "/proposedAction"},
                            },
                        }
                    },
                },
            ]
        )
        for c in components:
            if c.get("id") == "approval-column":
                c["children"].append("approval-button")
                break

    return components


def build_surface_envelope(
    metrics: dict[str, Any],
    result: AnalysisResult,
) -> dict[str, Any]:
    data = build_data(metrics, result)
    operations = [
        create_surface(SURFACE_ID, CATALOG_ID),
        update_components(
            SURFACE_ID,
            build_components(result.analysis.requires_approval),
        ),
        update_data_model(SURFACE_ID, data),
    ]
    return {A2UI_OPERATIONS_KEY: operations}


def build_remediation_update(
    *,
    host: str,
    action: str,
    metrics_after: dict[str, Any],
) -> dict[str, Any]:
    data = {
        "hostRaw": host,
        "host": f"Host: {host}",
        "severity": "Severity: OK",
        "summary": "承認済みのデモ復旧操作を実行し、メトリクスが正常範囲へ戻りました。",
        "provider": "LLM: remediation workflow",
        "warning": "",
        "cpu": f"CPU: {metrics_after['cpu']}%",
        "memory": f"Memory: {metrics_after['memory']}%",
        "rpm": f"Requests/min: {metrics_after['requests_per_minute']}",
        "errorRate": f"Error rate: {metrics_after['error_rate']}%",
        "http5xx": f"HTTP 5xx: {metrics_after['http_5xx']}",
        "cause1": "復旧操作後のメトリクス改善を確認",
        "cause2": "",
        "cause3": "",
        "recommendation1": "しばらく時系列監視を継続する",
        "recommendation2": "根本原因分析のため障害時間帯のログを保存する",
        "recommendation3": "",
        "approvalMessage": "承認済み操作を実行しました。",
        "proposedAction": action,
    }
    return {
        A2UI_OPERATIONS_KEY: [
            update_data_model(SURFACE_ID, data),
        ]
    }
