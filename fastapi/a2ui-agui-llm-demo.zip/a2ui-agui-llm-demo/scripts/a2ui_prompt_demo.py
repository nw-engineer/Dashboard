"""a2ui-agent-sdk による LLM 用 System Prompt 生成例。

メインのデモは再現性を優先して「LLM -> IncidentAnalysis -> A2UI Builder」の
安全な構成にしています。このスクリプトでは、公式SDKを使って
LLMへA2UI Schema / Catalogを直接渡す方法を確認できます。
"""

from a2ui.basic_catalog.provider import BasicCatalog
from a2ui.schema.constants import VERSION_0_9
from a2ui.strategies.schema import A2uiSchemaManager


manager = A2uiSchemaManager(
    version=VERSION_0_9,
    catalogs=[BasicCatalog.get_config(version=VERSION_0_9)],
)

prompt = manager.generate_system_prompt(
    role_description=(
        "You are an SRE assistant. Your final output is an A2UI JSON response."
    ),
    ui_description=(
        "Use Text, Card, Column and Button to create an incident analysis dashboard. "
        "For critical operations, show a server action button requiring approval."
    ),
    include_schema=True,
    include_examples=True,
    validate_examples=True,
)

print(prompt)
