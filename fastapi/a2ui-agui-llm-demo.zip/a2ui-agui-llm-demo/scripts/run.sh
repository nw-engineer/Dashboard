#!/bin/sh
set -eu
python -m uvicorn app.main:app --host 0.0.0.0 --port 8002 --reload
