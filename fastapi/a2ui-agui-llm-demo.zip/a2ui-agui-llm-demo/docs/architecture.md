# Architecture

```text
┌────────────────────────────────────────────┐
│ Browser                                    │
│  - AG-UI Event Viewer                      │
│  - Diagnostic A2UI Renderer                │
└──────────────────┬─────────────────────────┘
                   │ POST /agent
                   │ AG-UI SSE
                   ▼
┌────────────────────────────────────────────┐
│ FastAPI                                    │
│                                            │
│ AG-UI                                      │
│ - RUN / STEP                              │
│ - TOOL_CALL                               │
│ - STATE                                   │
│ - TEXT                                    │
│ - CUSTOM(A2UI)                            │
│                                            │
│ Tool: get_server_metrics                  │
│                  ↓                         │
│ LLM: Mock / OpenAI Responses API           │
│                  ↓                         │
│ IncidentAnalysis (Pydantic)                │
│                  ↓                         │
│ A2UI Builder                               │
└──────────────────┬─────────────────────────┘
                   │ A2UI operations
                   ▼
┌────────────────────────────────────────────┐
│ A2UI Surface                               │
│ Card / Text / Column / Button              │
│ Data Binding                               │
│ Action                                     │
└──────────────────┬─────────────────────────┘
                   │ approve_remediation
                   ▼
┌────────────────────────────────────────────┐
│ Human-in-the-Loop                          │
│ Tool: apply_remediation                    │
│ AG-UI State Update + A2UI Data Update      │
└────────────────────────────────────────────┘
```

## なぜ LLM に A2UI JSON を直接作らせないのか

メインデモは再現性を優先し、

```text
LLM
 ↓
IncidentAnalysis (strict schema)
 ↓
Trusted A2UI Builder
```

としている。

この形は、

- LLM出力の制約
- UI Component の Allowlist
- Tool実行境界
- Human Approval

を説明しやすい。

`a2ui-agent-sdk` で LLM に A2UI Schema / Catalog を直接与える例は
`scripts/a2ui_prompt_demo.py` に分離している。
