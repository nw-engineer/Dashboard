# デモシナリオ

## 目的

調査資料で説明している以下を、1つの画面で実演する。

```text
User
 ↓
AG-UI
 ↓
Tool Call
 ↓
LLM Analysis
 ↓
AG-UI Text / State
 ↓
A2UI Dashboard
 ↓
User Approval Action
 ↓
Tool Execution
 ↓
A2UI Update
```

## デモ 1: 正常

Scenario: `normal`

入力例:

```text
web-01 の状態を分析してください
```

確認ポイント:

- RUN_STARTED / STEP_STARTED
- TOOL_CALL_* で監視データ取得
- STATE_SNAPSHOT / STATE_DELTA
- LLM分析
- A2UI Dashboard
- Human Approval Button は表示されない

## デモ 2: Critical + LLM

Scenario: `critical`

入力例:

```text
web-01 の状態を分析して、必要なら対応案を表示してください
```

確認ポイント:

1. AG-UI `TOOL_CALL_START / ARGS / END / RESULT`
2. 監視メトリクスが State に入る
3. OpenAI または Mock LLM が IncidentAnalysis を生成
4. AG-UI `TEXT_MESSAGE_*` で要約を表示
5. `CUSTOM` Event に A2UI operations を格納
6. A2UI で Incident Dashboard を表示
7. Critical のため「対応を承認して実行」Button を表示

## デモ 3: Human Approval

Critical Dashboard の Button をクリックする。

A2UI v0.9 Action:

```json
{
  "version": "v0.9",
  "action": {
    "name": "approve_remediation",
    "surfaceId": "incident-dashboard",
    "sourceComponentId": "approval-button",
    "timestamp": "...",
    "context": {
      "host": "web-01",
      "action": "..."
    }
  }
}
```

Backend は AG-UI で `apply_remediation` Tool Call を通知し、
完了後に `STATE_DELTA` と A2UI `updateDataModel` を返す。

## プレゼン時に伝えるポイント

- **AG-UI** は「実行中に何が起きているか」を Event として表現する。
- **A2UI** は「その結果をどのUIとして見せるか」を宣言的に表現する。
- **LLM** は分析・判断を担うが、UI描画やTool実行を直接自由に行わせない。
- Critical な変更は Human Approval を挟む。
