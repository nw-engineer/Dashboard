# A2UI / AG-UI + LLM Demo

調査資料の内容に合わせて、以下を1つのPoCとして確認するためのデモです。

```text
User
 ↓
AG-UI
 ↓
Monitoring Tool
 ↓
LLM Analysis
 ↓
AG-UI Text / State
 ↓
A2UI Incident Dashboard
 ↓
Human Approval
 ↓
Remediation Tool
 ↓
A2UI Update
```

## このデモで確認できること

### AG-UI

- RUN_STARTED / RUN_FINISHED
- STEP_STARTED / STEP_FINISHED
- TEXT_MESSAGE streaming
- TOOL_CALL_START / ARGS / END / RESULT
- STATE_SNAPSHOT / STATE_DELTA
- CUSTOM Event

### A2UI

- createSurface
- updateComponents
- updateDataModel
- Data Binding
- Card / Text / Column / Button
- Action
- Human Approval のUI表現

### LLM

- `LLM_PROVIDER=mock`
  - APIキー不要
  - デモの動作確認用
- `LLM_PROVIDER=openai`
  - OpenAI Responses API を利用
  - Structured Outputs で `IncidentAnalysis` を生成
  - API失敗時は設定により Mock へフォールバック

## 1. セットアップ

```bash
python -m venv .venv
source .venv/bin/activate

pip install -r requirements.txt

cp .env.example .env
```

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1

pip install -r requirements.txt
Copy-Item .env.example .env
```

## 2. まず Mock で起動

`.env`:

```env
LLM_PROVIDER=mock
```

起動:

```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8002 --reload
```

ブラウザ:

```text
http://127.0.0.1:8002/demo
```

別PCからアクセスする場合:

```text
http://<サーバIP>:8002/demo
```

Health Check:

```text
http://127.0.0.1:8002/health
```

## 3. OpenAI LLM を利用する

`.env`:

```env
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-5.6
ALLOW_MOCK_FALLBACK=true
```

再起動:

```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8002 --reload
```

画面下に、

```text
Backend LLM_PROVIDER=openai / OPENAI_MODEL=gpt-5.6
```

と表示されれば設定が読まれています。

APIキーはブラウザへ渡さず、FastAPI側のみで利用します。

## 4. おすすめのデモ手順

### ① Normal

`正常シナリオ` をクリック。

見る場所:

- Raw Event Stream
- Tool Call
- State
- A2UI Dashboard

### ② Critical + LLM

`重大＋承認` をクリック。

LLM分析後、A2UI Dashboard に、

- Severity
- CPU / Memory / Error
- Likely Causes
- Recommendations
- Human in the Loop

が表示されます。

### ③ Approval

`対応を承認して実行` をクリック。

A2UI Action が Backend へ戻り、

```text
TOOL_CALL_START
TOOL_CALL_ARGS
TOOL_CALL_END
TOOL_CALL_RESULT
STATE_DELTA
CUSTOM(A2UI update)
```

が流れ、Dashboard が正常状態へ更新されます。

## 5. A2UI Agent SDK の Prompt 生成も確認する

メインデモは安定性を優先し、
`LLM -> Pydantic domain model -> trusted A2UI builder`
という構成です。

A2UI Agent SDK が提供する Schema / Catalog Prompt 生成は別途:

```bash
python scripts/a2ui_prompt_demo.py
```

で確認できます。

このスクリプトでは `A2uiSchemaManager` と `BasicCatalog` を使い、
LLMにA2UIを直接生成させる場合のSystem Promptを生成します。

## 6. 実システムへ発展させる場合

デモTool:

```text
get_server_metrics()
```

を実際の、

- Zabbix API
- OpenSearch
- CloudWatch
- Datadog
- Prometheus

等へ置換可能です。

`apply_remediation()` は本番では直接変更を行わせず、

- Approval
- RBAC
- Audit Log
- Dry Run
- Change Management
- Rollback

等を組み込むことを推奨します。

## 7. PoC上の割り切り

このブラウザは A2UI の仕組みを見せるための
**Diagnostic Renderer** です。

本番では公式 Renderer / Framework Integration を利用してください。

また Human-in-the-Loop は、
A2UI Button Action → AG-UI Tool/State Event という流れでデモしています。
Agent Framework 固有の resumable interrupt / checkpoint を利用する場合は、
LangGraph / ADK 等の Integration へ置き換える想定です。

## Files

```text
a2ui-agui-llm-demo/
├── app/
│   ├── main.py
│   ├── llm.py
│   ├── models.py
│   ├── tools.py
│   └── a2ui_builder.py
├── static/
│   └── index.html
├── scripts/
│   ├── run.sh
│   ├── run.ps1
│   └── a2ui_prompt_demo.py
├── docs/
│   ├── architecture.md
│   └── demo-scenario.md
├── .env.example
├── requirements.txt
└── README.md
```
