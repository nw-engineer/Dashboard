FROM node:22-slim AS build
ENV NODE_EXTRA_CA_CERTS=/usr/local/share/ca-certificates/zscaler-ca.crt \
    npm_config_cafile=/etc/ssl/certs/ca-certificates.crt
WORKDIR /app
COPY certs/zscaler-ca.crt /usr/local/share/ca-certificates/zscaler-ca.crt
RUN test -s /usr/local/share/ca-certificates/zscaler-ca.crt \
    && cat /usr/local/share/ca-certificates/zscaler-ca.crt >> /etc/ssl/certs/ca-certificates.crt
COPY console/package*.json ./
RUN npm install
COPY console ./
RUN npm run build

FROM nginx:1.27-alpine
COPY docker/console-ui-nginx.conf /etc/nginx/conf.d/default.conf
COPY --from=build /app/dist /usr/share/nginx/html
EXPOSE 80
