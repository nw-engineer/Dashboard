FROM python:3.11-slim
ENV SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt \
    REQUESTS_CA_BUNDLE=/etc/ssl/certs/ca-certificates.crt
WORKDIR /app
COPY certs/zscaler-ca.crt /usr/local/share/ca-certificates/zscaler-ca.crt
COPY docker/python-ca-install.sh /usr/local/bin/python-ca-install.sh
RUN chmod 0755 /usr/local/bin/python-ca-install.sh && /usr/local/bin/python-ca-install.sh
COPY pyproject.toml ./
COPY shared ./shared
COPY services ./services
COPY load_generator ./load_generator
RUN pip install --no-cache-dir .
