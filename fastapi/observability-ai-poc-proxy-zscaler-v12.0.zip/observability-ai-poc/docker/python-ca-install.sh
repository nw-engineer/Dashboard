#!/bin/sh
set -eu

CA_FILE="/usr/local/share/ca-certificates/zscaler-ca.crt"
if [ ! -s "$CA_FILE" ]; then
  echo "Zscaler CA is missing or empty: $CA_FILE" >&2
  exit 2
fi
update-ca-certificates >/dev/null
