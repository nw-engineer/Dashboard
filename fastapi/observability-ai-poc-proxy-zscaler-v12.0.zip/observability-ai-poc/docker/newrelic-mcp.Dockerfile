FROM python:3.12-slim
ENV SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt \
    REQUESTS_CA_BUNDLE=/etc/ssl/certs/ca-certificates.crt \
    MCP_TRANSPORT=streamable-http \
    MCP_HOST=0.0.0.0 \
    MCP_PORT=8000
WORKDIR /app
COPY certs/zscaler-ca.crt /usr/local/share/ca-certificates/zscaler-ca.crt
COPY docker/python-ca-install.sh /usr/local/bin/python-ca-install.sh
RUN chmod 0755 /usr/local/bin/python-ca-install.sh && /usr/local/bin/python-ca-install.sh
COPY vendor/newrelic-mcp-server/pyproject.toml vendor/newrelic-mcp-server/README.md ./
COPY vendor/newrelic-mcp-server/src ./src
RUN pip install --no-cache-dir .
EXPOSE 8000
CMD ["newrelic-mcp"]
