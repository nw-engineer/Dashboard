"""Presentation helpers for the Phase 5 troubleshooting console."""
