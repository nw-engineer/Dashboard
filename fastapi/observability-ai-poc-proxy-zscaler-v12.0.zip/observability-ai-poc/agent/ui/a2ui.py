from __future__ import annotations

from typing import Any

from agent.ui.models import TroubleshootingViewModel

A2UI_VERSION = "v0.9.1"
TROUBLESHOOTING_CATALOG_ID = "dev.observability:troubleshooting-v1"


def _validate_namespaces(view: TroubleshootingViewModel) -> None:
    evidence_ids = view.all_evidence_ids
    gap_ids = {gap.gap_id for gap in view.evidence_gaps}
    if evidence_ids & gap_ids:
        raise ValueError("evidence and gap identifiers must be disjoint")

    references = set(view.supporting_evidence_ids)
    references.update(view.new_relic_evidence_ids)
    references.update(view.splunk_evidence_ids)
    for hypothesis in view.hypotheses:
        references.update(hypothesis.supporting_evidence_ids)
        references.update(hypothesis.opposing_evidence_ids)
    unknown = references - evidence_ids
    if unknown:
        raise ValueError(f"presentation contains unknown evidence IDs: {sorted(unknown)}")


def _build_components(view: TroubleshootingViewModel) -> list[dict[str, Any]]:
    children = ["trace", "timeline"]
    evidence_components = []
    for index, item in enumerate(view.evidence):
        component_id = f"evidence-{index}"
        children.append(component_id)
        evidence_components.append(
            {
                "id": component_id,
                "component": "EvidenceCard",
                "data": item.model_dump(mode="json"),
            }
        )

    gap_components = []
    for index, gap in enumerate(view.evidence_gaps):
        component_id = f"gap-{index}"
        children.append(component_id)
        gap_components.append(
            {
                "id": component_id,
                "component": "EvidenceGapCard",
                "data": gap.model_dump(mode="json"),
            }
        )

    children.extend(["logs", "hypotheses", "recommendations", "queries"])
    return [
        {
            "id": "root",
            "component": "HealthSummary",
            "data": {
                "incident_summary": view.incident_summary,
                "impact": view.impact,
                "likely_cause": view.likely_cause,
                "confidence": view.confidence,
            },
            "children": children,
        },
        {
            "id": "trace",
            "component": "TraceCard",
            "data": {
                "investigation_id": view.investigation_id,
                "request_id": view.request_id,
                "trace_id": view.trace_id,
                "services": view.services,
                "environment": view.environment,
            },
        },
        {
            "id": "timeline",
            "component": "TimelineChart",
            "data": [item.model_dump(mode="json") for item in view.timeline],
        },
        *evidence_components,
        *gap_components,
        {
            "id": "logs",
            "component": "LogTable",
            "data": [item.model_dump(mode="json") for item in view.log_rows],
        },
        {
            "id": "hypotheses",
            "component": "HypothesisCard",
            "data": [item.model_dump(mode="json") for item in view.hypotheses],
        },
        {
            "id": "recommendations",
            "component": "RecommendationCard",
            "data": {
                "checks": view.recommended_checks,
                "actions": view.recommended_actions,
            },
        },
        {
            "id": "queries",
            "component": "QueryDisclosure",
            "data": [item.model_dump(mode="json") for item in view.queries],
        },
    ]


def build_a2ui_messages(view: TroubleshootingViewModel) -> list[dict[str, Any]]:
    _validate_namespaces(view)
    surface_id = view.investigation_id
    return [
        {
            "version": A2UI_VERSION,
            "createSurface": {
                "surfaceId": surface_id,
                "catalogId": TROUBLESHOOTING_CATALOG_ID,
                "sendDataModel": False,
            },
        },
        {
            "version": A2UI_VERSION,
            "updateComponents": {
                "surfaceId": surface_id,
                "components": _build_components(view),
            },
        },
        {
            "version": A2UI_VERSION,
            "updateDataModel": {
                "surfaceId": surface_id,
                "path": "/",
                "value": view.model_dump(mode="json"),
            },
        },
    ]
