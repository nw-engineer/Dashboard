from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel

from agent.evidence.models import EvidenceCategory, EvidenceSource


class TimelineEntry(BaseModel):
    evidence_id: str
    source: EvidenceSource
    category: EvidenceCategory
    service_name: str | None = None
    observed_at: datetime
    summary: str


class EvidenceView(BaseModel):
    evidence_id: str
    source: EvidenceSource
    category: EvidenceCategory
    summary: str
    service_name: str | None = None
    observed_at: datetime | None = None
    query_or_tool: str
    facts: dict[str, Any]


class EvidenceGapView(BaseModel):
    gap_id: str
    source: EvidenceSource | None = None
    category: EvidenceCategory | None = None
    summary: str


class ContradictionView(BaseModel):
    contradiction_id: str
    summary: str
    left_evidence_ids: list[str]
    right_evidence_ids: list[str]


class HypothesisView(BaseModel):
    summary: str
    supporting_evidence_ids: list[str]
    opposing_evidence_ids: list[str]


class QueryDisclosureView(BaseModel):
    disclosure_id: str
    source: EvidenceSource
    operation: str
    arguments: dict[str, Any]


class TroubleshootingViewModel(BaseModel):
    investigation_id: str
    request_id: str
    trace_id: str
    services: list[str]
    environment: str
    incident_summary: str
    impact: str
    likely_cause: str
    confidence: str
    supporting_evidence_ids: list[str]
    new_relic_evidence_ids: list[str]
    splunk_evidence_ids: list[str]
    timeline: list[TimelineEntry]
    evidence: list[EvidenceView]
    evidence_gaps: list[EvidenceGapView]
    contradictions: list[ContradictionView]
    hypotheses: list[HypothesisView]
    recommended_checks: list[str]
    recommended_actions: list[str]
    queries: list[QueryDisclosureView]
    log_rows: list[EvidenceView]

    @property
    def all_evidence_ids(self) -> set[str]:
        return {item.evidence_id for item in self.evidence}
