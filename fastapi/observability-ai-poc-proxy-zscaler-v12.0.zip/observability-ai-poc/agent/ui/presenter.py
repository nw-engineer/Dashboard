from __future__ import annotations

from agent.evidence.models import EvidenceSource
from agent.orchestrator import InvestigationResult
from agent.ui.models import (
    ContradictionView,
    EvidenceGapView,
    EvidenceView,
    HypothesisView,
    QueryDisclosureView,
    TimelineEntry,
    TroubleshootingViewModel,
)


def _environment(result: InvestigationResult) -> str:
    for item in result.bundle.evidence:
        value = item.facts.get("deployment.environment")
        if isinstance(value, str) and value.strip():
            return value.strip()
    return "unknown"


def _services(result: InvestigationResult) -> list[str]:
    return list(
        dict.fromkeys(
            item.service_name
            for item in result.bundle.evidence
            if item.service_name
        )
    )


def present_investigation(result: InvestigationResult) -> TroubleshootingViewModel:
    evidence = [
        EvidenceView(
            evidence_id=item.evidence_id,
            source=item.source,
            category=item.category,
            summary=item.summary,
            service_name=item.service_name,
            observed_at=item.observed_at,
            query_or_tool=item.query_or_tool,
            facts=item.facts,
        )
        for item in result.bundle.evidence
    ]
    timeline = sorted(
        [
            TimelineEntry(
                evidence_id=item.evidence_id,
                source=item.source,
                category=item.category,
                service_name=item.service_name,
                observed_at=item.observed_at,
                summary=item.summary,
            )
            for item in result.bundle.evidence
            if item.observed_at is not None
        ],
        key=lambda item: item.observed_at,
    )
    return TroubleshootingViewModel(
        investigation_id=result.bundle.investigation_id,
        request_id=result.bundle.request_id,
        trace_id=result.bundle.trace_id,
        services=_services(result),
        environment=_environment(result),
        incident_summary=result.analysis.incident_summary,
        impact=result.analysis.impact,
        likely_cause=result.analysis.likely_cause,
        confidence=result.analysis.confidence.value,
        supporting_evidence_ids=list(result.analysis.supporting_evidence_ids),
        new_relic_evidence_ids=list(result.analysis.new_relic_evidence_ids),
        splunk_evidence_ids=list(result.analysis.splunk_evidence_ids),
        timeline=timeline,
        evidence=evidence,
        evidence_gaps=[
            EvidenceGapView(
                gap_id=gap.gap_id,
                source=gap.source,
                category=gap.category,
                summary=gap.summary,
            )
            for gap in result.bundle.gaps
        ],
        contradictions=[
            ContradictionView(
                contradiction_id=item.contradiction_id,
                summary=item.summary,
                left_evidence_ids=list(item.left_evidence_ids),
                right_evidence_ids=list(item.right_evidence_ids),
            )
            for item in result.bundle.contradictions
        ],
        hypotheses=[
            HypothesisView(
                summary=item.summary,
                supporting_evidence_ids=list(item.supporting_evidence_ids),
                opposing_evidence_ids=list(item.opposing_evidence_ids),
            )
            for item in result.analysis.alternative_hypotheses
        ],
        recommended_checks=list(result.analysis.recommended_checks),
        recommended_actions=list(result.analysis.recommended_actions),
        queries=[
            QueryDisclosureView(
                disclosure_id=item.disclosure_id,
                source=item.source,
                operation=item.operation,
                arguments=item.arguments,
            )
            for item in result.bundle.queries_used
        ],
        log_rows=[item for item in evidence if item.source is EvidenceSource.SPLUNK],
    )
