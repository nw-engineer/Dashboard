from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from pydantic import BaseModel

from agent.analysis.analyzer import IncidentAnalyzer, validate_analysis_references
from agent.analysis.models import IncidentAnalysis
from agent.evidence.correlation import CorrelationResolver
from agent.evidence.correlator import EvidenceCorrelator
from agent.evidence.models import (
    EvidenceBundle,
    EvidenceGap,
    EvidenceSource,
    QueryDisclosure,
)
from agent.evidence.newrelic_collector import (
    NewRelicEvidenceCollector,
    NewRelicEvidenceResult,
    NewRelicEvidenceUnavailable,
)
from agent.evidence.splunk_collector import (
    SplunkEvidenceCollector,
    SplunkEvidenceResult,
    SplunkEvidenceUnavailable,
)
from agent.progress import InvestigationProgressReporter, NullInvestigationProgressReporter


class InvestigationResult(BaseModel):
    bundle: EvidenceBundle
    analysis: IncidentAnalysis


class InvestigationOrchestrator:
    def __init__(
        self,
        *,
        resolver: CorrelationResolver,
        splunk_collector: SplunkEvidenceCollector,
        newrelic_collector: NewRelicEvidenceCollector,
        correlator: EvidenceCorrelator,
        analyzer: IncidentAnalyzer,
        progress: InvestigationProgressReporter | None = None,
    ) -> None:
        self.resolver = resolver
        self.splunk_collector = splunk_collector
        self.newrelic_collector = newrelic_collector
        self.correlator = correlator
        self.analyzer = analyzer
        self.progress = progress or NullInvestigationProgressReporter()

    async def investigate_request_id(
        self,
        request_id: str,
        earliest: datetime,
        latest: datetime,
    ) -> InvestigationResult:
        await self.progress.step_started("correlation")
        context = await self.resolver.resolve_request(request_id, earliest, latest)
        await self.progress.step_finished("correlation")

        await self.progress.step_started("splunk")
        try:
            splunk = await self.splunk_collector.collect(context, earliest, latest)
        except SplunkEvidenceUnavailable:
            splunk = SplunkEvidenceResult(
                evidence=[],
                query=QueryDisclosure(
                    disclosure_id="query-splunk-unavailable-001",
                    source=EvidenceSource.SPLUNK,
                    operation="search",
                    arguments={
                        "query": f'trace.id="{context.trace_id}"',
                        "earliest": earliest.isoformat(),
                        "latest": latest.isoformat(),
                        "max_results": 200,
                    },
                ),
                gaps=[
                    EvidenceGap(
                        gap_id="gap-splunk-unavailable",
                        summary="Splunk evidence was unavailable after correlation was established",
                        source=EvidenceSource.SPLUNK,
                    )
                ],
            )
        await self.progress.step_finished("splunk")

        await self.progress.step_started("newrelic")
        try:
            newrelic = await self.newrelic_collector.collect(context, earliest, latest)
        except NewRelicEvidenceUnavailable:
            newrelic = NewRelicEvidenceResult(
                evidence=[],
                gaps=[
                    EvidenceGap(
                        gap_id="gap-newrelic-unavailable",
                        summary="New Relic evidence was unavailable for this investigation",
                        source=EvidenceSource.NEW_RELIC,
                    )
                ],
                queries=[],
            )
        await self.progress.step_finished("newrelic")

        await self.progress.step_started("correlate")
        bundle = self.correlator.build_bundle(
            investigation_id=f"inv-{uuid4()}",
            context=context,
            splunk=splunk,
            newrelic=newrelic,
        )
        await self.progress.step_finished("correlate")

        await self.progress.step_started("analyze")
        analysis = await self.analyzer.analyze(bundle)
        validate_analysis_references(bundle, analysis)
        await self.progress.step_finished("analyze")
        return InvestigationResult(bundle=bundle, analysis=analysis)
