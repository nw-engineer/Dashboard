from __future__ import annotations

from typing import Protocol


class InvestigationProgressReporter(Protocol):
    async def step_started(self, step_name: str) -> None: ...

    async def step_finished(self, step_name: str) -> None: ...


class NullInvestigationProgressReporter:
    async def step_started(self, step_name: str) -> None:
        return None

    async def step_finished(self, step_name: str) -> None:
        return None
