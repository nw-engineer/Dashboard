from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field, model_validator


class SplunkSearchRequest(BaseModel):
    query: str = Field(min_length=1)
    earliest: datetime
    latest: datetime
    max_results: int = Field(default=100, ge=1)

    @model_validator(mode="after")
    def validate_time_order(self):
        if self.latest <= self.earliest:
            raise ValueError("latest must be after earliest")
        return self
