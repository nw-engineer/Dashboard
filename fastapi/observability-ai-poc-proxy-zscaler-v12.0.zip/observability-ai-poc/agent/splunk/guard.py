from __future__ import annotations

import re
from datetime import timedelta

from agent.splunk.models import SplunkSearchRequest

_FIXED_INDEX = "poc_observability"
_FORBIDDEN_COMMANDS = re.compile(
    r"\|\s*("
    r"delete|collect|outputlookup|sendalert|sendemail|outputcsv|tscollect|"
    r"rest|script|runshellscript|savedsearch|loadjob|map"
    r")\b",
    re.IGNORECASE,
)
_INDEX_PATTERN = re.compile(r"\bindex\s*=\s*([^\s|]+)", re.IGNORECASE)


class SplunkQueryRejected(ValueError):
    pass


def normalize_search_request(request: SplunkSearchRequest) -> SplunkSearchRequest:
    if request.latest - request.earliest > timedelta(hours=2):
        raise SplunkQueryRejected("search range cannot exceed 2 hours")
    if request.max_results > 200:
        raise SplunkQueryRejected("max_results cannot exceed 200")

    query = request.query.strip()
    if "`" in query:
        raise SplunkQueryRejected("SPL macro expansion is forbidden")
    if _FORBIDDEN_COMMANDS.search(query):
        raise SplunkQueryRejected("mutating or alerting SPL commands are forbidden")

    indexes = [match.group(1).strip('"\'') for match in _INDEX_PATTERN.finditer(query)]
    if any(index.lower() != _FIXED_INDEX for index in indexes):
        raise SplunkQueryRejected(f"only index={_FIXED_INDEX} is allowed")

    if query.lower().startswith("search"):
        remainder = query[6:].lstrip()
        if not indexes:
            query = f"search index={_FIXED_INDEX} {remainder}".rstrip()
    else:
        if indexes:
            query = f"search {query}"
        else:
            query = f"search index={_FIXED_INDEX} {query}"

    return request.model_copy(update={"query": query})
