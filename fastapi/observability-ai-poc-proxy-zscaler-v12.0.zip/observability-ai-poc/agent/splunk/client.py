from __future__ import annotations

import asyncio
import json
import time
from typing import Any

import httpx

from agent.splunk.guard import normalize_search_request
from agent.splunk.models import SplunkSearchRequest


class SplunkSearchTimeout(TimeoutError):
    pass


class SplunkSearchFailed(RuntimeError):
    pass


class SplunkSearchClient:
    def __init__(
        self,
        *,
        base_url: str,
        username: str,
        password: str,
        transport: httpx.AsyncBaseTransport | None = None,
        poll_interval: float = 0.25,
        timeout_seconds: float = 15.0,
        verify_ssl: bool = True,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.password = password
        self.transport = transport
        self.poll_interval = poll_interval
        self.timeout_seconds = timeout_seconds
        self.verify_ssl = verify_ssl

    async def search(self, request: SplunkSearchRequest) -> list[dict[str, Any]]:
        normalized = normalize_search_request(request)
        auth = httpx.BasicAuth(self.username, self.password)
        async with httpx.AsyncClient(
            auth=auth,
            timeout=5.0,
            transport=self.transport,
            verify=self.verify_ssl,
        ) as client:
            create = await client.post(
                f"{self.base_url}/services/search/jobs",
                data={
                    "search": normalized.query,
                    "earliest_time": normalized.earliest.isoformat(),
                    "latest_time": normalized.latest.isoformat(),
                    "output_mode": "json",
                },
            )
            create.raise_for_status()
            sid = create.json().get("sid")
            if not sid:
                raise RuntimeError("Splunk search job did not return sid")

            deadline = time.monotonic() + self.timeout_seconds
            while True:
                status = await client.get(
                    f"{self.base_url}/services/search/jobs/{sid}",
                    params={"output_mode": "json"},
                )
                status.raise_for_status()
                entries = status.json().get("entry", [])
                content = entries[0].get("content", {}) if entries else {}
                dispatch_state = str(content.get("dispatchState", "")).upper()
                if dispatch_state == "FAILED":
                    messages = content.get("messages", [])
                    detail = "; ".join(
                        str(message.get("text", ""))
                        for message in messages
                        if isinstance(message, dict) and message.get("text")
                    )
                    raise SplunkSearchFailed(detail or f"Splunk search job {sid} failed")

                raw_is_done = content.get("isDone")
                is_done = raw_is_done is True or raw_is_done == 1 or raw_is_done == "1"
                if is_done:
                    break
                if time.monotonic() >= deadline:
                    raise SplunkSearchTimeout(f"Splunk search job {sid} timed out")
                await asyncio.sleep(self.poll_interval)

            results = await client.get(
                f"{self.base_url}/services/search/jobs/{sid}/results",
                params={"output_mode": "json", "count": normalized.max_results},
            )
            results.raise_for_status()
            rows = list(results.json().get("results", []))
            return [self._expand_raw_json_fields(row) for row in rows]

    @staticmethod
    def _expand_raw_json_fields(row: dict[str, Any]) -> dict[str, Any]:
        raw = row.get("_raw")
        if not isinstance(raw, str):
            return row
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return row
        if not isinstance(parsed, dict):
            return row
        return {**parsed, **row}
