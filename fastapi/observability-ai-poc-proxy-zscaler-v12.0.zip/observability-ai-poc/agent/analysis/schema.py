from __future__ import annotations

import copy

from agent.analysis.models import IncidentAnalysis
from agent.evidence.models import EvidenceBundle, EvidenceSource


def build_incident_analysis_schema() -> dict:
    schema = copy.deepcopy(IncidentAnalysis.model_json_schema())
    _make_object_properties_required(schema)
    _require_hypothesis_evidence_reference(schema)
    return schema



_AZURE_UNSUPPORTED_STRUCTURED_OUTPUT_KEYWORDS = {
    "minLength",
    "maxLength",
    "pattern",
    "format",
    "minimum",
    "maximum",
    "multipleOf",
    "patternProperties",
    "unevaluatedProperties",
    "propertyNames",
    "minProperties",
    "maxProperties",
    "unevaluatedItems",
    "contains",
    "minContains",
    "maxContains",
    "minItems",
    "maxItems",
    "uniqueItems",
}


def build_azure_incident_analysis_schema(bundle: EvidenceBundle | None = None) -> dict:
    schema = copy.deepcopy(IncidentAnalysis.model_json_schema())
    _make_object_properties_required(schema)
    _remove_keywords(schema, _AZURE_UNSUPPORTED_STRUCTURED_OUTPUT_KEYWORDS)
    if bundle is not None:
        _constrain_reference_ids(schema, bundle)
    return schema

def build_ollama_incident_analysis_schema() -> dict:
    schema = copy.deepcopy(IncidentAnalysis.model_json_schema())
    _make_object_properties_required(schema)
    return schema



def _constrain_reference_ids(schema: dict, bundle: EvidenceBundle) -> None:
    properties = schema.get("properties", {})
    hypothesis_properties = (
        schema.get("$defs", {}).get("Hypothesis", {}).get("properties", {})
    )

    all_evidence_ids = [item.evidence_id for item in bundle.evidence]
    new_relic_evidence_ids = [
        item.evidence_id
        for item in bundle.evidence
        if item.source is EvidenceSource.NEW_RELIC
    ]
    splunk_evidence_ids = [
        item.evidence_id
        for item in bundle.evidence
        if item.source is EvidenceSource.SPLUNK
    ]
    query_ids = [item.disclosure_id for item in bundle.queries_used]
    contradiction_ids = [item.contradiction_id for item in bundle.contradictions]

    _set_array_item_enum(properties.get("supporting_evidence_ids"), all_evidence_ids)
    _set_array_item_enum(
        hypothesis_properties.get("supporting_evidence_ids"), all_evidence_ids
    )
    _set_array_item_enum(
        hypothesis_properties.get("opposing_evidence_ids"), all_evidence_ids
    )
    _set_array_item_enum(
        properties.get("new_relic_evidence_ids"), new_relic_evidence_ids
    )
    _set_array_item_enum(
        properties.get("splunk_evidence_ids"), splunk_evidence_ids
    )
    _set_array_item_enum(properties.get("query_disclosure_ids"), query_ids)
    _set_array_item_enum(properties.get("contradiction_ids"), contradiction_ids)


def _set_array_item_enum(property_schema, allowed_values: list[str]) -> None:
    if not allowed_values or not isinstance(property_schema, dict):
        return
    items = property_schema.get("items")
    if isinstance(items, dict):
        items["enum"] = allowed_values

def _make_object_properties_required(node) -> None:
    if isinstance(node, dict):
        properties = node.get("properties")
        if node.get("type") == "object" and isinstance(properties, dict):
            node["additionalProperties"] = False
            node["required"] = list(properties)
        for value in node.values():
            _make_object_properties_required(value)
    elif isinstance(node, list):
        for item in node:
            _make_object_properties_required(item)


def _require_hypothesis_evidence_reference(schema: dict) -> None:
    hypothesis = schema.get("$defs", {}).get("Hypothesis")
    if not isinstance(hypothesis, dict):
        return
    hypothesis["anyOf"] = [
        {"properties": {"supporting_evidence_ids": {"minItems": 1}}},
        {"properties": {"opposing_evidence_ids": {"minItems": 1}}},
    ]


def _remove_keywords(node, keywords: set[str]) -> None:
    if isinstance(node, dict):
        for key in list(node):
            if key in keywords:
                del node[key]
                continue
            _remove_keywords(node[key], keywords)
    elif isinstance(node, list):
        for item in node:
            _remove_keywords(item, keywords)
