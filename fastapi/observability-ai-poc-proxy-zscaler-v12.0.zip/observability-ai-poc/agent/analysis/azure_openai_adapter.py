from __future__ import annotations

import json
import os

import httpx
from pydantic import ValidationError

from agent.analysis.analyzer import InvalidAnalysisReference, validate_analysis_references
from agent.analysis.models import IncidentAnalysis
from agent.analysis.prompt import ANALYSIS_CONTRACT
from agent.analysis.schema import build_azure_incident_analysis_schema
from agent.evidence.models import EvidenceBundle


class AzureOpenAIConfigurationError(RuntimeError):
    pass


class AzureOpenAIAnalysisError(RuntimeError):
    pass


class AzureOpenAIIncidentAnalyzer:
    def __init__(
        self,
        *,
        api_key: str,
        model: str,
        base_url: str,
        client: httpx.AsyncClient | None = None,
        timeout_seconds: float = 60.0,
        max_output_tokens: int = 2500,
    ) -> None:
        self.api_key = api_key
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.client = client
        self.timeout_seconds = timeout_seconds
        self.max_output_tokens = max_output_tokens

    @classmethod
    def from_env(cls) -> "AzureOpenAIIncidentAnalyzer":
        api_key = os.getenv("AZURE_OPENAI_API_KEY")
        if not api_key:
            raise AzureOpenAIConfigurationError("AZURE_OPENAI_API_KEY is required")
        base_url = os.getenv("AZURE_OPENAI_BASE_URL")
        if not base_url:
            raise AzureOpenAIConfigurationError("AZURE_OPENAI_BASE_URL is required")
        model = os.getenv("AZURE_OPENAI_MODEL")
        if not model:
            raise AzureOpenAIConfigurationError("AZURE_OPENAI_MODEL is required")
        raw_max_output_tokens = os.getenv("AZURE_OPENAI_MAX_OUTPUT_TOKENS", "2500")
        try:
            max_output_tokens = int(raw_max_output_tokens)
        except ValueError:
            raise AzureOpenAIConfigurationError(
                "AZURE_OPENAI_MAX_OUTPUT_TOKENS must be a positive integer"
            ) from None
        if max_output_tokens <= 0:
            raise AzureOpenAIConfigurationError(
                "AZURE_OPENAI_MAX_OUTPUT_TOKENS must be a positive integer"
            )
        raw_timeout = os.getenv("AZURE_OPENAI_TIMEOUT_SECONDS", "60")
        try:
            timeout_seconds = float(raw_timeout)
        except ValueError:
            raise AzureOpenAIConfigurationError(
                "AZURE_OPENAI_TIMEOUT_SECONDS must be a positive number"
            ) from None
        if timeout_seconds <= 0:
            raise AzureOpenAIConfigurationError(
                "AZURE_OPENAI_TIMEOUT_SECONDS must be a positive number"
            )
        return cls(
            api_key=api_key,
            model=model,
            base_url=base_url,
            max_output_tokens=max_output_tokens,
            timeout_seconds=timeout_seconds,
        )

    async def analyze(self, bundle: EvidenceBundle) -> IncidentAnalysis:
        schema = build_azure_incident_analysis_schema(bundle)
        analysis = await self._request_analysis(
            input_text=bundle.model_dump_json(),
            schema=schema,
        )
        try:
            validate_analysis_references(bundle, analysis)
            return analysis
        except InvalidAnalysisReference as first_error:
            repair_input = _build_reference_repair_input(
                bundle=bundle,
                analysis=analysis,
                error=first_error,
            )

        repaired_analysis = await self._request_analysis(
            input_text=repair_input,
            schema=schema,
        )
        try:
            validate_analysis_references(bundle, repaired_analysis)
        except InvalidAnalysisReference as exc:
            raise AzureOpenAIAnalysisError(
                "Azure OpenAI failed reference validation after repair attempt"
            ) from exc
        return repaired_analysis

    async def _request_analysis(
        self,
        *,
        input_text: str,
        schema: dict,
    ) -> IncidentAnalysis:
        payload = {
            "model": self.model,
            "store": False,
            "max_output_tokens": self.max_output_tokens,
            "instructions": ANALYSIS_CONTRACT,
            "input": input_text,
            "text": {
                "format": {
                    "type": "json_schema",
                    "name": "incident_analysis",
                    "schema": schema,
                    "strict": True,
                }
            },
        }
        headers = {
            "api-key": self.api_key,
            "Content-Type": "application/json",
        }
        try:
            if self.client is not None:
                response = await self.client.post(
                    f"{self.base_url}/responses", headers=headers, json=payload
                )
            else:
                async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
                    response = await client.post(
                        f"{self.base_url}/responses", headers=headers, json=payload
                    )
        except httpx.RequestError:
            raise AzureOpenAIAnalysisError(
                "Azure OpenAI Responses API request failed"
            ) from None
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise AzureOpenAIAnalysisError(
                f"Azure OpenAI Responses API returned HTTP {exc.response.status_code}"
            ) from None
        try:
            body = response.json()
        except (json.JSONDecodeError, ValueError):
            raise AzureOpenAIAnalysisError(
                "Azure OpenAI returned an invalid JSON response"
            ) from None
        status = body.get("status")
        if status != "completed":
            raise AzureOpenAIAnalysisError(
                f"Azure OpenAI response status was {status or 'unknown'}"
            )
        output_text = _extract_output_text(body)
        try:
            return IncidentAnalysis.model_validate(json.loads(output_text))
        except (json.JSONDecodeError, ValidationError, TypeError) as exc:
            raise AzureOpenAIAnalysisError(
                "Azure OpenAI returned invalid structured output"
            ) from exc


def _build_reference_repair_input(
    *,
    bundle: EvidenceBundle,
    analysis: IncidentAnalysis,
    error: InvalidAnalysisReference,
) -> str:
    allowed_evidence = [
        {"evidence_id": item.evidence_id, "source": item.source.value}
        for item in bundle.evidence
    ]
    allowed_queries = [item.disclosure_id for item in bundle.queries_used]
    allowed_contradictions = [item.contradiction_id for item in bundle.contradictions]
    gap_ids = [item.gap_id for item in bundle.gaps]
    repair_context = {
        "task": "repair_incident_analysis_references",
        "validation_error": str(error),
        "allowed_evidence_ids": allowed_evidence,
        "allowed_query_disclosure_ids": allowed_queries,
        "allowed_contradiction_ids": allowed_contradictions,
        "evidence_gap_ids_not_valid_as_evidence_ids": gap_ids,
        "previous_incident_analysis": analysis.model_dump(mode="json"),
        "evidence_bundle": bundle.model_dump(mode="json"),
    }
    return (
        "Repair the previous IncidentAnalysis because it failed reference validation. "
        "Use only IDs listed in the allowed ID lists. EvidenceGap IDs are not EvidenceItem "
        "IDs and must never appear in any evidence ID field. Do not invent new facts, IDs, "
        "queries, or contradictions. Preserve valid analysis content where possible and return "
        "only a corrected IncidentAnalysis matching the required schema.\n"
        + json.dumps(repair_context, separators=(",", ":"))
    )


def _extract_output_text(body: dict) -> str:
    for item in body.get("output", []):
        if item.get("type") != "message":
            continue
        for content in item.get("content", []):
            if content.get("type") == "refusal":
                raise AzureOpenAIAnalysisError(
                    "Azure OpenAI model refused the analysis request"
                )
            if content.get("type") == "output_text":
                text = content.get("text")
                if isinstance(text, str) and text:
                    return text
    raise AzureOpenAIAnalysisError("Azure OpenAI response did not contain output_text")
