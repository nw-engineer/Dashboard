"""Phase 4 analysis contracts."""
