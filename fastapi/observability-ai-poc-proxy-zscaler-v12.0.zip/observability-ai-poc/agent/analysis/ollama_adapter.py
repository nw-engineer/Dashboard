from __future__ import annotations

import json
import os

import httpx
from pydantic import ValidationError

from agent.analysis.analyzer import InvalidAnalysisReference, validate_analysis_references
from agent.analysis.models import IncidentAnalysis
from agent.analysis.prompt import ANALYSIS_CONTRACT
from agent.analysis.schema import build_ollama_incident_analysis_schema
from agent.evidence.models import EvidenceBundle


class OllamaConfigurationError(RuntimeError):
    pass


class OllamaAnalysisError(RuntimeError):
    pass


class OllamaIncidentAnalyzer:
    def __init__(
        self,
        *,
        base_url: str = "http://localhost:11434",
        model: str = "gpt-oss:20b",
        reasoning_effort: str = "medium",
        client: httpx.AsyncClient | None = None,
        timeout_seconds: float = 180.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.reasoning_effort = reasoning_effort
        self.client = client
        self.timeout_seconds = timeout_seconds

    @classmethod
    def from_env(cls) -> "OllamaIncidentAnalyzer":
        reasoning_effort = os.getenv("OLLAMA_REASONING_EFFORT", "medium").strip().lower()
        if reasoning_effort not in {"low", "medium", "high"}:
            raise OllamaConfigurationError(
                "OLLAMA_REASONING_EFFORT must be one of: low, medium, high"
            )
        raw_timeout = os.getenv("OLLAMA_TIMEOUT_SECONDS", "180")
        try:
            timeout_seconds = float(raw_timeout)
        except ValueError:
            raise OllamaConfigurationError(
                "OLLAMA_TIMEOUT_SECONDS must be a positive number"
            ) from None
        if timeout_seconds <= 0:
            raise OllamaConfigurationError(
                "OLLAMA_TIMEOUT_SECONDS must be a positive number"
            )
        return cls(
            base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
            model=os.getenv("OLLAMA_MODEL", "gpt-oss:20b"),
            reasoning_effort=reasoning_effort,
            timeout_seconds=timeout_seconds,
        )

    async def analyze(self, bundle: EvidenceBundle) -> IncidentAnalysis:
        schema = build_ollama_incident_analysis_schema()
        messages = [
            {
                "role": "system",
                "content": (
                    f"{ANALYSIS_CONTRACT}\n\n"
                    "Return only JSON matching this JSON Schema:\n"
                    f"{json.dumps(schema, separators=(',', ':'))}"
                ),
            },
            {"role": "user", "content": bundle.model_dump_json()},
        ]

        content = await self._request_content(messages=messages, schema=schema)
        try:
            analysis = IncidentAnalysis.model_validate_json(content)
            validate_analysis_references(bundle, analysis)
            return analysis
        except InvalidAnalysisReference as first_error:
            repair_instruction = _build_reference_repair_instruction(
                bundle=bundle,
                analysis=analysis,
                error=first_error,
            )
        except (ValidationError, ValueError, TypeError) as first_error:
            repair_instruction = _build_repair_instruction(first_error)

        repair_messages = [
            *messages,
            {"role": "assistant", "content": content},
            {"role": "user", "content": repair_instruction},
        ]
        repaired_content = await self._request_content(
            messages=repair_messages,
            schema=schema,
        )
        try:
            repaired_analysis = IncidentAnalysis.model_validate_json(repaired_content)
        except (ValidationError, ValueError, TypeError) as exc:
            raise OllamaAnalysisError(
                "Ollama returned invalid structured output after repair attempt"
            ) from exc
        try:
            validate_analysis_references(bundle, repaired_analysis)
        except InvalidAnalysisReference as exc:
            raise OllamaAnalysisError(
                "Ollama failed reference validation after repair attempt"
            ) from exc
        return repaired_analysis

    async def _request_content(self, *, messages: list[dict], schema: dict) -> str:
        payload = {
            "model": self.model,
            "stream": False,
            "think": self.reasoning_effort,
            "messages": messages,
            "format": schema,
            "options": {"temperature": 0},
        }

        try:
            if self.client is not None:
                response = await self.client.post(f"{self.base_url}/api/chat", json=payload)
            else:
                async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
                    response = await client.post(f"{self.base_url}/api/chat", json=payload)
        except httpx.RequestError:
            raise OllamaAnalysisError("Ollama API request failed") from None
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise OllamaAnalysisError(
                f"Ollama API returned HTTP {exc.response.status_code}"
            ) from None
        try:
            body = response.json()
        except (json.JSONDecodeError, ValueError):
            raise OllamaAnalysisError("Ollama returned an invalid JSON response") from None
        if body.get("done") is not True:
            raise OllamaAnalysisError("Ollama response was not completed")
        message = body.get("message")
        content = message.get("content") if isinstance(message, dict) else None
        if not isinstance(content, str) or not content:
            raise OllamaAnalysisError("Ollama response did not contain message content")
        return content


def _build_repair_instruction(error: Exception) -> str:
    if isinstance(error, ValidationError):
        details = []
        for item in error.errors(include_input=False, include_url=False):
            location = ".".join(str(part) for part in item.get("loc", ())) or "root"
            details.append(f"- {location}: {item.get('msg', 'invalid value')}")
        validation_details = "\n".join(details)
    else:
        validation_details = f"- root: {type(error).__name__}"

    return (
        "Repair the previous JSON so it satisfies the required IncidentAnalysis schema.\n"
        "Do not add facts, evidence IDs, query IDs, or contradictions that are not present "
        "in the supplied EvidenceBundle. Preserve valid content where possible. "
        "Return only the repaired JSON.\n"
        "Validation errors:\n"
        f"{validation_details}"
    )

def _build_reference_repair_instruction(
    *,
    bundle: EvidenceBundle,
    analysis: IncidentAnalysis,
    error: InvalidAnalysisReference,
) -> str:
    allowed_evidence = [
        {"evidence_id": item.evidence_id, "source": item.source.value}
        for item in bundle.evidence
    ]
    repair_context = {
        "validation_error": str(error),
        "allowed_evidence_ids": allowed_evidence,
        "allowed_query_disclosure_ids": [
            item.disclosure_id for item in bundle.queries_used
        ],
        "allowed_contradiction_ids": [
            item.contradiction_id for item in bundle.contradictions
        ],
        "evidence_gap_ids_not_valid_as_evidence_ids": [
            item.gap_id for item in bundle.gaps
        ],
        "previous_incident_analysis": analysis.model_dump(mode="json"),
    }
    return (
        "Repair the previous IncidentAnalysis because it failed reference validation. "
        "Use only IDs listed in the allowed ID lists. EvidenceGap IDs are not EvidenceItem "
        "IDs and must never appear in any evidence ID field. Do not invent new facts, IDs, "
        "queries, or contradictions. Preserve valid analysis content where possible. "
        "Return only the repaired JSON.\n"
        + json.dumps(repair_context, separators=(",", ":"))
    )

