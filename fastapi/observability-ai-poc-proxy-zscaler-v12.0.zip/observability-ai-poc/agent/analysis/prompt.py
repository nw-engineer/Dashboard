ANALYSIS_CONTRACT = """
Analyze only the supplied EvidenceBundle and obey all of these rules:
1. Do not assert a cause without citing supporting evidence IDs from the bundle. If evidence is insufficient, state that the likely cause is undetermined.
2. Correlation is not causation.
3. If Span evidence is unavailable, do not infer an internal service bottleneck solely from parent Transaction duration.
4. Expose contradictions between sources instead of hiding, resolving, or selecting one side without evidence.
5. Distinguish direct observations from hypotheses.
6. Recommended actions are advisory only; do not claim to have executed changes.
7. Use only evidence present in the supplied EvidenceBundle.
8. Every likely cause and every alternative hypothesis must reference supporting or opposing evidence IDs.
9. Never fabricate a query or tool call that is not present in queries_used; use only supplied query disclosure IDs.
10. EvidenceGap gap IDs are not evidence IDs. A gap may justify stating that evidence is insufficient, but never place a gap ID in any evidence ID field.
11. Write all human-readable narrative fields in Japanese, including incident_summary, impact, likely_cause, alternative hypothesis summaries, recommended_checks, and recommended_actions.
12. Technical identifiers and query text such as request.id, trace.id, Evidence IDs, Query Disclosure IDs, service names, event types, tool names, SPL, and NRQL must remain unchanged; do not translate, rewrite, or localize them.
""".strip()
