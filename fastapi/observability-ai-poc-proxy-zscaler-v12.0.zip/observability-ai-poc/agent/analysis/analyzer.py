from __future__ import annotations

from typing import Protocol

from agent.analysis.models import IncidentAnalysis
from agent.evidence.models import EvidenceBundle


class InvalidAnalysisReference(ValueError):
    pass


class IncidentAnalyzer(Protocol):
    async def analyze(self, bundle: EvidenceBundle) -> IncidentAnalysis:
        ...


def validate_analysis_references(bundle: EvidenceBundle, analysis: IncidentAnalysis) -> None:
    known_evidence = {item.evidence_id for item in bundle.evidence}
    known_queries = {item.disclosure_id for item in bundle.queries_used}
    known_contradictions = {item.contradiction_id for item in bundle.contradictions}

    referenced_evidence = set(analysis.supporting_evidence_ids)
    referenced_evidence.update(analysis.new_relic_evidence_ids)
    referenced_evidence.update(analysis.splunk_evidence_ids)
    for hypothesis in analysis.alternative_hypotheses:
        referenced_evidence.update(hypothesis.supporting_evidence_ids)
        referenced_evidence.update(hypothesis.opposing_evidence_ids)

    unknown_evidence = sorted(referenced_evidence - known_evidence)
    if unknown_evidence:
        raise InvalidAnalysisReference(f"unknown evidence IDs: {', '.join(unknown_evidence)}")

    unknown_queries = sorted(set(analysis.query_disclosure_ids) - known_queries)
    if unknown_queries:
        raise InvalidAnalysisReference(f"unknown query IDs: {', '.join(unknown_queries)}")

    unknown_contradictions = sorted(set(analysis.contradiction_ids) - known_contradictions)
    if unknown_contradictions:
        raise InvalidAnalysisReference(
            f"unknown contradiction IDs: {', '.join(unknown_contradictions)}"
        )
