from __future__ import annotations

import os

from agent.analysis.analyzer import IncidentAnalyzer
from agent.analysis.azure_openai_adapter import AzureOpenAIIncidentAnalyzer
from agent.analysis.ollama_adapter import OllamaIncidentAnalyzer
from agent.analysis.openai_adapter import OpenAIIncidentAnalyzer


class LLMProviderConfigurationError(RuntimeError):
    pass


def create_incident_analyzer_from_env() -> IncidentAnalyzer:
    provider = os.getenv("LLM_PROVIDER", "ollama").strip().lower()
    if provider == "ollama":
        return OllamaIncidentAnalyzer.from_env()
    if provider == "azure_openai":
        return AzureOpenAIIncidentAnalyzer.from_env()
    if provider == "openai":
        return OpenAIIncidentAnalyzer.from_env()
    raise LLMProviderConfigurationError(
        "LLM_PROVIDER must be one of: ollama, azure_openai, openai"
    )
