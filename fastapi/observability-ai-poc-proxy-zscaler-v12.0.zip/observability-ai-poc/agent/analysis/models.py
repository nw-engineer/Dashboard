from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, model_validator


class Confidence(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class Hypothesis(BaseModel):
    model_config = ConfigDict(extra="forbid")

    summary: str = Field(min_length=1)
    supporting_evidence_ids: list[str] = Field(default_factory=list)
    opposing_evidence_ids: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def evidence_reference_required(self):
        if not self.supporting_evidence_ids and not self.opposing_evidence_ids:
            raise ValueError("hypothesis requires evidence references")
        return self


class IncidentAnalysis(BaseModel):
    model_config = ConfigDict(extra="forbid")

    incident_summary: str = Field(min_length=1)
    impact: str = Field(min_length=1)
    likely_cause: str = Field(min_length=1)
    confidence: Confidence
    supporting_evidence_ids: list[str]
    alternative_hypotheses: list[Hypothesis]
    recommended_checks: list[str]
    recommended_actions: list[str]
    new_relic_evidence_ids: list[str]
    splunk_evidence_ids: list[str]
    contradiction_ids: list[str]
    query_disclosure_ids: list[str]

    @model_validator(mode="after")
    def evidence_rules(self):
        if self.confidence is Confidence.HIGH and not self.supporting_evidence_ids:
            raise ValueError("high confidence requires supporting evidence")
        if not self.supporting_evidence_ids and "undetermined" not in self.likely_cause.lower():
            raise ValueError("likely cause requires supporting evidence or an undetermined statement")
        return self
