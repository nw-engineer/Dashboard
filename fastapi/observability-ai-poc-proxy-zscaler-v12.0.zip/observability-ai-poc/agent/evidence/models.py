from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator


class EvidenceSource(StrEnum):
    SPLUNK = "splunk"
    NEW_RELIC = "newrelic"


class EvidenceCategory(StrEnum):
    TRANSACTION = "transaction"
    SPAN = "span"
    GOLDEN_METRIC = "golden_metric"
    DB = "db"
    DEPENDENCY = "dependency"
    EXCEPTION = "exception"
    CAPACITY = "capacity"
    DEPLOYMENT = "deployment"
    APPLICATION = "application"
    CORRELATION = "correlation"


_JSON_SCALARS = (str, int, float, bool, type(None))


def _is_json_compatible(value: Any) -> bool:
    if isinstance(value, _JSON_SCALARS):
        return True
    if isinstance(value, list):
        return all(_is_json_compatible(item) for item in value)
    if isinstance(value, dict):
        return all(
            isinstance(key, str) and _is_json_compatible(item)
            for key, item in value.items()
        )
    return False


class QueryDisclosure(BaseModel):
    disclosure_id: str = Field(min_length=1)
    source: EvidenceSource
    operation: str = Field(min_length=1)
    arguments: dict[str, Any]

    @field_validator("arguments")
    @classmethod
    def validate_arguments(cls, value: dict[str, Any]) -> dict[str, Any]:
        if not _is_json_compatible(value):
            raise ValueError("arguments must be JSON-compatible")
        return value


class EvidenceItem(BaseModel):
    evidence_id: str = Field(min_length=1)
    source: EvidenceSource
    category: EvidenceCategory
    summary: str = Field(min_length=1)
    facts: dict[str, Any]
    query_or_tool: str = Field(min_length=1)
    service_name: str | None = None
    observed_at: datetime | None = None
    request_id: str | None = None
    trace_id: str | None = None
    entity_guid: str | None = None

    @field_validator("facts")
    @classmethod
    def validate_facts(cls, value: dict[str, Any]) -> dict[str, Any]:
        if not _is_json_compatible(value):
            raise ValueError("facts must be JSON-compatible")
        return value


class EvidenceGap(BaseModel):
    gap_id: str = Field(min_length=1)
    summary: str = Field(min_length=1)
    source: EvidenceSource | None = None
    category: EvidenceCategory | None = None


class EvidenceContradiction(BaseModel):
    contradiction_id: str = Field(min_length=1)
    summary: str = Field(min_length=1)
    left_evidence_ids: list[str]
    right_evidence_ids: list[str]


class CorrelationContext(BaseModel):
    request_id: str = Field(min_length=1)
    trace_id: str = Field(min_length=1)
    services: list[str] = Field(default_factory=list)
    entity_guids: dict[str, str] = Field(default_factory=dict)

    @field_validator("services")
    @classmethod
    def unique_services(cls, value: list[str]) -> list[str]:
        return list(dict.fromkeys(service for service in value if service))


class EvidenceBundle(BaseModel):
    investigation_id: str = Field(min_length=1)
    request_id: str = Field(min_length=1)
    trace_id: str = Field(min_length=1)
    evidence: list[EvidenceItem]
    contradictions: list[EvidenceContradiction]
    gaps: list[EvidenceGap]
    queries_used: list[QueryDisclosure]

    @model_validator(mode="after")
    def validate_unique_ids(self):
        evidence_ids = [item.evidence_id for item in self.evidence]
        if len(evidence_ids) != len(set(evidence_ids)):
            raise ValueError("duplicate evidence_id")
        disclosure_ids = [item.disclosure_id for item in self.queries_used]
        if len(disclosure_ids) != len(set(disclosure_ids)):
            raise ValueError("duplicate disclosure_id")
        return self
