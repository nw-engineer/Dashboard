from __future__ import annotations

from datetime import datetime

from agent.evidence.models import CorrelationContext
from agent.splunk.client import SplunkSearchClient
from agent.splunk.models import SplunkSearchRequest


class CorrelationNotFound(LookupError):
    pass


class TraceIdNotFound(LookupError):
    pass


class AmbiguousTraceId(LookupError):
    pass


class CorrelationResolver:
    def __init__(self, splunk: SplunkSearchClient) -> None:
        self.splunk = splunk

    async def resolve_request(
        self,
        request_id: str,
        earliest: datetime,
        latest: datetime,
    ) -> CorrelationContext:
        rows = await self.splunk.search(
            SplunkSearchRequest(
                query=f'request.id="{request_id}"',
                earliest=earliest,
                latest=latest,
                max_results=200,
            )
        )
        if not rows:
            raise CorrelationNotFound(f"request.id not found: {request_id}")

        trace_ids = sorted({str(row["trace.id"]) for row in rows if row.get("trace.id")})
        if not trace_ids:
            raise TraceIdNotFound(f"trace.id not found for request.id={request_id}")
        if len(trace_ids) != 1:
            raise AmbiguousTraceId(
                f"multiple trace.id values for request.id={request_id}: {', '.join(trace_ids)}"
            )

        services = [str(row["service.name"]) for row in rows if row.get("service.name")]
        entity_guids = {
            str(row["service.name"]): str(row["entity.guid"])
            for row in rows
            if row.get("service.name") and row.get("entity.guid")
        }
        return CorrelationContext(
            request_id=request_id,
            trace_id=trace_ids[0],
            services=services,
            entity_guids=entity_guids,
        )
