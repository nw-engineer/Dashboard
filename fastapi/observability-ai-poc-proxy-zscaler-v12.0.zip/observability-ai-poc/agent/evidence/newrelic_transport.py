from __future__ import annotations

import json
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any, AsyncContextManager, Callable


class NewRelicMcpTransportError(RuntimeError):
    pass


@dataclass(frozen=True)
class McpToolInfo:
    name: str
    description: str | None
    input_schema: dict[str, object]


SessionFactory = Callable[[str], AsyncContextManager[Any]]


def _attr(value: object, *names: str, default: object = None) -> object:
    if isinstance(value, dict):
        for name in names:
            if name in value:
                return value[name]
        return default
    for name in names:
        if hasattr(value, name):
            return getattr(value, name)
    return default


def _normalize_tool_result(result: object) -> object:
    is_error = bool(_attr(result, "isError", "is_error", default=False))
    if is_error:
        raise NewRelicMcpTransportError("MCP tool call failed")

    structured = _attr(
        result,
        "structuredContent",
        "structured_content",
        default=None,
    )
    if structured is not None:
        return structured

    content = _attr(result, "content", default=[])
    if not isinstance(content, list):
        return {"content": str(content)}

    texts: list[str] = []
    for item in content:
        text = _attr(item, "text", default=None)
        if isinstance(text, str):
            texts.append(text)

    combined = "\n".join(texts)
    if not combined:
        return {}

    try:
        return json.loads(combined)
    except json.JSONDecodeError:
        return {"content": combined}


@asynccontextmanager
async def _default_session_factory(url: str):
    try:
        from mcp import ClientSession
        from mcp.client.streamable_http import streamable_http_client
    except ImportError:
        raise NewRelicMcpTransportError(
            "MCP Python SDK is required for Streamable HTTP transport"
        ) from None

    try:
        async with streamable_http_client(url) as streams:
            read_stream, write_stream = streams[0], streams[1]
            async with ClientSession(read_stream, write_stream) as session:
                yield session
    except NewRelicMcpTransportError:
        raise
    except Exception:
        raise NewRelicMcpTransportError("New Relic MCP transport was unavailable") from None


class StreamableHttpNewRelicMcpGateway:
    def __init__(
        self,
        base_url: str = "http://localhost:8000/mcp",
        *,
        session_factory: SessionFactory | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self._session_factory = session_factory or _default_session_factory

    async def list_tools(self) -> list[McpToolInfo]:
        async with self._session_factory(self.base_url) as session:
            try:
                await session.initialize()
                response = await session.list_tools()
            except NewRelicMcpTransportError:
                raise
            except Exception:
                raise NewRelicMcpTransportError("MCP tools/list failed") from None

        tools = _attr(response, "tools", default=[])
        if not isinstance(tools, list):
            raise NewRelicMcpTransportError("MCP tools/list returned an unsupported payload")

        normalized: list[McpToolInfo] = []
        for tool in tools:
            name = _attr(tool, "name", default=None)
            if not isinstance(name, str) or not name:
                continue
            description = _attr(tool, "description", default=None)
            schema = _attr(tool, "inputSchema", "input_schema", default={})
            normalized.append(
                McpToolInfo(
                    name=name,
                    description=description if isinstance(description, str) else None,
                    input_schema=schema if isinstance(schema, dict) else {},
                )
            )
        return normalized

    async def call_tool(self, name: str, arguments: dict[str, object]) -> object:
        async with self._session_factory(self.base_url) as session:
            try:
                await session.initialize()
                result = await session.call_tool(name, arguments)
            except NewRelicMcpTransportError:
                raise
            except Exception:
                raise NewRelicMcpTransportError("MCP tool call failed") from None
        return _normalize_tool_result(result)
