from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel

from agent.evidence.models import (
    CorrelationContext,
    EvidenceCategory,
    EvidenceGap,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)
from agent.evidence.newrelic_gateway import NewRelicMcpGateway


class NewRelicEvidenceUnavailable(RuntimeError):
    pass


class NewRelicEvidenceResult(BaseModel):
    evidence: list[EvidenceItem]
    gaps: list[EvidenceGap]
    queries: list[QueryDisclosure]


def _parse_time(value: Any) -> datetime | None:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            seconds = float(value) / 1000.0 if abs(float(value)) >= 100_000_000_000 else float(value)
            return datetime.fromtimestamp(seconds, tz=timezone.utc)
        except (OverflowError, OSError, ValueError):
            return None
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _require_list(payload: object, key: str, tool_name: str) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        raise NewRelicEvidenceUnavailable(f"unsupported response from {tool_name}")
    rows = payload.get(key)
    if not isinstance(rows, list):
        raise NewRelicEvidenceUnavailable(f"unsupported response from {tool_name}")
    if not all(isinstance(row, dict) for row in rows):
        raise NewRelicEvidenceUnavailable(f"unsupported response from {tool_name}")
    return rows


class NewRelicEvidenceCollector:
    def __init__(self, gateway: NewRelicMcpGateway, *, account_id: int) -> None:
        if account_id <= 0:
            raise ValueError("account_id must be a positive integer")
        self.gateway = gateway
        self.account_id = account_id

    async def collect(
        self,
        context: CorrelationContext,
        earliest: datetime,
        latest: datetime,
    ) -> NewRelicEvidenceResult:
        evidence: list[EvidenceItem] = []
        gaps: list[EvidenceGap] = []
        queries: list[QueryDisclosure] = []
        evidence_counter = 1
        query_counter = 1

        minutes = max(1, min(120, math.ceil((latest - earliest).total_seconds() / 60)))
        trace_id = context.trace_id.replace("'", "\\'")

        transaction_query = (
            "SELECT appName, name, duration, error, timestamp, traceId "
            "FROM Transaction "
            f"WHERE traceId = '{trace_id}' "
            f"SINCE {minutes} minutes ago LIMIT 200"
        )
        transaction_disclosure = QueryDisclosure(
            disclosure_id=f"query-newrelic-{query_counter:03d}",
            source=EvidenceSource.NEW_RELIC,
            operation="execute_nrql_query",
            arguments={"nrql_query": transaction_query, "account_id": self.account_id},
        )
        query_counter += 1
        queries.append(transaction_disclosure)
        try:
            transaction_payload = await self.gateway.call_tool(
                "execute_nrql_query",
                {"nrql_query": transaction_query, "account_id": self.account_id},
            )
        except Exception as exc:
            raise NewRelicEvidenceUnavailable(
                "New Relic MCP tool execute_nrql_query was unavailable"
            ) from None
        transaction_rows = _require_list(
            transaction_payload, "results", "execute_nrql_query"
        )
        for row in transaction_rows:
            facts = {
                key: row[key]
                for key in ("appName", "name", "duration", "error", "timestamp", "traceId")
                if key in row
            }
            evidence.append(
                EvidenceItem(
                    evidence_id=f"newrelic-{evidence_counter:03d}",
                    source=EvidenceSource.NEW_RELIC,
                    category=EvidenceCategory.TRANSACTION,
                    summary="New Relicで相関対象のTransactionを観測しました",
                    facts=facts,
                    query_or_tool=transaction_disclosure.disclosure_id,
                    service_name=str(row["appName"]) if row.get("appName") else None,
                    observed_at=_parse_time(row.get("timestamp")),
                    request_id=context.request_id,
                    trace_id=str(row["traceId"]) if row.get("traceId") else context.trace_id,
                )
            )
            evidence_counter += 1

        span_query = (
            "SELECT appName, name, duration, timestamp, traceId "
            "FROM Span "
            f"WHERE traceId = '{trace_id}' "
            f"SINCE {minutes} minutes ago LIMIT 200"
        )
        span_disclosure = QueryDisclosure(
            disclosure_id=f"query-newrelic-{query_counter:03d}",
            source=EvidenceSource.NEW_RELIC,
            operation="execute_nrql_query",
            arguments={"nrql_query": span_query, "account_id": self.account_id},
        )
        query_counter += 1
        queries.append(span_disclosure)
        try:
            span_payload = await self.gateway.call_tool(
                "execute_nrql_query",
                {"nrql_query": span_query, "account_id": self.account_id},
            )
            span_rows = _require_list(span_payload, "results", "execute_nrql_query")
        except Exception:
            span_rows = []

        if not span_rows:
            gaps.append(
                EvidenceGap(
                    gap_id="gap-newrelic-span-unavailable",
                    summary="相関対象のトレースではNew RelicのSpan証拠を観測できませんでした",
                    source=EvidenceSource.NEW_RELIC,
                    category=EvidenceCategory.SPAN,
                )
            )
        else:
            for row in span_rows:
                facts = {
                    key: row[key]
                    for key in ("appName", "name", "duration", "timestamp", "traceId")
                    if key in row
                }
                evidence.append(
                    EvidenceItem(
                        evidence_id=f"newrelic-{evidence_counter:03d}",
                        source=EvidenceSource.NEW_RELIC,
                        category=EvidenceCategory.SPAN,
                        summary="New Relicで相関対象のSpanを観測しました",
                        facts=facts,
                        query_or_tool=span_disclosure.disclosure_id,
                        service_name=str(row["appName"]) if row.get("appName") else None,
                        observed_at=_parse_time(row.get("timestamp")),
                        request_id=context.request_id,
                        trace_id=str(row["traceId"]) if row.get("traceId") else context.trace_id,
                    )
                )
                evidence_counter += 1

        history_period_hours = max(
            1, math.ceil((latest - earliest).total_seconds() / 3600)
        )
        for service, entity_guid in context.entity_guids.items():
            arguments: dict[str, object] = {
                "entity_guid": entity_guid,
                "history_period_hours": history_period_hours,
            }
            disclosure = QueryDisclosure(
                disclosure_id=f"query-newrelic-{query_counter:03d}",
                source=EvidenceSource.NEW_RELIC,
                operation="list_change_events",
                arguments=arguments,
            )
            query_counter += 1
            queries.append(disclosure)

            events: list[dict[str, Any]] | None = None
            evidence_disclosure = disclosure
            try:
                change_payload = await self.gateway.call_tool("list_change_events", arguments)
                if not (isinstance(change_payload, dict) and change_payload.get("ok") is False):
                    try:
                        events = _require_list(change_payload, "events", "list_change_events")
                    except NewRelicEvidenceUnavailable:
                        events = None
            except Exception:
                events = None

            if events is None:
                escaped_guid = entity_guid.replace("'", "\\'")
                change_query = (
                    "SELECT eventType(), deploymentId, changeTrackingId, category, "
                    "categoryType, description, entity.guid, entity.name, gitSha, "
                    "groupId, serviceVersion, shortDescription, timestamp, type, version "
                    "FROM ChangeTrackingEvent, Deployment "
                    f"WHERE entity.guid = '{escaped_guid}' "
                    f"SINCE {history_period_hours} hours ago LIMIT 100"
                )
                fallback_disclosure = QueryDisclosure(
                    disclosure_id=f"query-newrelic-{query_counter:03d}",
                    source=EvidenceSource.NEW_RELIC,
                    operation="execute_nrql_query",
                    arguments={
                        "nrql_query": change_query,
                        "account_id": self.account_id,
                    },
                )
                query_counter += 1
                queries.append(fallback_disclosure)
                evidence_disclosure = fallback_disclosure
                try:
                    fallback_payload = await self.gateway.call_tool(
                        "execute_nrql_query",
                        {"nrql_query": change_query, "account_id": self.account_id},
                    )
                    if isinstance(fallback_payload, dict) and fallback_payload.get("ok") is False:
                        raise NewRelicEvidenceUnavailable(
                            "New Relic change tracking evidence was unavailable"
                        )
                    events = _require_list(
                        fallback_payload, "results", "change tracking NRQL fallback"
                    )
                except NewRelicEvidenceUnavailable:
                    raise NewRelicEvidenceUnavailable(
                        "New Relic change tracking evidence was unavailable"
                    ) from None
                except Exception:
                    raise NewRelicEvidenceUnavailable(
                        "New Relic change tracking evidence was unavailable"
                    ) from None

            for event in events:
                fact_keys = (
                    "entityName",
                    "entity.name",
                    "entity.guid",
                    "eventType()",
                    "category",
                    "categoryType",
                    "type",
                    "version",
                    "serviceVersion",
                    "deploymentId",
                    "changeTrackingId",
                    "groupId",
                    "gitSha",
                    "shortDescription",
                    "description",
                    "timestamp",
                )
                facts = {key: event[key] for key in fact_keys if key in event}
                event_service = event.get("entityName") or event.get("entity.name") or service
                event_guid = event.get("entity.guid") or entity_guid
                evidence.append(
                    EvidenceItem(
                        evidence_id=f"newrelic-{evidence_counter:03d}",
                        source=EvidenceSource.NEW_RELIC,
                        category=EvidenceCategory.DEPLOYMENT,
                        summary="New Relicで変更・デプロイイベントを観測しました",
                        facts=facts,
                        query_or_tool=evidence_disclosure.disclosure_id,
                        service_name=str(event_service) if event_service else None,
                        observed_at=_parse_time(event.get("timestamp")),
                        request_id=context.request_id,
                        trace_id=context.trace_id,
                        entity_guid=str(event_guid) if event_guid else None,
                    )
                )
                evidence_counter += 1

        return NewRelicEvidenceResult(evidence=evidence, gaps=gaps, queries=queries)
