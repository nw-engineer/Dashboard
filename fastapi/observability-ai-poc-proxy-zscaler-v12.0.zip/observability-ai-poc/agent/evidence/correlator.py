from __future__ import annotations

from agent.evidence.models import (
    CorrelationContext,
    EvidenceBundle,
    EvidenceContradiction,
    EvidenceItem,
)
from agent.evidence.newrelic_collector import NewRelicEvidenceResult
from agent.evidence.splunk_collector import SplunkEvidenceResult


class EvidenceCorrelator:
    def build_bundle(
        self,
        *,
        investigation_id: str,
        context: CorrelationContext,
        splunk: SplunkEvidenceResult,
        newrelic: NewRelicEvidenceResult,
    ) -> EvidenceBundle:
        evidence = [*splunk.evidence, *newrelic.evidence]
        contradictions: list[EvidenceContradiction] = []
        counter = 1

        for item in evidence:
            mismatch_parts: list[str] = []
            if item.request_id is not None and item.request_id != context.request_id:
                mismatch_parts.append(
                    f"request.id={item.request_id} は相関対象の {context.request_id} と一致しません"
                )
            if item.trace_id is not None and item.trace_id != context.trace_id:
                mismatch_parts.append(
                    f"trace.id={item.trace_id} は相関対象の {context.trace_id} と一致しません"
                )
            if not mismatch_parts:
                continue

            opposing = [
                candidate.evidence_id
                for candidate in evidence
                if candidate.source != item.source
                and (candidate.request_id in (None, context.request_id))
                and (candidate.trace_id in (None, context.trace_id))
            ]
            contradictions.append(
                EvidenceContradiction(
                    contradiction_id=f"contradiction-{counter:03d}",
                    summary="; ".join(mismatch_parts),
                    left_evidence_ids=[item.evidence_id],
                    right_evidence_ids=opposing,
                )
            )
            counter += 1

        return EvidenceBundle(
            investigation_id=investigation_id,
            request_id=context.request_id,
            trace_id=context.trace_id,
            evidence=evidence,
            contradictions=contradictions,
            gaps=[*splunk.gaps, *newrelic.gaps],
            queries_used=[splunk.query, *newrelic.queries],
        )
