from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Protocol


class NewRelicMcpGateway(Protocol):
    async def call_tool(self, name: str, arguments: dict[str, object]) -> object:
        ...


class CallableNewRelicMcpGateway:
    def __init__(
        self,
        caller: Callable[[str, dict[str, object]], Awaitable[object]],
    ) -> None:
        self._caller = caller

    async def call_tool(self, name: str, arguments: dict[str, object]) -> object:
        return await self._caller(name, arguments)
