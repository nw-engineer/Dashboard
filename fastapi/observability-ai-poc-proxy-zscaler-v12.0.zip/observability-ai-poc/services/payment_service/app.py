import os
from time import perf_counter
from uuid import uuid4

import httpx
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel

from shared.correlation import add_transaction_attributes
from shared.logging import build_event, record_event

app = FastAPI(title="Payment Service")
PAYMENT_MOCK_URL = os.getenv("PAYMENT_MOCK_URL", "http://payment-mock:8084")


class Payment(BaseModel):
    order_id: str
    amount: int


class PaymentDependency:
    async def charge(
        self,
        order_id: str,
        amount: int,
        *,
        request_id: str | None = None,
        scenario_id: str | None = None,
    ) -> dict:
        headers: dict[str, str] = {}
        if request_id:
            headers["X-Request-ID"] = request_id
        if scenario_id:
            headers["X-Scenario-ID"] = scenario_id
        async with httpx.AsyncClient(timeout=1.5) as client:
            response = await client.post(
                f"{PAYMENT_MOCK_URL}/charge",
                json={"order_id": order_id, "amount": amount},
                headers=headers,
            )
            response.raise_for_status()
            return response.json()


payment_dependency = PaymentDependency()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/payments")
async def pay(payload: Payment, request: Request):
    request_id = request.headers.get("X-Request-ID") or str(uuid4())
    scenario_id = request.headers.get("X-Scenario-ID")
    add_transaction_attributes(
        request_id=request_id,
        scenario_id=scenario_id,
        order_id=payload.order_id,
    )

    for attempt in range(1, 4):
        started = perf_counter()
        try:
            result = await payment_dependency.charge(
                payload.order_id,
                payload.amount,
                request_id=request_id,
                scenario_id=scenario_id,
            )
            record_event(build_event(
                "dependency.call",
                service_name="payment-service",
                request_id=request_id,
                scenario_id=scenario_id,
                attributes={
                    "dependency.name": "payment-api",
                    "dependency.type": "http",
                    "dependency.status_code": 200,
                    "dependency.duration_ms": round((perf_counter() - started) * 1000, 3),
                    "retry_count": attempt,
                },
            ))
            return result
        except (httpx.TimeoutException, httpx.HTTPStatusError) as exc:
            status_code = exc.response.status_code if isinstance(exc, httpx.HTTPStatusError) else 504
            record_event(build_event(
                "dependency.call",
                level="ERROR",
                service_name="payment-service",
                request_id=request_id,
                scenario_id=scenario_id,
                attributes={
                    "dependency.name": "payment-api",
                    "dependency.type": "http",
                    "dependency.status_code": status_code,
                    "dependency.duration_ms": round((perf_counter() - started) * 1000, 3),
                    "retry_count": attempt,
                },
            ))
            if attempt < 3:
                record_event(build_event(
                    "retry",
                    level="WARN",
                    service_name="payment-service",
                    request_id=request_id,
                    scenario_id=scenario_id,
                    attributes={"dependency.name": "payment-api", "retry_count": attempt},
                ))
            if attempt == 3:
                raise HTTPException(status_code=502, detail="payment dependency failed")
    raise AssertionError("unreachable")
