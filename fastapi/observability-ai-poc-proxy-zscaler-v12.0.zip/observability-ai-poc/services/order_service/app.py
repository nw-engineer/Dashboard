import asyncio
from uuid import uuid4

import httpx
from fastapi import FastAPI, HTTPException, Request, status
from pydantic import BaseModel

from shared.correlation import add_transaction_attributes
from shared.logging import build_event, record_event
from shared.scenario import ScenarioId
from shared.scenario_client import ScenarioClient
from services.order_service.capacity import CapacityGate
from services.order_service.client import InventoryDependency, PaymentDependency

app = FastAPI(title="Order Service")
inventory_dependency = InventoryDependency()
payment_dependency = PaymentDependency()
scenario = ScenarioClient()
capacity_gate = CapacityGate(limit=4)


class OrderRequest(BaseModel):
    product_id: str
    quantity: int
    amount: int


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/orders", status_code=status.HTTP_201_CREATED)
async def create_order(payload: OrderRequest, request: Request):
    request_id = request.headers.get("X-Request-ID") or str(uuid4())
    current = await scenario.get_current()
    scenario_id = current.value
    add_transaction_attributes(
        request_id=request_id,
        scenario_id=scenario_id,
        product_id=payload.product_id,
    )

    if payload.product_id == "BUG-001":
        try:
            broken = None
            return broken.customer_id
        except AttributeError as exc:
            record_event(build_event(
                "exception",
                level="ERROR",
                service_name="order-service",
                request_id=request_id,
                scenario_id=scenario_id,
                attributes={
                    "error.type": type(exc).__name__,
                    "error.message": str(exc),
                    "operation": "create_order",
                    "product.id": payload.product_id,
                },
            ))
            raise

    lease = await capacity_gate.acquire()
    try:
        if current is ScenarioId.UC04_HIGH_LOAD:
            await asyncio.sleep(0.25)

        inventory = await inventory_dependency.get_inventory(
            payload.product_id,
            request_id=request_id,
            scenario_id=scenario_id,
        )
        if inventory["quantity"] < payload.quantity:
            raise HTTPException(status_code=409, detail="insufficient inventory")

        order_id = f"ord-{uuid4()}"
        add_transaction_attributes(
            order_id=order_id,
            queue_wait_ms=round(lease.queue_wait_ms, 3),
            active_workers=lease.active_workers,
            inflight_requests=lease.inflight_requests,
        )
        record_event(build_event(
            "capacity.snapshot",
            service_name="order-service",
            request_id=request_id,
            scenario_id=scenario_id,
            attributes={
                "queue_wait_ms": round(lease.queue_wait_ms, 3),
                "active_workers": lease.active_workers,
                "inflight_requests": lease.inflight_requests,
                "order.id": order_id,
            },
        ))
        try:
            payment = await payment_dependency.pay(
                order_id,
                payload.amount,
                request_id=request_id,
                scenario_id=scenario_id,
            )
        except httpx.HTTPStatusError as exc:
            raise HTTPException(
                status_code=exc.response.status_code,
                detail="payment service failed",
            ) from exc
        return {
            "order_id": order_id,
            "status": "created",
            "queue_wait_ms": round(lease.queue_wait_ms, 3),
            "active_workers": lease.active_workers,
            "inflight_requests": lease.inflight_requests,
            "inventory_service_version": inventory.get("service_version"),
            "correlation": {
                "order_request_id": request_id,
                "inventory_request_id": inventory.get("request_id"),
                "payment_request_id": payment.get("request_id"),
            },
        }
    finally:
        lease.release()
