import os

import httpx

INVENTORY_SERVICE_URL = os.getenv("INVENTORY_SERVICE_URL", "http://inventory-service:8082")
PAYMENT_SERVICE_URL = os.getenv("PAYMENT_SERVICE_URL", "http://payment-service:8083")


def _context_headers(request_id: str | None, scenario_id: str | None) -> dict[str, str]:
    headers: dict[str, str] = {}
    if request_id:
        headers["X-Request-ID"] = request_id
    if scenario_id:
        headers["X-Scenario-ID"] = scenario_id
    return headers


class InventoryDependency:
    async def get_inventory(
        self,
        product_id: str,
        *,
        request_id: str | None = None,
        scenario_id: str | None = None,
    ) -> dict:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(
                f"{INVENTORY_SERVICE_URL}/inventory/{product_id}",
                headers=_context_headers(request_id, scenario_id),
            )
            response.raise_for_status()
            return response.json()


class PaymentDependency:
    async def pay(
        self,
        order_id: str,
        amount: int,
        *,
        request_id: str | None = None,
        scenario_id: str | None = None,
    ) -> dict:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(
                f"{PAYMENT_SERVICE_URL}/payments",
                json={"order_id": order_id, "amount": amount},
                headers=_context_headers(request_id, scenario_id),
            )
            response.raise_for_status()
            return response.json()
