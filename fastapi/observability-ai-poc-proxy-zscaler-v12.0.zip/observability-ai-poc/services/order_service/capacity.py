import asyncio
import time
from dataclasses import dataclass
from typing import Callable


@dataclass
class CapacityLease:
    queue_wait_ms: float
    active_workers: int
    inflight_requests: int
    _release: Callable[[], None]
    _released: bool = False

    def release(self) -> None:
        if self._released:
            return
        self._released = True
        self._release()


class CapacityGate:
    def __init__(self, limit: int = 4):
        if limit < 1:
            raise ValueError("limit must be positive")
        self._semaphore = asyncio.Semaphore(limit)
        self.active_workers = 0
        self.inflight_requests = 0

    async def acquire(self) -> CapacityLease:
        self.inflight_requests += 1
        started = time.monotonic()
        await self._semaphore.acquire()
        queue_wait_ms = (time.monotonic() - started) * 1000.0
        self.active_workers += 1

        def release() -> None:
            self.active_workers -= 1
            self.inflight_requests -= 1
            self._semaphore.release()

        return CapacityLease(
            queue_wait_ms=queue_wait_ms,
            active_workers=self.active_workers,
            inflight_requests=self.inflight_requests,
            _release=release,
        )
