import os
import time
from dataclasses import dataclass
from typing import Protocol

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine


@dataclass(frozen=True)
class InventoryItem:
    product_id: str
    quantity: int


class InventoryReader(Protocol):
    def get_inventory(self, product_id: str, pre_query_delay: float = 0.0) -> InventoryItem | None: ...


class InventoryRepository:
    def __init__(self, engine: Engine):
        self.engine = engine

    @classmethod
    def from_env(cls) -> "InventoryRepository":
        url = os.getenv("DATABASE_URL", "postgresql+psycopg://poc:poc@postgres:5432/poc")
        return cls(create_engine(url, pool_pre_ping=True))

    def get_inventory(self, product_id: str, pre_query_delay: float = 0.0) -> InventoryItem | None:
        if pre_query_delay:
            time.sleep(pre_query_delay)
        with self.engine.connect() as conn:
            row = conn.execute(
                text("SELECT product_id, quantity FROM inventory WHERE product_id = :product_id"),
                {"product_id": product_id},
            ).mappings().first()
        if row is None:
            return None
        return InventoryItem(product_id=row["product_id"], quantity=row["quantity"])
