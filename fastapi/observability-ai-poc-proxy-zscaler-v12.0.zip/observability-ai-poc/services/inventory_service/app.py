import asyncio
import os
from time import perf_counter
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Request

from shared.correlation import add_transaction_attributes
from shared.logging import build_event, record_event
from shared.scenario_client import ScenarioClient
from services.inventory_service.db import InventoryReader, InventoryRepository
from services.inventory_service.models import behavior_for

app = FastAPI(title="Inventory Service")
scenario = ScenarioClient()
repository: InventoryReader | None = None


def get_repository() -> InventoryReader:
    global repository
    if repository is None:
        repository = InventoryRepository.from_env()
    return repository


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/inventory/{product_id}")
async def inventory(product_id: str, request: Request):
    request_id = request.headers.get("X-Request-ID") or str(uuid4())
    current = await scenario.get_current()
    behavior = behavior_for(current)
    add_transaction_attributes(
        request_id=request_id,
        scenario_id=current.value,
        product_id=product_id,
        service_version=behavior.service_version,
    )

    db_started = perf_counter()
    item = get_repository().get_inventory(product_id, pre_query_delay=behavior.db_delay_seconds)
    db_duration_ms = round((perf_counter() - db_started) * 1000, 3)
    record_event(build_event(
        "db.query",
        service_name="inventory-service",
        service_version=behavior.service_version,
        request_id=request_id,
        scenario_id=current.value,
        attributes={
            "db.system": "postgresql",
            "db.query_name": "get_inventory",
            "db.duration_ms": db_duration_ms,
            "product.id": product_id,
        },
    ))
    if item is None:
        raise HTTPException(status_code=404, detail="product not found")
    if current.value == "UC05_BAD_DEPLOYMENT":
        record_event(build_event(
            "deployment",
            service_name="inventory-service",
            service_version=behavior.service_version,
            request_id=request_id,
            scenario_id=current.value,
            attributes={
                "deployment.id": os.getenv("DEPLOYMENT_ID", "uc05-demo-deploy-001"),
                "git.sha": os.getenv("GIT_SHA", "local-poc"),
            },
        ))
    if behavior.processing_delay_seconds:
        await asyncio.sleep(behavior.processing_delay_seconds)
    return {
        "product_id": product_id,
        "quantity": item.quantity,
        "service_version": behavior.service_version,
        "request_id": request_id,
    }
