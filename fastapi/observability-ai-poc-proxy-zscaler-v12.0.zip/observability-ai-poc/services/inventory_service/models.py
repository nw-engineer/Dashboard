from dataclasses import dataclass

from shared.scenario import ScenarioId


@dataclass(frozen=True)
class InventoryBehavior:
    db_delay_seconds: float
    processing_delay_seconds: float
    service_version: str


def behavior_for(scenario: ScenarioId) -> InventoryBehavior:
    if scenario is ScenarioId.UC01_DB_SLOW:
        return InventoryBehavior(2.5, 0.0, "1.0.0")
    if scenario is ScenarioId.UC05_BAD_DEPLOYMENT:
        return InventoryBehavior(0.0, 0.3, "1.1.0")
    return InventoryBehavior(0.0, 0.0, "1.0.0")
