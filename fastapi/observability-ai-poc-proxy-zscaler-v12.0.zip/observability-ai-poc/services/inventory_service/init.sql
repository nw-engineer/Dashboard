CREATE TABLE IF NOT EXISTS inventory (
    product_id TEXT PRIMARY KEY,
    quantity INTEGER NOT NULL
);

INSERT INTO inventory (product_id, quantity) VALUES
    ('SKU-001', 100),
    ('SKU-002', 50),
    ('BUG-001', 10)
ON CONFLICT (product_id) DO UPDATE SET quantity = EXCLUDED.quantity;
