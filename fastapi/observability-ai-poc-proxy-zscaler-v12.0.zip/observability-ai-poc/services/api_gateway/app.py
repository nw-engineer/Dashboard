import os
from time import perf_counter
from uuid import uuid4

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from shared.correlation import add_transaction_attributes
from shared.logging import build_event, record_event

app = FastAPI(title="API Gateway")
ORDER_SERVICE_URL = os.getenv("ORDER_SERVICE_URL", "http://order-service:8081")


class OrderRequest(BaseModel):
    product_id: str
    quantity: int
    amount: int


class OrderDependency:
    async def create_order(self, payload: dict, request_id: str) -> tuple[int, dict]:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                f"{ORDER_SERVICE_URL}/orders",
                json=payload,
                headers={"X-Request-ID": request_id},
            )
            try:
                body = response.json()
            except ValueError:
                body = {"detail": response.text}
            return response.status_code, body


order_dependency = OrderDependency()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/orders")
async def create_order(payload: OrderRequest, request: Request):
    request_id = request.headers.get("X-Request-ID") or str(uuid4())
    add_transaction_attributes(request_id=request_id, product_id=payload.product_id)
    record_event(build_event(
        "application.request",
        service_name="api-gateway",
        request_id=request_id,
        attributes={"http.method": "POST", "http.route": "/orders", "product.id": payload.product_id},
    ))
    started = perf_counter()
    status_code, body = await order_dependency.create_order(payload.model_dump(), request_id)
    duration_ms = round((perf_counter() - started) * 1000, 3)
    record_event(build_event(
        "application.response",
        service_name="api-gateway",
        request_id=request_id,
        attributes={"http.method": "POST", "http.route": "/orders", "http.status_code": status_code, "duration_ms": duration_ms},
    ))
    return JSONResponse(
        status_code=status_code,
        content=body,
        headers={"X-Request-ID": request_id},
    )
