import asyncio
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel

from shared.correlation import add_transaction_attributes
from shared.scenario import ScenarioId
from shared.scenario_client import ScenarioClient

app = FastAPI(title="Payment Mock")
scenario = ScenarioClient()


class Charge(BaseModel):
    order_id: str
    amount: int


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/charge")
async def charge(payload: Charge, request: Request) -> dict[str, str]:
    request_id = request.headers.get("X-Request-ID") or str(uuid4())
    current = await scenario.get_current()
    add_transaction_attributes(
        request_id=request_id,
        scenario_id=current.value,
        order_id=payload.order_id,
    )
    if current is ScenarioId.UC02_PAYMENT_FAILURE:
        await asyncio.sleep(1.0)
        raise HTTPException(status_code=503, detail="payment provider unavailable")
    return {"status": "approved", "order_id": payload.order_id, "request_id": request_id}
