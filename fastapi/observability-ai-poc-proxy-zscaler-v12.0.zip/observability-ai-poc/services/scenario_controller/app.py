from fastapi import FastAPI

from shared.logging import build_event, record_event
from shared.scenario import ScenarioState

app = FastAPI(title="Scenario Controller")
_state = ScenarioState()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/scenario", response_model=ScenarioState)
def get_scenario() -> ScenarioState:
    return _state


@app.put("/scenario", response_model=ScenarioState)
def set_scenario(state: ScenarioState) -> ScenarioState:
    global _state
    previous = _state
    _state = state
    record_event(build_event(
        "scenario.change",
        service_name="scenario-controller",
        scenario_id=state.scenario.value,
        attributes={"from": previous.scenario.value, "to": state.scenario.value},
    ))
    return _state
