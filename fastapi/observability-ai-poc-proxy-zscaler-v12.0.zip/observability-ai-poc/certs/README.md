# Zscaler CA placement

Place the operator-provided Zscaler root/intermediate CA bundle here as:

```text
certs/zscaler-ca.crt
```

Requirements:

- PEM/CRT format containing `BEGIN CERTIFICATE` / `END CERTIFICATE` markers.
- The real certificate is environment-specific and is intentionally **not** committed or packaged in the distribution ZIP.
- Do not place proxy credentials or API keys in this directory.

The Proxy/Zscaler Compose overlay copies this CA into application images and refreshes the OS certificate trust store before package installation and at runtime.
