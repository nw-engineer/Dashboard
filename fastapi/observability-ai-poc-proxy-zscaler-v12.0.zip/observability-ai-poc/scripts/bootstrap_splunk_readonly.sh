#!/bin/sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"

set -a
# shellcheck disable=SC1091
. ./.env
set +a

: "${SPLUNK_PASSWORD:?SPLUNK_PASSWORD is required}"
: "${SPLUNK_SEARCH_PASSWORD:?SPLUNK_SEARCH_PASSWORD is required}"

compose() {
  docker compose -f docker-compose.yml -f compose.proxy.yml --profile splunk "$@"
}

mgmt_port="${SPLUNK_MGMT_HOST_PORT:-8089}"
base="https://localhost:${mgmt_port}"
admin_auth="admin:${SPLUNK_PASSWORD}"
search_user="${SPLUNK_SEARCH_USERNAME:-ai_search}"
search_auth="${search_user}:${SPLUNK_SEARCH_PASSWORD}"

echo "splunk-bootstrap: waiting for management endpoint"
i=0
until curl -ksSf -u "$admin_auth" "$base/services/server/info?output_mode=json" >/dev/null 2>&1; do
  i=$((i + 1))
  [ "$i" -lt 90 ] || { echo "splunk-bootstrap: FAIL: Splunk not ready" >&2; exit 2; }
  sleep 2
done

role_url="$base/services/authorization/roles/poc_ai_search"
role_args='capabilities=search&srchIndexesAllowed=poc_observability&srchIndexesDefault=poc_observability&srchTimeWin=7200&srchJobsQuota=3&cumulativeSrchJobsQuota=6'
if curl -ksSf -u "$admin_auth" "$role_url?output_mode=json" >/dev/null 2>&1; then
  curl -ksSf -u "$admin_auth" -X POST "$role_url" \
    -d capabilities=search \
    -d srchIndexesAllowed=poc_observability \
    -d srchIndexesDefault=poc_observability \
    -d srchTimeWin=7200 \
    -d srchJobsQuota=3 \
    -d cumulativeSrchJobsQuota=6 >/dev/null
else
  curl -ksSf -u "$admin_auth" -X POST "$base/services/authorization/roles" \
    -d name=poc_ai_search \
    -d capabilities=search \
    -d srchIndexesAllowed=poc_observability \
    -d srchIndexesDefault=poc_observability \
    -d srchTimeWin=7200 \
    -d srchJobsQuota=3 \
    -d cumulativeSrchJobsQuota=6 >/dev/null
fi
unset role_args
echo "splunk-bootstrap: PASS: role"

user_url="$base/services/authentication/users/${search_user}"
if curl -ksSf -u "$admin_auth" "$user_url?output_mode=json" >/dev/null 2>&1; then
  curl -ksSf -u "$admin_auth" -X POST "$user_url" \
    -d password="$SPLUNK_SEARCH_PASSWORD" \
    -d roles=poc_ai_search \
    -d force-change-pass=false >/dev/null
else
  curl -ksSf -u "$admin_auth" -X POST "$base/services/authentication/users" \
    -d name="$search_user" \
    -d password="$SPLUNK_SEARCH_PASSWORD" \
    -d roles=poc_ai_search \
    -d force-change-pass=false >/dev/null
fi
echo "splunk-bootstrap: PASS: user"

auth_file="$(mktemp)"
context_file="$(mktemp)"
search_file="$(mktemp)"
trap 'rm -f "$auth_file" "$context_file" "$search_file"' EXIT HUP INT TERM
cat > "$auth_file" <<'EOF'
[role_poc_ai_search]
edit_own_objects = disabled
list_all_objects = disabled
run_collect = disabled
run_mcollect = disabled
schedule_rtsearch = disabled
search = enabled
srchIndexesAllowed = poc_observability
srchIndexesDefault = poc_observability
srchTimeWin = 7200
EOF
compose cp "$auth_file" splunk:/opt/splunk/etc/system/local/authorize.conf >/dev/null
compose exec -T -u splunk splunk /opt/splunk/bin/splunk reload auth -auth "$admin_auth" >/dev/null
echo "splunk-bootstrap: PASS: authorize.conf"

curl -ksSf -u "$search_auth" \
  "$base/services/authentication/current-context?output_mode=json" > "$context_file"
python3 - "$context_file" <<'PY'
import json, sys
p = sys.argv[1]
data = json.load(open(p, encoding='utf-8'))
entries = data.get('entry') or []
if not entries:
    raise SystemExit('current-context returned no entry')
content = entries[0].get('content') or {}
caps = content.get('capabilities') or []
if isinstance(caps, str):
    caps = [caps]
if sorted(caps) != ['search']:
    raise SystemExit('effective capability set is not exactly search')
PY
echo "splunk-bootstrap: PASS: effective capability search-only"

internal_code="$(curl -ksS -o "$search_file" -w '%{http_code}' -u "$search_auth" \
  "$base/services/search/jobs/export" \
  --data-urlencode 'search=search index=_internal | head 1' \
  -d output_mode=json || true)"
case "$internal_code" in
  200)
    if grep -q '"result"' "$search_file"; then
      echo "splunk-bootstrap: FAIL: ai_search can read _internal" >&2
      exit 2
    fi
    ;;
  401|403) : ;;
  *) echo "splunk-bootstrap: FAIL: unexpected _internal verification status" >&2; exit 2 ;;
esac
echo "splunk-bootstrap: PASS: _internal inaccessible"

poc_code="$(curl -ksS -o "$search_file" -w '%{http_code}' -u "$search_auth" \
  "$base/services/search/jobs/export" \
  --data-urlencode 'search=search index=poc_observability | head 1' \
  -d output_mode=json || true)"
[ "$poc_code" = "200" ] || { echo "splunk-bootstrap: FAIL: poc_observability not searchable" >&2; exit 2; }
echo "splunk-bootstrap: PASS: poc_observability searchable"

echo "splunk-bootstrap: PASS"
