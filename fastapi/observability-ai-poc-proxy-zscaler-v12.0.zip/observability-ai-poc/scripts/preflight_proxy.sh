#!/bin/sh
set -eu

ROOT="${POC_ROOT:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)}"
ENV_FILE="$ROOT/.env"
CA_FILE="$ROOT/certs/zscaler-ca.crt"

fail() {
  echo "preflight: FAIL: $1" >&2
  exit 2
}

pass() {
  echo "preflight: PASS: $1"
}

[ -f "$ENV_FILE" ] || fail ".env is required"
[ -s "$CA_FILE" ] || fail "ZSCALER_CA file is required at certs/zscaler-ca.crt"
grep -q -- '-----BEGIN CERTIFICATE-----' "$CA_FILE" || fail "ZSCALER_CA must contain BEGIN CERTIFICATE"
grep -q -- '-----END CERTIFICATE-----' "$CA_FILE" || fail "ZSCALER_CA must contain END CERTIFICATE"
pass "ZSCALER_CA"

(
  unset HTTP_PROXY HTTPS_PROXY NO_PROXY http_proxy https_proxy no_proxy
  set -a
  # shellcheck disable=SC1090
  . "$ENV_FILE"
  set +a

  require_var() {
    name="$1"
    eval 'value=${'"$name"':-}'
    [ -n "$value" ] || fail "$name is required"
    pass "$name"
  }

  require_true() {
    name="$1"
    eval 'value=${'"$name"':-}'
    case "$(printf '%s' "$value" | tr '[:upper:]' '[:lower:]')" in
      1|true|yes|on) pass "$name" ;;
      *) fail "$name must be true for the full Proxy/Zscaler PoC stack" ;;
    esac
  }

  require_var HTTP_PROXY
  require_var HTTPS_PROXY
  require_var NO_PROXY

  for item in \
    localhost 127.0.0.1 ::1 \
    10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 \
    host.docker.internal splunk postgres scenario-controller payment-mock \
    payment-service inventory-service order-service api-gateway load-generator \
    newrelic-mcp console-api console-ui; do
    case ",${NO_PROXY}," in
      *",${item},"*) : ;;
      *) fail "NO_PROXY is missing required entry: $item" ;;
    esac
  done
  pass "NO_PROXY required entries"

  for name in \
    SPLUNK_PASSWORD SPLUNK_HEC_TOKEN SPLUNK_SEARCH_PASSWORD \
    NEW_RELIC_LICENSE_KEY NEW_RELIC_API_KEY NEW_RELIC_MCP_USER_KEY NEW_RELIC_ACCOUNT_ID; do
    require_var "$name"
  done
  require_true SPLUNK_HEC_ENABLED
  require_true NEW_RELIC_ENABLED

  provider="${LLM_PROVIDER:-ollama}"
  case "$provider" in
    ollama)
      pass "LLM_PROVIDER ollama"
      ;;
    azure_openai)
      require_var AZURE_OPENAI_API_KEY
      require_var AZURE_OPENAI_BASE_URL
      require_var AZURE_OPENAI_MODEL
      ;;
    openai)
      require_var OPENAI_API_KEY
      require_var OPENAI_MODEL
      ;;
    *) fail "LLM_PROVIDER must be ollama, azure_openai, or openai" ;;
  esac

  echo "preflight: PASS"
)
