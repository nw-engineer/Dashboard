#!/bin/sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"

compose() {
  docker compose -f docker-compose.yml -f compose.proxy.yml --profile splunk "$@"
}

for svc in api-gateway newrelic-mcp console-api; do
  compose exec -T "$svc" sh -lc \
    'test -s /usr/local/share/ca-certificates/zscaler-ca.crt && test -s /etc/ssl/certs/ca-certificates.crt'
  echo "proxy-ca-check: PASS: $svc"
done

echo "proxy-ca-check: PASS"
