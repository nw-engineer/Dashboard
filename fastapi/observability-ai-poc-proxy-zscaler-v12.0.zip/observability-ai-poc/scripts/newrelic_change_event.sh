#!/usr/bin/env bash
set -euo pipefail

required_vars=(
  NEW_RELIC_API_KEY
  NEW_RELIC_ENTITY_GUID
  DEPLOYMENT_ID
  SERVICE_VERSION
)

missing=()
for name in "${required_vars[@]}"; do
  if [[ -z "${!name:-}" ]]; then
    missing+=("$name")
  fi
done

if (( ${#missing[@]} > 0 )); then
  printf 'Missing required environment variable: %s\n' "${missing[@]}" >&2
  exit 2
fi

NEW_RELIC_NERDGRAPH_URL="${NEW_RELIC_NERDGRAPH_URL:-https://api.newrelic.com/graphql}"
GIT_SHA="${GIT_SHA:-unknown}"
CHANGE_USER="${NEW_RELIC_CHANGE_USER:-observability-ai-poc}"

query="$({
  python3 - \
    "$NEW_RELIC_ENTITY_GUID" \
    "$DEPLOYMENT_ID" \
    "$SERVICE_VERSION" \
    "$GIT_SHA" \
    "$CHANGE_USER" <<'PY'
import json
import sys

entity_guid, deployment_id, service_version, git_sha, user = sys.argv[1:]
q = json.dumps
entity_query = f"id = '{entity_guid}'"
short_description = f"PoC inventory-service deployment {service_version}"
description = (
    f"UC05 deployment {deployment_id}; service.version={service_version}; "
    f"git.sha={git_sha}"
)

print(f'''mutation {{
  changeTrackingCreateEvent(
    changeTrackingEvent: {{
      categoryAndTypeData: {{
        categoryFields: {{ deployment: {{ version: {q(service_version)} }} }}
        kind: {{ category: "deployment", type: "basic" }}
      }}
      user: {q(user)}
      groupId: {q(deployment_id)}
      shortDescription: {q(short_description)}
      description: {q(description)}
      customAttributes: {{
        serviceVersion: {q(service_version)}
        gitSha: {q(git_sha)}
      }}
      entitySearch: {{ query: {q(entity_query)} }}
    }}
  ) {{
    changeTrackingEvent {{
      changeTrackingId
      category
      type
      timestamp
      entity {{ name guid }}
    }}
    messages
  }}
}}''')
PY
})"

payload="$(GRAPHQL_QUERY="$query" python3 - <<'PY'
import json
import os
print(json.dumps({"query": os.environ["GRAPHQL_QUERY"]}))
PY
)"

response="$(curl \
  --fail-with-body \
  --silent \
  --show-error \
  "$NEW_RELIC_NERDGRAPH_URL" \
  -H 'Content-Type: application/json' \
  -H "API-Key: ${NEW_RELIC_API_KEY}" \
  --data-binary "$payload")"

printf '%s' "$response" | python3 -c '
import json
import sys

body = json.load(sys.stdin)
if body.get("errors"):
    print(json.dumps(body["errors"]), file=sys.stderr)
    raise SystemExit(1)
result = body.get("data", {}).get("changeTrackingCreateEvent", {})
event = result.get("changeTrackingEvent")
messages = result.get("messages") or []
print(json.dumps({"changeTrackingEvent": event, "messages": messages}, separators=(",", ":")))
'
