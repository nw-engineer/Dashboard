#!/bin/sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"

set -a
# shellcheck disable=SC1091
. ./.env
set +a

compose() {
  docker compose -f docker-compose.yml -f compose.proxy.yml --profile splunk "$@"
}

expected="splunk postgres scenario-controller payment-mock payment-service inventory-service order-service api-gateway load-generator newrelic-mcp console-api console-ui"
running="$(compose ps --status running --services)"
for svc in $expected; do
  printf '%s\n' "$running" | grep -qx "$svc" || {
    echo "stack-check: FAIL: $svc is not running" >&2
    exit 2
  }
done
echo "stack-check: PASS: services running"

mgmt_port="${SPLUNK_MGMT_HOST_PORT:-8089}"
hec_port="${SPLUNK_HEC_HOST_PORT:-8088}"
mcp_port="${NEW_RELIC_MCP_HOST_PORT:-8000}"
api_port="${CONSOLE_API_HOST_PORT:-8095}"
ui_port="${CONSOLE_UI_HOST_PORT:-5173}"

curl -ksSf -u "admin:${SPLUNK_PASSWORD}" \
  "https://localhost:${mgmt_port}/services/server/info?output_mode=json" >/dev/null
echo "stack-check: PASS: Splunk management"

hec_response="$(curl -sSf "http://localhost:${hec_port}/services/collector/event" \
  -H "Authorization: Splunk ${SPLUNK_HEC_TOKEN}" \
  -H 'Content-Type: application/json' \
  -d '{"index":"poc_observability","sourcetype":"poc:app:json","event":{"event_type":"hec.smoke","service.name":"verify-stack"}}')"
printf '%s' "$hec_response" | python3 -c 'import json,sys; assert json.load(sys.stdin).get("code") == 0'
echo "stack-check: PASS: Splunk HEC"

mcp_code="$(curl -sS -o /dev/null -w '%{http_code}' "http://localhost:${mcp_port}/mcp" || true)"
case "$mcp_code" in
  200|400|405) echo "stack-check: PASS: New Relic MCP" ;;
  *) echo "stack-check: FAIL: New Relic MCP endpoint" >&2; exit 2 ;;
esac

curl -fsS "http://localhost:${api_port}/openapi.json" >/dev/null
echo "stack-check: PASS: Console API"

curl -fsS "http://localhost:${ui_port}/" >/dev/null
echo "stack-check: PASS: Console UI"

echo "stack-check: PASS"
