from __future__ import annotations

from typing import Any


class OfficialAguiEventFactory:
    """Create AG-UI SDK event models without importing the optional SDK at module load."""

    def __init__(self) -> None:
        try:
            from ag_ui.core import (
                CustomEvent,
                EventType,
                RunErrorEvent,
                RunFinishedEvent,
                RunStartedEvent,
                StepFinishedEvent,
                StepStartedEvent,
            )
        except ImportError:
            raise RuntimeError(
                "ag-ui-protocol is required to serve the Phase 5 console API"
            ) from None
        self.CustomEvent = CustomEvent
        self.EventType = EventType
        self.RunErrorEvent = RunErrorEvent
        self.RunFinishedEvent = RunFinishedEvent
        self.RunStartedEvent = RunStartedEvent
        self.StepFinishedEvent = StepFinishedEvent
        self.StepStartedEvent = StepStartedEvent

    def run_started(self, *, thread_id: str, run_id: str):
        return self.RunStartedEvent(
            type=self.EventType.RUN_STARTED,
            thread_id=thread_id,
            run_id=run_id,
        )

    def step_started(self, step_name: str):
        return self.StepStartedEvent(
            type=self.EventType.STEP_STARTED,
            step_name=step_name,
        )

    def step_finished(self, step_name: str):
        return self.StepFinishedEvent(
            type=self.EventType.STEP_FINISHED,
            step_name=step_name,
        )

    def custom(self, *, name: str, value: Any):
        return self.CustomEvent(
            type=self.EventType.CUSTOM,
            name=name,
            value=value,
        )

    def run_finished(self, *, thread_id: str, run_id: str, result: Any):
        return self.RunFinishedEvent(
            type=self.EventType.RUN_FINISHED,
            thread_id=thread_id,
            run_id=run_id,
            result=result,
        )

    def run_error(self, *, message: str, code: str):
        return self.RunErrorEvent(
            type=self.EventType.RUN_ERROR,
            message=message,
            code=code,
        )


def create_official_encoder(accept: str | None):
    try:
        from ag_ui.encoder import EventEncoder
    except ImportError:
        raise RuntimeError(
            "ag-ui-protocol is required to encode the Phase 5 console stream"
        ) from None
    return EventEncoder(accept=accept)
