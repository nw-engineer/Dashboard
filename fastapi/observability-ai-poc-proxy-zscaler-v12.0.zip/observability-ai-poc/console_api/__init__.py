"""FastAPI adapter for the Phase 5 troubleshooting console."""
