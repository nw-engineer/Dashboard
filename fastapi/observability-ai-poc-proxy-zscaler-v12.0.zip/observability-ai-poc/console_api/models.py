from __future__ import annotations

from datetime import datetime, timedelta

from pydantic import BaseModel, field_validator, model_validator


class InvestigationStreamRequest(BaseModel):
    request_id: str
    earliest: datetime
    latest: datetime

    @field_validator("request_id")
    @classmethod
    def normalize_request_id(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("request_id must not be blank")
        return value

    @field_validator("earliest", "latest")
    @classmethod
    def require_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("datetime must be timezone-aware")
        return value

    @model_validator(mode="after")
    def validate_window(self):
        if self.earliest >= self.latest:
            raise ValueError("earliest must be before latest")
        if self.latest - self.earliest > timedelta(hours=2):
            raise ValueError("time window must not exceed two hours")
        return self
