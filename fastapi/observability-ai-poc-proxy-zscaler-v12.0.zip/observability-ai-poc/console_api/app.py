from __future__ import annotations

from collections.abc import Callable
from typing import Any

from fastapi import FastAPI, Header
from fastapi.responses import StreamingResponse

from console_api.agui_sdk import OfficialAguiEventFactory, create_official_encoder
from console_api.dependencies import build_orchestrator
from console_api.models import InvestigationStreamRequest
from console_api.stream import stream_investigation


def create_app(
    *,
    orchestrator_factory: Callable[[Any], Any] = build_orchestrator,
    event_factory: Any | None = None,
    encoder_factory: Callable[[str | None], Any] = create_official_encoder,
) -> FastAPI:
    app = FastAPI(title="Observability AI Troubleshooting Console API")

    @app.post("/api/investigations/stream")
    async def investigate(
        request: InvestigationStreamRequest,
        accept: str | None = Header(default="text/event-stream"),
    ):
        events = event_factory or OfficialAguiEventFactory()
        encoder = encoder_factory(accept)

        async def body():
            async for event in stream_investigation(
                request,
                orchestrator_factory,
                event_factory=events,
            ):
                yield encoder.encode(event)

        return StreamingResponse(
            body(),
            media_type=encoder.get_content_type(),
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
            },
        )

    return app


app = create_app()
