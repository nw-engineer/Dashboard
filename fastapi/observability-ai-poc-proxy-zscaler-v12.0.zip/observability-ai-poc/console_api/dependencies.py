from __future__ import annotations

import os

from agent.analysis.factory import create_incident_analyzer_from_env
from agent.evidence.correlation import CorrelationResolver
from agent.evidence.correlator import EvidenceCorrelator
from agent.evidence.newrelic_collector import NewRelicEvidenceCollector
from agent.evidence.newrelic_transport import StreamableHttpNewRelicMcpGateway
from agent.evidence.splunk_collector import SplunkEvidenceCollector
from agent.orchestrator import InvestigationOrchestrator
from agent.progress import InvestigationProgressReporter
from agent.splunk.client import SplunkSearchClient


def _env_bool(name: str, default: str = "false") -> bool:
    return os.getenv(name, default).lower() in {"1", "true", "yes", "on"}


def build_orchestrator(
    progress: InvestigationProgressReporter,
) -> InvestigationOrchestrator:
    splunk_password = os.getenv("SPLUNK_SEARCH_PASSWORD")
    new_relic_mcp_url = os.getenv("NEW_RELIC_MCP_URL")
    new_relic_account_id = os.getenv("NEW_RELIC_ACCOUNT_ID")
    if not splunk_password:
        raise RuntimeError("SPLUNK_SEARCH_PASSWORD is required")
    if not new_relic_mcp_url:
        raise RuntimeError("NEW_RELIC_MCP_URL is required")
    if not new_relic_account_id:
        raise RuntimeError("NEW_RELIC_ACCOUNT_ID is required")

    splunk = SplunkSearchClient(
        base_url=os.getenv("SPLUNK_SEARCH_URL", "https://localhost:8089"),
        username=os.getenv("SPLUNK_SEARCH_USERNAME", "ai_search"),
        password=splunk_password,
        verify_ssl=_env_bool("SPLUNK_SEARCH_VERIFY_SSL"),
        poll_interval=0.25,
        timeout_seconds=20.0,
    )
    account_id = int(new_relic_account_id)
    return InvestigationOrchestrator(
        resolver=CorrelationResolver(splunk),
        splunk_collector=SplunkEvidenceCollector(splunk),
        newrelic_collector=NewRelicEvidenceCollector(
            StreamableHttpNewRelicMcpGateway(new_relic_mcp_url),
            account_id=account_id,
        ),
        correlator=EvidenceCorrelator(),
        analyzer=create_incident_analyzer_from_env(),
        progress=progress,
    )
