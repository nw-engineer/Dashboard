from __future__ import annotations

from pydantic import BaseModel

from agent.analysis.azure_openai_adapter import (
    AzureOpenAIAnalysisError,
    AzureOpenAIConfigurationError,
)
from agent.analysis.ollama_adapter import OllamaAnalysisError, OllamaConfigurationError
from agent.analysis.openai_adapter import OpenAIAnalysisError, OpenAIConfigurationError
from agent.evidence.correlation import AmbiguousTraceId, CorrelationNotFound, TraceIdNotFound


class PublicInvestigationError(BaseModel):
    code: str
    message: str


_CORRELATION_NOT_FOUND = PublicInvestigationError(
    code="CORRELATION_NOT_FOUND",
    message="指定したリクエストIDと時間範囲に一致する相関トレースが見つかりませんでした。",
)
_CORRELATION_AMBIGUOUS = PublicInvestigationError(
    code="CORRELATION_AMBIGUOUS",
    message="指定したリクエストIDと時間範囲に一致する相関トレースが複数見つかりました。",
)
_LLM_ANALYSIS_FAILED = PublicInvestigationError(
    code="LLM_ANALYSIS_FAILED",
    message="LLM分析中に一時的なエラーが発生しました。再度実行してください。",
)
_LLM_CONFIGURATION_ERROR = PublicInvestigationError(
    code="LLM_CONFIGURATION_ERROR",
    message="LLM分析サービスの設定を確認してください。",
)
_GENERIC = PublicInvestigationError(
    code="INVESTIGATION_FAILED",
    message="調査を完了できませんでした。",
)

_LLM_ANALYSIS_ERRORS = (
    AzureOpenAIAnalysisError,
    OllamaAnalysisError,
    OpenAIAnalysisError,
)
_LLM_CONFIGURATION_ERRORS = (
    AzureOpenAIConfigurationError,
    OllamaConfigurationError,
    OpenAIConfigurationError,
)


def to_public_error(exc: Exception) -> PublicInvestigationError:
    if isinstance(exc, (CorrelationNotFound, TraceIdNotFound)):
        return _CORRELATION_NOT_FOUND.model_copy()
    if isinstance(exc, AmbiguousTraceId):
        return _CORRELATION_AMBIGUOUS.model_copy()
    if isinstance(exc, _LLM_CONFIGURATION_ERRORS):
        return _LLM_CONFIGURATION_ERROR.model_copy()
    if isinstance(exc, _LLM_ANALYSIS_ERRORS):
        return _LLM_ANALYSIS_FAILED.model_copy()
    return _GENERIC.model_copy()


def classify_internal_error(exc: Exception) -> str:
    if isinstance(exc, _LLM_CONFIGURATION_ERRORS):
        return "configuration_error"
    if not isinstance(exc, _LLM_ANALYSIS_ERRORS):
        return "investigation_failed"

    message = str(exc).lower()
    if "http 429" in message:
        return "rate_limit"
    if "http 401" in message or "http 403" in message:
        return "authentication_error"
    if "request failed" in message:
        return "request_failed"
    if "reference validation" in message:
        return "reference_validation_failed"
    if "structured output" in message or "invalid json" in message:
        return "invalid_model_output"
    if "refused" in message:
        return "model_refused"
    return "analysis_failed"
