from __future__ import annotations

import asyncio
import logging
import os
from collections.abc import AsyncIterator, Callable
from typing import Any, Protocol
from uuid import uuid4

from agent.progress import InvestigationProgressReporter
from agent.ui.a2ui import build_a2ui_messages
from agent.ui.presenter import present_investigation
from console_api.agui_sdk import OfficialAguiEventFactory
from console_api.errors import classify_internal_error, to_public_error
from console_api.models import InvestigationStreamRequest

logger = logging.getLogger(__name__)


class AguiEventFactory(Protocol):
    def run_started(self, *, thread_id: str, run_id: str) -> Any: ...
    def step_started(self, step_name: str) -> Any: ...
    def step_finished(self, step_name: str) -> Any: ...
    def custom(self, *, name: str, value: Any) -> Any: ...
    def run_finished(self, *, thread_id: str, run_id: str, result: Any) -> Any: ...
    def run_error(self, *, message: str, code: str) -> Any: ...


class QueueProgressReporter(InvestigationProgressReporter):
    def __init__(self, queue: asyncio.Queue[Any], event_factory: AguiEventFactory) -> None:
        self.queue = queue
        self.event_factory = event_factory
        self.current_step = "setup"

    async def step_started(self, step_name: str) -> None:
        self.current_step = step_name
        await self.queue.put(self.event_factory.step_started(step_name))

    async def step_finished(self, step_name: str) -> None:
        await self.queue.put(self.event_factory.step_finished(step_name))


async def _yield_progress_until_done(
    task: asyncio.Task[Any], queue: asyncio.Queue[Any]
) -> AsyncIterator[Any]:
    while True:
        if task.done():
            while not queue.empty():
                yield queue.get_nowait()
            return

        get_task = asyncio.create_task(queue.get())
        done, _ = await asyncio.wait(
            {task, get_task}, return_when=asyncio.FIRST_COMPLETED
        )
        if get_task in done:
            yield get_task.result()
            continue

        get_task.cancel()
        await asyncio.gather(get_task, return_exceptions=True)
        while not queue.empty():
            yield queue.get_nowait()
        return


def _llm_provider_and_model() -> tuple[str, str]:
    provider = os.getenv("LLM_PROVIDER", "ollama").strip().lower() or "ollama"
    model_env = {
        "azure_openai": "AZURE_OPENAI_MODEL",
        "openai": "OPENAI_MODEL",
        "ollama": "OLLAMA_MODEL",
    }.get(provider)
    model = os.getenv(model_env, "unknown") if model_env else "unknown"
    return provider, model or "unknown"


def _log_failure(exc: Exception, *, step: str) -> None:
    provider, model = _llm_provider_and_model()
    logger.error(
        "investigation_failed step=%s provider=%s model=%s error_type=%s exception_type=%s",
        step,
        provider,
        model,
        classify_internal_error(exc),
        type(exc).__name__,
    )


async def stream_investigation(
    request: InvestigationStreamRequest,
    orchestrator_factory: Callable[[InvestigationProgressReporter], Any],
    *,
    event_factory: AguiEventFactory | None = None,
    thread_id: str | None = None,
    run_id: str | None = None,
) -> AsyncIterator[Any]:
    event_factory = event_factory or OfficialAguiEventFactory()
    thread_id = thread_id or f"investigation-{uuid4()}"
    run_id = run_id or f"run-{uuid4()}"

    yield event_factory.run_started(thread_id=thread_id, run_id=run_id)

    queue: asyncio.Queue[Any] = asyncio.Queue()
    progress = QueueProgressReporter(queue, event_factory)
    try:
        orchestrator = orchestrator_factory(progress)
        task = asyncio.create_task(
            orchestrator.investigate_request_id(
                request.request_id,
                request.earliest,
                request.latest,
            )
        )
    except Exception as exc:
        _log_failure(exc, step=progress.current_step)
        public = to_public_error(exc)
        yield event_factory.run_error(message=public.message, code=public.code)
        return

    async for event in _yield_progress_until_done(task, queue):
        yield event

    try:
        result = await task
    except Exception as exc:
        _log_failure(exc, step=progress.current_step)
        public = to_public_error(exc)
        yield event_factory.run_error(message=public.message, code=public.code)
        return

    view = present_investigation(result)
    for message in build_a2ui_messages(view):
        yield event_factory.custom(name="a2ui.message", value=message)
    yield event_factory.run_finished(
        thread_id=thread_id,
        run_id=run_id,
        result={"investigationId": result.bundle.investigation_id},
    )
