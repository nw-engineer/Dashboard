# Observability AI PoC

Demo commerce system for five deterministic observability scenarios.

## Scenarios

- `NORMAL`
- `UC01_DB_SLOW`
- `UC02_PAYMENT_FAILURE`
- `UC03_APP_EXCEPTION`
- `UC04_HIGH_LOAD`
- `UC05_BAD_DEPLOYMENT`

## Local run

```bash
docker compose up -d --build
curl -fsS http://localhost:8085/health
curl -fsS http://localhost:8091/scenario
```

Set a scenario:

```bash
curl -fsS -X PUT http://localhost:8091/scenario \
  -H 'content-type: application/json' \
  -d '{"scenario":"UC01_DB_SLOW"}'
```

Reset to normal:

```bash
curl -fsS -X PUT http://localhost:8091/scenario \
  -H 'content-type: application/json' \
  -d '{"scenario":"NORMAL"}'
```

By default the API gateway is published as host `8085` -> container `8080`, and the scenario controller as host `8091` -> container `8090`. Override them with `GATEWAY_HOST_PORT` and `SCENARIO_HOST_PORT` if needed. Service-to-service traffic stays on the Compose network.

## Phase 2: New Relic APM

The FastAPI services are launched through `newrelic-admin run-program`. New Relic is disabled by default in Compose so the Phase 1 demo still starts without credentials.

Create or update `.env` locally (do not commit it):

```bash
NEW_RELIC_ENABLED=true
NEW_RELIC_LICENSE_KEY=<your New Relic ingest license key>
NEW_RELIC_DISTRIBUTED_TRACING_ENABLED=true
NEW_RELIC_APPLICATION_LOGGING_ENABLED=true
NEW_RELIC_APPLICATION_LOGGING_FORWARDING_ENABLED=false
DEPLOYMENT_ENVIRONMENT=poc
```

Rebuild after enabling the agent:

```bash
docker compose up -d --build
```

Generate one correlated order:

```bash
curl -fsS -X PUT http://localhost:${SCENARIO_HOST_PORT:-8091}/scenario \
  -H 'content-type: application/json' \
  -d '{"scenario":"NORMAL"}'

curl -i -X POST http://localhost:${GATEWAY_HOST_PORT:-8085}/orders \
  -H 'content-type: application/json' \
  -H 'X-Request-ID: nr-trace-demo-001' \
  -d '{"product_id":"SKU-001","quantity":1,"amount":1200}'
```

Run the vendor-neutral request correlation test from a Python 3.11 test container:

```bash
docker run --rm --network host -v "$PWD:/workspace" -w /workspace python:3.11-slim sh -lc "
  python -m pip install -q -e '.[dev]' &&
  POC_GATEWAY_URL=http://127.0.0.1:${GATEWAY_HOST_PORT:-8085} \
  POC_SCENARIO_URL=http://127.0.0.1:${SCENARIO_HOST_PORT:-8091} \
  python -m pytest tests/integration/test_trace_context.py -v
"
```

### New Relic evidence checklist

After generating traffic, confirm in New Relic that a distributed trace contains:

```text
poc-api-gateway
  -> poc-order-service
       -> poc-inventory-service
            -> PostgreSQL
       -> poc-payment-service
            -> poc-payment-mock
```

Also verify:

- `UC01_DB_SLOW`: datastore time dominates the inventory transaction.
- `UC02_PAYMENT_FAILURE`: the payment external call is slow/failing and the 502/503 path is visible.
- `UC03_APP_EXCEPTION`: an error group is created for the intentional application exception.
- Transaction/span attributes include `service.name`, `service.version`, `deployment.environment`, `request.id`, `scenario.id`, and the applicable product/order IDs.
- Application log forwarding to New Relic remains disabled; detailed logs will be sent to Splunk in Phase 3.

### UC05: New Relic Change Tracking event

UC05 uses the current NerdGraph Change Tracking Events API (`changeTrackingCreateEvent`) rather than the legacy deployment marker API.

The API key for this step is a New Relic **User key** for NerdGraph, not the ingest license key used by the Python APM agent.

Set these values in your local `.env` or export them in the shell. Do not commit secrets:

```bash
export NEW_RELIC_API_KEY='<New Relic User key>'
export NEW_RELIC_ENTITY_GUID='<poc-inventory-service entity GUID>'
export NEW_RELIC_NERDGRAPH_URL='https://api.newrelic.com/graphql'
export DEPLOYMENT_ID='uc05-demo-deploy-001'
export SERVICE_VERSION='1.1.0'
export GIT_SHA="$(git rev-parse --short HEAD 2>/dev/null || echo local-poc)"
```

For EU or JP accounts, use the corresponding NerdGraph endpoint:

```text
US: https://api.newrelic.com/graphql
EU: https://api.eu.newrelic.com/graphql
JP: https://api.jp.newrelic.com/graphql
```

Create the change event immediately before generating UC05 traffic:

```bash
bash scripts/newrelic_change_event.sh

curl -fsS -X PUT http://localhost:${SCENARIO_HOST_PORT:-8091}/scenario \
  -H 'content-type: application/json' \
  -d '{"scenario":"UC05_BAD_DEPLOYMENT"}'

for i in $(seq 1 20); do
  curl -fsS -X POST http://localhost:${GATEWAY_HOST_PORT:-8085}/orders \
    -H 'content-type: application/json' \
    -H "X-Request-ID: uc05-${i}" \
    -d '{"product_id":"SKU-001","quantity":1,"amount":1200}' >/dev/null
done
```

The script never prints `NEW_RELIC_API_KEY`. It records the deployment version in the Deployment category, uses `DEPLOYMENT_ID` as the change group ID, and records `deploymentId`, `serviceVersion`, and `gitSha` as custom attributes.

In New Relic, verify the change event aligns with the latency increase for `poc-inventory-service`. This is the evidence used later by the troubleshooting agent for the deployment-regression scenario.

## Phase 3 Splunk Search REST field expansion note (2026-09-03)

Splunk Search Job `/results` may omit search-time JSON fields that are present in `_raw` unless the SPL explicitly references or projects those fields. In live verification, a plain `request.id="..."` search returned `request.id` but omitted `trace.id`, even though `_raw` contained the same `trace.id`. Adding `| table ... trace.id` caused Splunk to return it explicitly.

`SplunkSearchClient` therefore expands top-level fields from `_raw` when `_raw` is a JSON object, while preserving fields already returned explicitly by Splunk. This keeps `request.id -> trace.id -> same trace` correlation stable without forcing every Agent query to append a fixed `table` projection.

## Phase 4 Core: Evidence Correlation

Phase 4 adds an evidence-first correlation layer without changing the Phase 1-3 observability data plane.

```text
request.id
  -> real Splunk trace.id
  -> real Splunk evidence + NewRelicMcpGateway evidence
  -> EvidenceBundle
  -> IncidentAnalyzer (provider-neutral contract)
```

### Safety boundary

- Splunk `ai_search` remains a search-only account restricted to `poc_observability`.
- All Splunk I/O continues through the existing guarded `SplunkSearchClient`.
- Splunk evidence copies only allow-listed factual fields; secrets and arbitrary raw fields are not promoted to `EvidenceItem.facts`.
- New Relic evidence is obtained only through `NewRelicMcpGateway`; Phase 4 adds no direct New Relic REST/NerdGraph client.
- Missing Span observations are represented as `EvidenceGap`; parent Transaction duration alone is not treated as proof of an internal service bottleneck.
- Contradictory source observations remain in the bundle and are surfaced as `EvidenceContradiction`.
- Recommended actions are advisory strings only. Phase 4 exposes no restart, rollback, delete, deploy, write, or configuration-mutation action.

### Phase 4 core VM integration test

The core integration slice uses real Demo Commerce + real Splunk and a deterministic MCP-shaped New Relic gateway response. This verifies the evidence model independently of the deployment-specific MCP transport.

```bash
export SPLUNK_SEARCH_PASSWORD="$SPLUNK_AI_SEARCH_PASSWORD"

docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e SPLUNK_SEARCH_URL=https://localhost:8089 \
  -e SPLUNK_SEARCH_USERNAME=ai_search \
  -e SPLUNK_SEARCH_PASSWORD \
  -e SPLUNK_SEARCH_VERIFY_SSL=false \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase4_evidence_integration.py -v
  "
```

Expected test:

```text
test_phase4_request_builds_cross_source_evidence_bundle PASSED
```

### New Relic MCP deployment adapter boundary

The Phase 3 deployment archive proves New Relic MCP is operational, but does not contain the concrete MCP transport/launcher contract. The Phase 4 core therefore remains transport-neutral. Before adding a live transport adapter, record (without secret values):

- launcher command/process;
- transport type (stdio, SSE, Streamable HTTP, or other);
- endpoint or stdio command;
- authentication mechanism name;
- client package used to call MCP tools, if any;
- known-working tool-call path for `execute_nrql_query`.

The live transport binding can then be implemented as a small adapter behind `NewRelicMcpGateway` without changing collectors, correlation rules, or analysis contracts.

## Phase 4: New Relic MCP Streamable HTTP transport

The live New Relic MCP server is expected to expose a stateful Streamable HTTP endpoint such as:

```text
http://localhost:8000/mcp
```

Configure the endpoint with:

```bash
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp
```

The adapter is implemented in `agent/evidence/newrelic_transport.py`. It uses the official MCP Python SDK, initializes a session for each tool operation, supports `tools/list` and `tools/call`, prefers structured tool output, and falls back to parsing JSON text content. Transport errors are surfaced without embedding server response text or secrets.

Live transport verification:

```bash
python -m pytest tests/integration/test_newrelic_mcp_transport_integration.py -v
```

The live test verifies that the MCP handshake succeeds and that the read-only tools required by Phase 4 (`execute_nrql_query` and `list_change_events`) are advertised by the server.

## Phase 4 v7: Live New Relic MCP contract

The live New Relic MCP server at `NEW_RELIC_MCP_URL` exposes a stateful Streamable HTTP endpoint.
The Phase 4 collector uses the live tool contracts discovered from `tools/list`:

- `execute_nrql_query(nrql_query: str, account_id: int)`
- `list_change_events(entity_guid: str, history_period_hours: int = 48)`

Set the account ID separately from credentials:

```bash
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp
export NEW_RELIC_ACCOUNT_ID=<account-id>
```

`CorrelationResolver` carries `service.name -> entity.guid` values observed in Splunk so Change Tracking calls can use an explicit New Relic entity GUID instead of guessing from the service name. New Relic epoch-millisecond timestamps are normalized to UTC datetimes.

The live cross-source test is:

```bash
python -m pytest tests/integration/test_phase4_live_cross_source.py -v
```

It requires `SPLUNK_SEARCH_PASSWORD`, `NEW_RELIC_MCP_URL`, and `NEW_RELIC_ACCOUNT_ID`. The test intentionally limits the live New Relic assertion to Transaction/Span evidence; Change Tracking response-shape verification remains a separate live contract check.

## Phase 4 v8: Change Tracking NRQL fallback

Live verification showed that `list_change_events` can fail inside the New Relic MCP server with a NerdGraph GraphQL fragment/type-overlap error even when the MCP transport, authentication, and `entity_guid` are valid.

Phase 4 therefore uses defense in depth for Change Tracking:

1. Call the specialized read-only MCP tool `list_change_events(entity_guid, history_period_hours)`.
2. If the tool raises, returns `ok=false`, or returns an unsupported payload, fall back to the same MCP server's read-only `execute_nrql_query` tool.
3. The fallback NRQL is deliberately SELECT-first because the MCP server's read-only guard requires the query string to begin with `SELECT`.
4. Query both `ChangeTrackingEvent` and legacy `Deployment`, filtered by the explicit `entity.guid` already correlated from Splunk.
5. Normalize the observed event into Deployment Evidence while preserving the specialized-tool call and fallback NRQL in Query Disclosure.

The fallback remains read-only and still traverses the New Relic MCP server; Phase 4 does not add a direct NerdGraph client.

Live Change Tracking verification requires:

```bash
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp
export NEW_RELIC_ACCOUNT_ID=<account-id>
export NEW_RELIC_ENTITY_GUID=<entity-guid>
export NEW_RELIC_ENTITY_NAME=poc-inventory-service

python -m pytest tests/integration/test_phase4_live_change_tracking.py -v
```

The live test asserts that a real Change Tracking/Deployment event is returned as Deployment Evidence and that the SELECT-first NRQL fallback is disclosed.

## Phase 4 v9: Real LLM Provider Adapter (OpenAI)

Phase 4 now includes a concrete `IncidentAnalyzer` implementation in
`agent/analysis/openai_adapter.py`.

The adapter keeps the Phase 4 core provider-neutral: collectors and the correlator still depend only on the existing `IncidentAnalyzer` protocol. The concrete OpenAI adapter is selected at composition time.

Safety and contract rules:

- uses the OpenAI Responses API at `/v1/responses`;
- sends only the already-normalized `EvidenceBundle` to the model;
- uses strict JSON Schema structured output for `IncidentAnalysis`;
- Pydantic validates the structured result before it is returned;
- `InvestigationOrchestrator` performs the existing Evidence ID / Query ID / Contradiction ID reference validation after analysis;
- `store=false` is always sent so the Response is not stored as application state by this request;
- the API key is read from `OPENAI_API_KEY` and is never embedded in query disclosure or exception text;
- upstream HTTP bodies and network-error details are not propagated by the adapter;
- recommended actions remain advisory only; no mutation tool is added.

Default PoC model:

```text
gpt-5.6-luna
```

Override it without changing code:

```bash
export OPENAI_API_KEY='<your-api-key>'
export OPENAI_MODEL=gpt-5.6-luna
export OPENAI_BASE_URL=https://api.openai.com/v1
export OPENAI_MAX_OUTPUT_TOKENS=2500
```

### Provider-only live test

This test proves the real LLM boundary independently of Splunk/New Relic availability:

```bash
python -m pytest tests/integration/test_phase4_live_openai_analysis.py -v
```

Expected:

```text
test_live_openai_analyzer_returns_reference_safe_incident_analysis PASSED
```

It executes:

```text
EvidenceBundle
  -> OpenAI Responses API
  -> strict IncidentAnalysis JSON
  -> Pydantic validation
  -> Evidence / Query reference validation
```

### Full Phase 4 live end-to-end test

After the v8 Change Tracking test and provider-only OpenAI test pass, run the complete path with real Demo Commerce, Splunk, New Relic MCP, and OpenAI:

```bash
export SPLUNK_SEARCH_URL=https://localhost:8089
export SPLUNK_SEARCH_USERNAME=ai_search
export SPLUNK_SEARCH_PASSWORD='<ai_search-password>'
export SPLUNK_SEARCH_VERIFY_SSL=false
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp
export NEW_RELIC_ACCOUNT_ID=8292460
export OPENAI_API_KEY='<your-api-key>'
export OPENAI_MODEL=gpt-5.6-luna

docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e SPLUNK_SEARCH_URL \
  -e SPLUNK_SEARCH_USERNAME \
  -e SPLUNK_SEARCH_PASSWORD \
  -e SPLUNK_SEARCH_VERIFY_SSL \
  -e NEW_RELIC_MCP_URL \
  -e NEW_RELIC_ACCOUNT_ID \
  -e OPENAI_API_KEY \
  -e OPENAI_MODEL \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase4_live_end_to_end.py -v
  "
```

Expected:

```text
test_live_phase4_real_sources_to_real_llm_incident_analysis PASSED
```

The test waits for the newly-created request to become visible in Splunk and New Relic before invoking the real analyzer. The final `InvestigationOrchestrator` call performs the reference-safety validation already required by Phase 4.

## Phase 4 v10.6: Multi-provider LLM (Ollama default + Azure OpenAI + OpenAI)

v10.6 keeps the Phase 4 `IncidentAnalyzer` protocol and Evidence-first validation unchanged while making the concrete LLM provider selectable through configuration.

```text
InvestigationOrchestrator
        |
        v
IncidentAnalyzer Protocol
        |
        +----------------------+----------------------+
        |                      |                      |
        v                      v                      v
OllamaIncidentAnalyzer   AzureOpenAIIncidentAnalyzer OpenAIIncidentAnalyzer
        |                      |                      |
        v                      v                      v
Ollama /api/chat         Azure /openai/v1/responses  OpenAI /v1/responses
```

Provider selection:

```bash
export LLM_PROVIDER=ollama          # default
# or
export LLM_PROVIDER=azure_openai
# or
export LLM_PROVIDER=openai
```

There is intentionally **no automatic provider failover**. An explicit provider switch is required so that cost, data residency, and security behavior cannot change silently.

### Local default: Ollama + gpt-oss:20b

Install/start Ollama on the VM according to the Ollama documentation, then pull the local model:

```bash
ollama pull gpt-oss:20b
ollama list
curl http://localhost:11434/api/tags
```

Configure the PoC:

```bash
export LLM_PROVIDER=ollama
export OLLAMA_BASE_URL=http://localhost:11434
export OLLAMA_MODEL=gpt-oss:20b
export OLLAMA_REASONING_EFFORT=medium
export OLLAMA_TIMEOUT_SECONDS=180
```

The adapter uses Ollama's native non-streaming `/api/chat` endpoint. A deliberately simple `IncidentAnalysis` JSON Schema (all object fields required, type constraints, and `additionalProperties=false`) is passed in `format` and is also included in the system instruction for schema grounding. Semantic Evidence-first rules that are difficult for Ollama to enforce reliably through compound JSON Schema keywords remain enforced by Pydantic and reference validation. In v10.6, the adapter validates Evidence/Query/Contradiction references before returning. If the first response fails either Pydantic validation or reference validation, the adapter sends the invalid JSON plus sanitized validation context back to the same local model for exactly one repair attempt. For reference failures, the repair prompt includes explicit allowed Evidence/Query/Contradiction IDs and identifies EvidenceGap IDs as invalid evidence references. The repaired JSON is Pydantic-validated and reference-validated again; a second failure is rejected. Network/HTTP failures are not retried, there is no provider failover, and application code never silently substitutes evidence IDs. Ollama's separate `message.thinking` value is ignored and is not copied into `IncidentAnalysis`.

Run the provider-only live test:

```bash
export RUN_OLLAMA_LIVE_TESTS=1
python -m pytest tests/integration/test_phase4_live_ollama_analysis.py -v
```

When running the test from the project Docker test pattern on Linux, pass the Ollama variables and use host networking so `localhost:11434` resolves to the VM host:

```bash
docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e LLM_PROVIDER \
  -e OLLAMA_BASE_URL \
  -e OLLAMA_MODEL \
  -e OLLAMA_REASONING_EFFORT \
  -e OLLAMA_TIMEOUT_SECONDS \
  -e RUN_OLLAMA_LIVE_TESTS \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase4_live_ollama_analysis.py -v
  "
```

### Azure OpenAI provider

Use the Azure OpenAI v1 base URL including `/openai/v1` and the deployed model/deployment name:

```bash
export LLM_PROVIDER=azure_openai
export AZURE_OPENAI_API_KEY='<set-in-shell-only>'
export AZURE_OPENAI_BASE_URL='https://<resource>.openai.azure.com/openai/v1'
export AZURE_OPENAI_MODEL='<deployment-name>'
export AZURE_OPENAI_MAX_OUTPUT_TOKENS=2500
export AZURE_OPENAI_TIMEOUT_SECONDS=60
```

The Azure adapter uses:

```text
POST {AZURE_OPENAI_BASE_URL}/responses
api-key: <AZURE_OPENAI_API_KEY>
```

and requests an Azure-compatible strict `IncidentAnalysis` JSON Schema under `text.format`. Azure Structured Outputs supports only a subset of JSON Schema, so the Azure schema removes unsupported keywords such as `minLength` and `minItems` while keeping all object fields required and `additionalProperties=false`. The schema is scoped to the current `EvidenceBundle`: evidence-reference arrays receive `enum` values containing only real `EvidenceItem.evidence_id` values, source-specific evidence arrays receive source-specific enums, and query/contradiction reference arrays are constrained to the IDs present in the bundle when such IDs exist. `EvidenceGap.gap_id` values are explicitly not evidence IDs and are never included in those enums. Since v10.5 the Azure adapter also performs reference validation before returning an analysis. If a Pydantic-valid response still cites an unknown Evidence, Query, or Contradiction ID, the adapter sends the invalid analysis, the reference-validation error, the original EvidenceBundle, and explicit allowed-ID lists back to the same Azure deployment for exactly one repair attempt. The repaired result is Pydantic-validated and reference-validated again; a second reference failure is rejected. Network, HTTP, refusal, and malformed structured-output errors are not retried. There is no provider failover.

Provider-only Azure live test:

```bash
export RUN_AZURE_OPENAI_LIVE_TESTS=1
python -m pytest tests/integration/test_phase4_live_azure_openai_analysis.py -v
```

### Existing OpenAI provider

The v9 OpenAI provider remains available:

```bash
export LLM_PROVIDER=openai
export OPENAI_API_KEY='<set-in-shell-only>'
export OPENAI_MODEL=gpt-5.6-luna
export OPENAI_BASE_URL=https://api.openai.com/v1
export OPENAI_MAX_OUTPUT_TOKENS=2500
```

### Provider-neutral full Phase 4 E2E

The full E2E test no longer constructs `OpenAIIncidentAnalyzer` directly. It calls `create_incident_analyzer_from_env()`, so the same observability pipeline can be tested against any configured provider.

For the default local PoC:

```bash
export LLM_PROVIDER=ollama
export RUN_OLLAMA_LIVE_TESTS=1

export SPLUNK_SEARCH_URL=https://localhost:8089
export SPLUNK_SEARCH_USERNAME=ai_search
export SPLUNK_SEARCH_PASSWORD='<set-in-shell-only>'
export SPLUNK_SEARCH_VERIFY_SSL=false

export NEW_RELIC_MCP_URL=http://localhost:8000/mcp
export NEW_RELIC_ACCOUNT_ID=8292460

python -m pytest tests/integration/test_phase4_live_end_to_end.py -v
```

The final path is:

```text
Demo Commerce
 -> Splunk
 -> request.id / trace.id correlation
 -> New Relic MCP
 -> EvidenceBundle
 -> selected IncidentAnalyzer
 -> IncidentAnalysis
 -> Evidence / Query / Contradiction reference validation
```

The Read Only and Evidence-first rules remain unchanged:

- New Relic and Splunk are observation sources only.
- Correlation is not causation.
- Missing Span evidence must not be replaced with an inferred internal bottleneck.
- Contradictions remain explicit evidence.
- Recommended actions are advisory only.
- Unknown Evidence IDs, Query IDs, and Contradiction IDs are rejected after LLM analysis.

## Phase 5: AG-UI + A2UI AI Troubleshooting Console

Phase 5 adds a read-only browser console on top of the completed Phase 4 Evidence-first core. Phase 4 domain contracts remain unchanged: the console renders only an already validated `InvestigationResult` and does not expose remediation/write controls.

### Architecture

```text
Browser / React
  -> POST /api/investigations/stream
  -> AG-UI SSE lifecycle + step events
  -> InvestigationOrchestrator (Phase 4)
  -> validated InvestigationResult
  -> deterministic A2UI v0.9.1 messages
  -> AG-UI CUSTOM(name="a2ui.message")
  -> @a2ui/web_core MessageProcessor
  -> @a2ui/react A2uiSurface
```

The first Phase 5 vertical slice accepts only:

- Request ID
- Earliest timestamp
- Latest timestamp

The search window is limited to two hours. Service, environment, and trace ID are derived from correlated evidence and displayed as result context rather than accepted as unused inputs.

### Safety boundary

- Splunk and New Relic access remains read-only.
- The React catalog is fixed to the troubleshooting display components in `console/src/a2ui/catalogContract.ts`.
- The server deterministically builds A2UI envelopes; the LLM does not generate React/HTML/component code.
- `EvidenceGap.gap_id` stays in a separate namespace and is never rendered as a supporting Evidence ID.
- Recommended actions are advisory text only. The result surface has no restart, rollback, deploy, delete, or configuration-mutation controls.
- Escaping backend exceptions are mapped to closed public `RUN_ERROR` messages; credentials and upstream response bodies are not streamed to the browser.

### Backend API

Install Python dependencies in the same Python 3.11 environment used for the PoC, then launch:

```bash
python -m pip install -e '.[dev]'
uvicorn console_api.app:app --host 0.0.0.0 --port 8095
```

The endpoint is:

```text
POST http://localhost:8095/api/investigations/stream
Content-Type: application/json
Accept: text/event-stream
```

Example request:

```json
{
  "request_id": "manual-trace-check-001",
  "earliest": "2026-09-04T00:00:00Z",
  "latest": "2026-09-04T00:10:00Z"
}
```

AG-UI progress uses the stable step names:

```text
correlation -> splunk -> newrelic -> correlate -> analyze
```

After analysis succeeds, the stream emits three `CUSTOM` events named `a2ui.message` containing A2UI v0.9.1 `createSurface`, `updateComponents`, and `updateDataModel` envelopes, followed by `RUN_FINISHED`.

### Frontend

The frontend uses Node.js, React, Vite, `@a2ui/web_core/v0_9`, and `@a2ui/react/v0_9`.

```bash
cd console
npm install
npm run dev -- --host 0.0.0.0
```

The Vite development server proxies `/api` to `http://localhost:8095`, so observability credentials remain only in the Python backend environment.

Production/type verification:

```bash
cd console
npm test
npm run build
```

Dependency-free core transport/safety tests can also be run with Node 22:

```bash
cd console
npm run test:core
```

### Phase 5 local verification

```bash
python -m pytest tests/unit -q
python -m pytest tests/integration/test_phase5_console_api.py -v
python -m compileall agent console_api shared services load_generator
```

### Phase 5 VM live smoke

Use the same environment variables that already pass the Phase 4 real-source/full-LLM E2E, plus:

```bash
export RUN_PHASE5_LIVE_TESTS=1
```

Then run:

```bash
docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e SPLUNK_SEARCH_URL \
  -e SPLUNK_SEARCH_USERNAME \
  -e SPLUNK_SEARCH_PASSWORD \
  -e SPLUNK_SEARCH_VERIFY_SSL \
  -e NEW_RELIC_MCP_URL \
  -e NEW_RELIC_ACCOUNT_ID \
  -e LLM_PROVIDER \
  -e OLLAMA_BASE_URL \
  -e OLLAMA_MODEL \
  -e OLLAMA_REASONING_EFFORT \
  -e OLLAMA_TIMEOUT_SECONDS \
  -e RUN_OLLAMA_LIVE_TESTS \
  -e RUN_PHASE5_LIVE_TESTS \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase5_live_console.py -v
  "
```

Expected:

```text
test_live_phase5_console_streams_progress_and_a2ui_result PASSED
```

After installing Phase 5 on the VM, re-run `tests/integration/test_phase4_live_end_to_end.py -v` once to confirm that the optional progress hooks did not change Phase 4 result behavior.

### Phase 5 Japanese-default UI and analysis (v11.2)

The troubleshooting console now defaults to Japanese without relying on browser translation.

- Fixed UI labels, progress labels, validation errors, public API errors, evidence summaries, and evidence-gap summaries are Japanese.
- `IncidentAnalysis` human-readable narrative fields are instructed to be generated in Japanese for Ollama / Azure OpenAI / OpenAI through the shared `ANALYSIS_CONTRACT`.
- Technical identifiers remain literal and are never translated: `request.id`, `trace.id`, Evidence IDs, Query Disclosure IDs, service names, event types, tool names, SPL, and NRQL.
- Confidence is rendered as `高 / 中 / 低`; timestamps use `ja-JP` formatting.
- The Evidence-first, reference-validation, and read-only/advisory safety boundaries are unchanged.

### Phase 5 v11.3: inclusive end-minute + safe LLM failure observability

v11.3 tightens three browser-console behaviors discovered during VM/browser validation:

1. A minute-resolution `終了日時` now includes the whole selected minute. For example, `09:25` is normalized to `09:25:59.999` before conversion to ISO, so an event at `09:25:18` is not accidentally excluded.
2. The empty A2UI result placeholder is Japanese: `検証済みの調査結果がここに表示されます。`
3. LLM failures are observable without leaking provider secrets or Evidence content.

Safe public error classes:

```text
LLM_ANALYSIS_FAILED
  LLM分析中に一時的なエラーが発生しました。再度実行してください。

LLM_CONFIGURATION_ERROR
  LLM分析サービスの設定を確認してください。
```

The server logs only safe operational metadata for failures:

```text
investigation_failed step=analyze provider=azure_openai model=gpt-5.6-sol error_type=rate_limit exception_type=AzureOpenAIAnalysisError
```

It does not log the exception text, API keys, request payload/EvidenceBundle, SPL, or NRQL as part of the failure record. Canonical `error_type` values include `rate_limit`, `authentication_error`, `request_failed`, `reference_validation_failed`, `invalid_model_output`, `model_refused`, `configuration_error`, and generic failure classes.

The two-hour limit is applied to the effective inclusive search window; selecting a minute range whose end-of-minute expansion would exceed two hours is rejected client-side.

## Proxy + Zscaler CA 環境へのデプロイ

Phase 5完了版をProxy + Zscaler CA環境へ新規導入する場合は、次の手順を使用してください。

- `docs/SETUP_PROXY_ZSCALER.md` - `.env`、CA配置、Splunk Read Only、New Relic MCP、Console API/UIまでの1からのセットアップ
- `docs/TESTING_PROXY_ZSCALER.md` - Python/Node/MCP/Proxy/CA/Splunk/LLM/Phase 4/Phase 5の検証手順

Docker daemonおよびベースイメージpull用のProxy設定は本プロジェクトでは変更しません。`docker pull` が可能な状態を環境管理者側で準備したうえで、`make proxy-preflight` -> `make proxy-up` -> `./scripts/bootstrap_splunk_readonly.sh` -> `make proxy-test` の順に進めてください。
