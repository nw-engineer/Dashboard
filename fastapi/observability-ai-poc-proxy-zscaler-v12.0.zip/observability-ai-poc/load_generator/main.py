import asyncio
import os

import httpx

from shared.logging import build_event, record_event
from shared.scenario import ScenarioId
from shared.scenario_client import ScenarioClient

GATEWAY_URL = os.getenv("GATEWAY_URL", "http://api-gateway:8080")


def requests_per_minute(scenario: ScenarioId) -> int:
    return 1000 if scenario is ScenarioId.UC04_HIGH_LOAD else 50


def record_load_profile(scenario: ScenarioId) -> None:
    record_event(build_event(
        "load.profile",
        service_name="load-generator",
        scenario_id=scenario.value,
        attributes={"requests_per_minute": requests_per_minute(scenario)},
    ))


async def send_order(client: httpx.AsyncClient, semaphore: asyncio.Semaphore) -> None:
    async with semaphore:
        try:
            await client.post(
                f"{GATEWAY_URL}/orders",
                json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
            )
        except httpx.HTTPError:
            return


async def run() -> None:
    scenario_client = ScenarioClient()
    concurrency = asyncio.Semaphore(50)
    last_scenario: ScenarioId | None = None
    async with httpx.AsyncClient(timeout=10.0) as client:
        while True:
            current = await scenario_client.get_current()
            if current is not last_scenario:
                record_load_profile(current)
                last_scenario = current
            rpm = requests_per_minute(current)
            asyncio.create_task(send_order(client, concurrency))
            await asyncio.sleep(60.0 / rpm)


if __name__ == "__main__":
    asyncio.run(run())
