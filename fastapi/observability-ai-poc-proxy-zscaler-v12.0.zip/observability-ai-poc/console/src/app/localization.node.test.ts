import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import test from 'node:test';

const read = (path: string) => readFileSync(new URL(path, import.meta.url), 'utf8');

test('console defaults to Japanese without browser translation', () => {
  const html = read('../../index.html');
  const app = read('./App.tsx');
  const form = read('../components/InvestigationForm.tsx');
  const progress = read('../state/progress.ts');
  const recommendation = read('../components/RecommendationCard.tsx');

  assert.match(html, /<html lang="ja">/);
  assert.match(html, /AIトラブルシューティングコンソール/);
  assert.match(app, /証拠優先のオブザーバビリティ/);
  assert.match(app, /読み取り専用/);
  assert.match(form, /リクエストID/);
  assert.match(form, /調査する/);
  assert.match(progress, /Splunkの調査/);
  assert.match(progress, /LLM分析/);
  assert.match(recommendation, /推奨される確認項目と対応策/);
  const health = read('../components/HealthSummary.tsx');
  const timeline = read('../components/TimelineChart.tsx');
  assert.match(health, /high: '高'/);
  assert.match(timeline, /toLocaleString\('ja-JP'\)/);
});

test('technical identifiers remain literal in the Japanese UI', () => {
  const trace = read('../components/TraceCard.tsx');
  const query = read('../components/QueryDisclosure.tsx');
  assert.match(trace, /Request ID/);
  assert.match(trace, /Trace ID/);
  assert.match(query, /query\.operation/);
  assert.match(query, /query\.disclosure_id/);
});


test('empty A2UI surface placeholder is Japanese', () => {
  const surface = read('../a2ui/TroubleshootingSurface.tsx');
  assert.match(surface, /検証済みの調査結果がここに表示されます。/);
  assert.doesNotMatch(surface, /Validated investigation results will appear here\./);
});
