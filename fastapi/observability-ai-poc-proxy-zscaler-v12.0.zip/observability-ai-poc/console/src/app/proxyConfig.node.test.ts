import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import test from 'node:test';

test('vite dev proxy target is environment configurable with localhost default', () => {
  const source = readFileSync(new URL('../../vite.config.ts', import.meta.url), 'utf8');
  assert.match(source, /VITE_DEV_API_PROXY_TARGET/);
  assert.match(source, /http:\/\/localhost:8095/);
});
