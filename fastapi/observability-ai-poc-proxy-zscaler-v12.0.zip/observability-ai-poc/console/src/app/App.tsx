import {useEffect, useRef, useState} from 'react';
import type {AguiEvent, InvestigationRequest} from '../api/investigationStream';
import {streamInvestigation} from '../api/investigationStream';
import {forwardA2uiCustomEvent} from '../a2ui/forwarding';
import {createTroubleshootingProcessor} from '../a2ui/processor';
import {TroubleshootingSurface} from '../a2ui/TroubleshootingSurface';
import {InvestigationForm} from '../components/InvestigationForm';
import {InvestigationProgress} from '../components/InvestigationProgress';
import {initialProgress, reduceProgress} from '../state/progress';

const GENERIC_NETWORK_ERROR = '調査ストリームを完了できませんでした。コンソールのバックエンドを確認して、もう一度実行してください。';

function eventType(event: AguiEvent): string | undefined {
  return typeof event.type === 'string' ? event.type : undefined;
}

export function App() {
  const [processor, setProcessor] = useState(() => createTroubleshootingProcessor());
  const [progress, setProgress] = useState(initialProgress);
  const [busy, setBusy] = useState(false);
  const [started, setStarted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => () => abortRef.current?.abort(), []);

  async function investigate(request: InvestigationRequest) {
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    const nextProcessor = createTroubleshootingProcessor();
    setProcessor(nextProcessor);
    setProgress(initialProgress());
    setError(null);
    setStarted(true);
    setBusy(true);

    const onEvent = (event: AguiEvent) => {
      setProgress((current) => reduceProgress(current, {
        type: event.type,
        stepName: event.stepName,
      }));
      forwardA2uiCustomEvent(nextProcessor, event);

      if (eventType(event) === 'RUN_ERROR') {
        setError(typeof event.message === 'string' ? event.message : '調査に失敗しました。');
        setBusy(false);
      } else if (eventType(event) === 'RUN_FINISHED') {
        setBusy(false);
      }
    };

    try {
      await streamInvestigation(request, onEvent, controller.signal);
    } catch (streamError) {
      if (streamError instanceof DOMException && streamError.name === 'AbortError') {
        return;
      }
      setError(GENERIC_NETWORK_ERROR);
      setBusy(false);
    }
  }

  return (
    <main className="app-shell">
      <header className="hero">
        <div>
          <p className="eyebrow">証拠優先のオブザーバビリティ</p>
          <h1>AIトラブルシューティングコンソール</h1>
          <p className="hero-copy">
            SplunkのログとNew Relic APMの証拠を関連付け、本番環境に変更を加えることなく、検証済みの結果を提示します。
          </p>
        </div>
        <span className="read-only-badge">読み取り専用</span>
      </header>

      <section className="control-panel" aria-label="調査条件">
        <InvestigationForm disabled={busy} onSubmit={investigate} />
      </section>

      <InvestigationProgress state={progress} visible={started} />
      {error && <div className="run-error" role="alert">{error}</div>}

      <TroubleshootingSurface processor={processor} />
    </main>
  );
}
