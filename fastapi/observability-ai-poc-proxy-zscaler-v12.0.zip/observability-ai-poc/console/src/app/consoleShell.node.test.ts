import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import test from 'node:test';

const read = (path: string) => readFileSync(new URL(path, import.meta.url), 'utf8');

test('fixed investigation form exposes only request id and time range inputs', () => {
  const source = read('../components/InvestigationForm.tsx');
  assert.match(source, /リクエストID/);
  assert.match(source, /開始日時/);
  assert.match(source, /終了日時/);
  assert.doesNotMatch(source, /Service[^A-Za-z]/);
  assert.doesNotMatch(source, /Environment[^A-Za-z]/);
  assert.doesNotMatch(source, /Question[^A-Za-z]/);
});

test('app wires AG-UI lifecycle and A2UI custom events without action controls', () => {
  const source = read('./App.tsx');
  assert.match(source, /streamInvestigation/);
  assert.match(source, /createTroubleshootingProcessor/);
  assert.match(source, /forwardA2uiCustomEvent/);
  assert.match(source, /RUN_ERROR/);
  assert.match(source, /RUN_FINISHED/);
  assert.doesNotMatch(source, /dangerouslySetInnerHTML/);
});
