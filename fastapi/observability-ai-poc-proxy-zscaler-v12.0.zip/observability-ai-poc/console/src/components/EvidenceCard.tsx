import {createComponentImplementation} from '@a2ui/react/v0_9';
import {EvidenceCardApi} from '../a2ui/componentApis';

export const EvidenceCard = createComponentImplementation(
  EvidenceCardApi,
  ({props}) => (
    <article className="panel evidence-card">
      <div className="panel-heading">
        <h3>証拠</h3>
        <code>{props.data.evidence_id}</code>
      </div>
      <p>{props.data.summary}</p>
      <div className="tag-row">
        <span>{props.data.source}</span><span>{props.data.category}</span>
        {props.data.service_name && <span>{props.data.service_name}</span>}
      </div>
      <details>
        <summary>証拠の詳細</summary>
        <p><strong>クエリ / ツール:</strong> {props.data.query_or_tool}</p>
        <pre>{JSON.stringify(props.data.facts, null, 2)}</pre>
      </details>
    </article>
  ),
);
