import {createComponentImplementation} from '@a2ui/react/v0_9';
import {TimelineChartApi} from '../a2ui/componentApis';

export const TimelineChart = createComponentImplementation(
  TimelineChartApi,
  ({props}) => (
    <section className="panel" aria-labelledby="timeline-title">
      <div className="panel-heading"><h3 id="timeline-title">証拠のタイムライン</h3></div>
      {props.data.length === 0 ? <p className="muted">時刻付きの証拠はありません。</p> : (
        <ol className="timeline">
          {props.data.map((item) => (
            <li key={item.evidence_id}>
              <time>{new Date(item.observed_at).toLocaleString('ja-JP')}</time>
              <strong>{item.service_name ?? item.source}</strong>
              <span>{item.summary}</span>
              <code>{item.evidence_id}</code>
            </li>
          ))}
        </ol>
      )}
    </section>
  ),
);
