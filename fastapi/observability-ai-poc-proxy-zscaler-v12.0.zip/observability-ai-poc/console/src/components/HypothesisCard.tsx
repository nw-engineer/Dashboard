import {createComponentImplementation} from '@a2ui/react/v0_9';
import {HypothesisCardApi} from '../a2ui/componentApis';

export const HypothesisCard = createComponentImplementation(
  HypothesisCardApi,
  ({props}) => (
    <section className="panel" aria-labelledby="hypotheses-title">
      <div className="panel-heading"><h3 id="hypotheses-title">代替仮説</h3></div>
      {props.data.length === 0 ? <p className="muted">代替仮説はありません。</p> : props.data.map((item, index) => (
        <article className="hypothesis" key={`${index}-${item.summary}`}>
          <p>{item.summary}</p>
          <p><strong>支持する証拠:</strong> {item.supporting_evidence_ids.join(', ') || '—'}</p>
          <p><strong>反証となる証拠:</strong> {item.opposing_evidence_ids.join(', ') || '—'}</p>
        </article>
      ))}
    </section>
  ),
);
