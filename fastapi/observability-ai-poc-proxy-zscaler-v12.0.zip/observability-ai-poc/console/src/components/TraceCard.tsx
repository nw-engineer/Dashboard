import {createComponentImplementation} from '@a2ui/react/v0_9';
import {TraceCardApi} from '../a2ui/componentApis';

export const TraceCard = createComponentImplementation(
  TraceCardApi,
  ({props}) => (
    <section className="panel trace-card" aria-labelledby="trace-title">
      <div className="panel-heading"><h3 id="trace-title">相関関係の文脈</h3></div>
      <dl className="trace-grid">
        <div><dt>Request ID</dt><dd><code>{props.data.request_id}</code></dd></div>
        <div><dt>Trace ID</dt><dd><code>{props.data.trace_id}</code></dd></div>
        <div><dt>環境</dt><dd>{props.data.environment === 'unknown' ? '不明' : props.data.environment}</dd></div>
        <div><dt>サービス</dt><dd>{props.data.services.join(', ') || '—'}</dd></div>
      </dl>
    </section>
  ),
);
