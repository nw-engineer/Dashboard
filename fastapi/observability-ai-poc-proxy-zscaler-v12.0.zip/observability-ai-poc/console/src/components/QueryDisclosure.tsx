import {createComponentImplementation} from '@a2ui/react/v0_9';
import {QueryDisclosureApi} from '../a2ui/componentApis';

export const QueryDisclosure = createComponentImplementation(
  QueryDisclosureApi,
  ({props}) => (
    <section className="panel" aria-labelledby="queries-title">
      <div className="panel-heading"><h3 id="queries-title">クエリ開示</h3></div>
      {props.data.length === 0 ? <p className="muted">開示するクエリはありません。</p> : props.data.map((query) => (
        <details key={query.disclosure_id}>
          <summary>{query.source} · {query.operation} · <code>{query.disclosure_id}</code></summary>
          <pre>{JSON.stringify(query.arguments, null, 2)}</pre>
        </details>
      ))}
    </section>
  ),
);
