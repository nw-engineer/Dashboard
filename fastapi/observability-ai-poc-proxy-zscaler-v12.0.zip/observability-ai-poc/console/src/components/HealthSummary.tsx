import {Fragment} from 'react';
import {createComponentImplementation} from '@a2ui/react/v0_9';
import {HealthSummaryApi} from '../a2ui/componentApis';

const CONFIDENCE_LABELS: Record<string, string> = {high: '高', medium: '中', low: '低'};

export const HealthSummary = createComponentImplementation(
  HealthSummaryApi,
  ({props, buildChild}) => (
    <section className="result-stack" aria-label="調査結果">
      <article className="panel health-summary">
        <div className="panel-heading">
          <p className="eyebrow">インシデント分析</p>
          <span className="confidence">信頼度: {CONFIDENCE_LABELS[props.data.confidence] ?? props.data.confidence}</span>
        </div>
        <h2>{props.data.incident_summary}</h2>
        <dl className="summary-grid">
          <div><dt>影響</dt><dd>{props.data.impact}</dd></div>
          <div><dt>考えられる原因</dt><dd>{props.data.likely_cause}</dd></div>
        </dl>
      </article>
      {props.children.map((childId: string) => (
        <Fragment key={childId}>{buildChild(childId)}</Fragment>
      ))}
    </section>
  ),
);
