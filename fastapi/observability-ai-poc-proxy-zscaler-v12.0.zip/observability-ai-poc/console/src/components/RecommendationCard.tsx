import {createComponentImplementation} from '@a2ui/react/v0_9';
import {RecommendationCardApi} from '../a2ui/componentApis';

export const RecommendationCard = createComponentImplementation(
  RecommendationCardApi,
  ({props}) => (
    <section className="panel recommendation-card" aria-labelledby="recommendations-title">
      <div className="panel-heading"><h3 id="recommendations-title">推奨される確認項目と対応策</h3></div>
      <div className="recommendation-columns">
        <div>
          <h4>確認項目</h4>
          <ul>{props.data.checks.map((item, index) => <li key={`${index}-${item}`}>{item}</li>)}</ul>
        </div>
        <div>
          <h4>推奨される行動</h4>
          <ul>{props.data.actions.map((item, index) => <li key={`${index}-${item}`}>{item}</li>)}</ul>
        </div>
      </div>
      <p className="advisory">これは情報提供のみを目的としており、このコンソールから何らかの操作が実行されることはありません。</p>
    </section>
  ),
);
