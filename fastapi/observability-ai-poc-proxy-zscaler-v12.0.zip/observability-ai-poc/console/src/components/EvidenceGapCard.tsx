import {createComponentImplementation} from '@a2ui/react/v0_9';
import {EvidenceGapCardApi} from '../a2ui/componentApis';

export const EvidenceGapCard = createComponentImplementation(
  EvidenceGapCardApi,
  ({props}) => (
    <article className="panel evidence-gap" aria-label="証拠の不足">
      <div className="panel-heading"><h3>証拠の不足</h3><code>{props.data.gap_id}</code></div>
      <p>{props.data.summary}</p>
      <p className="muted">
        {props.data.source ?? '不明なソース'} · {props.data.category ?? '未分類'}
      </p>
      <p className="gap-note">Gap IDはEvidence IDではなく、根拠となる証拠として引用されません。</p>
    </article>
  ),
);
