import {STEP_NAMES, type ProgressState, type StepStatus} from '../state/progress';

const STATUS_LABELS: Record<StepStatus, string> = {pending: '待機中', running: '実行中', finished: '終了'};

export function InvestigationProgress({state, visible}: {state: ProgressState; visible: boolean}) {
  if (!visible) {
    return null;
  }
  return (
    <section className="progress-panel" aria-label="調査の進捗" aria-live="polite">
      {STEP_NAMES.map((step) => (
        <div className={`progress-step ${state[step]}`} key={step}>
          <span className="progress-dot" aria-hidden="true" />
          <span>{state.labels[step]}</span>
          <small>{STATUS_LABELS[state[step]]}</small>
        </div>
      ))}
    </section>
  );
}
