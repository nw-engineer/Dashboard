import {createComponentImplementation} from '@a2ui/react/v0_9';
import {LogTableApi} from '../a2ui/componentApis';

export const LogTable = createComponentImplementation(
  LogTableApi,
  ({props}) => (
    <section className="panel" aria-labelledby="logs-title">
      <div className="panel-heading"><h3 id="logs-title">Splunkログの証拠</h3></div>
      {props.data.length === 0 ? <p className="muted">Splunkの証拠はありません。</p> : (
        <div className="table-scroll">
          <table>
            <thead><tr><th>ID</th><th>サービス</th><th>カテゴリ</th><th>概要</th></tr></thead>
            <tbody>
              {props.data.map((row) => (
                <tr key={row.evidence_id}>
                  <td><code>{row.evidence_id}</code></td>
                  <td>{row.service_name ?? '—'}</td>
                  <td>{row.category}</td>
                  <td>{row.summary}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  ),
);
