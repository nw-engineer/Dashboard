import type {InvestigationRequest} from '../api/investigationStream.ts';

export type InvestigationFormInput = {
  requestId: string;
  earliest: string;
  latest: string;
};

const MAX_WINDOW_MS = 2 * 60 * 60 * 1000;

export function normalizeInvestigationInput(
  input: InvestigationFormInput,
): InvestigationRequest {
  const requestId = input.requestId.trim();
  if (!requestId) {
    throw new Error('リクエストIDを入力してください');
  }

  const earliest = new Date(input.earliest);
  const latest = new Date(input.latest);
  if (Number.isNaN(earliest.valueOf()) || Number.isNaN(latest.valueOf())) {
    throw new Error('有効な時間範囲を指定してください');
  }

  const inclusiveLatest = new Date(latest.valueOf());
  inclusiveLatest.setSeconds(59, 999);
  const windowMs = inclusiveLatest.valueOf() - earliest.valueOf();
  if (windowMs <= 0) {
    throw new Error('終了日時は開始日時より後にしてください');
  }
  if (windowMs > MAX_WINDOW_MS) {
    throw new Error('時間範囲は2時間以内にしてください');
  }

  return {
    request_id: requestId,
    earliest: earliest.toISOString(),
    latest: inclusiveLatest.toISOString(),
  };
}
