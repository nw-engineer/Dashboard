import assert from 'node:assert/strict';
import test from 'node:test';

import {normalizeInvestigationInput} from './formValidation.ts';


test('normalizeInvestigationInput trims id and converts local dates to ISO', () => {
  const value = normalizeInvestigationInput({
    requestId: '  req-1 ',
    earliest: '2026-09-04T08:00',
    latest: '2026-09-04T08:10',
  });
  assert.equal(value.request_id, 'req-1');
  assert.match(value.earliest, /Z$/);
  assert.match(value.latest, /Z$/);
});


test('normalizeInvestigationInput rejects blank id and windows over two hours', () => {
  assert.throws(() => normalizeInvestigationInput({
    requestId: ' ',
    earliest: '2026-09-04T08:00',
    latest: '2026-09-04T08:10',
  }));
  assert.throws(() => normalizeInvestigationInput({
    requestId: 'req-1',
    earliest: '2026-09-04T08:00',
    latest: '2026-09-04T10:00:01',
  }));
});


test('normalizeInvestigationInput includes the entire selected latest minute', () => {
  const value = normalizeInvestigationInput({
    requestId: 'req-1',
    earliest: '2026-09-04T09:09',
    latest: '2026-09-04T09:25',
  });

  const latest = new Date(value.latest);
  assert.equal(latest.getSeconds(), 59);
  assert.equal(latest.getMilliseconds(), 999);
});


test('normalizeInvestigationInput keeps the effective search window within two hours', () => {
  assert.throws(() => normalizeInvestigationInput({
    requestId: 'req-1',
    earliest: '2026-09-04T08:00',
    latest: '2026-09-04T10:00',
  }), /2時間以内/);
});
