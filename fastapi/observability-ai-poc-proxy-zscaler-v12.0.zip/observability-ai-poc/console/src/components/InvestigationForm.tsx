import {useState, type FormEvent} from 'react';
import type {InvestigationRequest} from '../api/investigationStream';
import {normalizeInvestigationInput} from './formValidation';

function toLocalInput(date: Date): string {
  const offset = date.getTimezoneOffset() * 60_000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 16);
}

export function InvestigationForm({
  disabled,
  onSubmit,
}: {
  disabled: boolean;
  onSubmit: (request: InvestigationRequest) => void;
}) {
  const now = new Date();
  const [requestId, setRequestId] = useState('');
  const [earliest, setEarliest] = useState(() => toLocalInput(new Date(now.getTime() - 15 * 60_000)));
  const [latest, setLatest] = useState(() => toLocalInput(now));
  const [validationError, setValidationError] = useState<string | null>(null);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try {
      const request = normalizeInvestigationInput({requestId, earliest, latest});
      setValidationError(null);
      onSubmit(request);
    } catch (error) {
      setValidationError(error instanceof Error ? error.message : '調査条件が正しくありません');
    }
  }

  return (
    <form className="investigation-form" onSubmit={submit}>
      <label>
        <span>リクエストID</span>
        <input
          name="requestId"
          value={requestId}
          onChange={(event) => setRequestId(event.target.value)}
          placeholder="request-123"
          disabled={disabled}
          autoComplete="off"
        />
      </label>
      <label>
        <span>開始日時</span>
        <input
          name="earliest"
          type="datetime-local"
          value={earliest}
          onChange={(event) => setEarliest(event.target.value)}
          disabled={disabled}
        />
      </label>
      <label>
        <span>終了日時</span>
        <input
          name="latest"
          type="datetime-local"
          value={latest}
          onChange={(event) => setLatest(event.target.value)}
          disabled={disabled}
        />
      </label>
      <div className="form-submit">
        <button type="submit" disabled={disabled}>{disabled ? '調査中…' : '調査する'}</button>
        {validationError && <p className="form-error" role="alert">{validationError}</p>}
      </div>
    </form>
  );
}
