import assert from 'node:assert/strict';
import test from 'node:test';

import {SseJsonParser} from './investigationStream.ts';


test('SseJsonParser emits complete JSON events across split chunks', () => {
  const parser = new SseJsonParser();
  const events = [
    ...parser.feed('data: {"type":"RUN_STAR'),
    ...parser.feed('TED","runId":"r1"}\n\n: keepalive\n\n'),
    ...parser.feed('data: {"type":"STEP_STARTED",\n'),
    ...parser.feed('data: "stepName":"splunk"}\n\n'),
  ];

  assert.deepEqual(events, [
    {type: 'RUN_STARTED', runId: 'r1'},
    {type: 'STEP_STARTED', stepName: 'splunk'},
  ]);
});


test('SseJsonParser ignores blank and comment-only event blocks', () => {
  const parser = new SseJsonParser();
  assert.deepEqual(parser.feed(': heartbeat\n\n\n\n'), []);
});
