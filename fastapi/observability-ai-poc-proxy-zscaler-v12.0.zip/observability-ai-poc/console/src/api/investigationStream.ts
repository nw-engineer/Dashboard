export type InvestigationRequest = {
  request_id: string;
  earliest: string;
  latest: string;
};

export type AguiEvent = Record<string, unknown>;

export class SseJsonParser {
  private buffer = '';

  feed(chunk: string): AguiEvent[] {
    this.buffer += chunk;
    const events: AguiEvent[] = [];

    for (;;) {
      const separator = this.buffer.match(/\r?\n\r?\n/);
      if (!separator || separator.index === undefined) {
        break;
      }

      const block = this.buffer.slice(0, separator.index);
      this.buffer = this.buffer.slice(separator.index + separator[0].length);
      const dataLines = block
        .split(/\r?\n/)
        .filter((line) => line.startsWith('data:'))
        .map((line) => line.slice(5).replace(/^ /, ''));

      if (dataLines.length === 0) {
        continue;
      }

      events.push(JSON.parse(dataLines.join('\n')) as AguiEvent);
    }

    return events;
  }
}

export async function streamInvestigation(
  input: InvestigationRequest,
  onEvent: (event: AguiEvent) => void,
  signal?: AbortSignal,
): Promise<void> {
  const response = await fetch('/api/investigations/stream', {
    method: 'POST',
    headers: {
      Accept: 'text/event-stream',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(input),
    signal,
  });

  if (!response.ok) {
    throw new Error(`Investigation request failed (${response.status})`);
  }
  if (!response.body) {
    throw new Error('Streaming response body unavailable');
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  const parser = new SseJsonParser();

  for (;;) {
    const {done, value} = await reader.read();
    if (done) {
      break;
    }
    for (const event of parser.feed(decoder.decode(value, {stream: true}))) {
      onEvent(event);
    }
  }

  for (const event of parser.feed(decoder.decode())) {
    onEvent(event);
  }
}
