export const STEP_NAMES = [
  'correlation',
  'splunk',
  'newrelic',
  'correlate',
  'analyze',
] as const;

export type StepName = (typeof STEP_NAMES)[number];
export type StepStatus = 'pending' | 'running' | 'finished';

export type ProgressState = Record<StepName, StepStatus> & {
  labels: Record<StepName, string>;
};

const LABELS: Record<StepName, string> = {
  correlation: '相関',
  splunk: 'Splunkの調査',
  newrelic: 'New Relicの調査',
  correlate: '証拠の相関',
  analyze: 'LLM分析',
};

export function initialProgress(): ProgressState {
  return {
    correlation: 'pending',
    splunk: 'pending',
    newrelic: 'pending',
    correlate: 'pending',
    analyze: 'pending',
    labels: {...LABELS},
  };
}

export function reduceProgress(
  state: ProgressState,
  event: {type?: unknown; stepName?: unknown},
): ProgressState {
  if (
    (event.type !== 'STEP_STARTED' && event.type !== 'STEP_FINISHED') ||
    typeof event.stepName !== 'string' ||
    !STEP_NAMES.includes(event.stepName as StepName)
  ) {
    return state;
  }

  const stepName = event.stepName as StepName;
  return {
    ...state,
    [stepName]: event.type === 'STEP_STARTED' ? 'running' : 'finished',
  };
}
