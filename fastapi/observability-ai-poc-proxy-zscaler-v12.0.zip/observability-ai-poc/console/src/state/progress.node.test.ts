import assert from 'node:assert/strict';
import test from 'node:test';

import {initialProgress, reduceProgress} from './progress.ts';


test('reduceProgress tracks the five stable AG-UI steps', () => {
  let state = initialProgress();
  state = reduceProgress(state, {type: 'STEP_STARTED', stepName: 'splunk'});
  assert.equal(state.splunk, 'running');
  state = reduceProgress(state, {type: 'STEP_FINISHED', stepName: 'splunk'});
  assert.equal(state.splunk, 'finished');
  assert.equal(state.labels.splunk, 'Splunkの調査');
});


test('reduceProgress ignores unknown step names', () => {
  const state = initialProgress();
  assert.deepEqual(
    reduceProgress(state, {type: 'STEP_STARTED', stepName: 'untrusted-step'}),
    state,
  );
});
