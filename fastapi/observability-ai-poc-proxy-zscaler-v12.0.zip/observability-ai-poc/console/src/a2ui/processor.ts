import {MessageProcessor} from '@a2ui/web_core/v0_9';
import {troubleshootingCatalog} from './catalog';

export function createTroubleshootingProcessor() {
  return new MessageProcessor([troubleshootingCatalog]);
}

export type TroubleshootingProcessor = ReturnType<typeof createTroubleshootingProcessor>;
