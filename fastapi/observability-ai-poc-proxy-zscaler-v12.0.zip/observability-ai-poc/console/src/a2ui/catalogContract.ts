export const TROUBLESHOOTING_CATALOG_ID = 'dev.observability:troubleshooting-v1';

export const APPROVED_COMPONENT_NAMES = [
  'HealthSummary',
  'TimelineChart',
  'TraceCard',
  'EvidenceCard',
  'EvidenceGapCard',
  'LogTable',
  'HypothesisCard',
  'RecommendationCard',
  'QueryDisclosure',
] as const;

export type ApprovedComponentName = (typeof APPROVED_COMPONENT_NAMES)[number];
