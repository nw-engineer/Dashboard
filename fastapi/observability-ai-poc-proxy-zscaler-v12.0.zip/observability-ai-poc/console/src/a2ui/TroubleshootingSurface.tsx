import {useEffect, useState} from 'react';
import {A2uiSurface} from '@a2ui/react/v0_9';
import type {TroubleshootingProcessor} from './processor';

export function TroubleshootingSurface({processor}: {processor: TroubleshootingProcessor}) {
  const [surfaces, setSurfaces] = useState(() => Array.from(processor.model.surfacesMap.values()));

  useEffect(() => {
    const sync = () => setSurfaces(Array.from(processor.model.surfacesMap.values()));
    const created = processor.onSurfaceCreated(sync);
    const deleted = processor.onSurfaceDeleted(sync);
    sync();
    return () => {
      created.unsubscribe();
      deleted.unsubscribe();
    };
  }, [processor]);

  if (surfaces.length === 0) {
    return <div className="result-placeholder">検証済みの調査結果がここに表示されます。</div>;
  }

  return (
    <div className="a2ui-surfaces">
      {surfaces.map((surface) => <A2uiSurface key={surface.id} surface={surface} />)}
    </div>
  );
}
