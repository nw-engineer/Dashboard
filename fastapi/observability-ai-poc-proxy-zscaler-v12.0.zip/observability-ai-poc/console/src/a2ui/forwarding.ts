import type {TroubleshootingProcessor} from './processor';

type ProcessorInput = Parameters<TroubleshootingProcessor['processMessages']>[0];
type A2uiMessageBatch = Extract<ProcessorInput, unknown[]>;
type A2uiMessage = A2uiMessageBatch[number];

export type A2uiMessageProcessor = {
  processMessages(messages: A2uiMessageBatch): unknown;
};

export function forwardA2uiCustomEvent(
  processor: A2uiMessageProcessor,
  event: {type?: unknown; name?: unknown; value?: unknown},
): boolean {
  if (event.type !== 'CUSTOM' || event.name !== 'a2ui.message' || !('value' in event)) {
    return false;
  }
  processor.processMessages([event.value as A2uiMessage]);
  return true;
}
