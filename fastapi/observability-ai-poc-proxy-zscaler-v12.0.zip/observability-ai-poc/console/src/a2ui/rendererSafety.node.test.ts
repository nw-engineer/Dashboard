import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import test from 'node:test';

const read = (path: string) => readFileSync(new URL(path, import.meta.url), 'utf8');

test('recommendation renderer is advisory-only and exposes no remediation control', () => {
  const source = read('../components/RecommendationCard.tsx');
  assert.match(source, /情報提供のみ/);
  assert.doesNotMatch(source, /<button\b/i);
  assert.doesNotMatch(source, /dangerouslySetInnerHTML/i);
  assert.doesNotMatch(source, /onClick\s*=/i);
});

test('troubleshooting catalog uses fixed custom component implementations only', () => {
  const source = read('./catalog.tsx');
  assert.match(source, /new Catalog\(/);
  assert.match(source, /TROUBLESHOOTING_CATALOG_ID/);
  assert.doesNotMatch(source, /basicCatalog/);
  assert.doesNotMatch(source, /ButtonImplementation|TextField|ChoicePicker/);
});

test('processor wrapper uses the official v0_9 MessageProcessor with the fixed catalog', () => {
  const source = read('./processor.ts');
  assert.match(source, /MessageProcessor/);
  assert.match(source, /@a2ui\/web_core\/v0_9/);
  assert.match(source, /troubleshootingCatalog/);
});

test('surface renderer uses official A2uiSurface and disposes subscriptions', () => {
  const source = read('./TroubleshootingSurface.tsx');
  assert.match(source, /A2uiSurface/);
  assert.match(source, /@a2ui\/react\/v0_9/);
  assert.match(source, /unsubscribe\(\)/);
});

test('A2UI forwarding narrows the processor batch type from the official processor signature', () => {
  const source = read('./forwarding.ts');
  assert.match(source, /TroubleshootingProcessor/);
  assert.match(source, /Extract<ProcessorInput, unknown\[\]>/);
  assert.doesNotMatch(source, /processMessages\(messages: unknown\[\]\)/);
});

test('HealthSummary gives child ids an explicit string type under strict TypeScript', () => {
  const source = read('../components/HealthSummary.tsx');
  assert.match(source, /map\(\(childId: string\)/);
});
