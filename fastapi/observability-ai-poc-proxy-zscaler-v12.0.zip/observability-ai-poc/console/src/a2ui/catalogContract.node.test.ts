import assert from 'node:assert/strict';
import test from 'node:test';

import {
  APPROVED_COMPONENT_NAMES,
  TROUBLESHOOTING_CATALOG_ID,
} from './catalogContract.ts';


test('catalog contract exposes only approved read-only troubleshooting components', () => {
  assert.equal(TROUBLESHOOTING_CATALOG_ID, 'dev.observability:troubleshooting-v1');
  assert.deepEqual(APPROVED_COMPONENT_NAMES, [
    'HealthSummary',
    'TimelineChart',
    'TraceCard',
    'EvidenceCard',
    'EvidenceGapCard',
    'LogTable',
    'HypothesisCard',
    'RecommendationCard',
    'QueryDisclosure',
  ]);
  assert.equal(APPROVED_COMPONENT_NAMES.includes('Button' as never), false);
});
