import {z} from 'zod';

const nullableString = z.string().nullable().optional();
const evidenceData = z.object({
  evidence_id: z.string(),
  source: z.string(),
  category: z.string(),
  summary: z.string(),
  service_name: nullableString,
  observed_at: nullableString,
  query_or_tool: z.string(),
  facts: z.record(z.any()),
});

export const HealthSummaryApi = {
  name: 'HealthSummary',
  schema: z.object({
    data: z.object({
      incident_summary: z.string(),
      impact: z.string(),
      likely_cause: z.string(),
      confidence: z.string(),
    }),
    children: z.array(z.string()),
  }),
};

export const TimelineChartApi = {
  name: 'TimelineChart',
  schema: z.object({
    data: z.array(z.object({
      evidence_id: z.string(),
      source: z.string(),
      category: z.string(),
      service_name: nullableString,
      observed_at: z.string(),
      summary: z.string(),
    })),
  }),
};

export const TraceCardApi = {
  name: 'TraceCard',
  schema: z.object({
    data: z.object({
      investigation_id: z.string(),
      request_id: z.string(),
      trace_id: z.string(),
      services: z.array(z.string()),
      environment: z.string(),
    }),
  }),
};

export const EvidenceCardApi = {
  name: 'EvidenceCard',
  schema: z.object({data: evidenceData}),
};

export const EvidenceGapCardApi = {
  name: 'EvidenceGapCard',
  schema: z.object({
    data: z.object({
      gap_id: z.string(),
      source: nullableString,
      category: nullableString,
      summary: z.string(),
    }),
  }),
};

export const LogTableApi = {
  name: 'LogTable',
  schema: z.object({data: z.array(evidenceData)}),
};

export const HypothesisCardApi = {
  name: 'HypothesisCard',
  schema: z.object({
    data: z.array(z.object({
      summary: z.string(),
      supporting_evidence_ids: z.array(z.string()),
      opposing_evidence_ids: z.array(z.string()),
    })),
  }),
};

export const RecommendationCardApi = {
  name: 'RecommendationCard',
  schema: z.object({
    data: z.object({
      checks: z.array(z.string()),
      actions: z.array(z.string()),
    }),
  }),
};

export const QueryDisclosureApi = {
  name: 'QueryDisclosure',
  schema: z.object({
    data: z.array(z.object({
      disclosure_id: z.string(),
      source: z.string(),
      operation: z.string(),
      arguments: z.record(z.any()),
    })),
  }),
};
