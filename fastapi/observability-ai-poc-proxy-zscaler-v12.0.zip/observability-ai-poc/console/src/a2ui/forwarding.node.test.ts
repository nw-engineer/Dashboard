import assert from 'node:assert/strict';
import test from 'node:test';

import {forwardA2uiCustomEvent} from './forwarding.ts';


test('forwardA2uiCustomEvent forwards only a2ui.message custom events', () => {
  const received: unknown[] = [];
  const processor = {processMessages: (messages: unknown[]) => received.push(...messages)};

  assert.equal(forwardA2uiCustomEvent(processor, {type: 'CUSTOM', name: 'other', value: {x: 1}}), false);
  assert.equal(forwardA2uiCustomEvent(processor, {
    type: 'CUSTOM',
    name: 'a2ui.message',
    value: {version: 'v0.9.1', createSurface: {surfaceId: 'inv-1'}},
  }), true);
  assert.deepEqual(received, [
    {version: 'v0.9.1', createSurface: {surfaceId: 'inv-1'}},
  ]);
});
