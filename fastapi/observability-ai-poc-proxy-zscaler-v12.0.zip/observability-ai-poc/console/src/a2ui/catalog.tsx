import {Catalog} from '@a2ui/web_core/v0_9';

import {TROUBLESHOOTING_CATALOG_ID} from './catalogContract';
import {EvidenceCard} from '../components/EvidenceCard';
import {EvidenceGapCard} from '../components/EvidenceGapCard';
import {HealthSummary} from '../components/HealthSummary';
import {HypothesisCard} from '../components/HypothesisCard';
import {LogTable} from '../components/LogTable';
import {QueryDisclosure} from '../components/QueryDisclosure';
import {RecommendationCard} from '../components/RecommendationCard';
import {TimelineChart} from '../components/TimelineChart';
import {TraceCard} from '../components/TraceCard';

export const troubleshootingCatalog = new Catalog(
  TROUBLESHOOTING_CATALOG_ID,
  [
    HealthSummary,
    TimelineChart,
    TraceCard,
    EvidenceCard,
    EvidenceGapCard,
    LogTable,
    HypothesisCard,
    RecommendationCard,
    QueryDisclosure,
  ],
  [],
);
