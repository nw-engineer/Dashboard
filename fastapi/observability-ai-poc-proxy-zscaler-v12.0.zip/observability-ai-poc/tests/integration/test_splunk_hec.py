import asyncio
import os
from datetime import datetime, timedelta, timezone
from uuid import uuid4

import httpx
import pytest

from agent.splunk.client import SplunkSearchClient
from agent.splunk.models import SplunkSearchRequest


GATEWAY = os.getenv("POC_GATEWAY_URL", "http://localhost:8085")
SCENARIO = os.getenv("POC_SCENARIO_URL", "http://localhost:8091")
SEARCH_URL = os.getenv("SPLUNK_SEARCH_URL", "https://localhost:8089")
SEARCH_USERNAME = os.getenv("SPLUNK_SEARCH_USERNAME", "")
SEARCH_PASSWORD = os.getenv("SPLUNK_SEARCH_PASSWORD", "")
VERIFY_SSL = os.getenv("SPLUNK_SEARCH_VERIFY_SSL", "false").lower() in {"1", "true", "yes", "on"}

pytestmark = pytest.mark.skipif(
    not SEARCH_USERNAME or not SEARCH_PASSWORD,
    reason="SPLUNK_SEARCH_USERNAME and SPLUNK_SEARCH_PASSWORD are required",
)


@pytest.mark.asyncio
async def test_normal_order_is_searchable_by_request_id_with_trace_id():
    request_id = f"splunk-correlation-{uuid4()}"
    async with httpx.AsyncClient(timeout=15.0) as client:
        scenario_response = await client.put(
            f"{SCENARIO}/scenario", json={"scenario": "NORMAL"}
        )
        scenario_response.raise_for_status()
        response = await client.post(
            f"{GATEWAY}/orders",
            headers={"X-Request-ID": request_id},
            json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
        )
        assert response.status_code == 201

    search_client = SplunkSearchClient(
        base_url=SEARCH_URL,
        username=SEARCH_USERNAME,
        password=SEARCH_PASSWORD,
        verify_ssl=VERIFY_SSL,
        timeout_seconds=20.0,
    )

    results = []
    for _ in range(20):
        latest = datetime.now(timezone.utc) + timedelta(seconds=5)
        results = await search_client.search(
            SplunkSearchRequest(
                query=f'request.id="{request_id}"',
                earliest=latest - timedelta(minutes=5),
                latest=latest,
                max_results=100,
            )
        )
        if results:
            break
        await asyncio.sleep(1.0)

    assert results, f"no Splunk events found for request.id={request_id}"
    assert all(row.get("request.id") == request_id for row in results if row.get("request.id"))
    trace_ids = {row.get("trace.id") for row in results if row.get("trace.id")}
    assert trace_ids, "expected at least one New Relic trace.id"

    trace_id = next(iter(trace_ids))
    trace_results = await search_client.search(
        SplunkSearchRequest(
            query=f'trace.id="{trace_id}"',
            earliest=latest - timedelta(minutes=5),
            latest=latest,
            max_results=200,
        )
    )

    assert trace_results, f"no Splunk events found for trace.id={trace_id}"
    assert any(row.get("request.id") == request_id for row in trace_results)
    assert all(
        row.get("trace.id") == trace_id
        for row in trace_results
        if row.get("trace.id")
    )
