from __future__ import annotations

import os

import pytest

from agent.analysis.analyzer import validate_analysis_references
from agent.analysis.openai_adapter import OpenAIIncidentAnalyzer
from agent.evidence.models import (
    EvidenceBundle,
    EvidenceCategory,
    EvidenceGap,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)


OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")


def _live_bundle() -> EvidenceBundle:
    return EvidenceBundle(
        investigation_id="inv-live-openai-001",
        request_id="live-openai-request-001",
        trace_id="live-openai-trace-001",
        evidence=[
            EvidenceItem(
                evidence_id="newrelic-live-001",
                source=EvidenceSource.NEW_RELIC,
                category=EvidenceCategory.TRANSACTION,
                summary="The correlated inventory transaction duration is 1.8 seconds.",
                facts={"duration": 1.8, "error": False},
                query_or_tool="query-newrelic-live-001",
                service_name="poc-inventory-service",
                request_id="live-openai-request-001",
                trace_id="live-openai-trace-001",
            ),
            EvidenceItem(
                evidence_id="splunk-live-001",
                source=EvidenceSource.SPLUNK,
                category=EvidenceCategory.DEPLOYMENT,
                summary="A deployment event for inventory-service version 1.1.0 is present in the trace window.",
                facts={"service.version": "1.1.0", "category": "Deployment"},
                query_or_tool="query-splunk-live-001",
                service_name="poc-inventory-service",
                request_id="live-openai-request-001",
                trace_id="live-openai-trace-001",
            ),
        ],
        contradictions=[],
        gaps=[
            EvidenceGap(
                gap_id="gap-live-span-001",
                summary="No Span evidence is available to prove which internal operation consumed the transaction time.",
                source=EvidenceSource.NEW_RELIC,
                category=EvidenceCategory.SPAN,
            )
        ],
        queries_used=[
            QueryDisclosure(
                disclosure_id="query-newrelic-live-001",
                source=EvidenceSource.NEW_RELIC,
                operation="execute_nrql_query",
                arguments={"nrql_query": "SELECT duration FROM Transaction"},
            ),
            QueryDisclosure(
                disclosure_id="query-splunk-live-001",
                source=EvidenceSource.SPLUNK,
                operation="search",
                arguments={"query": 'trace.id="live-openai-trace-001"'},
            ),
        ],
    )


@pytest.mark.asyncio
@pytest.mark.skipif(not OPENAI_API_KEY, reason="OPENAI_API_KEY is required")
async def test_live_openai_analyzer_returns_reference_safe_incident_analysis():
    bundle = _live_bundle()
    analyzer = OpenAIIncidentAnalyzer.from_env()

    analysis = await analyzer.analyze(bundle)
    validate_analysis_references(bundle, analysis)

    assert analysis.incident_summary
    assert analysis.impact
    assert analysis.likely_cause
    assert set(analysis.new_relic_evidence_ids) <= {"newrelic-live-001"}
    assert set(analysis.splunk_evidence_ids) <= {"splunk-live-001"}
    assert set(analysis.query_disclosure_ids) <= {
        "query-newrelic-live-001",
        "query-splunk-live-001",
    }
