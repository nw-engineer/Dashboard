from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta

import pytest

from agent.evidence.models import CorrelationContext, EvidenceCategory
from agent.evidence.newrelic_collector import NewRelicEvidenceCollector
from agent.evidence.newrelic_transport import StreamableHttpNewRelicMcpGateway


NEW_RELIC_MCP_URL = os.getenv("NEW_RELIC_MCP_URL")
NEW_RELIC_ACCOUNT_ID = os.getenv("NEW_RELIC_ACCOUNT_ID")
NEW_RELIC_ENTITY_GUID = os.getenv("NEW_RELIC_ENTITY_GUID")
NEW_RELIC_ENTITY_NAME = os.getenv("NEW_RELIC_ENTITY_NAME", "poc-inventory-service")


@pytest.mark.asyncio
@pytest.mark.skipif(
    not (NEW_RELIC_MCP_URL and NEW_RELIC_ACCOUNT_ID and NEW_RELIC_ENTITY_GUID),
    reason=(
        "NEW_RELIC_MCP_URL, NEW_RELIC_ACCOUNT_ID, and "
        "NEW_RELIC_ENTITY_GUID are required"
    ),
)
async def test_live_change_tracking_falls_back_to_read_only_nrql():
    collector = NewRelicEvidenceCollector(
        StreamableHttpNewRelicMcpGateway(NEW_RELIC_MCP_URL or ""),
        account_id=int(NEW_RELIC_ACCOUNT_ID or "0"),
    )
    context = CorrelationContext(
        request_id="phase4-live-change-tracking",
        trace_id="phase4-live-change-tracking",
        services=[NEW_RELIC_ENTITY_NAME],
        entity_guids={NEW_RELIC_ENTITY_NAME: NEW_RELIC_ENTITY_GUID or ""},
    )
    latest = datetime.now(UTC)

    result = await collector.collect(context, latest - timedelta(hours=48), latest)

    deployment = next(
        (
            item
            for item in result.evidence
            if item.category is EvidenceCategory.DEPLOYMENT
            and item.entity_guid == NEW_RELIC_ENTITY_GUID
        ),
        None,
    )
    assert deployment is not None, "No Change Tracking deployment evidence was returned"
    assert deployment.service_name == NEW_RELIC_ENTITY_NAME
    assert deployment.observed_at is not None
    assert deployment.facts.get("category") == "Deployment"
    assert deployment.facts.get("eventType()") in {"ChangeTrackingEvent", "Deployment"}

    operations = [query.operation for query in result.queries]
    assert "list_change_events" in operations
    fallback_queries = [
        query
        for query in result.queries
        if query.operation == "execute_nrql_query"
        and "ChangeTrackingEvent" in str(query.arguments.get("nrql_query", ""))
    ]
    assert fallback_queries, "Change Tracking NRQL fallback was not disclosed"
    fallback_nrql = str(fallback_queries[0].arguments["nrql_query"])
    assert fallback_nrql.startswith("SELECT ")
    assert "FROM ChangeTrackingEvent, Deployment" in fallback_nrql
    assert NEW_RELIC_ENTITY_GUID in fallback_nrql
