from __future__ import annotations

import asyncio
import os
import uuid
from datetime import UTC, datetime, timedelta

import httpx
import pytest

from agent.splunk.client import SplunkSearchClient
from agent.splunk.models import SplunkSearchRequest


SPLUNK_URL = os.getenv("SPLUNK_SEARCH_URL", "https://localhost:8089")
SPLUNK_USERNAME = os.getenv("SPLUNK_SEARCH_USERNAME", "ai_search")
SPLUNK_PASSWORD = os.getenv("SPLUNK_SEARCH_PASSWORD")
SPLUNK_VERIFY_SSL = os.getenv("SPLUNK_SEARCH_VERIFY_SSL", "false").lower() in {
    "1",
    "true",
    "yes",
}
API_GATEWAY_URL = os.getenv("POC_API_GATEWAY_URL", "http://localhost:8085")

pytestmark = pytest.mark.skipif(
    not SPLUNK_PASSWORD,
    reason="SPLUNK_SEARCH_PASSWORD is required for live Splunk integration tests",
)


async def _wait_for_request_results(
    client: SplunkSearchClient,
    request_id: str,
    *,
    attempts: int = 8,
    delay_seconds: float = 1.0,
) -> list[dict[str, object]]:
    for attempt in range(attempts):
        now = datetime.now(UTC)
        results = await client.search(
            SplunkSearchRequest(
                query=f'request.id="{request_id}"',
                earliest=now - timedelta(minutes=10),
                latest=now,
                max_results=200,
            )
        )
        if results:
            return results
        if attempt + 1 < attempts:
            await asyncio.sleep(delay_seconds)
    return []


@pytest.mark.asyncio
async def test_request_id_resolves_to_trace_id_and_same_trace() -> None:
    request_id = f"splunk-tool-it-{uuid.uuid4()}"

    async with httpx.AsyncClient(timeout=10.0) as http:
        response = await http.post(
            f"{API_GATEWAY_URL.rstrip('/')}/orders",
            headers={"X-Request-ID": request_id},
            json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
        )
    assert response.status_code < 500, response.text

    client = SplunkSearchClient(
        base_url=SPLUNK_URL,
        username=SPLUNK_USERNAME,
        password=SPLUNK_PASSWORD or "",
        verify_ssl=SPLUNK_VERIFY_SSL,
        poll_interval=0.25,
        timeout_seconds=20.0,
    )

    request_results = await _wait_for_request_results(client, request_id)
    assert request_results, f"No Splunk events found for request.id={request_id}"

    trace_ids = {
        str(row["trace.id"])
        for row in request_results
        if row.get("trace.id") not in (None, "")
    }
    assert len(trace_ids) == 1, f"Expected one trace.id, got {sorted(trace_ids)}"
    trace_id = next(iter(trace_ids))

    now = datetime.now(UTC)
    trace_results = await client.search(
        SplunkSearchRequest(
            query=f'trace.id="{trace_id}"',
            earliest=now - timedelta(minutes=10),
            latest=now,
            max_results=200,
        )
    )

    assert trace_results, f"No Splunk events found for trace.id={trace_id}"
    assert any(row.get("request.id") == request_id for row in trace_results)
