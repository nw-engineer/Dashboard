import os
import time

import httpx
import pytest

GATEWAY = os.getenv("POC_GATEWAY_URL", "http://localhost:8085")
SCENARIO = os.getenv("POC_SCENARIO_URL", "http://localhost:8091")


@pytest.fixture
def client():
    with httpx.Client(timeout=10.0) as value:
        yield value


def set_scenario(client: httpx.Client, scenario: str) -> None:
    response = client.put(f"{SCENARIO}/scenario", json={"scenario": scenario})
    response.raise_for_status()


def order(client: httpx.Client, product_id: str = "SKU-001") -> httpx.Response:
    return client.post(
        f"{GATEWAY}/orders",
        json={"product_id": product_id, "quantity": 1, "amount": 1200},
    )


def test_normal_order_round_trip(client):
    set_scenario(client, "NORMAL")
    response = order(client)
    assert response.status_code == 201
    assert response.headers["x-request-id"]


def test_uc01_is_slow(client):
    set_scenario(client, "UC01_DB_SLOW")
    started = time.monotonic()
    response = order(client)
    elapsed = time.monotonic() - started
    assert response.status_code == 201
    assert elapsed >= 2.5


def test_uc02_dependency_failure(client):
    set_scenario(client, "UC02_PAYMENT_FAILURE")
    response = order(client)
    assert response.status_code == 502


def test_uc03_application_exception(client):
    set_scenario(client, "UC03_APP_EXCEPTION")
    response = order(client, product_id="BUG-001")
    assert response.status_code == 500


def test_uc05_reports_bad_deployment_version(client):
    set_scenario(client, "UC05_BAD_DEPLOYMENT")
    response = order(client)
    assert response.status_code == 201
    assert response.json()["inventory_service_version"] == "1.1.0"
