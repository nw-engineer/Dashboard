from __future__ import annotations

import asyncio
import json
import os
import time
import uuid
from datetime import UTC, datetime, timedelta

import httpx
import pytest

from agent.evidence.correlation import CorrelationNotFound, CorrelationResolver, TraceIdNotFound
from agent.evidence.models import CorrelationContext, EvidenceCategory
from agent.evidence.newrelic_collector import NewRelicEvidenceCollector
from agent.evidence.newrelic_transport import StreamableHttpNewRelicMcpGateway
from agent.splunk.client import SplunkSearchClient
from console_api.app import create_app

SPLUNK_PASSWORD = os.getenv("SPLUNK_SEARCH_PASSWORD")
SPLUNK_URL = os.getenv("SPLUNK_SEARCH_URL", "https://localhost:8089")
SPLUNK_USERNAME = os.getenv("SPLUNK_SEARCH_USERNAME", "ai_search")
SPLUNK_VERIFY_SSL = os.getenv("SPLUNK_SEARCH_VERIFY_SSL", "false").lower() in {
    "1", "true", "yes", "on"
}
NEW_RELIC_MCP_URL = os.getenv("NEW_RELIC_MCP_URL")
NEW_RELIC_ACCOUNT_ID = os.getenv("NEW_RELIC_ACCOUNT_ID")
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "ollama").strip().lower()
API_GATEWAY_URL = os.getenv("API_GATEWAY_URL", "http://localhost:8085")


def _provider_live_ready() -> bool:
    if LLM_PROVIDER == "ollama":
        return os.getenv("RUN_OLLAMA_LIVE_TESTS") == "1"
    if LLM_PROVIDER == "azure_openai":
        return (
            os.getenv("RUN_AZURE_OPENAI_LIVE_TESTS") == "1"
            and bool(os.getenv("AZURE_OPENAI_API_KEY"))
            and bool(os.getenv("AZURE_OPENAI_BASE_URL"))
            and bool(os.getenv("AZURE_OPENAI_MODEL"))
        )
    if LLM_PROVIDER == "openai":
        return bool(os.getenv("OPENAI_API_KEY"))
    return False


LIVE_READY = bool(
    os.getenv("RUN_PHASE5_LIVE_TESTS") == "1"
    and SPLUNK_PASSWORD
    and NEW_RELIC_MCP_URL
    and NEW_RELIC_ACCOUNT_ID
    and _provider_live_ready()
)


@pytest.mark.asyncio
@pytest.mark.skipif(not LIVE_READY, reason="Phase 5 live environment is required")
async def test_live_phase5_console_streams_progress_and_a2ui_result():
    request_id = f"phase5-console-e2e-{uuid.uuid4()}"
    latest = datetime.now(UTC)
    earliest = latest - timedelta(minutes=10)

    async with httpx.AsyncClient(timeout=10.0) as http:
        response = await http.post(
            f"{API_GATEWAY_URL.rstrip('/')}/orders",
            headers={"X-Request-ID": request_id},
            json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
        )
    assert response.status_code < 500, response.text

    splunk_client = SplunkSearchClient(
        base_url=SPLUNK_URL,
        username=SPLUNK_USERNAME,
        password=SPLUNK_PASSWORD or "",
        verify_ssl=SPLUNK_VERIFY_SSL,
        poll_interval=0.25,
        timeout_seconds=20.0,
    )
    resolver = CorrelationResolver(splunk_client)

    context = None
    deadline = time.monotonic() + 20.0
    while time.monotonic() < deadline:
        try:
            context = await resolver.resolve_request(request_id, earliest, datetime.now(UTC))
            break
        except (CorrelationNotFound, TraceIdNotFound):
            await asyncio.sleep(1.0)
    assert context is not None, f"Splunk did not resolve trace.id for {request_id}"

    newrelic_collector = NewRelicEvidenceCollector(
        StreamableHttpNewRelicMcpGateway(NEW_RELIC_MCP_URL or ""),
        account_id=int(NEW_RELIC_ACCOUNT_ID or "0"),
    )
    transaction_context = CorrelationContext(
        request_id=context.request_id,
        trace_id=context.trace_id,
        services=context.services,
        entity_guids={},
    )
    deadline = time.monotonic() + 30.0
    while time.monotonic() < deadline:
        newrelic = await newrelic_collector.collect(
            transaction_context, earliest, datetime.now(UTC)
        )
        if any(
            item.category is EvidenceCategory.TRANSACTION
            and item.trace_id == context.trace_id
            for item in newrelic.evidence
        ):
            break
        await asyncio.sleep(1.0)
    else:
        pytest.fail(f"New Relic MCP did not return traceId={context.trace_id}")

    app = create_app()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test", timeout=240.0) as client:
        response = await client.post(
            "/api/investigations/stream",
            headers={"accept": "text/event-stream"},
            json={
                "request_id": request_id,
                "earliest": earliest.isoformat(),
                "latest": datetime.now(UTC).isoformat(),
            },
        )

    assert response.status_code == 200
    events = [
        json.loads(line.removeprefix("data: "))
        for line in response.text.splitlines()
        if line.startswith("data: ")
    ]
    assert events[0]["type"] == "RUN_STARTED"
    assert events[-1]["type"] == "RUN_FINISHED"

    step_pairs = [
        (event["type"], event.get("stepName"))
        for event in events
        if event["type"] in {"STEP_STARTED", "STEP_FINISHED"}
    ]
    assert step_pairs == [
        ("STEP_STARTED", "correlation"), ("STEP_FINISHED", "correlation"),
        ("STEP_STARTED", "splunk"), ("STEP_FINISHED", "splunk"),
        ("STEP_STARTED", "newrelic"), ("STEP_FINISHED", "newrelic"),
        ("STEP_STARTED", "correlate"), ("STEP_FINISHED", "correlate"),
        ("STEP_STARTED", "analyze"), ("STEP_FINISHED", "analyze"),
    ]

    custom = [
        event for event in events
        if event["type"] == "CUSTOM" and event.get("name") == "a2ui.message"
    ]
    assert len(custom) >= 3
    assert "createSurface" in custom[0]["value"]
    assert "updateComponents" in custom[1]["value"]
    assert "updateDataModel" in custom[2]["value"]

    investigation_id = events[-1]["result"]["investigationId"]
    assert custom[0]["value"]["createSurface"]["surfaceId"] == investigation_id
