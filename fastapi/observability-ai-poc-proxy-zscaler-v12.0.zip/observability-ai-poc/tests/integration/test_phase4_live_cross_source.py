from __future__ import annotations

import asyncio
import os
import time
import uuid
from datetime import UTC, datetime, timedelta

import httpx
import pytest

from agent.evidence.correlation import CorrelationNotFound, CorrelationResolver, TraceIdNotFound
from agent.evidence.models import CorrelationContext, EvidenceCategory, EvidenceSource
from agent.evidence.newrelic_collector import NewRelicEvidenceCollector
from agent.evidence.newrelic_transport import StreamableHttpNewRelicMcpGateway
from agent.evidence.splunk_collector import SplunkEvidenceCollector
from agent.splunk.client import SplunkSearchClient


SPLUNK_PASSWORD = os.getenv("SPLUNK_SEARCH_PASSWORD")
SPLUNK_URL = os.getenv("SPLUNK_SEARCH_URL", "https://localhost:8089")
SPLUNK_USERNAME = os.getenv("SPLUNK_SEARCH_USERNAME", "ai_search")
SPLUNK_VERIFY_SSL = os.getenv("SPLUNK_SEARCH_VERIFY_SSL", "false").lower() in {
    "1", "true", "yes", "on"
}
NEW_RELIC_MCP_URL = os.getenv("NEW_RELIC_MCP_URL")
NEW_RELIC_ACCOUNT_ID = os.getenv("NEW_RELIC_ACCOUNT_ID")
API_GATEWAY_URL = os.getenv("API_GATEWAY_URL", "http://localhost:8085")


@pytest.mark.asyncio
@pytest.mark.skipif(
    not (SPLUNK_PASSWORD and NEW_RELIC_MCP_URL and NEW_RELIC_ACCOUNT_ID),
    reason=(
        "SPLUNK_SEARCH_PASSWORD, NEW_RELIC_MCP_URL, and "
        "NEW_RELIC_ACCOUNT_ID are required"
    ),
)
async def test_live_request_correlates_real_splunk_and_newrelic_transaction_evidence():
    request_id = f"phase4-live-{uuid.uuid4()}"

    async with httpx.AsyncClient(timeout=10.0) as http:
        response = await http.post(
            f"{API_GATEWAY_URL.rstrip('/')}/orders",
            headers={"X-Request-ID": request_id},
            json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
        )
    assert response.status_code < 500, response.text

    splunk = SplunkSearchClient(
        base_url=SPLUNK_URL,
        username=SPLUNK_USERNAME,
        password=SPLUNK_PASSWORD or "",
        verify_ssl=SPLUNK_VERIFY_SSL,
        poll_interval=0.25,
        timeout_seconds=20.0,
    )
    resolver = CorrelationResolver(splunk)
    earliest = datetime.now(UTC) - timedelta(minutes=10)

    context = None
    deadline = time.monotonic() + 20.0
    while time.monotonic() < deadline:
        try:
            context = await resolver.resolve_request(
                request_id, earliest, datetime.now(UTC)
            )
            break
        except (CorrelationNotFound, TraceIdNotFound):
            await asyncio.sleep(1.0)
    assert context is not None, f"Splunk did not resolve trace.id for {request_id}"

    splunk_result = await SplunkEvidenceCollector(splunk).collect(
        context, earliest, datetime.now(UTC)
    )
    assert any(
        item.source is EvidenceSource.SPLUNK and item.trace_id == context.trace_id
        for item in splunk_result.evidence
    )

    # Change Tracking is tested separately after its live response contract is observed.
    transaction_context = CorrelationContext(
        request_id=context.request_id,
        trace_id=context.trace_id,
        services=context.services,
        entity_guids={},
    )
    collector = NewRelicEvidenceCollector(
        StreamableHttpNewRelicMcpGateway(NEW_RELIC_MCP_URL or ""),
        account_id=int(NEW_RELIC_ACCOUNT_ID or "0"),
    )

    nr_result = None
    deadline = time.monotonic() + 30.0
    while time.monotonic() < deadline:
        nr_result = await collector.collect(
            transaction_context, earliest, datetime.now(UTC)
        )
        if any(
            item.category is EvidenceCategory.TRANSACTION
            and item.trace_id == context.trace_id
            for item in nr_result.evidence
        ):
            break
        await asyncio.sleep(1.0)

    assert nr_result is not None
    transactions = [
        item
        for item in nr_result.evidence
        if item.category is EvidenceCategory.TRANSACTION
        and item.trace_id == context.trace_id
    ]
    assert transactions, f"New Relic MCP did not return traceId={context.trace_id}"
    assert any(item.service_name == "poc-api-gateway" for item in transactions)
    assert all(item.observed_at is not None for item in transactions)

    nrql_disclosures = [
        item for item in nr_result.queries if item.operation == "execute_nrql_query"
    ]
    assert nrql_disclosures
    assert all(
        item.arguments.get("account_id") == int(NEW_RELIC_ACCOUNT_ID or "0")
        for item in nrql_disclosures
    )
    assert all("nrql_query" in item.arguments for item in nrql_disclosures)
