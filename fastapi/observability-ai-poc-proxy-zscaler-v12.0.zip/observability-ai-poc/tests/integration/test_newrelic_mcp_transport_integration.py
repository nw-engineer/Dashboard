import os

import pytest

from agent.evidence.newrelic_transport import StreamableHttpNewRelicMcpGateway


NEW_RELIC_MCP_URL = os.getenv("NEW_RELIC_MCP_URL")


@pytest.mark.asyncio
@pytest.mark.skipif(
    not NEW_RELIC_MCP_URL,
    reason="NEW_RELIC_MCP_URL is required for the live New Relic MCP integration test",
)
async def test_live_newrelic_mcp_lists_required_read_only_tools():
    gateway = StreamableHttpNewRelicMcpGateway(NEW_RELIC_MCP_URL or "")

    tools = await gateway.list_tools()
    by_name = {tool.name: tool for tool in tools}

    assert "execute_nrql_query" in by_name
    assert "list_change_events" in by_name

    # Preserve the live schemas so failures clearly show an incompatible MCP contract.
    nrql_schema = by_name["execute_nrql_query"].input_schema
    change_schema = by_name["list_change_events"].input_schema
    assert set(nrql_schema.get("required", [])) == {"nrql_query", "account_id"}
    assert set(change_schema.get("required", [])) == {"entity_guid"}
