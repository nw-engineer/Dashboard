from fastapi.testclient import TestClient
import httpx

from services.payment_service import app as payment_service_module

client = TestClient(payment_service_module.app)


class FailingPaymentClient:
    def __init__(self):
        self.calls = 0

    async def charge(
        self,
        order_id: str,
        amount: int,
        *,
        request_id: str | None = None,
        scenario_id: str | None = None,
    ) -> dict:
        self.calls += 1
        raise httpx.HTTPStatusError(
            "503",
            request=httpx.Request("POST", "http://payment-mock:8084/charge"),
            response=httpx.Response(503),
        )


def test_payment_service_returns_502_after_three_dependency_failures(monkeypatch):
    fake = FailingPaymentClient()
    monkeypatch.setattr(payment_service_module, "payment_dependency", fake)

    response = client.post("/payments", json={"order_id": "o-1", "amount": 1200})

    assert response.status_code == 502
    assert fake.calls == 3
