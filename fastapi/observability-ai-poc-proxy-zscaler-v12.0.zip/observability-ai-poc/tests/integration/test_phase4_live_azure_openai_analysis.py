from __future__ import annotations

import os

import pytest

from agent.analysis.analyzer import validate_analysis_references
from agent.analysis.azure_openai_adapter import AzureOpenAIIncidentAnalyzer
from agent.evidence.models import (
    EvidenceBundle,
    EvidenceCategory,
    EvidenceGap,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)


REQUIRED_AZURE_ENV = (
    "AZURE_OPENAI_API_KEY",
    "AZURE_OPENAI_BASE_URL",
    "AZURE_OPENAI_MODEL",
)


def _live_bundle() -> EvidenceBundle:
    return EvidenceBundle(
        investigation_id="inv-live-azure-001",
        request_id="live-azure-request-001",
        trace_id="live-azure-trace-001",
        evidence=[
            EvidenceItem(
                evidence_id="newrelic-live-001",
                source=EvidenceSource.NEW_RELIC,
                category=EvidenceCategory.TRANSACTION,
                summary="The correlated inventory transaction duration is 1.8 seconds.",
                facts={"duration": 1.8, "error": False},
                query_or_tool="query-newrelic-live-001",
                service_name="poc-inventory-service",
                request_id="live-azure-request-001",
                trace_id="live-azure-trace-001",
            ),
            EvidenceItem(
                evidence_id="splunk-live-001",
                source=EvidenceSource.SPLUNK,
                category=EvidenceCategory.DEPLOYMENT,
                summary=(
                    "A deployment event for inventory-service version 1.1.0 "
                    "is present in the trace window."
                ),
                facts={"service.version": "1.1.0", "category": "Deployment"},
                query_or_tool="query-splunk-live-001",
                service_name="poc-inventory-service",
                request_id="live-azure-request-001",
                trace_id="live-azure-trace-001",
            ),
        ],
        contradictions=[],
        gaps=[
            EvidenceGap(
                gap_id="gap-live-span-001",
                summary=(
                    "No Span evidence is available to prove which internal operation "
                    "consumed the transaction time."
                ),
                source=EvidenceSource.NEW_RELIC,
                category=EvidenceCategory.SPAN,
            )
        ],
        queries_used=[
            QueryDisclosure(
                disclosure_id="query-newrelic-live-001",
                source=EvidenceSource.NEW_RELIC,
                operation="execute_nrql_query",
                arguments={"nrql_query": "SELECT duration FROM Transaction"},
            ),
            QueryDisclosure(
                disclosure_id="query-splunk-live-001",
                source=EvidenceSource.SPLUNK,
                operation="search",
                arguments={"query": 'trace.id="live-azure-trace-001"'},
            ),
        ],
    )


def _azure_live_ready() -> bool:
    return (
        os.getenv("RUN_AZURE_OPENAI_LIVE_TESTS") == "1"
        and all(os.getenv(name) for name in REQUIRED_AZURE_ENV)
    )


@pytest.mark.asyncio
@pytest.mark.skipif(
    not _azure_live_ready(),
    reason=(
        "RUN_AZURE_OPENAI_LIVE_TESTS=1 and AZURE_OPENAI_API_KEY, "
        "AZURE_OPENAI_BASE_URL, AZURE_OPENAI_MODEL are required"
    ),
)
async def test_live_azure_openai_analyzer_returns_reference_safe_incident_analysis():
    bundle = _live_bundle()
    analyzer = AzureOpenAIIncidentAnalyzer.from_env()

    analysis = await analyzer.analyze(bundle)
    validate_analysis_references(bundle, analysis)

    assert analysis.incident_summary
    assert analysis.impact
    assert analysis.likely_cause
    assert set(analysis.new_relic_evidence_ids) <= {"newrelic-live-001"}
    assert set(analysis.splunk_evidence_ids) <= {"splunk-live-001"}
    assert set(analysis.query_disclosure_ids) <= {
        "query-newrelic-live-001",
        "query-splunk-live-001",
    }
