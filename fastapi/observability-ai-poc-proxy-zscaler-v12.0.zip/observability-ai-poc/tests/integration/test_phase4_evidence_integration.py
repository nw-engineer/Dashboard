from __future__ import annotations

import asyncio
import os
import time
import uuid
from datetime import UTC, datetime, timedelta

import httpx
import pytest

from agent.evidence.correlation import CorrelationNotFound, CorrelationResolver, TraceIdNotFound
from agent.evidence.correlator import EvidenceCorrelator
from agent.evidence.models import EvidenceSource
from agent.evidence.newrelic_collector import NewRelicEvidenceCollector
from agent.evidence.newrelic_gateway import CallableNewRelicMcpGateway
from agent.evidence.splunk_collector import SplunkEvidenceCollector
from agent.splunk.client import SplunkSearchClient


SPLUNK_PASSWORD = os.getenv("SPLUNK_SEARCH_PASSWORD")
SPLUNK_URL = os.getenv("SPLUNK_SEARCH_URL", "https://localhost:8089")
SPLUNK_USERNAME = os.getenv("SPLUNK_SEARCH_USERNAME", "ai_search")
SPLUNK_VERIFY_SSL = os.getenv("SPLUNK_SEARCH_VERIFY_SSL", "false").lower() in {
    "1",
    "true",
    "yes",
    "on",
}
API_GATEWAY_URL = os.getenv("API_GATEWAY_URL", "http://localhost:8085")


@pytest.mark.asyncio
@pytest.mark.skipif(not SPLUNK_PASSWORD, reason="SPLUNK_SEARCH_PASSWORD is required")
async def test_phase4_request_builds_cross_source_evidence_bundle() -> None:
    request_id = f"phase4-it-{uuid.uuid4()}"

    async with httpx.AsyncClient(timeout=10.0) as http:
        response = await http.post(
            f"{API_GATEWAY_URL.rstrip('/')}/orders",
            headers={"X-Request-ID": request_id},
            json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
        )
    assert response.status_code < 500, response.text

    splunk_client = SplunkSearchClient(
        base_url=SPLUNK_URL,
        username=SPLUNK_USERNAME,
        password=SPLUNK_PASSWORD or "",
        verify_ssl=SPLUNK_VERIFY_SSL,
        poll_interval=0.25,
        timeout_seconds=20.0,
    )
    resolver = CorrelationResolver(splunk_client)
    latest = datetime.now(UTC)
    earliest = latest - timedelta(minutes=10)

    deadline = time.monotonic() + 20.0
    context = None
    while time.monotonic() < deadline:
        try:
            context = await resolver.resolve_request(request_id, earliest, datetime.now(UTC))
            break
        except (CorrelationNotFound, TraceIdNotFound):
            await asyncio.sleep(1.0)
    assert context is not None, f"Splunk did not resolve trace.id for request.id={request_id}"
    resolved_trace_id = context.trace_id

    async def fake_call_tool(name: str, arguments: dict[str, object]) -> object:
        if name == "execute_nrql_query":
            query = str(arguments.get("nrql_query", ""))
            if "FROM Span" in query:
                return {"results": []}
            return {
                "results": [
                    {
                        "traceId": resolved_trace_id,
                        "appName": "poc-api-gateway",
                        "name": "WebTransaction/Uri/orders",
                        "duration": 0.1,
                        "error": False,
                    }
                ]
            }
        if name == "list_change_events":
            return {"events": []}
        raise AssertionError(f"unexpected MCP tool: {name}")

    splunk_result = await SplunkEvidenceCollector(splunk_client).collect(
        context, earliest, datetime.now(UTC)
    )
    newrelic_result = await NewRelicEvidenceCollector(
        CallableNewRelicMcpGateway(fake_call_tool), account_id=8292460
    ).collect(context, earliest, datetime.now(UTC))

    bundle = EvidenceCorrelator().build_bundle(
        investigation_id="phase4-live-integration",
        context=context,
        splunk=splunk_result,
        newrelic=newrelic_result,
    )

    assert bundle.trace_id == resolved_trace_id
    assert any(
        item.source is EvidenceSource.SPLUNK and item.trace_id == resolved_trace_id
        for item in bundle.evidence
    )
    assert any(
        item.source is EvidenceSource.NEW_RELIC
        and item.category.value == "transaction"
        and item.trace_id == resolved_trace_id
        for item in bundle.evidence
    )

    disclosure_ids = {item.disclosure_id for item in bundle.queries_used}
    assert disclosure_ids
    assert all(item.query_or_tool in disclosure_ids for item in bundle.evidence)
