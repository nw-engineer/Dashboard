import json

import httpx
import pytest

from console_api.app import create_app
from tests.unit.test_agui_stream import DictEventFactory, FakeOrchestrator


class JsonSseEncoder:
    def encode(self, event):
        return f"data: {json.dumps(event, separators=(',', ':'))}\n\n"

    def get_content_type(self):
        return "text/event-stream"


@pytest.mark.asyncio
async def test_console_endpoint_streams_sse_for_valid_request():
    app = create_app(
        orchestrator_factory=lambda progress: FakeOrchestrator(progress),
        event_factory=DictEventFactory(),
        encoder_factory=lambda _accept: JsonSseEncoder(),
    )
    transport = httpx.ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/api/investigations/stream",
            headers={"accept": "text/event-stream"},
            json={
                "request_id": "req-1",
                "earliest": "2026-09-04T00:00:00Z",
                "latest": "2026-09-04T00:10:00Z",
            },
        )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    payloads = [
        json.loads(line.removeprefix("data: "))
        for line in response.text.splitlines()
        if line.startswith("data: ")
    ]
    assert payloads[0]["type"] == "RUN_STARTED"
    assert payloads[-1]["type"] == "RUN_FINISHED"
    assert [p["type"] for p in payloads].count("CUSTOM") == 3


@pytest.mark.asyncio
async def test_console_endpoint_rejects_invalid_window_before_orchestrator_creation():
    calls = []

    def factory(progress):
        calls.append(progress)
        return FakeOrchestrator(progress)

    app = create_app(
        orchestrator_factory=factory,
        event_factory=DictEventFactory(),
        encoder_factory=lambda _accept: JsonSseEncoder(),
    )
    transport = httpx.ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/api/investigations/stream",
            json={
                "request_id": "req-1",
                "earliest": "2026-09-04T00:00:00Z",
                "latest": "2026-09-04T03:00:00Z",
            },
        )

    assert response.status_code == 422
    assert calls == []
