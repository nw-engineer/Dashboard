import os
from uuid import uuid4

import httpx

GATEWAY = os.getenv("POC_GATEWAY_URL", "http://localhost:8085")
SCENARIO = os.getenv("POC_SCENARIO_URL", "http://localhost:8091")


def test_request_id_survives_gateway_order_inventory_and_payment():
    request_id = f"trace-check-{uuid4()}"
    with httpx.Client(timeout=15.0) as client:
        scenario_response = client.put(f"{SCENARIO}/scenario", json={"scenario": "NORMAL"})
        scenario_response.raise_for_status()

        response = client.post(
            f"{GATEWAY}/orders",
            headers={"X-Request-ID": request_id},
            json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
        )

    assert response.status_code == 201
    assert response.headers["x-request-id"] == request_id
    assert response.json()["correlation"] == {
        "order_request_id": request_id,
        "inventory_request_id": request_id,
        "payment_request_id": request_id,
    }
