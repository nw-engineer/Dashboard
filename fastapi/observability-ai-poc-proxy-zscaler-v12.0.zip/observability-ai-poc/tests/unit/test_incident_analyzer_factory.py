import pytest


def test_factory_defaults_to_ollama(monkeypatch):
    from agent.analysis.factory import create_incident_analyzer_from_env
    from agent.analysis.ollama_adapter import OllamaIncidentAnalyzer

    monkeypatch.delenv("LLM_PROVIDER", raising=False)
    analyzer = create_incident_analyzer_from_env()

    assert isinstance(analyzer, OllamaIncidentAnalyzer)


def test_factory_selects_azure_openai(monkeypatch):
    from agent.analysis.azure_openai_adapter import AzureOpenAIIncidentAnalyzer
    from agent.analysis.factory import create_incident_analyzer_from_env

    monkeypatch.setenv("LLM_PROVIDER", "azure_openai")
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "env-key")
    monkeypatch.setenv(
        "AZURE_OPENAI_BASE_URL", "https://example.openai.azure.com/openai/v1"
    )
    monkeypatch.setenv("AZURE_OPENAI_MODEL", "deployment")

    analyzer = create_incident_analyzer_from_env()

    assert isinstance(analyzer, AzureOpenAIIncidentAnalyzer)


def test_factory_selects_openai(monkeypatch):
    from agent.analysis.factory import create_incident_analyzer_from_env
    from agent.analysis.openai_adapter import OpenAIIncidentAnalyzer

    monkeypatch.setenv("LLM_PROVIDER", "openai")
    monkeypatch.setenv("OPENAI_API_KEY", "env-key")

    analyzer = create_incident_analyzer_from_env()

    assert isinstance(analyzer, OpenAIIncidentAnalyzer)


def test_factory_normalizes_provider_name(monkeypatch):
    from agent.analysis.factory import create_incident_analyzer_from_env
    from agent.analysis.ollama_adapter import OllamaIncidentAnalyzer

    monkeypatch.setenv("LLM_PROVIDER", "  OLLAMA  ")

    analyzer = create_incident_analyzer_from_env()

    assert isinstance(analyzer, OllamaIncidentAnalyzer)


def test_factory_rejects_unknown_provider(monkeypatch):
    from agent.analysis.factory import (
        LLMProviderConfigurationError,
        create_incident_analyzer_from_env,
    )

    monkeypatch.setenv("LLM_PROVIDER", "some_other_provider")

    with pytest.raises(LLMProviderConfigurationError, match="ollama, azure_openai, openai"):
        create_incident_analyzer_from_env()
