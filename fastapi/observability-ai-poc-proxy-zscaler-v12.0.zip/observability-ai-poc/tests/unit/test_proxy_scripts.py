from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_preflight_checks_required_files_and_proxy_names_without_printing_values():
    text = (ROOT / "scripts/preflight_proxy.sh").read_text()
    assert "certs/zscaler-ca.crt" in text
    assert "HTTP_PROXY" in text
    assert "HTTPS_PROXY" in text
    assert "NO_PROXY" in text
    assert "SPLUNK_PASSWORD" in text
    assert "NEW_RELIC_LICENSE_KEY" in text
    assert "NEW_RELIC_MCP_USER_KEY" in text
    assert "cat .env" not in text
    assert "env |" not in text
    assert "printenv" not in text


def test_makefile_exposes_proxy_workflow_targets():
    text = (ROOT / "Makefile").read_text()
    for target in ["proxy-preflight:", "proxy-up:", "proxy-ps:", "proxy-test:", "proxy-down:"]:
        assert target in text


def _run_preflight(tmp_path, env_text: str, with_ca: bool = True):
    import os
    import subprocess

    (tmp_path / ".env").write_text(env_text)
    (tmp_path / "certs").mkdir()
    if with_ca:
        (tmp_path / "certs/zscaler-ca.crt").write_text(
            "-----BEGIN CERTIFICATE-----\nTEST\n-----END CERTIFICATE-----\n"
        )
    env = os.environ.copy()
    env["POC_ROOT"] = str(tmp_path)
    return subprocess.run(
        ["sh", str(ROOT / "scripts/preflight_proxy.sh")],
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )


def test_preflight_rejects_missing_ca(tmp_path):
    result = _run_preflight(
        tmp_path,
        "HTTP_PROXY=http://p:1\nHTTPS_PROXY=http://p:1\nNO_PROXY=10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,splunk,newrelic-mcp,console-api\n",
        with_ca=False,
    )
    assert result.returncode != 0
    assert "ZSCALER_CA" in result.stderr


def test_preflight_rejects_missing_proxy(tmp_path):
    result = _run_preflight(
        tmp_path,
        "NO_PROXY=10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,splunk,newrelic-mcp,console-api\n",
    )
    assert result.returncode != 0
    assert "HTTP_PROXY" in result.stderr or "HTTPS_PROXY" in result.stderr


def test_preflight_rejects_incomplete_no_proxy(tmp_path):
    result = _run_preflight(
        tmp_path,
        "HTTP_PROXY=http://p:1\nHTTPS_PROXY=http://p:1\nNO_PROXY=localhost,splunk\n",
    )
    assert result.returncode != 0
    assert "NO_PROXY" in result.stderr


def test_preflight_accepts_complete_fixture(tmp_path):
    env_text = "\n".join([
        "HTTP_PROXY=http://p:1",
        "HTTPS_PROXY=http://p:1",
        "NO_PROXY=localhost,127.0.0.1,::1,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,host.docker.internal,splunk,postgres,scenario-controller,payment-mock,payment-service,inventory-service,order-service,api-gateway,load-generator,newrelic-mcp,console-api,console-ui",
        "SPLUNK_PASSWORD=x",
        "SPLUNK_HEC_ENABLED=true",
        "SPLUNK_HEC_TOKEN=x",
        "SPLUNK_SEARCH_PASSWORD=x",
        "NEW_RELIC_LICENSE_KEY=x",
        "NEW_RELIC_ENABLED=true",
        "NEW_RELIC_API_KEY=x",
        "NEW_RELIC_MCP_USER_KEY=x",
        "NEW_RELIC_ACCOUNT_ID=1",
        "LLM_PROVIDER=ollama",
    ]) + "\n"
    result = _run_preflight(tmp_path, env_text)
    assert result.returncode == 0, result.stderr
    assert "http://p:1" not in result.stdout + result.stderr


def test_preflight_rejects_disabled_observability_emitters(tmp_path):
    env_text = "\n".join([
        "HTTP_PROXY=http://p:1",
        "HTTPS_PROXY=http://p:1",
        "NO_PROXY=localhost,127.0.0.1,::1,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,host.docker.internal,splunk,postgres,scenario-controller,payment-mock,payment-service,inventory-service,order-service,api-gateway,load-generator,newrelic-mcp,console-api,console-ui",
        "SPLUNK_PASSWORD=x",
        "SPLUNK_HEC_ENABLED=false",
        "SPLUNK_HEC_TOKEN=x",
        "SPLUNK_SEARCH_PASSWORD=x",
        "NEW_RELIC_ENABLED=true",
        "NEW_RELIC_LICENSE_KEY=x",
        "NEW_RELIC_API_KEY=x",
        "NEW_RELIC_MCP_USER_KEY=x",
        "NEW_RELIC_ACCOUNT_ID=1",
        "LLM_PROVIDER=ollama",
    ]) + "\n"
    result = _run_preflight(tmp_path, env_text)
    assert result.returncode != 0
    assert "SPLUNK_HEC_ENABLED" in result.stderr
