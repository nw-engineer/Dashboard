import json
import os
import subprocess
from pathlib import Path

SCRIPT = Path('scripts/newrelic_change_event.sh')


def run_script(env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    merged = os.environ.copy()
    merged.update(env)
    return subprocess.run(
        ['bash', str(SCRIPT)],
        text=True,
        capture_output=True,
        env=merged,
        check=False,
    )


def test_change_event_script_requires_core_environment_variables():
    result = run_script({
        'NEW_RELIC_API_KEY': '',
        'NEW_RELIC_ENTITY_GUID': '',
        'DEPLOYMENT_ID': '',
        'SERVICE_VERSION': '',
    })

    assert result.returncode != 0
    assert 'NEW_RELIC_API_KEY' in result.stderr
    assert 'NEW_RELIC_ENTITY_GUID' in result.stderr
    assert 'DEPLOYMENT_ID' in result.stderr
    assert 'SERVICE_VERSION' in result.stderr


def test_change_event_script_posts_modern_nerdgraph_change_event(tmp_path: Path):
    capture = tmp_path / 'curl_args.json'
    fake_curl = tmp_path / 'curl'
    fake_curl.write_text(
        '#!/usr/bin/env python3\n'
        'import json, os, sys\n'
        'open(os.environ["CURL_CAPTURE"], "w").write(json.dumps(sys.argv[1:]))\n'
        'print(\'{"data":{"changeTrackingCreateEvent":{"messages":[]}}}\')\n'
    )
    fake_curl.chmod(0o755)

    secret = 'NRAK-secret-user-key'
    result = run_script({
        'PATH': f'{tmp_path}:{os.environ["PATH"]}',
        'CURL_CAPTURE': str(capture),
        'NEW_RELIC_API_KEY': secret,
        'NEW_RELIC_ENTITY_GUID': 'ENTITY-GUID-123',
        'NEW_RELIC_NERDGRAPH_URL': 'https://api.newrelic.com/graphql',
        'DEPLOYMENT_ID': 'demo-deploy-005',
        'SERVICE_VERSION': '1.1.0',
        'GIT_SHA': 'abc123def',
    })

    assert result.returncode == 0, result.stderr
    assert secret not in result.stdout
    assert secret not in result.stderr

    args = json.loads(capture.read_text())
    assert 'https://api.newrelic.com/graphql' in args
    payload = args[args.index('--data-binary') + 1]
    body = json.loads(payload)
    query = body['query']
    assert 'changeTrackingCreateEvent' in query
    assert 'ENTITY-GUID-123' in query
    assert 'version: "1.1.0"' in query
    assert 'groupId: "demo-deploy-005"' in query
    assert 'deploymentId:' not in query
    assert 'gitSha: "abc123def"' in query
