import json

import httpx
import pytest

from agent.analysis.models import IncidentAnalysis
from agent.analysis.prompt import ANALYSIS_CONTRACT
from agent.analysis.schema import build_azure_incident_analysis_schema
from agent.evidence.models import (
    EvidenceBundle,
    EvidenceCategory,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)


def _bundle() -> EvidenceBundle:
    return EvidenceBundle(
        investigation_id="inv-azure-1",
        request_id="req-1",
        trace_id="trace-1",
        evidence=[
            EvidenceItem(
                evidence_id="newrelic-001",
                source=EvidenceSource.NEW_RELIC,
                category=EvidenceCategory.TRANSACTION,
                summary="Transaction duration increased after deployment.",
                facts={"duration": 1.8, "error": False},
                query_or_tool="query-newrelic-001",
                request_id="req-1",
                trace_id="trace-1",
            ),
            EvidenceItem(
                evidence_id="splunk-001",
                source=EvidenceSource.SPLUNK,
                category=EvidenceCategory.DEPLOYMENT,
                summary="inventory-service version 1.1.0 was deployed.",
                facts={"service.version": "1.1.0"},
                query_or_tool="query-splunk-001",
                request_id="req-1",
                trace_id="trace-1",
            ),
        ],
        contradictions=[],
        gaps=[],
        queries_used=[
            QueryDisclosure(
                disclosure_id="query-newrelic-001",
                source=EvidenceSource.NEW_RELIC,
                operation="execute_nrql_query",
                arguments={"nrql_query": "SELECT duration FROM Transaction"},
            ),
            QueryDisclosure(
                disclosure_id="query-splunk-001",
                source=EvidenceSource.SPLUNK,
                operation="search",
                arguments={"query": 'trace.id="trace-1"'},
            ),
        ],
    )


def _analysis_payload() -> dict:
    return {
        "incident_summary": "The correlated request was slow after a deployment.",
        "impact": "One request was observed with elevated latency.",
        "likely_cause": "Deployment 1.1.0 is a supported cause candidate, not proven causation.",
        "confidence": "medium",
        "supporting_evidence_ids": ["newrelic-001", "splunk-001"],
        "alternative_hypotheses": [],
        "recommended_checks": ["Compare latency before and after deployment 1.1.0."],
        "recommended_actions": ["Review the deployment diff before making any change."],
        "new_relic_evidence_ids": ["newrelic-001"],
        "splunk_evidence_ids": ["splunk-001"],
        "contradiction_ids": [],
        "query_disclosure_ids": ["query-newrelic-001", "query-splunk-001"],
    }


def _completed_response(payload: dict) -> dict:
    return {
        "id": "resp_azure_test",
        "status": "completed",
        "output": [
            {
                "type": "message",
                "content": [
                    {
                        "type": "output_text",
                        "text": json.dumps(payload),
                        "annotations": [],
                    }
                ],
            }
        ],
    }


@pytest.mark.asyncio
async def test_azure_analyzer_uses_responses_api_with_api_key_and_strict_schema():
    from agent.analysis.azure_openai_adapter import AzureOpenAIIncidentAnalyzer

    captured = {}

    async def handler(request: httpx.Request) -> httpx.Response:
        captured["request"] = request
        captured["payload"] = json.loads(request.content)
        return httpx.Response(200, json=_completed_response(_analysis_payload()))

    bundle = _bundle()
    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = AzureOpenAIIncidentAnalyzer(
            api_key="azure-test-key",
            model="poc-analysis-deployment",
            base_url="https://example.openai.azure.com/openai/v1",
            client=client,
        )
        analysis = await analyzer.analyze(bundle)

    assert analysis == IncidentAnalysis(**_analysis_payload())
    request = captured["request"]
    payload = captured["payload"]
    assert str(request.url) == "https://example.openai.azure.com/openai/v1/responses"
    assert request.headers["api-key"] == "azure-test-key"
    assert payload["model"] == "poc-analysis-deployment"
    assert payload["store"] is False
    assert payload["max_output_tokens"] == 2500
    assert payload["instructions"] == ANALYSIS_CONTRACT
    assert payload["text"]["format"]["type"] == "json_schema"
    assert payload["text"]["format"]["strict"] is True
    assert payload["text"]["format"]["schema"] == build_azure_incident_analysis_schema(bundle)



def test_azure_schema_omits_unsupported_structured_output_keywords():
    schema = build_azure_incident_analysis_schema()
    unsupported = {
        "minLength", "maxLength", "pattern", "format",
        "minimum", "maximum", "multipleOf",
        "patternProperties", "unevaluatedProperties", "propertyNames",
        "minProperties", "maxProperties",
        "unevaluatedItems", "contains", "minContains", "maxContains",
        "minItems", "maxItems", "uniqueItems",
    }
    found = []

    def walk(node, path="$"):
        if isinstance(node, dict):
            for key, value in node.items():
                if key in unsupported:
                    found.append((path, key))
                walk(value, f"{path}.{key}")
        elif isinstance(node, list):
            for index, value in enumerate(node):
                walk(value, f"{path}[{index}]")

    walk(schema)
    assert found == []


def test_azure_analyzer_from_env_requires_api_key(monkeypatch):
    from agent.analysis.azure_openai_adapter import (
        AzureOpenAIConfigurationError,
        AzureOpenAIIncidentAnalyzer,
    )

    monkeypatch.delenv("AZURE_OPENAI_API_KEY", raising=False)
    monkeypatch.setenv("AZURE_OPENAI_BASE_URL", "https://example.openai.azure.com/openai/v1")
    monkeypatch.setenv("AZURE_OPENAI_MODEL", "deployment")

    with pytest.raises(AzureOpenAIConfigurationError, match="AZURE_OPENAI_API_KEY"):
        AzureOpenAIIncidentAnalyzer.from_env()


def test_azure_analyzer_from_env_requires_base_url(monkeypatch):
    from agent.analysis.azure_openai_adapter import (
        AzureOpenAIConfigurationError,
        AzureOpenAIIncidentAnalyzer,
    )

    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "env-key")
    monkeypatch.delenv("AZURE_OPENAI_BASE_URL", raising=False)
    monkeypatch.setenv("AZURE_OPENAI_MODEL", "deployment")

    with pytest.raises(AzureOpenAIConfigurationError, match="AZURE_OPENAI_BASE_URL"):
        AzureOpenAIIncidentAnalyzer.from_env()


def test_azure_analyzer_from_env_requires_model(monkeypatch):
    from agent.analysis.azure_openai_adapter import (
        AzureOpenAIConfigurationError,
        AzureOpenAIIncidentAnalyzer,
    )

    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "env-key")
    monkeypatch.setenv("AZURE_OPENAI_BASE_URL", "https://example.openai.azure.com/openai/v1")
    monkeypatch.delenv("AZURE_OPENAI_MODEL", raising=False)

    with pytest.raises(AzureOpenAIConfigurationError, match="AZURE_OPENAI_MODEL"):
        AzureOpenAIIncidentAnalyzer.from_env()


def test_azure_analyzer_from_env_reads_numeric_configuration(monkeypatch):
    from agent.analysis.azure_openai_adapter import AzureOpenAIIncidentAnalyzer

    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "env-key")
    monkeypatch.setenv("AZURE_OPENAI_BASE_URL", "https://example.openai.azure.com/openai/v1/")
    monkeypatch.setenv("AZURE_OPENAI_MODEL", "deployment")
    monkeypatch.setenv("AZURE_OPENAI_MAX_OUTPUT_TOKENS", "3000")
    monkeypatch.setenv("AZURE_OPENAI_TIMEOUT_SECONDS", "75")

    analyzer = AzureOpenAIIncidentAnalyzer.from_env()

    assert analyzer.base_url == "https://example.openai.azure.com/openai/v1"
    assert analyzer.model == "deployment"
    assert analyzer.max_output_tokens == 3000
    assert analyzer.timeout_seconds == 75.0


def test_azure_analyzer_from_env_rejects_invalid_max_output_tokens(monkeypatch):
    from agent.analysis.azure_openai_adapter import (
        AzureOpenAIConfigurationError,
        AzureOpenAIIncidentAnalyzer,
    )

    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "env-key")
    monkeypatch.setenv("AZURE_OPENAI_BASE_URL", "https://example.openai.azure.com/openai/v1")
    monkeypatch.setenv("AZURE_OPENAI_MODEL", "deployment")
    monkeypatch.setenv("AZURE_OPENAI_MAX_OUTPUT_TOKENS", "not-an-int")

    with pytest.raises(AzureOpenAIConfigurationError, match="AZURE_OPENAI_MAX_OUTPUT_TOKENS"):
        AzureOpenAIIncidentAnalyzer.from_env()


def test_azure_analyzer_from_env_rejects_invalid_timeout(monkeypatch):
    from agent.analysis.azure_openai_adapter import (
        AzureOpenAIConfigurationError,
        AzureOpenAIIncidentAnalyzer,
    )

    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "env-key")
    monkeypatch.setenv("AZURE_OPENAI_BASE_URL", "https://example.openai.azure.com/openai/v1")
    monkeypatch.setenv("AZURE_OPENAI_MODEL", "deployment")
    monkeypatch.setenv("AZURE_OPENAI_TIMEOUT_SECONDS", "not-a-number")

    with pytest.raises(AzureOpenAIConfigurationError, match="AZURE_OPENAI_TIMEOUT_SECONDS"):
        AzureOpenAIIncidentAnalyzer.from_env()


@pytest.mark.asyncio
async def test_azure_analyzer_wraps_network_error():
    from agent.analysis.azure_openai_adapter import (
        AzureOpenAIAnalysisError,
        AzureOpenAIIncidentAnalyzer,
    )

    async def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("network unavailable", request=request)

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = AzureOpenAIIncidentAnalyzer(
            api_key="azure-test-key",
            model="deployment",
            base_url="https://example.openai.azure.com/openai/v1",
            client=client,
        )
        with pytest.raises(AzureOpenAIAnalysisError, match="request failed") as exc_info:
            await analyzer.analyze(_bundle())

    assert "network unavailable" not in str(exc_info.value)


@pytest.mark.asyncio
async def test_azure_analyzer_wraps_http_error_without_response_body():
    from agent.analysis.azure_openai_adapter import (
        AzureOpenAIAnalysisError,
        AzureOpenAIIncidentAnalyzer,
    )

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(429, text='{"error":"secret-ish upstream detail"}')

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = AzureOpenAIIncidentAnalyzer(
            api_key="azure-test-key",
            model="deployment",
            base_url="https://example.openai.azure.com/openai/v1",
            client=client,
        )
        with pytest.raises(AzureOpenAIAnalysisError) as exc_info:
            await analyzer.analyze(_bundle())

    message = str(exc_info.value)
    assert "429" in message
    assert "secret-ish upstream detail" not in message
    assert "azure-test-key" not in message


@pytest.mark.asyncio
async def test_azure_analyzer_wraps_non_json_api_response():
    from agent.analysis.azure_openai_adapter import (
        AzureOpenAIAnalysisError,
        AzureOpenAIIncidentAnalyzer,
    )

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text="not-json")

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = AzureOpenAIIncidentAnalyzer(
            api_key="azure-test-key",
            model="deployment",
            base_url="https://example.openai.azure.com/openai/v1",
            client=client,
        )
        with pytest.raises(AzureOpenAIAnalysisError, match="invalid JSON response"):
            await analyzer.analyze(_bundle())


@pytest.mark.asyncio
async def test_azure_analyzer_rejects_incomplete_response():
    from agent.analysis.azure_openai_adapter import (
        AzureOpenAIAnalysisError,
        AzureOpenAIIncidentAnalyzer,
    )

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "resp_incomplete",
                "status": "incomplete",
                "output": [
                    {
                        "type": "message",
                        "content": [
                            {
                                "type": "output_text",
                                "text": json.dumps(_analysis_payload()),
                            }
                        ],
                    }
                ],
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = AzureOpenAIIncidentAnalyzer(
            api_key="azure-test-key",
            model="deployment",
            base_url="https://example.openai.azure.com/openai/v1",
            client=client,
        )
        with pytest.raises(AzureOpenAIAnalysisError, match="incomplete"):
            await analyzer.analyze(_bundle())


@pytest.mark.asyncio
async def test_azure_analyzer_rejects_refusal_response():
    from agent.analysis.azure_openai_adapter import (
        AzureOpenAIAnalysisError,
        AzureOpenAIIncidentAnalyzer,
    )

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "resp_refusal",
                "status": "completed",
                "output": [
                    {
                        "type": "message",
                        "content": [
                            {"type": "refusal", "refusal": "Cannot comply."}
                        ],
                    }
                ],
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = AzureOpenAIIncidentAnalyzer(
            api_key="azure-test-key",
            model="deployment",
            base_url="https://example.openai.azure.com/openai/v1",
            client=client,
        )
        with pytest.raises(AzureOpenAIAnalysisError, match="refused"):
            await analyzer.analyze(_bundle())


@pytest.mark.asyncio
async def test_azure_analyzer_wraps_invalid_structured_output():
    from agent.analysis.azure_openai_adapter import (
        AzureOpenAIAnalysisError,
        AzureOpenAIIncidentAnalyzer,
    )

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "resp_bad_json",
                "status": "completed",
                "output": [
                    {
                        "type": "message",
                        "content": [
                            {"type": "output_text", "text": "{not-json"}
                        ],
                    }
                ],
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = AzureOpenAIIncidentAnalyzer(
            api_key="azure-test-key",
            model="deployment",
            base_url="https://example.openai.azure.com/openai/v1",
            client=client,
        )
        with pytest.raises(AzureOpenAIAnalysisError, match="structured output"):
            await analyzer.analyze(_bundle())


def test_azure_schema_constrains_reference_fields_to_ids_from_bundle():
    from agent.evidence.models import EvidenceGap

    bundle = _bundle()
    bundle.gaps.append(
        EvidenceGap(
            gap_id="gap-live-span-001",
            summary="Span evidence is unavailable.",
            source=EvidenceSource.NEW_RELIC,
            category=EvidenceCategory.SPAN,
        )
    )

    schema = build_azure_incident_analysis_schema(bundle)
    properties = schema["properties"]
    hypothesis = schema["$defs"]["Hypothesis"]["properties"]

    assert properties["supporting_evidence_ids"]["items"]["enum"] == [
        "newrelic-001",
        "splunk-001",
    ]
    assert hypothesis["supporting_evidence_ids"]["items"]["enum"] == [
        "newrelic-001",
        "splunk-001",
    ]
    assert hypothesis["opposing_evidence_ids"]["items"]["enum"] == [
        "newrelic-001",
        "splunk-001",
    ]
    assert properties["new_relic_evidence_ids"]["items"]["enum"] == [
        "newrelic-001"
    ]
    assert properties["splunk_evidence_ids"]["items"]["enum"] == ["splunk-001"]
    assert properties["query_disclosure_ids"]["items"]["enum"] == [
        "query-newrelic-001",
        "query-splunk-001",
    ]
    assert "enum" not in properties["contradiction_ids"]["items"]
    assert "gap-live-span-001" not in json.dumps(schema)


def test_analysis_contract_says_gap_ids_are_not_evidence_ids():
    assert "EvidenceGap gap IDs are not evidence IDs" in ANALYSIS_CONTRACT
    assert "never place a gap ID in any evidence ID field" in ANALYSIS_CONTRACT


@pytest.mark.asyncio
async def test_azure_analyzer_sends_bundle_scoped_reference_enums():
    from agent.analysis.azure_openai_adapter import AzureOpenAIIncidentAnalyzer
    from agent.evidence.models import EvidenceGap

    bundle = _bundle()
    bundle.gaps.append(
        EvidenceGap(
            gap_id="gap-live-span-001",
            summary="Span evidence is unavailable.",
            source=EvidenceSource.NEW_RELIC,
            category=EvidenceCategory.SPAN,
        )
    )
    captured = {}

    async def handler(request: httpx.Request) -> httpx.Response:
        captured["payload"] = json.loads(request.content)
        return httpx.Response(200, json=_completed_response(_analysis_payload()))

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = AzureOpenAIIncidentAnalyzer(
            api_key="azure-test-key",
            model="deployment",
            base_url="https://example.openai.azure.com/openai/v1",
            client=client,
        )
        await analyzer.analyze(bundle)

    sent_schema = captured["payload"]["text"]["format"]["schema"]
    assert sent_schema == build_azure_incident_analysis_schema(bundle)
    assert "gap-live-span-001" not in json.dumps(sent_schema)


@pytest.mark.asyncio
async def test_azure_analyzer_repairs_unknown_evidence_reference_once():
    from agent.analysis.azure_openai_adapter import AzureOpenAIIncidentAnalyzer
    from agent.analysis.analyzer import validate_analysis_references
    from agent.evidence.models import EvidenceGap

    bundle = _bundle()
    bundle.gaps.append(
        EvidenceGap(
            gap_id="gap-live-span-001",
            summary="Span evidence is unavailable.",
            source=EvidenceSource.NEW_RELIC,
            category=EvidenceCategory.SPAN,
        )
    )
    invalid_payload = _analysis_payload()
    invalid_payload["alternative_hypotheses"] = [
        {
            "summary": "Missing span evidence may explain the uncertainty.",
            "supporting_evidence_ids": ["gap-live-span-001"],
            "opposing_evidence_ids": [],
        }
    ]
    repaired_payload = _analysis_payload()
    repaired_payload["alternative_hypotheses"] = [
        {
            "summary": "The observed New Relic transaction may reflect a broader latency issue.",
            "supporting_evidence_ids": ["newrelic-001"],
            "opposing_evidence_ids": [],
        }
    ]
    requests = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(json.loads(request.content))
        payload = invalid_payload if len(requests) == 1 else repaired_payload
        return httpx.Response(200, json=_completed_response(payload))

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = AzureOpenAIIncidentAnalyzer(
            api_key="azure-test-key",
            model="deployment",
            base_url="https://example.openai.azure.com/openai/v1",
            client=client,
        )
        analysis = await analyzer.analyze(bundle)

    validate_analysis_references(bundle, analysis)
    assert analysis == IncidentAnalysis(**repaired_payload)
    assert len(requests) == 2
    repair_request = requests[1]
    assert repair_request["text"]["format"]["schema"] == build_azure_incident_analysis_schema(bundle)
    assert "gap-live-span-001" in repair_request["input"]
    assert "unknown evidence IDs" in repair_request["input"]
    assert "newrelic-001" in repair_request["input"]
    assert "splunk-001" in repair_request["input"]
    assert "EvidenceGap" in repair_request["input"]


@pytest.mark.asyncio
async def test_azure_analyzer_stops_after_one_failed_reference_repair_attempt():
    from agent.analysis.azure_openai_adapter import (
        AzureOpenAIAnalysisError,
        AzureOpenAIIncidentAnalyzer,
    )
    from agent.evidence.models import EvidenceGap

    bundle = _bundle()
    bundle.gaps.append(
        EvidenceGap(
            gap_id="gap-live-span-001",
            summary="Span evidence is unavailable.",
            source=EvidenceSource.NEW_RELIC,
            category=EvidenceCategory.SPAN,
        )
    )
    invalid_payload = _analysis_payload()
    invalid_payload["alternative_hypotheses"] = [
        {
            "summary": "Missing span evidence may explain the uncertainty.",
            "supporting_evidence_ids": ["gap-live-span-001"],
            "opposing_evidence_ids": [],
        }
    ]
    calls = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(200, json=_completed_response(invalid_payload))

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = AzureOpenAIIncidentAnalyzer(
            api_key="azure-test-key",
            model="deployment",
            base_url="https://example.openai.azure.com/openai/v1",
            client=client,
        )
        with pytest.raises(AzureOpenAIAnalysisError, match="reference validation after repair attempt"):
            await analyzer.analyze(bundle)

    assert calls == 2
