from load_generator.main import requests_per_minute
from shared.scenario import ScenarioId


def test_high_load_profile():
    assert requests_per_minute(ScenarioId.NORMAL) == 50
    assert requests_per_minute(ScenarioId.UC04_HIGH_LOAD) == 1000
