import json
from contextlib import asynccontextmanager

import pytest

from agent.evidence.newrelic_transport import (
    McpToolInfo,
    NewRelicMcpTransportError,
    StreamableHttpNewRelicMcpGateway,
)


class FakeTool:
    def __init__(self, name, description=None, input_schema=None):
        self.name = name
        self.description = description
        self.inputSchema = input_schema or {}


class FakeListToolsResult:
    def __init__(self, tools):
        self.tools = tools


class FakeTextContent:
    def __init__(self, text):
        self.text = text


class FakeCallToolResult:
    def __init__(self, *, structured=None, text=None, is_error=False):
        self.structuredContent = structured
        self.content = [] if text is None else [FakeTextContent(text)]
        self.isError = is_error


class FakeSession:
    def __init__(self, *, call_result=None):
        self.initialized = 0
        self.calls = []
        self.call_result = call_result or FakeCallToolResult(structured={"results": []})

    async def initialize(self):
        self.initialized += 1

    async def list_tools(self):
        return FakeListToolsResult(
            [
                FakeTool(
                    "execute_nrql_query",
                    "Run NRQL",
                    {"type": "object", "properties": {"query": {"type": "string"}}},
                ),
                FakeTool("list_change_events", "List changes", {"type": "object"}),
            ]
        )

    async def call_tool(self, name, arguments):
        self.calls.append((name, arguments))
        return self.call_result


class SessionFactory:
    def __init__(self, session):
        self.session = session
        self.urls = []

    @asynccontextmanager
    async def __call__(self, url):
        self.urls.append(url)
        yield self.session


@pytest.mark.asyncio
async def test_list_tools_initializes_session_and_preserves_schema():
    session = FakeSession()
    factory = SessionFactory(session)
    gateway = StreamableHttpNewRelicMcpGateway(
        "http://localhost:8000/mcp", session_factory=factory
    )

    tools = await gateway.list_tools()

    assert session.initialized == 1
    assert factory.urls == ["http://localhost:8000/mcp"]
    assert tools == [
        McpToolInfo(
            name="execute_nrql_query",
            description="Run NRQL",
            input_schema={"type": "object", "properties": {"query": {"type": "string"}}},
        ),
        McpToolInfo(
            name="list_change_events",
            description="List changes",
            input_schema={"type": "object"},
        ),
    ]


@pytest.mark.asyncio
async def test_call_tool_returns_structured_content_without_stringifying_it():
    payload = {"results": [{"traceId": "trace-1", "duration": 0.1}]}
    session = FakeSession(call_result=FakeCallToolResult(structured=payload))
    gateway = StreamableHttpNewRelicMcpGateway(
        "http://localhost:8000/mcp", session_factory=SessionFactory(session)
    )

    result = await gateway.call_tool("execute_nrql_query", {"query": "SELECT 1"})

    assert result == payload
    assert session.calls == [("execute_nrql_query", {"query": "SELECT 1"})]


@pytest.mark.asyncio
async def test_call_tool_parses_json_text_when_structured_content_is_absent():
    payload = {"events": [{"category": "Deployment", "version": "1.1.0"}]}
    session = FakeSession(
        call_result=FakeCallToolResult(text=json.dumps(payload, separators=(",", ":")))
    )
    gateway = StreamableHttpNewRelicMcpGateway(
        "http://localhost:8000/mcp", session_factory=SessionFactory(session)
    )

    result = await gateway.call_tool("list_change_events", {})

    assert result == payload


@pytest.mark.asyncio
async def test_call_tool_keeps_non_json_text_as_content_for_diagnostics():
    session = FakeSession(call_result=FakeCallToolResult(text="plain diagnostic text"))
    gateway = StreamableHttpNewRelicMcpGateway(
        "http://localhost:8000/mcp", session_factory=SessionFactory(session)
    )

    result = await gateway.call_tool("some_tool", {})

    assert result == {"content": "plain diagnostic text"}


@pytest.mark.asyncio
async def test_mcp_error_result_raises_sanitized_transport_error():
    session = FakeSession(
        call_result=FakeCallToolResult(text="password=secret token=abc", is_error=True)
    )
    gateway = StreamableHttpNewRelicMcpGateway(
        "http://localhost:8000/mcp", session_factory=SessionFactory(session)
    )

    with pytest.raises(NewRelicMcpTransportError, match="MCP tool call failed") as exc:
        await gateway.call_tool("execute_nrql_query", {"query": "SELECT 1"})

    message = str(exc.value).lower()
    assert "secret" not in message
    assert "token=abc" not in message
