from datetime import datetime, timedelta, timezone

import pytest

from agent.splunk.guard import SplunkQueryRejected, normalize_search_request
from agent.splunk.models import SplunkSearchRequest


NOW = datetime(2026, 9, 3, 4, 0, tzinfo=timezone.utc)


def request(query: str, *, hours: float = 1, max_results: int = 100):
    return SplunkSearchRequest(
        query=query,
        earliest=NOW - timedelta(hours=hours),
        latest=NOW,
        max_results=max_results,
    )


@pytest.mark.parametrize(
    "query",
    [
        "index=poc_observability | delete",
        "index=poc_observability | collect index=other",
        "index=poc_observability | outputlookup x.csv",
        "index=poc_observability | sendalert email",
        "index=poc_observability | sendemail to=ops@example.com",
        "index=poc_observability | outputcsv evidence.csv",
        "index=poc_observability | tscollect namespace=foo",
        "index=poc_observability | rest /services/server/info",
        "index=poc_observability | script python risky.py",
        "index=poc_observability | runshellscript risky.sh",
        "index=poc_observability | savedsearch privileged_search",
        "index=poc_observability | loadjob savedsearch=admin:search:foo",
        "index=poc_observability | map search=\"search index=poc_observability\"",
    ],
)
def test_rejects_mutating_commands(query):
    with pytest.raises(SplunkQueryRejected):
        normalize_search_request(request(query))


def test_rejects_other_index():
    with pytest.raises(SplunkQueryRejected):
        normalize_search_request(request("index=prod_logs error"))


def test_rejects_range_over_two_hours():
    with pytest.raises(SplunkQueryRejected):
        normalize_search_request(request("error", hours=2.01))


def test_rejects_more_than_200_results():
    with pytest.raises(SplunkQueryRejected):
        normalize_search_request(request("error", max_results=201))


def test_prepends_fixed_index_when_missing():
    normalized = normalize_search_request(request('request.id="r1" | table event_type'))
    assert normalized.query == 'search index=poc_observability request.id="r1" | table event_type'


def test_preserves_search_with_fixed_index():
    normalized = normalize_search_request(
        request('search index=poc_observability scenario.id="UC01_DB_SLOW"')
    )
    assert normalized.query.startswith("search index=poc_observability")


def test_rejects_spl_macro_expansion():
    with pytest.raises(SplunkQueryRejected):
        normalize_search_request(request('index=poc_observability `hidden_macro`'))
