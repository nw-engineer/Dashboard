import json

import httpx
import pytest

from agent.analysis.models import IncidentAnalysis
from agent.analysis.schema import build_ollama_incident_analysis_schema
from agent.evidence.models import (
    EvidenceBundle,
    EvidenceCategory,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)


def _bundle() -> EvidenceBundle:
    return EvidenceBundle(
        investigation_id="inv-ollama-1",
        request_id="req-1",
        trace_id="trace-1",
        evidence=[
            EvidenceItem(
                evidence_id="newrelic-001",
                source=EvidenceSource.NEW_RELIC,
                category=EvidenceCategory.TRANSACTION,
                summary="Transaction duration increased after deployment.",
                facts={"duration": 1.8, "error": False},
                query_or_tool="query-newrelic-001",
                request_id="req-1",
                trace_id="trace-1",
            ),
            EvidenceItem(
                evidence_id="splunk-001",
                source=EvidenceSource.SPLUNK,
                category=EvidenceCategory.DEPLOYMENT,
                summary="inventory-service version 1.1.0 was deployed.",
                facts={"service.version": "1.1.0"},
                query_or_tool="query-splunk-001",
                request_id="req-1",
                trace_id="trace-1",
            ),
        ],
        contradictions=[],
        gaps=[],
        queries_used=[
            QueryDisclosure(
                disclosure_id="query-newrelic-001",
                source=EvidenceSource.NEW_RELIC,
                operation="execute_nrql_query",
                arguments={"nrql_query": "SELECT duration FROM Transaction"},
            ),
            QueryDisclosure(
                disclosure_id="query-splunk-001",
                source=EvidenceSource.SPLUNK,
                operation="search",
                arguments={"query": 'trace.id="trace-1"'},
            ),
        ],
    )


def _analysis_payload() -> dict:
    return {
        "incident_summary": "The correlated request was slow after a deployment.",
        "impact": "One request was observed with elevated latency.",
        "likely_cause": "Deployment 1.1.0 is a supported cause candidate, not proven causation.",
        "confidence": "medium",
        "supporting_evidence_ids": ["newrelic-001", "splunk-001"],
        "alternative_hypotheses": [],
        "recommended_checks": ["Compare latency before and after deployment 1.1.0."],
        "recommended_actions": ["Review the deployment diff before making any change."],
        "new_relic_evidence_ids": ["newrelic-001"],
        "splunk_evidence_ids": ["splunk-001"],
        "contradiction_ids": [],
        "query_disclosure_ids": ["query-newrelic-001", "query-splunk-001"],
    }


@pytest.mark.asyncio
async def test_ollama_analyzer_uses_native_chat_with_schema_and_no_streaming():
    from agent.analysis.ollama_adapter import OllamaIncidentAnalyzer

    captured = {}

    async def handler(request: httpx.Request) -> httpx.Response:
        captured["request"] = request
        captured["payload"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={
                "model": "gpt-oss:20b",
                "message": {
                    "role": "assistant",
                    "content": json.dumps(_analysis_payload()),
                    "thinking": "internal reasoning that must not be used",
                },
                "done": True,
                "done_reason": "stop",
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(
            base_url="http://localhost:11434",
            model="gpt-oss:20b",
            reasoning_effort="medium",
            client=client,
        )
        analysis = await analyzer.analyze(_bundle())

    assert analysis == IncidentAnalysis(**_analysis_payload())
    request = captured["request"]
    payload = captured["payload"]
    assert str(request.url) == "http://localhost:11434/api/chat"
    assert payload["model"] == "gpt-oss:20b"
    assert payload["stream"] is False
    assert payload["think"] == "medium"
    assert payload["format"] == build_ollama_incident_analysis_schema()
    assert payload["options"]["temperature"] == 0
    assert "internal reasoning" not in analysis.model_dump_json()


def test_ollama_analyzer_from_env_reads_provider_configuration(monkeypatch):
    from agent.analysis.ollama_adapter import OllamaIncidentAnalyzer

    monkeypatch.setenv("OLLAMA_BASE_URL", "http://ollama.internal:11434/")
    monkeypatch.setenv("OLLAMA_MODEL", "gpt-oss:20b-custom")
    monkeypatch.setenv("OLLAMA_REASONING_EFFORT", "high")
    monkeypatch.setenv("OLLAMA_TIMEOUT_SECONDS", "240")

    analyzer = OllamaIncidentAnalyzer.from_env()

    assert analyzer.base_url == "http://ollama.internal:11434"
    assert analyzer.model == "gpt-oss:20b-custom"
    assert analyzer.reasoning_effort == "high"
    assert analyzer.timeout_seconds == 240.0


def test_ollama_analyzer_from_env_rejects_invalid_reasoning_effort(monkeypatch):
    from agent.analysis.ollama_adapter import OllamaConfigurationError, OllamaIncidentAnalyzer

    monkeypatch.setenv("OLLAMA_REASONING_EFFORT", "extreme")

    with pytest.raises(OllamaConfigurationError, match="OLLAMA_REASONING_EFFORT"):
        OllamaIncidentAnalyzer.from_env()


def test_ollama_analyzer_from_env_rejects_invalid_timeout(monkeypatch):
    from agent.analysis.ollama_adapter import OllamaConfigurationError, OllamaIncidentAnalyzer

    monkeypatch.setenv("OLLAMA_TIMEOUT_SECONDS", "not-a-number")

    with pytest.raises(OllamaConfigurationError, match="OLLAMA_TIMEOUT_SECONDS"):
        OllamaIncidentAnalyzer.from_env()


@pytest.mark.asyncio
async def test_ollama_analyzer_wraps_network_error():
    from agent.analysis.ollama_adapter import OllamaAnalysisError, OllamaIncidentAnalyzer

    async def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("network unavailable", request=request)

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(client=client)
        with pytest.raises(OllamaAnalysisError, match="request failed") as exc_info:
            await analyzer.analyze(_bundle())

    assert "network unavailable" not in str(exc_info.value)


@pytest.mark.asyncio
async def test_ollama_analyzer_wraps_http_error_without_response_body():
    from agent.analysis.ollama_adapter import OllamaAnalysisError, OllamaIncidentAnalyzer

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, text='{"error":"secret-ish upstream detail"}')

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(client=client)
        with pytest.raises(OllamaAnalysisError) as exc_info:
            await analyzer.analyze(_bundle())

    message = str(exc_info.value)
    assert "500" in message
    assert "secret-ish upstream detail" not in message


@pytest.mark.asyncio
async def test_ollama_analyzer_wraps_non_json_api_response():
    from agent.analysis.ollama_adapter import OllamaAnalysisError, OllamaIncidentAnalyzer

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text="not-json")

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(client=client)
        with pytest.raises(OllamaAnalysisError, match="invalid JSON response"):
            await analyzer.analyze(_bundle())


@pytest.mark.asyncio
async def test_ollama_analyzer_rejects_incomplete_response():
    from agent.analysis.ollama_adapter import OllamaAnalysisError, OllamaIncidentAnalyzer

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "model": "gpt-oss:20b",
                "message": {"role": "assistant", "content": json.dumps(_analysis_payload())},
                "done": False,
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(client=client)
        with pytest.raises(OllamaAnalysisError, match="not completed"):
            await analyzer.analyze(_bundle())


@pytest.mark.asyncio
async def test_ollama_analyzer_rejects_missing_message_content():
    from agent.analysis.ollama_adapter import OllamaAnalysisError, OllamaIncidentAnalyzer

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "model": "gpt-oss:20b",
                "message": {"role": "assistant", "content": ""},
                "done": True,
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(client=client)
        with pytest.raises(OllamaAnalysisError, match="message content"):
            await analyzer.analyze(_bundle())


@pytest.mark.asyncio
async def test_ollama_analyzer_wraps_invalid_structured_output():
    from agent.analysis.ollama_adapter import OllamaAnalysisError, OllamaIncidentAnalyzer

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "model": "gpt-oss:20b",
                "message": {"role": "assistant", "content": "{not-json"},
                "done": True,
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(client=client)
        with pytest.raises(OllamaAnalysisError, match="structured output"):
            await analyzer.analyze(_bundle())

@pytest.mark.asyncio
async def test_ollama_analyzer_repairs_invalid_structured_output_once():
    from agent.analysis.ollama_adapter import OllamaIncidentAnalyzer

    requests = []
    invalid_payload = _analysis_payload()
    invalid_payload["alternative_hypotheses"] = [
        {
            "supporting_evidence_ids": ["newrelic-001"],
            "opposing_evidence_ids": [],
        }
    ]
    valid_payload = _analysis_payload()
    valid_payload["alternative_hypotheses"] = [
        {
            "summary": "A dependency slowdown may also have contributed.",
            "supporting_evidence_ids": ["newrelic-001"],
            "opposing_evidence_ids": [],
        }
    ]

    async def handler(request: httpx.Request) -> httpx.Response:
        request_payload = json.loads(request.content)
        requests.append(request_payload)
        content = invalid_payload if len(requests) == 1 else valid_payload
        return httpx.Response(
            200,
            json={
                "model": "gpt-oss:20b",
                "message": {"role": "assistant", "content": json.dumps(content)},
                "done": True,
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(client=client)
        analysis = await analyzer.analyze(_bundle())

    assert analysis == IncidentAnalysis(**valid_payload)
    assert len(requests) == 2
    repair_messages = requests[1]["messages"]
    assert repair_messages[-2]["role"] == "assistant"
    assert json.loads(repair_messages[-2]["content"]) == invalid_payload
    assert repair_messages[-1]["role"] == "user"
    assert "alternative_hypotheses.0.summary" in repair_messages[-1]["content"]
    assert "repair" in repair_messages[-1]["content"].lower()


@pytest.mark.asyncio
async def test_ollama_analyzer_stops_after_one_failed_repair_attempt():
    from agent.analysis.ollama_adapter import OllamaAnalysisError, OllamaIncidentAnalyzer

    calls = 0
    invalid_payload = _analysis_payload()
    invalid_payload["alternative_hypotheses"] = [
        {
            "supporting_evidence_ids": ["newrelic-001"],
            "opposing_evidence_ids": [],
        }
    ]

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(
            200,
            json={
                "model": "gpt-oss:20b",
                "message": {"role": "assistant", "content": json.dumps(invalid_payload)},
                "done": True,
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(client=client)
        with pytest.raises(OllamaAnalysisError, match="after repair attempt"):
            await analyzer.analyze(_bundle())

    assert calls == 2

@pytest.mark.asyncio
async def test_ollama_analyzer_uses_simple_hypothesis_schema_without_anyof():
    from agent.analysis.ollama_adapter import OllamaIncidentAnalyzer

    captured = {}

    async def handler(request: httpx.Request) -> httpx.Response:
        captured["payload"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={
                "model": "gpt-oss:20b",
                "message": {"role": "assistant", "content": json.dumps(_analysis_payload())},
                "done": True,
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(client=client)
        await analyzer.analyze(_bundle())

    hypothesis_schema = captured["payload"]["format"]["$defs"]["Hypothesis"]
    assert "anyOf" not in hypothesis_schema
    assert set(hypothesis_schema["required"]) == {
        "summary",
        "supporting_evidence_ids",
        "opposing_evidence_ids",
    }
    assert hypothesis_schema["additionalProperties"] is False

@pytest.mark.asyncio
async def test_ollama_analyzer_repairs_unknown_evidence_reference_once():
    from agent.analysis.analyzer import validate_analysis_references
    from agent.analysis.ollama_adapter import OllamaIncidentAnalyzer
    from agent.evidence.models import EvidenceGap

    bundle = _bundle()
    bundle.gaps.append(
        EvidenceGap(
            gap_id="gap-newrelic-span-unavailable",
            summary="Span evidence is unavailable.",
            source=EvidenceSource.NEW_RELIC,
            category=EvidenceCategory.SPAN,
        )
    )
    invalid_payload = _analysis_payload()
    invalid_payload["alternative_hypotheses"] = [
        {
            "summary": "Missing span evidence may explain the uncertainty.",
            "supporting_evidence_ids": ["gap-newrelic-span-unavailable"],
            "opposing_evidence_ids": [],
        }
    ]
    repaired_payload = _analysis_payload()
    repaired_payload["alternative_hypotheses"] = [
        {
            "summary": "The observed New Relic transaction may reflect a broader latency issue.",
            "supporting_evidence_ids": ["newrelic-001"],
            "opposing_evidence_ids": [],
        }
    ]
    requests = []

    async def handler(request: httpx.Request) -> httpx.Response:
        request_payload = json.loads(request.content)
        requests.append(request_payload)
        payload = invalid_payload if len(requests) == 1 else repaired_payload
        return httpx.Response(
            200,
            json={
                "model": "gpt-oss:20b",
                "message": {"role": "assistant", "content": json.dumps(payload)},
                "done": True,
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(client=client)
        analysis = await analyzer.analyze(bundle)

    validate_analysis_references(bundle, analysis)
    assert analysis == IncidentAnalysis(**repaired_payload)
    assert len(requests) == 2
    repair_messages = requests[1]["messages"]
    assert repair_messages[-2]["role"] == "assistant"
    assert json.loads(repair_messages[-2]["content"]) == invalid_payload
    assert repair_messages[-1]["role"] == "user"
    assert "unknown evidence IDs" in repair_messages[-1]["content"]
    assert "gap-newrelic-span-unavailable" in repair_messages[-1]["content"]
    assert "newrelic-001" in repair_messages[-1]["content"]
    assert "splunk-001" in repair_messages[-1]["content"]
    assert "EvidenceGap" in repair_messages[-1]["content"]


@pytest.mark.asyncio
async def test_ollama_analyzer_stops_after_one_failed_reference_repair_attempt():
    from agent.analysis.ollama_adapter import OllamaAnalysisError, OllamaIncidentAnalyzer
    from agent.evidence.models import EvidenceGap

    bundle = _bundle()
    bundle.gaps.append(
        EvidenceGap(
            gap_id="gap-newrelic-span-unavailable",
            summary="Span evidence is unavailable.",
            source=EvidenceSource.NEW_RELIC,
            category=EvidenceCategory.SPAN,
        )
    )
    invalid_payload = _analysis_payload()
    invalid_payload["alternative_hypotheses"] = [
        {
            "summary": "Missing span evidence may explain the uncertainty.",
            "supporting_evidence_ids": ["gap-newrelic-span-unavailable"],
            "opposing_evidence_ids": [],
        }
    ]
    calls = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(
            200,
            json={
                "model": "gpt-oss:20b",
                "message": {"role": "assistant", "content": json.dumps(invalid_payload)},
                "done": True,
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(client=client)
        with pytest.raises(OllamaAnalysisError, match="reference validation after repair attempt"):
            await analyzer.analyze(bundle)

    assert calls == 2
