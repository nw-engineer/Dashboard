from datetime import datetime, timedelta, timezone

import pytest
from pydantic import ValidationError

from console_api.models import InvestigationStreamRequest


def test_request_trims_request_id_and_accepts_two_hour_window():
    earliest = datetime(2026, 9, 4, 0, 0, tzinfo=timezone.utc)
    latest = earliest + timedelta(hours=2)

    request = InvestigationStreamRequest(
        request_id="  req-1  ",
        earliest=earliest,
        latest=latest,
    )

    assert request.request_id == "req-1"


@pytest.mark.parametrize(
    "payload",
    [
        {
            "request_id": "   ",
            "earliest": "2026-09-04T00:00:00Z",
            "latest": "2026-09-04T00:10:00Z",
        },
        {
            "request_id": "req-1",
            "earliest": "2026-09-04T00:10:00Z",
            "latest": "2026-09-04T00:00:00Z",
        },
        {
            "request_id": "req-1",
            "earliest": "2026-09-04T00:00:00Z",
            "latest": "2026-09-04T02:00:01Z",
        },
        {
            "request_id": "req-1",
            "earliest": "2026-09-04T00:00:00",
            "latest": "2026-09-04T00:10:00",
        },
    ],
)
def test_request_rejects_invalid_id_order_window_or_naive_datetimes(payload):
    with pytest.raises(ValidationError):
        InvestigationStreamRequest(**payload)
