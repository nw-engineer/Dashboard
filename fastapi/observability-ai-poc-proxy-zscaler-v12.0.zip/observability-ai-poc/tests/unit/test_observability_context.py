from fastapi.testclient import TestClient

from shared.scenario import ScenarioId
from services.api_gateway import app as gateway_module
from services.inventory_service import app as inventory_module
from services.order_service import app as order_module
from services.payment_mock import app as payment_mock_module
from services.payment_service import app as payment_module


class RecordingOrderDependency:
    def __init__(self):
        self.calls = []

    async def create_order(self, payload: dict, request_id: str):
        self.calls.append((payload, request_id))
        return 201, {"order_id": "ord-1", "status": "created"}


class RecordingInventoryDependency:
    def __init__(self):
        self.calls = []

    async def get_inventory(self, product_id: str, *, request_id: str, scenario_id: str):
        self.calls.append((product_id, request_id, scenario_id))
        return {"product_id": product_id, "quantity": 10, "service_version": "1.0.0"}


class RecordingPaymentDependency:
    def __init__(self):
        self.calls = []

    async def pay(self, order_id: str, amount: int, *, request_id: str, scenario_id: str):
        self.calls.append((order_id, amount, request_id, scenario_id))
        return {"status": "approved", "order_id": order_id}


class RecordingChargeDependency:
    def __init__(self):
        self.calls = []

    async def charge(self, order_id: str, amount: int, *, request_id: str, scenario_id: str):
        self.calls.append((order_id, amount, request_id, scenario_id))
        return {"status": "approved", "order_id": order_id}


def test_gateway_adds_request_and_product_attributes(monkeypatch):
    calls = []
    dependency = RecordingOrderDependency()
    monkeypatch.setattr(gateway_module, "order_dependency", dependency)
    monkeypatch.setattr(gateway_module, "add_transaction_attributes", lambda **kw: calls.append(kw))
    client = TestClient(gateway_module.app)

    response = client.post(
        "/orders",
        headers={"X-Request-ID": "req-123"},
        json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
    )

    assert response.status_code == 201
    assert calls == [{"request_id": "req-123", "product_id": "SKU-001"}]


def test_order_propagates_request_and_scenario_to_dependencies(monkeypatch):
    inventory = RecordingInventoryDependency()
    payment = RecordingPaymentDependency()
    calls = []
    monkeypatch.setattr(order_module, "inventory_dependency", inventory)
    monkeypatch.setattr(order_module, "payment_dependency", payment)
    monkeypatch.setattr(order_module, "add_transaction_attributes", lambda **kw: calls.append(kw))

    async def current():
        return ScenarioId.UC02_PAYMENT_FAILURE

    monkeypatch.setattr(order_module.scenario, "get_current", current)
    client = TestClient(order_module.app)

    response = client.post(
        "/orders",
        headers={"X-Request-ID": "req-123"},
        json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
    )

    assert response.status_code == 201
    assert inventory.calls == [("SKU-001", "req-123", "UC02_PAYMENT_FAILURE")]
    assert payment.calls[0][2:] == ("req-123", "UC02_PAYMENT_FAILURE")
    assert calls[0] == {
        "request_id": "req-123",
        "scenario_id": "UC02_PAYMENT_FAILURE",
        "product_id": "SKU-001",
    }
    assert calls[1]["order_id"].startswith("ord-")


def test_inventory_adds_dynamic_service_version(monkeypatch):
    calls = []
    monkeypatch.setattr(inventory_module, "add_transaction_attributes", lambda **kw: calls.append(kw))

    class Item:
        quantity = 10

    class Repo:
        def get_inventory(self, product_id: str, pre_query_delay: float = 0.0):
            return Item()

    async def current():
        return ScenarioId.UC05_BAD_DEPLOYMENT

    async def no_sleep(_seconds: float):
        return None

    monkeypatch.setattr(inventory_module, "repository", Repo())
    monkeypatch.setattr(inventory_module.scenario, "get_current", current)
    monkeypatch.setattr(inventory_module.asyncio, "sleep", no_sleep)
    client = TestClient(inventory_module.app)

    response = client.get("/inventory/SKU-001", headers={"X-Request-ID": "req-123"})

    assert response.status_code == 200
    assert calls == [{
        "request_id": "req-123",
        "scenario_id": "UC05_BAD_DEPLOYMENT",
        "product_id": "SKU-001",
        "service_version": "1.1.0",
    }]


def test_payment_service_propagates_context_to_payment_mock(monkeypatch):
    dependency = RecordingChargeDependency()
    calls = []
    monkeypatch.setattr(payment_module, "payment_dependency", dependency)
    monkeypatch.setattr(payment_module, "add_transaction_attributes", lambda **kw: calls.append(kw))
    client = TestClient(payment_module.app)

    response = client.post(
        "/payments",
        headers={"X-Request-ID": "req-123", "X-Scenario-ID": "UC02_PAYMENT_FAILURE"},
        json={"order_id": "ord-1", "amount": 1200},
    )

    assert response.status_code == 200
    assert dependency.calls == [("ord-1", 1200, "req-123", "UC02_PAYMENT_FAILURE")]
    assert calls == [{
        "request_id": "req-123",
        "scenario_id": "UC02_PAYMENT_FAILURE",
        "order_id": "ord-1",
    }]


def test_payment_mock_adds_context_attributes(monkeypatch):
    calls = []
    monkeypatch.setattr(payment_mock_module, "add_transaction_attributes", lambda **kw: calls.append(kw))

    async def current():
        return ScenarioId.NORMAL

    monkeypatch.setattr(payment_mock_module.scenario, "get_current", current)
    client = TestClient(payment_mock_module.app)

    response = client.post(
        "/charge",
        headers={"X-Request-ID": "req-123", "X-Scenario-ID": "NORMAL"},
        json={"order_id": "ord-1", "amount": 1200},
    )

    assert response.status_code == 200
    assert calls == [{
        "request_id": "req-123",
        "scenario_id": "NORMAL",
        "order_id": "ord-1",
    }]


def test_order_response_exposes_end_to_end_request_id_evidence(monkeypatch):
    class EvidenceInventory(RecordingInventoryDependency):
        async def get_inventory(self, product_id: str, *, request_id: str, scenario_id: str):
            await super().get_inventory(product_id, request_id=request_id, scenario_id=scenario_id)
            return {
                "product_id": product_id,
                "quantity": 10,
                "service_version": "1.0.0",
                "request_id": request_id,
            }

    class EvidencePayment(RecordingPaymentDependency):
        async def pay(self, order_id: str, amount: int, *, request_id: str, scenario_id: str):
            await super().pay(order_id, amount, request_id=request_id, scenario_id=scenario_id)
            return {"status": "approved", "order_id": order_id, "request_id": request_id}

    inventory = EvidenceInventory()
    payment = EvidencePayment()
    monkeypatch.setattr(order_module, "inventory_dependency", inventory)
    monkeypatch.setattr(order_module, "payment_dependency", payment)

    async def current():
        return ScenarioId.NORMAL

    monkeypatch.setattr(order_module.scenario, "get_current", current)
    client = TestClient(order_module.app)

    response = client.post(
        "/orders",
        headers={"X-Request-ID": "req-e2e"},
        json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
    )

    assert response.status_code == 201
    assert response.json()["correlation"] == {
        "order_request_id": "req-e2e",
        "inventory_request_id": "req-e2e",
        "payment_request_id": "req-e2e",
    }
