from tests.unit.test_ui_presenter import _result

from agent.ui.a2ui import (
    A2UI_VERSION,
    TROUBLESHOOTING_CATALOG_ID,
    build_a2ui_messages,
)
from agent.ui.presenter import present_investigation


APPROVED_COMPONENTS = {
    "HealthSummary",
    "TimelineChart",
    "TraceCard",
    "EvidenceCard",
    "EvidenceGapCard",
    "LogTable",
    "HypothesisCard",
    "RecommendationCard",
    "QueryDisclosure",
}


def _message_kind(message: dict) -> str:
    return next(key for key in message if key != "version")


def _collect_evidence_id_values(value):
    found = []
    if isinstance(value, dict):
        for key, item in value.items():
            if key.endswith("evidence_ids") and isinstance(item, list):
                found.extend(item)
            found.extend(_collect_evidence_id_values(item))
    elif isinstance(value, list):
        for item in value:
            found.extend(_collect_evidence_id_values(item))
    return found


def test_a2ui_builder_emits_v091_surface_component_and_data_messages_in_order():
    view = present_investigation(_result())

    messages = build_a2ui_messages(view)

    assert [_message_kind(message) for message in messages] == [
        "createSurface",
        "updateComponents",
        "updateDataModel",
    ]
    assert all(message["version"] == A2UI_VERSION == "v0.9.1" for message in messages)
    assert messages[0]["createSurface"] == {
        "surfaceId": "inv-1",
        "catalogId": TROUBLESHOOTING_CATALOG_ID,
        "sendDataModel": False,
    }
    assert messages[2]["updateDataModel"]["surfaceId"] == "inv-1"
    assert messages[2]["updateDataModel"]["path"] == "/"


def test_a2ui_builder_uses_only_fixed_troubleshooting_catalog_components():
    view = present_investigation(_result())

    components = build_a2ui_messages(view)[1]["updateComponents"]["components"]

    assert components[0]["id"] == "root"
    assert components[0]["component"] == "HealthSummary"
    assert {component["component"] for component in components} <= APPROVED_COMPONENTS
    assert any(component["component"] == "EvidenceCard" for component in components)
    assert any(component["component"] == "EvidenceGapCard" for component in components)


def test_a2ui_data_model_keeps_gap_ids_out_of_evidence_id_fields():
    view = present_investigation(_result())

    data = build_a2ui_messages(view)[2]["updateDataModel"]["value"]

    assert [item["evidence_id"] for item in data["evidence"]] == [
        "splunk-001",
        "newrelic-001",
    ]
    assert [item["gap_id"] for item in data["evidence_gaps"]] == [
        "gap-newrelic-span-unavailable"
    ]
    assert "gap-newrelic-span-unavailable" not in _collect_evidence_id_values(data)
