from agent.evidence.correlator import EvidenceCorrelator
from agent.evidence.models import (
    CorrelationContext,
    EvidenceCategory,
    EvidenceGap,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)
from agent.evidence.newrelic_collector import NewRelicEvidenceResult
from agent.evidence.splunk_collector import SplunkEvidenceResult


def _splunk_result(*items):
    return SplunkEvidenceResult(
        evidence=list(items),
        query=QueryDisclosure(
            disclosure_id="query-splunk-001",
            source=EvidenceSource.SPLUNK,
            operation="search",
            arguments={"query": 'trace.id="trace-1"'},
        ),
    )


def _newrelic_result(*items, gaps=None, query_id="query-newrelic-001"):
    return NewRelicEvidenceResult(
        evidence=list(items),
        gaps=list(gaps or []),
        queries=[
            QueryDisclosure(
                disclosure_id=query_id,
                source=EvidenceSource.NEW_RELIC,
                operation="execute_nrql_query",
                arguments={"query": "SELECT traceId FROM Transaction"},
            )
        ],
    )


def test_all_evidence_from_both_sources_remains_in_bundle():
    splunk_item = EvidenceItem(
        evidence_id="splunk-001",
        source=EvidenceSource.SPLUNK,
        category=EvidenceCategory.DB,
        summary="DB query observed",
        facts={"db.duration_ms": 1.2},
        query_or_tool="query-splunk-001",
        request_id="req-1",
        trace_id="trace-1",
    )
    nr_item = EvidenceItem(
        evidence_id="newrelic-001",
        source=EvidenceSource.NEW_RELIC,
        category=EvidenceCategory.TRANSACTION,
        summary="Transaction observed",
        facts={"duration": 0.1},
        query_or_tool="query-newrelic-001",
        request_id="req-1",
        trace_id="trace-1",
    )

    bundle = EvidenceCorrelator().build_bundle(
        investigation_id="inv-1",
        context=CorrelationContext(request_id="req-1", trace_id="trace-1"),
        splunk=_splunk_result(splunk_item),
        newrelic=_newrelic_result(nr_item),
    )

    assert [item.evidence_id for item in bundle.evidence] == ["splunk-001", "newrelic-001"]


def test_trace_mismatch_creates_contradiction_without_deleting_evidence():
    splunk_item = EvidenceItem(
        evidence_id="splunk-001",
        source=EvidenceSource.SPLUNK,
        category=EvidenceCategory.APPLICATION,
        summary="mismatched trace",
        facts={},
        query_or_tool="query-splunk-001",
        request_id="req-1",
        trace_id="trace-wrong",
    )
    nr_item = EvidenceItem(
        evidence_id="newrelic-001",
        source=EvidenceSource.NEW_RELIC,
        category=EvidenceCategory.TRANSACTION,
        summary="correlated trace",
        facts={},
        query_or_tool="query-newrelic-001",
        request_id="req-1",
        trace_id="trace-1",
    )

    bundle = EvidenceCorrelator().build_bundle(
        investigation_id="inv-1",
        context=CorrelationContext(request_id="req-1", trace_id="trace-1"),
        splunk=_splunk_result(splunk_item),
        newrelic=_newrelic_result(nr_item),
    )

    assert {item.evidence_id for item in bundle.evidence} == {"splunk-001", "newrelic-001"}
    contradiction = bundle.contradictions[0]
    assert contradiction.left_evidence_ids == ["splunk-001"]
    assert contradiction.right_evidence_ids == ["newrelic-001"]


def test_fast_db_observation_stays_factual_and_never_becomes_cause():
    db_item = EvidenceItem(
        evidence_id="splunk-001",
        source=EvidenceSource.SPLUNK,
        category=EvidenceCategory.DB,
        summary="DB query completed in 1.2 ms",
        facts={"db.duration_ms": 1.2},
        query_or_tool="query-splunk-001",
        request_id="req-1",
        trace_id="trace-1",
    )

    bundle = EvidenceCorrelator().build_bundle(
        investigation_id="inv-1",
        context=CorrelationContext(request_id="req-1", trace_id="trace-1"),
        splunk=_splunk_result(db_item),
        newrelic=_newrelic_result(),
    )

    assert bundle.evidence[0].facts["db.duration_ms"] == 1.2
    assert not hasattr(bundle, "likely_cause")


def test_missing_span_gap_survives_into_bundle():
    gap = EvidenceGap(
        gap_id="gap-span",
        summary="Span evidence was not observed for the correlated trace",
        source=EvidenceSource.NEW_RELIC,
        category=EvidenceCategory.SPAN,
    )

    bundle = EvidenceCorrelator().build_bundle(
        investigation_id="inv-1",
        context=CorrelationContext(request_id="req-1", trace_id="trace-1"),
        splunk=_splunk_result(),
        newrelic=_newrelic_result(gaps=[gap]),
    )

    assert bundle.gaps == [gap]


def test_source_prefixed_disclosure_ids_remain_unique():
    bundle = EvidenceCorrelator().build_bundle(
        investigation_id="inv-1",
        context=CorrelationContext(request_id="req-1", trace_id="trace-1"),
        splunk=_splunk_result(),
        newrelic=_newrelic_result(),
    )

    ids = [item.disclosure_id for item in bundle.queries_used]
    assert ids == ["query-splunk-001", "query-newrelic-001"]
    assert len(ids) == len(set(ids))
