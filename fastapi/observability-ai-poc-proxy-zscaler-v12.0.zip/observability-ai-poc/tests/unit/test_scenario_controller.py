from fastapi.testclient import TestClient
from services.scenario_controller.app import app

client = TestClient(app)


def test_defaults_to_normal():
    assert client.get("/scenario").json() == {"scenario": "NORMAL"}


def test_changes_scenario():
    response = client.put("/scenario", json={"scenario": "UC01_DB_SLOW"})
    assert response.status_code == 200
    assert response.json() == {"scenario": "UC01_DB_SLOW"}


def test_rejects_unknown_scenario():
    response = client.put("/scenario", json={"scenario": "NOT_REAL"})
    assert response.status_code == 422
