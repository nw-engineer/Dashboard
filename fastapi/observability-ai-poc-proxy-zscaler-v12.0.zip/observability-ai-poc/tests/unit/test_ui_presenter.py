from datetime import datetime, timezone

from agent.analysis.models import Hypothesis, IncidentAnalysis
from agent.evidence.models import (
    EvidenceBundle,
    EvidenceCategory,
    EvidenceContradiction,
    EvidenceGap,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)
from agent.orchestrator import InvestigationResult
from agent.ui.presenter import present_investigation


def _result(*, include_environment: bool = True) -> InvestigationResult:
    observed_at = datetime(2026, 9, 4, 0, 0, tzinfo=timezone.utc)
    splunk_facts = {"event_type": "application.request"}
    if include_environment:
        splunk_facts["deployment.environment"] = "poc"
    evidence = [
        EvidenceItem(
            evidence_id="splunk-001",
            source=EvidenceSource.SPLUNK,
            category=EvidenceCategory.APPLICATION,
            summary="application request",
            facts=splunk_facts,
            query_or_tool="query-splunk-001",
            service_name="api-gateway",
            observed_at=observed_at,
            request_id="req-1",
            trace_id="trace-1",
        ),
        EvidenceItem(
            evidence_id="newrelic-001",
            source=EvidenceSource.NEW_RELIC,
            category=EvidenceCategory.TRANSACTION,
            summary="transaction",
            facts={"duration": 0.5},
            query_or_tool="query-newrelic-001",
            service_name="order-service",
            request_id="req-1",
            trace_id="trace-1",
        ),
    ]
    bundle = EvidenceBundle(
        investigation_id="inv-1",
        request_id="req-1",
        trace_id="trace-1",
        evidence=evidence,
        contradictions=[
            EvidenceContradiction(
                contradiction_id="contradiction-001",
                summary="duration disagrees",
                left_evidence_ids=["splunk-001"],
                right_evidence_ids=["newrelic-001"],
            )
        ],
        gaps=[
            EvidenceGap(
                gap_id="gap-newrelic-span-unavailable",
                summary="span unavailable",
                source=EvidenceSource.NEW_RELIC,
                category=EvidenceCategory.SPAN,
            )
        ],
        queries_used=[
            QueryDisclosure(
                disclosure_id="query-splunk-001",
                source=EvidenceSource.SPLUNK,
                operation="search",
                arguments={"query": 'trace.id="trace-1"'},
            ),
            QueryDisclosure(
                disclosure_id="query-newrelic-001",
                source=EvidenceSource.NEW_RELIC,
                operation="execute_nrql_query",
                arguments={"nrql_query": "SELECT duration FROM Transaction"},
            ),
        ],
    )
    analysis = IncidentAnalysis(
        incident_summary="One request was slow.",
        impact="Single request impact.",
        likely_cause="The exact root cause is undetermined from available evidence.",
        confidence="low",
        supporting_evidence_ids=["splunk-001"],
        alternative_hypotheses=[
            Hypothesis(
                summary="APM transaction latency may be related.",
                supporting_evidence_ids=["newrelic-001"],
            )
        ],
        recommended_checks=["Inspect the trace."],
        recommended_actions=["Review before making any change."],
        new_relic_evidence_ids=["newrelic-001"],
        splunk_evidence_ids=["splunk-001"],
        contradiction_ids=["contradiction-001"],
        query_disclosure_ids=["query-splunk-001", "query-newrelic-001"],
    )
    return InvestigationResult(bundle=bundle, analysis=analysis)


def test_presenter_keeps_evidence_gap_and_query_namespaces_separate():
    result = _result()

    view = present_investigation(result)

    assert view.investigation_id == "inv-1"
    assert view.request_id == "req-1"
    assert view.trace_id == "trace-1"
    assert view.services == ["api-gateway", "order-service"]
    assert view.environment == "poc"
    assert [row.evidence_id for row in view.log_rows] == ["splunk-001"]
    assert [row.evidence_id for row in view.timeline] == ["splunk-001"]
    assert [gap.gap_id for gap in view.evidence_gaps] == ["gap-newrelic-span-unavailable"]
    assert "gap-newrelic-span-unavailable" not in view.all_evidence_ids
    assert [query.disclosure_id for query in view.queries] == [
        "query-splunk-001",
        "query-newrelic-001",
    ]
    assert [item.contradiction_id for item in view.contradictions] == ["contradiction-001"]


def test_presenter_uses_unknown_when_evidence_has_no_environment():
    view = present_investigation(_result(include_environment=False))

    assert view.environment == "unknown"


def test_presenter_preserves_advisory_analysis_text():
    view = present_investigation(_result())

    assert view.incident_summary == "One request was slow."
    assert view.recommended_checks == ["Inspect the trace."]
    assert view.recommended_actions == ["Review before making any change."]
    assert [hypothesis.supporting_evidence_ids for hypothesis in view.hypotheses] == [
        ["newrelic-001"]
    ]
