import pytest

from agent.evidence.correlation import AmbiguousTraceId, CorrelationNotFound, TraceIdNotFound
from console_api.errors import to_public_error


@pytest.mark.parametrize("error", [CorrelationNotFound("secret"), TraceIdNotFound("secret")])
def test_correlation_missing_maps_to_closed_public_error(error):
    public = to_public_error(error)

    assert public.code == "CORRELATION_NOT_FOUND"
    assert public.message == "指定したリクエストIDと時間範囲に一致する相関トレースが見つかりませんでした。"


def test_ambiguous_trace_maps_to_closed_public_error():
    public = to_public_error(AmbiguousTraceId("trace-a token=abc"))

    assert public.code == "CORRELATION_AMBIGUOUS"
    assert public.message == "指定したリクエストIDと時間範囲に一致する相関トレースが複数見つかりました。"
    assert "trace-a" not in public.message


def test_unexpected_error_never_leaks_exception_text():
    public = to_public_error(RuntimeError("password=do-not-leak token=abc123"))

    assert public.code == "INVESTIGATION_FAILED"
    assert public.message == "調査を完了できませんでした。"
    assert "password" not in public.message.lower()
    assert "token" not in public.message.lower()
    assert "abc123" not in public.message


def test_public_error_messages_are_japanese_by_default():
    assert "見つかりません" in to_public_error(CorrelationNotFound("x")).message
    assert "複数" in to_public_error(AmbiguousTraceId("x")).message
    assert "完了できません" in to_public_error(RuntimeError("x")).message



def test_llm_analysis_error_maps_to_safe_retryable_public_error():
    from agent.analysis.azure_openai_adapter import AzureOpenAIAnalysisError

    public = to_public_error(
        AzureOpenAIAnalysisError('Azure OpenAI Responses API returned HTTP 429 token=secret')
    )

    assert public.code == 'LLM_ANALYSIS_FAILED'
    assert public.message == 'LLM分析中に一時的なエラーが発生しました。再度実行してください。'
    assert '429' not in public.message
    assert 'secret' not in public.message



def test_llm_configuration_error_maps_to_safe_configuration_public_error():
    from agent.analysis.azure_openai_adapter import AzureOpenAIConfigurationError

    public = to_public_error(
        AzureOpenAIConfigurationError('AZURE_OPENAI_API_KEY is required secret=do-not-leak')
    )

    assert public.code == 'LLM_CONFIGURATION_ERROR'
    assert public.message == 'LLM分析サービスの設定を確認してください。'
    assert 'API_KEY' not in public.message
    assert 'secret' not in public.message
