from shared.scenario import ScenarioId
from services.inventory_service.models import behavior_for


def test_uc01_has_db_delay():
    behavior = behavior_for(ScenarioId.UC01_DB_SLOW)
    assert 2.5 <= behavior.db_delay_seconds <= 4.0
    assert behavior.processing_delay_seconds == 0.0


def test_uc05_has_regression_delay_and_version():
    behavior = behavior_for(ScenarioId.UC05_BAD_DEPLOYMENT)
    assert 0.3 <= behavior.processing_delay_seconds <= 0.8
    assert behavior.db_delay_seconds == 0.0
    assert behavior.service_version == "1.1.0"


def test_normal_has_no_artificial_delay():
    behavior = behavior_for(ScenarioId.NORMAL)
    assert behavior.db_delay_seconds == 0.0
    assert behavior.processing_delay_seconds == 0.0
    assert behavior.service_version == "1.0.0"
