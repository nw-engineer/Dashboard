from datetime import datetime, timedelta, timezone

import pytest

from agent.evidence.correlation import (
    AmbiguousTraceId,
    CorrelationNotFound,
    CorrelationResolver,
    TraceIdNotFound,
)


class FakeSplunkClient:
    def __init__(self, rows):
        self.rows = rows
        self.requests = []

    async def search(self, request):
        self.requests.append(request)
        return list(self.rows)


@pytest.mark.asyncio
async def test_resolve_request_returns_one_trace_and_services():
    client = FakeSplunkClient([
        {
            "request.id": "req-1",
            "trace.id": "trace-1",
            "service.name": "api-gateway",
            "entity.guid": "guid-api",
        },
        {
            "request.id": "req-1",
            "trace.id": "trace-1",
            "service.name": "order-service",
            "entity.guid": "guid-order",
        },
    ])
    resolver = CorrelationResolver(client)
    latest = datetime(2026, 9, 3, 6, 0, tzinfo=timezone.utc)

    context = await resolver.resolve_request("req-1", latest - timedelta(minutes=10), latest)

    assert context.trace_id == "trace-1"
    assert context.services == ["api-gateway", "order-service"]
    assert client.requests[0].query == 'request.id="req-1"'


@pytest.mark.asyncio
async def test_resolve_request_rejects_missing_request():
    resolver = CorrelationResolver(FakeSplunkClient([]))
    now = datetime.now(timezone.utc)

    with pytest.raises(CorrelationNotFound):
        await resolver.resolve_request("missing", now - timedelta(minutes=5), now)


@pytest.mark.asyncio
async def test_resolve_request_rejects_rows_without_trace_id():
    resolver = CorrelationResolver(FakeSplunkClient([{"request.id": "req-1"}]))
    now = datetime.now(timezone.utc)

    with pytest.raises(TraceIdNotFound):
        await resolver.resolve_request("req-1", now - timedelta(minutes=5), now)


@pytest.mark.asyncio
async def test_resolve_request_rejects_multiple_trace_ids():
    resolver = CorrelationResolver(FakeSplunkClient([
        {"request.id": "req-1", "trace.id": "trace-1"},
        {"request.id": "req-1", "trace.id": "trace-2"},
    ]))
    now = datetime.now(timezone.utc)

    with pytest.raises(AmbiguousTraceId, match="trace-1.*trace-2"):
        await resolver.resolve_request("req-1", now - timedelta(minutes=5), now)
