import asyncio

import pytest

from services.order_service.capacity import CapacityGate


@pytest.mark.asyncio
async def test_fifth_request_waits_when_four_slots_are_occupied():
    gate = CapacityGate(limit=4)
    leases = [await gate.acquire() for _ in range(4)]
    fifth = asyncio.create_task(gate.acquire())
    await asyncio.sleep(0.05)
    assert not fifth.done()
    leases[0].release()
    fifth_lease = await asyncio.wait_for(fifth, timeout=0.5)
    assert fifth_lease.queue_wait_ms >= 40
    fifth_lease.release()
    for lease in leases[1:]:
        lease.release()
