from datetime import datetime, timedelta, timezone

import pytest

from agent.evidence.models import CorrelationContext, EvidenceCategory
from agent.evidence.splunk_collector import SplunkEvidenceCollector


class FakeSplunkClient:
    def __init__(self, rows):
        self.rows = rows
        self.requests = []

    async def search(self, request):
        self.requests.append(request)
        return list(self.rows)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("event_type", "category"),
    [
        ("db.query", EvidenceCategory.DB),
        ("dependency.call", EvidenceCategory.DEPENDENCY),
        ("exception", EvidenceCategory.EXCEPTION),
        ("capacity.snapshot", EvidenceCategory.CAPACITY),
        ("deployment", EvidenceCategory.DEPLOYMENT),
        ("application.request", EvidenceCategory.APPLICATION),
        ("application.response", EvidenceCategory.APPLICATION),
        ("unknown.event", EvidenceCategory.APPLICATION),
    ],
)
async def test_event_type_maps_to_evidence_category(event_type, category):
    client = FakeSplunkClient([
        {
            "_time": "2026-09-03T06:00:00+00:00",
            "event_type": event_type,
            "service.name": "inventory-service",
            "request.id": "req-1",
            "trace.id": "trace-1",
            "db.duration_ms": 1.2,
        }
    ])
    collector = SplunkEvidenceCollector(client)
    context = CorrelationContext(
        request_id="req-1", trace_id="trace-1", services=["inventory-service"]
    )
    latest = datetime(2026, 9, 3, 6, 1, tzinfo=timezone.utc)

    result = await collector.collect(context, latest - timedelta(minutes=5), latest)

    assert result.evidence[0].category is category
    assert result.evidence[0].facts["db.duration_ms"] == 1.2
    assert result.evidence[0].request_id == "req-1"
    assert result.evidence[0].trace_id == "trace-1"
    assert result.query.arguments["query"] == 'trace.id="trace-1"'
    assert client.requests[0].query == 'trace.id="trace-1"'


@pytest.mark.asyncio
async def test_secret_like_fields_are_not_copied_to_evidence_facts():
    row = {
        "event_type": "application.request",
        "trace.id": "trace-1",
        "request.id": "req-1",
        "token": "must-not-leak",
        "password": "must-not-leak",
        "api_key": "must-not-leak",
        "card_number": "must-not-leak",
        "service.name": "api-gateway",
        "http.method": "POST",
    }
    collector = SplunkEvidenceCollector(FakeSplunkClient([row]))
    context = CorrelationContext(request_id="req-1", trace_id="trace-1")
    latest = datetime(2026, 9, 3, 6, 1, tzinfo=timezone.utc)

    result = await collector.collect(context, latest - timedelta(minutes=5), latest)
    item = result.evidence[0]

    assert "token" not in item.facts
    assert "password" not in item.facts
    assert "api_key" not in item.facts
    assert "card_number" not in item.facts
    assert item.facts["http.method"] == "POST"


@pytest.mark.asyncio
async def test_splunk_search_failure_is_wrapped_without_secret_text():
    from agent.evidence.splunk_collector import SplunkEvidenceUnavailable

    class BrokenSplunkClient:
        async def search(self, request):
            raise RuntimeError("password=secret token=abc")

    collector = SplunkEvidenceCollector(BrokenSplunkClient())
    context = CorrelationContext(request_id="req-1", trace_id="trace-1")
    latest = datetime(2026, 9, 3, 6, 1, tzinfo=timezone.utc)

    with pytest.raises(SplunkEvidenceUnavailable) as exc:
        await collector.collect(context, latest - timedelta(minutes=5), latest)

    assert "secret" not in str(exc.value).lower()
    assert "token=abc" not in str(exc.value).lower()


@pytest.mark.asyncio
async def test_splunk_evidence_summary_is_japanese_and_preserves_event_and_service_identifiers():
    client = FakeSplunkClient([{
        "_time": "2026-09-03T06:00:00+00:00",
        "event_type": "db.query",
        "service.name": "inventory-service",
        "request.id": "req-1",
        "trace.id": "trace-1",
    }])
    collector = SplunkEvidenceCollector(client)
    context = CorrelationContext(request_id="req-1", trace_id="trace-1")
    latest = datetime(2026, 9, 3, 6, 1, tzinfo=timezone.utc)

    result = await collector.collect(context, latest - timedelta(minutes=5), latest)

    assert result.evidence[0].summary == "Splunkで db.query を観測しました（サービス: inventory-service）"
