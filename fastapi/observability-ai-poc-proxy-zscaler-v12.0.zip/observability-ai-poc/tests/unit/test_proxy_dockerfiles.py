from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
BASE_DOCKERFILES = [
    ROOT / "services/api_gateway/Dockerfile",
    ROOT / "services/order_service/Dockerfile",
    ROOT / "services/inventory_service/Dockerfile",
    ROOT / "services/payment_service/Dockerfile",
    ROOT / "services/payment_mock/Dockerfile",
    ROOT / "services/scenario_controller/Dockerfile",
    ROOT / "load_generator/Dockerfile",
]


def test_base_python_images_remain_ca_agnostic_for_non_proxy_workflow():
    for path in BASE_DOCKERFILES:
        text = path.read_text()
        assert "ARG HTTP_PROXY" not in text, path
        assert "ARG HTTPS_PROXY" not in text, path
        assert "COPY certs/zscaler-ca.crt" not in text, path
        assert "python-ca-install.sh" not in text, path


def test_proxy_python_image_installs_zscaler_ca_before_pip():
    path = ROOT / "docker/python-service-proxy.Dockerfile"
    text = path.read_text()
    assert "ARG HTTP_PROXY" not in text
    assert "ARG HTTPS_PROXY" not in text
    assert "ARG NO_PROXY" not in text
    assert "COPY certs/zscaler-ca.crt" in text
    assert "docker/python-ca-install.sh" in text
    assert text.index("python-ca-install.sh") < text.index("pip install")


def test_proxy_overlay_switches_all_python_app_services_to_shared_proxy_image():
    text = (ROOT / "compose.proxy.yml").read_text()
    for service in [
        "scenario-controller",
        "payment-mock",
        "payment-service",
        "inventory-service",
        "order-service",
        "api-gateway",
        "load-generator",
    ]:
        match = re.search(
            rf"(?ms)^  {re.escape(service)}:\n(.*?)(?=^  [A-Za-z0-9_-]+:\n|\Z)",
            text,
        )
        assert match is not None, service
        block = match.group(1)
        assert "dockerfile: docker/python-service-proxy.Dockerfile" in block, service
        assert "command:" in block, service


def test_shared_ca_installer_refreshes_system_bundle_without_echoing_secrets():
    text = (ROOT / "docker/python-ca-install.sh").read_text()
    assert "update-ca-certificates" in text
    assert "cat $HTTP_PROXY" not in text
    assert "env" not in text


def test_newrelic_mcp_image_uses_vendored_fixed_server_and_zscaler_ca():
    dockerfile = (ROOT / "docker/newrelic-mcp.Dockerfile").read_text()
    assert "vendor/newrelic-mcp-server" in dockerfile
    assert "COPY certs/zscaler-ca.crt" in dockerfile
    assert "MCP_TRANSPORT=streamable-http" in dockerfile
    assert 'CMD ["newrelic-mcp"]' in dockerfile


def test_proxy_dockerfiles_do_not_bake_proxy_values_into_image_environment():
    for rel in [
        "docker/python-service-proxy.Dockerfile",
        "docker/console-api.Dockerfile",
        "docker/newrelic-mcp.Dockerfile",
        "docker/console-ui.Dockerfile",
    ]:
        text = (ROOT / rel).read_text()
        assert "ARG HTTP_PROXY" not in text, rel
        assert "ARG HTTPS_PROXY" not in text, rel
        assert "ARG NO_PROXY" not in text, rel
        assert "ENV HTTP_PROXY=${HTTP_PROXY}" not in text, rel
        assert "HTTPS_PROXY=${HTTPS_PROXY}" not in text.split("ENV", 1)[-1], rel
