from types import SimpleNamespace

import pytest

from shared import correlation


def test_add_transaction_attributes_filters_none_and_adds_service_context(monkeypatch):
    captured = {}
    fake_agent = SimpleNamespace(add_custom_attributes=lambda attrs: captured.update(attrs))
    monkeypatch.setattr(correlation, '_nr_agent', fake_agent)
    monkeypatch.setenv('NEW_RELIC_ENABLED', 'true')
    monkeypatch.setenv('SERVICE_NAME', 'order-service')
    monkeypatch.setenv('SERVICE_VERSION', '1.0.0')
    monkeypatch.setenv('DEPLOYMENT_ENVIRONMENT', 'poc')

    correlation.add_transaction_attributes(
        request_id='r1',
        scenario_id='UC01_DB_SLOW',
        product_id=None,
    )

    assert captured == {
        'service.name': 'order-service',
        'service.version': '1.0.0',
        'deployment.environment': 'poc',
        'request.id': 'r1',
        'scenario.id': 'UC01_DB_SLOW',
    }


def test_explicit_service_version_overrides_environment(monkeypatch):
    captured = {}
    fake_agent = SimpleNamespace(add_custom_attributes=lambda attrs: captured.update(attrs))
    monkeypatch.setattr(correlation, '_nr_agent', fake_agent)
    monkeypatch.setenv('NEW_RELIC_ENABLED', 'true')
    monkeypatch.setenv('SERVICE_VERSION', '1.0.0')

    correlation.add_transaction_attributes(service_version='1.1.0')

    assert captured['service.version'] == '1.1.0'


def test_get_linking_metadata_stringifies_and_filters_none(monkeypatch):
    fake_agent = SimpleNamespace(
        get_linking_metadata=lambda: {'trace.id': 123, 'span.id': 'abc', 'entity.guid': None}
    )
    monkeypatch.setattr(correlation, '_nr_agent', fake_agent)
    monkeypatch.setenv('NEW_RELIC_ENABLED', 'true')

    assert correlation.get_linking_metadata() == {'trace.id': '123', 'span.id': 'abc'}


def test_disabled_newrelic_is_noop(monkeypatch):
    monkeypatch.setattr(correlation, '_nr_agent', None)
    monkeypatch.setenv('NEW_RELIC_ENABLED', 'false')

    correlation.add_transaction_attributes(request_id='r1')
    assert correlation.get_linking_metadata() == {}


def test_enabled_newrelic_without_package_fails_loudly(monkeypatch):
    monkeypatch.setattr(correlation, '_nr_agent', None)
    monkeypatch.setenv('NEW_RELIC_ENABLED', 'true')

    with pytest.raises(RuntimeError, match='New Relic agent package'):
        correlation.add_transaction_attributes(request_id='r1')


def test_add_transaction_attributes_passes_tuple_list_to_newrelic(monkeypatch):
    captured = []

    def strict_add_custom_attributes(items):
        assert isinstance(items, list)
        assert all(isinstance(item, tuple) and len(item) == 2 for item in items)
        captured.extend(items)

    fake_agent = SimpleNamespace(add_custom_attributes=strict_add_custom_attributes)
    monkeypatch.setattr(correlation, '_nr_agent', fake_agent)
    monkeypatch.setenv('NEW_RELIC_ENABLED', 'true')
    monkeypatch.setenv('SERVICE_NAME', 'api-gateway')
    monkeypatch.setenv('SERVICE_VERSION', '1.0.0')
    monkeypatch.setenv('DEPLOYMENT_ENVIRONMENT', 'poc')

    correlation.add_transaction_attributes(request_id='req-1')

    assert ('request.id', 'req-1') in captured
