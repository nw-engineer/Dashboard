from dataclasses import dataclass

import httpx
from fastapi.testclient import TestClient

from shared.scenario import ScenarioId, ScenarioState
from services.api_gateway import app as gateway_module
from services.inventory_service import app as inventory_module
from services.order_service import app as order_module
from services.payment_service import app as payment_module
from services.scenario_controller import app as scenario_module


@dataclass
class FakeItem:
    product_id: str
    quantity: int


class FakeRepository:
    def get_inventory(self, product_id: str, pre_query_delay: float = 0.0):
        return FakeItem(product_id=product_id, quantity=10)


def capture_events(monkeypatch, module):
    events = []
    monkeypatch.setattr(module, "record_event", events.append)
    return events


def set_scenario(monkeypatch, module, scenario: ScenarioId):
    async def fake_get_current():
        return scenario

    monkeypatch.setattr(module.scenario, "get_current", fake_get_current)


def test_uc01_emits_db_query_evidence(monkeypatch):
    events = capture_events(monkeypatch, inventory_module)
    monkeypatch.setattr(inventory_module, "repository", FakeRepository())
    set_scenario(monkeypatch, inventory_module, ScenarioId.UC01_DB_SLOW)
    monkeypatch.setattr(inventory_module, "perf_counter", iter([10.0, 12.5]).__next__)

    response = TestClient(inventory_module.app).get(
        "/inventory/SKU-001", headers={"X-Request-ID": "r-db"}
    )

    assert response.status_code == 200
    db_event = next(event for event in events if event.event_type == "db.query")
    assert db_event.request_id == "r-db"
    assert db_event.scenario_id == "UC01_DB_SLOW"
    assert db_event.attributes["db.query_name"] == "get_inventory"
    assert db_event.attributes["db.duration_ms"] == 2500.0
    assert "db.statement" not in db_event.attributes


class Always503Payment:
    async def charge(self, order_id, amount, *, request_id=None, scenario_id=None):
        request = httpx.Request("POST", "http://payment-mock:8084/charge")
        response = httpx.Response(503, request=request, json={"detail": "down"})
        raise httpx.HTTPStatusError("503", request=request, response=response)


def test_uc02_emits_dependency_and_retry_evidence(monkeypatch):
    events = capture_events(monkeypatch, payment_module)
    monkeypatch.setattr(payment_module, "payment_dependency", Always503Payment())

    response = TestClient(payment_module.app).post(
        "/payments",
        headers={"X-Request-ID": "r-pay", "X-Scenario-ID": "UC02_PAYMENT_FAILURE"},
        json={"order_id": "o-1", "amount": 1200},
    )

    assert response.status_code == 502
    retries = [event for event in events if event.event_type == "retry"]
    dependency = [event for event in events if event.event_type == "dependency.call"][-1]
    assert len(retries) == 2
    assert dependency.attributes["dependency.name"] == "payment-api"
    assert dependency.attributes["dependency.status_code"] == 503
    assert dependency.attributes["retry_count"] == 3


def test_uc03_emits_exception_evidence(monkeypatch):
    events = capture_events(monkeypatch, order_module)
    set_scenario(monkeypatch, order_module, ScenarioId.UC03_APP_EXCEPTION)

    response = TestClient(order_module.app, raise_server_exceptions=False).post(
        "/orders",
        headers={"X-Request-ID": "r-bug"},
        json={"product_id": "BUG-001", "quantity": 1, "amount": 1200},
    )

    assert response.status_code == 500
    event = next(event for event in events if event.event_type == "exception")
    assert event.attributes["error.type"] == "AttributeError"
    assert event.attributes["operation"] == "create_order"
    assert "card_number" not in event.attributes


class FakeInventory:
    async def get_inventory(self, product_id, *, request_id=None, scenario_id=None):
        return {
            "product_id": product_id,
            "quantity": 10,
            "service_version": "1.0.0",
            "request_id": request_id,
        }


class FakePayment:
    async def pay(self, order_id, amount, *, request_id=None, scenario_id=None):
        return {"status": "approved", "order_id": order_id, "request_id": request_id}


def test_uc04_emits_capacity_snapshot(monkeypatch):
    events = capture_events(monkeypatch, order_module)
    set_scenario(monkeypatch, order_module, ScenarioId.UC04_HIGH_LOAD)
    monkeypatch.setattr(order_module, "inventory_dependency", FakeInventory())
    monkeypatch.setattr(order_module, "payment_dependency", FakePayment())

    async def no_sleep(seconds):
        return None

    monkeypatch.setattr(order_module.asyncio, "sleep", no_sleep)

    response = TestClient(order_module.app).post(
        "/orders", json={"product_id": "SKU-001", "quantity": 1, "amount": 1200}
    )

    assert response.status_code == 201
    event = next(event for event in events if event.event_type == "capacity.snapshot")
    assert "queue_wait_ms" in event.attributes
    assert "active_workers" in event.attributes
    assert "inflight_requests" in event.attributes


def test_uc05_emits_deployment_evidence(monkeypatch):
    events = capture_events(monkeypatch, inventory_module)
    monkeypatch.setattr(inventory_module, "repository", FakeRepository())
    set_scenario(monkeypatch, inventory_module, ScenarioId.UC05_BAD_DEPLOYMENT)

    async def no_sleep(seconds):
        return None

    monkeypatch.setattr(inventory_module.asyncio, "sleep", no_sleep)

    response = TestClient(inventory_module.app).get("/inventory/SKU-001")

    assert response.status_code == 200
    event = next(event for event in events if event.event_type == "deployment")
    assert event.service_version == "1.1.0"
    assert event.attributes["deployment.id"] == "uc05-demo-deploy-001"


def test_scenario_change_event_records_from_and_to(monkeypatch):
    events = capture_events(monkeypatch, scenario_module)
    monkeypatch.setattr(scenario_module, "_state", ScenarioState(scenario=ScenarioId.NORMAL))

    response = TestClient(scenario_module.app).put(
        "/scenario", json={"scenario": "UC01_DB_SLOW"}
    )

    assert response.status_code == 200
    event = next(event for event in events if event.event_type == "scenario.change")
    assert event.attributes["from"] == "NORMAL"
    assert event.attributes["to"] == "UC01_DB_SLOW"
    assert event.scenario_id == "UC01_DB_SLOW"


class FakeOrderDependency:
    async def create_order(self, payload, request_id):
        return 201, {"order_id": "o-1", "status": "created"}


def test_gateway_emits_application_request_and_response(monkeypatch):
    events = capture_events(monkeypatch, gateway_module)
    monkeypatch.setattr(gateway_module, "order_dependency", FakeOrderDependency())

    response = TestClient(gateway_module.app).post(
        "/orders",
        headers={"X-Request-ID": "r-app"},
        json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
    )

    assert response.status_code == 201
    assert [event.event_type for event in events] == [
        "application.request",
        "application.response",
    ]
    assert events[-1].attributes["http.status_code"] == 201


def test_load_generator_emits_profile_only_when_scenario_changes(monkeypatch):
    from load_generator import main as load_module

    events = []
    monkeypatch.setattr(load_module, "record_event", events.append)

    load_module.record_load_profile(ScenarioId.NORMAL)
    load_module.record_load_profile(ScenarioId.UC04_HIGH_LOAD)

    assert [event.event_type for event in events] == ["load.profile", "load.profile"]
    assert events[0].attributes["requests_per_minute"] == 50
    assert events[1].attributes["requests_per_minute"] == 1000
