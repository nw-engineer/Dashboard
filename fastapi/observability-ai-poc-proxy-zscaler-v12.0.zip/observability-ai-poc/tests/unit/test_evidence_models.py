from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from agent.evidence.models import (
    CorrelationContext,
    EvidenceBundle,
    EvidenceCategory,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)


def test_evidence_item_accepts_json_compatible_facts():
    item = EvidenceItem(
        evidence_id="splunk-001",
        source=EvidenceSource.SPLUNK,
        category=EvidenceCategory.DB,
        summary="Inventory DB query completed in 1.2 ms",
        facts={"db.query_name": "get_inventory", "db.duration_ms": 1.2},
        query_or_tool="query-001",
        service_name="inventory-service",
        request_id="req-1",
        trace_id="trace-1",
        observed_at=datetime(2026, 9, 3, 6, 0, tzinfo=timezone.utc),
    )

    assert item.facts["db.duration_ms"] == 1.2
    assert item.source is EvidenceSource.SPLUNK


def test_evidence_item_rejects_non_json_compatible_fact():
    with pytest.raises(ValidationError, match="JSON-compatible"):
        EvidenceItem(
            evidence_id="splunk-001",
            source=EvidenceSource.SPLUNK,
            category=EvidenceCategory.APPLICATION,
            summary="bad fact",
            facts={"bad": object()},
            query_or_tool="query-001",
        )


def test_evidence_bundle_rejects_duplicate_evidence_ids():
    item = EvidenceItem(
        evidence_id="ev-1",
        source=EvidenceSource.SPLUNK,
        category=EvidenceCategory.CORRELATION,
        summary="request resolved",
        facts={"trace.id": "trace-1"},
        query_or_tool="query-1",
    )
    query = QueryDisclosure(
        disclosure_id="query-1",
        source=EvidenceSource.SPLUNK,
        operation="search",
        arguments={"query": 'request.id="req-1"'},
    )

    with pytest.raises(ValidationError, match="duplicate evidence_id"):
        EvidenceBundle(
            investigation_id="inv-1",
            request_id="req-1",
            trace_id="trace-1",
            evidence=[item, item.model_copy()],
            contradictions=[],
            gaps=[],
            queries_used=[query],
        )


def test_correlation_context_deduplicates_services_preserving_order():
    context = CorrelationContext(
        request_id="req-1",
        trace_id="trace-1",
        services=["api-gateway", "order-service", "api-gateway"],
    )

    assert context.services == ["api-gateway", "order-service"]
