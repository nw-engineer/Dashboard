from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def test_compose_defines_splunk_ports_and_trial_settings():
    text = (ROOT / "docker-compose.yml").read_text()

    assert "splunk:" in text
    assert "splunk/splunk:" in text
    assert "SPLUNK_START_ARGS" in text
    assert "SPLUNK_GENERAL_TERMS" in text
    assert "SPLUNK_PASSWORD" in text
    assert '"${SPLUNK_WEB_HOST_PORT:-18000}:8000"' in text
    assert '"${SPLUNK_HEC_HOST_PORT:-8088}:8088"' in text
    assert '"${SPLUNK_MGMT_HOST_PORT:-8089}:8089"' in text
    assert "./splunk/config/default.yml:/tmp/defaults/default.yml:ro" in text


def test_services_receive_hec_configuration_from_environment():
    text = (ROOT / "docker-compose.yml").read_text()

    assert "SPLUNK_HEC_ENABLED: ${SPLUNK_HEC_ENABLED:-false}" in text
    assert "SPLUNK_HEC_URL: ${SPLUNK_HEC_URL:-http://splunk:8088}" in text
    assert "SPLUNK_HEC_TOKEN: ${SPLUNK_HEC_TOKEN:-}" in text


def test_env_example_separates_hec_and_search_credentials():
    text = (ROOT / ".env.example").read_text()

    assert "SPLUNK_HEC_TOKEN=" in text
    assert "SPLUNK_SEARCH_USERNAME=" in text
    assert "SPLUNK_SEARCH_PASSWORD=" in text
    assert "SPLUNK_PASSWORD=" in text
