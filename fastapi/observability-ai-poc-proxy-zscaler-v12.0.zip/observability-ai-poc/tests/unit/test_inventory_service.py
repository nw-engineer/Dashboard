from dataclasses import dataclass

from fastapi.testclient import TestClient

from shared.scenario import ScenarioId
from services.inventory_service import app as inventory_module

client = TestClient(inventory_module.app)


@dataclass
class FakeItem:
    product_id: str
    quantity: int


class FakeRepository:
    def __init__(self):
        self.delays: list[float] = []

    def get_inventory(self, product_id: str, pre_query_delay: float = 0.0):
        self.delays.append(pre_query_delay)
        return FakeItem(product_id=product_id, quantity=10)


def set_scenario(monkeypatch, scenario: ScenarioId):
    async def fake_get_current():
        return scenario

    monkeypatch.setattr(inventory_module.scenario, "get_current", fake_get_current)


def test_normal_inventory_returns_quantity_and_version(monkeypatch):
    fake_repo = FakeRepository()
    monkeypatch.setattr(inventory_module, "repository", fake_repo)
    set_scenario(monkeypatch, ScenarioId.NORMAL)

    response = client.get("/inventory/SKU-001", headers={"X-Request-ID": "req-inventory"})

    assert response.status_code == 200
    assert response.json() == {
        "product_id": "SKU-001",
        "quantity": 10,
        "service_version": "1.0.0",
        "request_id": "req-inventory",
    }
    assert fake_repo.delays == [0.0]


def test_uc01_marks_db_path_delay(monkeypatch):
    fake_repo = FakeRepository()
    monkeypatch.setattr(inventory_module, "repository", fake_repo)
    set_scenario(monkeypatch, ScenarioId.UC01_DB_SLOW)

    response = client.get("/inventory/SKU-001")

    assert response.status_code == 200
    assert fake_repo.delays == [2.5]


def test_uc05_reports_bad_deployment_version(monkeypatch):
    fake_repo = FakeRepository()
    monkeypatch.setattr(inventory_module, "repository", fake_repo)
    set_scenario(monkeypatch, ScenarioId.UC05_BAD_DEPLOYMENT)
    slept = []

    async def fake_sleep(seconds: float):
        slept.append(seconds)

    monkeypatch.setattr(inventory_module.asyncio, "sleep", fake_sleep)

    response = client.get("/inventory/SKU-001")

    assert response.status_code == 200
    assert response.json()["service_version"] == "1.1.0"
    assert slept == [0.3]
