from fastapi.testclient import TestClient

from services.api_gateway import app as gateway_module

client = TestClient(gateway_module.app)


class FakeOrderDependency:
    def __init__(self):
        self.calls = []

    async def create_order(self, payload: dict, request_id: str):
        self.calls.append((payload, request_id))
        return 201, {"order_id": "ord-test", "status": "created"}


def test_gateway_creates_request_id(monkeypatch):
    fake = FakeOrderDependency()
    monkeypatch.setattr(gateway_module, "order_dependency", fake)

    response = client.post(
        "/orders",
        json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
    )

    request_id = response.headers["x-request-id"]
    assert request_id
    assert fake.calls[0][1] == request_id


def test_gateway_preserves_request_id(monkeypatch):
    fake = FakeOrderDependency()
    monkeypatch.setattr(gateway_module, "order_dependency", fake)

    response = client.post(
        "/orders",
        headers={"X-Request-ID": "req-known"},
        json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
    )

    assert response.headers["x-request-id"] == "req-known"
    assert fake.calls[0][1] == "req-known"
