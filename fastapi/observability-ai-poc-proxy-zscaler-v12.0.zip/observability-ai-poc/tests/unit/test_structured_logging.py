from datetime import datetime, timezone

from shared.schemas import StructuredEvent


def test_serializes_dotted_observability_fields():
    event = StructuredEvent(
        timestamp=datetime(2026, 9, 3, tzinfo=timezone.utc),
        level="ERROR",
        event_type="dependency.call",
        service_name="payment-service",
        service_version="1.0.0",
        deployment_environment="poc",
        request_id="r1",
        scenario_id="UC02_PAYMENT_FAILURE",
        trace_id="t1",
        span_id="s1",
        attributes={"dependency.status_code": 503, "retry_count": 3},
    )

    payload = event.to_splunk_event()

    assert payload["index"] == "poc_observability"
    assert payload["sourcetype"] == "poc:app:json"
    assert payload["event"]["service.name"] == "payment-service"
    assert payload["event"]["service.version"] == "1.0.0"
    assert payload["event"]["deployment.environment"] == "poc"
    assert payload["event"]["request.id"] == "r1"
    assert payload["event"]["scenario.id"] == "UC02_PAYMENT_FAILURE"
    assert payload["event"]["trace.id"] == "t1"
    assert payload["event"]["span.id"] == "s1"
    assert payload["event"]["dependency.status_code"] == 503
    assert payload["event"]["retry_count"] == 3


def test_omits_trace_and_span_when_unavailable():
    event = StructuredEvent(
        timestamp=datetime(2026, 9, 3, tzinfo=timezone.utc),
        level="INFO",
        event_type="application.request",
        service_name="api-gateway",
        service_version="1.0.0",
        deployment_environment="poc",
        request_id="r2",
        scenario_id="NORMAL",
    )

    payload = event.to_splunk_event()

    assert "trace.id" not in payload["event"]
    assert "span.id" not in payload["event"]


def test_strips_forbidden_attribute_keys_case_insensitively():
    event = StructuredEvent(
        timestamp=datetime(2026, 9, 3, tzinfo=timezone.utc),
        level="INFO",
        event_type="application.request",
        service_name="api-gateway",
        service_version="1.0.0",
        deployment_environment="poc",
        request_id="r3",
        scenario_id="NORMAL",
        attributes={
            "safe.value": 1,
            "password": "secret",
            "db.API_KEY": "secret",
            "authToken": "secret",
            "payment.card_number": "4111111111111111",
        },
    )

    payload = event.to_splunk_event()

    assert payload["event"]["safe.value"] == 1
    serialized_keys = {key.lower() for key in payload["event"]}
    assert not any("password" in key for key in serialized_keys)
    assert not any("api_key" in key for key in serialized_keys)
    assert not any("token" in key for key in serialized_keys)
    assert not any("card_number" in key for key in serialized_keys)
