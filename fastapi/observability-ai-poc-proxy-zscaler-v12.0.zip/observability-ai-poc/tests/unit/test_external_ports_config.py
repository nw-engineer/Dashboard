from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_compose_host_ports_are_configurable_with_safe_defaults():
    compose = (ROOT / "docker-compose.yml").read_text()
    assert '${GATEWAY_HOST_PORT:-8085}:8080' in compose
    assert '${SCENARIO_HOST_PORT:-8091}:8090' in compose


def test_integration_test_urls_are_configurable_with_matching_defaults():
    source = (ROOT / "tests/integration/test_demo_app.py").read_text()
    assert 'os.getenv("POC_GATEWAY_URL", "http://localhost:8085")' in source
    assert 'os.getenv("POC_SCENARIO_URL", "http://localhost:8091")' in source
