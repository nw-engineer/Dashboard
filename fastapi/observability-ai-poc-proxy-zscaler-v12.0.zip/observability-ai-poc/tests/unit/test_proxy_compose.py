from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_proxy_overlay_adds_mcp_console_api_and_ui():
    text = (ROOT / "compose.proxy.yml").read_text()
    for service in ["newrelic-mcp:", "console-api:", "console-ui:"]:
        assert service in text
    assert "8000:8000" in text or '8000}:8000' in text
    assert "8095:8095" in text or '8095}:8095' in text
    assert "5173:80" in text or '5173}:80' in text


def test_console_api_uses_internal_service_urls():
    text = (ROOT / "compose.proxy.yml").read_text()
    assert "SPLUNK_SEARCH_URL: https://splunk:8089" in text
    assert "NEW_RELIC_MCP_URL: http://newrelic-mcp:8000/mcp" in text


def test_overlay_injects_proxy_env_and_build_args_without_proxying_internal_services():
    text = (ROOT / "compose.proxy.yml").read_text()
    for key in ["HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "SSL_CERT_FILE", "REQUESTS_CA_BUNDLE"]:
        assert key in text
    assert text.count("<<: *proxy-env") >= 10
    assert text.count("args: *proxy-build-args") >= 10
    env_text = (ROOT / ".env.example").read_text()
    assert "10.0.0.0/8" in env_text
    assert "newrelic-mcp" in env_text
    assert "host.docker.internal" in env_text


def test_proxy_overlay_uses_container_specific_ollama_url_without_changing_host_default():
    overlay = (ROOT / "compose.proxy.yml").read_text()
    env_text = (ROOT / ".env.example").read_text()
    assert "OLLAMA_BASE_URL=http://localhost:11434" in env_text
    assert "OLLAMA_CONTAINER_BASE_URL=http://host.docker.internal:11434" in env_text
    assert "OLLAMA_BASE_URL: ${OLLAMA_CONTAINER_BASE_URL:-http://host.docker.internal:11434}" in overlay
