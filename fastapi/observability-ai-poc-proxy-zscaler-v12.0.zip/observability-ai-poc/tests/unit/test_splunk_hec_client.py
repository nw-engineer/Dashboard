from datetime import datetime, timezone

import httpx
import pytest

from shared.schemas import StructuredEvent
from shared.splunk_hec import SplunkHecClient


def sample_event(**overrides):
    values = {
        "timestamp": datetime(2026, 9, 3, tzinfo=timezone.utc),
        "level": "INFO",
        "event_type": "application.request",
        "service_name": "order-service",
        "service_version": "1.0.0",
        "deployment_environment": "poc",
        "request_id": "req-1",
        "scenario_id": "NORMAL",
    }
    values.update(overrides)
    return StructuredEvent(**values)


@pytest.mark.asyncio
async def test_posts_hec_event_with_token_and_fixed_envelope(monkeypatch):
    requests: list[httpx.Request] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json={"text": "Success", "code": 0})

    transport = httpx.MockTransport(handler)
    monkeypatch.setattr(
        "shared.splunk_hec.get_linking_metadata",
        lambda: {"trace.id": "trace-1", "span.id": "span-1"},
    )
    client = SplunkHecClient(
        base_url="http://splunk:8088",
        token="hec-secret",
        transport=transport,
    )

    await client.emit(sample_event())

    assert len(requests) == 1
    request = requests[0]
    assert request.url.path == "/services/collector/event"
    assert request.headers["Authorization"] == "Splunk hec-secret"
    payload = __import__("json").loads(request.content)
    assert payload["index"] == "poc_observability"
    assert payload["sourcetype"] == "poc:app:json"
    assert payload["event"]["trace.id"] == "trace-1"
    assert payload["event"]["span.id"] == "span-1"


@pytest.mark.asyncio
async def test_explicit_trace_and_span_take_precedence(monkeypatch):
    captured: dict = {}

    async def handler(request: httpx.Request) -> httpx.Response:
        captured.update(__import__("json").loads(request.content))
        return httpx.Response(200, json={"text": "Success", "code": 0})

    monkeypatch.setattr(
        "shared.splunk_hec.get_linking_metadata",
        lambda: {
            "trace.id": "nr-trace",
            "span.id": "nr-span",
            "entity.guid": "guid-1",
            "entity.name": "poc-order-service",
        },
    )
    client = SplunkHecClient(
        base_url="http://splunk:8088",
        token="hec-secret",
        transport=httpx.MockTransport(handler),
    )

    await client.emit(sample_event(trace_id="explicit-trace", span_id="explicit-span"))

    event = captured["event"]
    assert event["trace.id"] == "explicit-trace"
    assert event["span.id"] == "explicit-span"
    assert event["entity.guid"] == "guid-1"
    assert event["entity.name"] == "poc-order-service"


@pytest.mark.asyncio
async def test_retries_once_on_transport_failure(monkeypatch):
    attempts = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal attempts
        attempts += 1
        if attempts == 1:
            raise httpx.ConnectError("temporary", request=request)
        return httpx.Response(200, json={"text": "Success", "code": 0})

    monkeypatch.setattr("shared.splunk_hec.get_linking_metadata", lambda: {})
    client = SplunkHecClient(
        base_url="http://splunk:8088",
        token="hec-secret",
        transport=httpx.MockTransport(handler),
    )

    await client.emit(sample_event())

    assert attempts == 2
