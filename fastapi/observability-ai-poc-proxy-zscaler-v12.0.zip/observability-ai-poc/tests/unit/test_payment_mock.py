from fastapi.testclient import TestClient

from shared.scenario import ScenarioId
from services.payment_mock import app as payment_mock_module

client = TestClient(payment_mock_module.app)


def _set_scenario(monkeypatch, scenario: ScenarioId):
    async def fake_get_current():
        return scenario

    monkeypatch.setattr(payment_mock_module.scenario, "get_current", fake_get_current)


def test_normal_payment_succeeds(monkeypatch):
    _set_scenario(monkeypatch, ScenarioId.NORMAL)
    response = client.post("/charge", json={"order_id": "o-1", "amount": 1200})
    assert response.status_code == 200
    assert response.json()["status"] == "approved"


def test_uc02_returns_503(monkeypatch):
    _set_scenario(monkeypatch, ScenarioId.UC02_PAYMENT_FAILURE)
    response = client.post("/charge", json={"order_id": "o-1", "amount": 1200})
    assert response.status_code == 503
