from pathlib import Path


FASTAPI_DOCKERFILES = [
    Path('services/api_gateway/Dockerfile'),
    Path('services/order_service/Dockerfile'),
    Path('services/inventory_service/Dockerfile'),
    Path('services/payment_service/Dockerfile'),
    Path('services/payment_mock/Dockerfile'),
    Path('services/scenario_controller/Dockerfile'),
]


def test_example_env_has_newrelic_settings():
    text = Path('.env.example').read_text()
    assert 'NEW_RELIC_LICENSE_KEY=' in text
    assert 'NEW_RELIC_ENABLED=' in text
    assert 'NEW_RELIC_DISTRIBUTED_TRACING_ENABLED=true' in text
    assert 'NEW_RELIC_APPLICATION_LOGGING_ENABLED=true' in text
    assert 'NEW_RELIC_APPLICATION_LOGGING_FORWARDING_ENABLED=false' in text
    assert 'DEPLOYMENT_ENVIRONMENT=poc' in text
    assert 'NEW_RELIC_ACCOUNT_ID=' in text


def test_project_declares_newrelic_dependency():
    text = Path('pyproject.toml').read_text()
    assert 'newrelic>=' in text


def test_fastapi_services_launch_through_newrelic_admin():
    for dockerfile in FASTAPI_DOCKERFILES:
        text = dockerfile.read_text()
        assert 'newrelic-admin' in text, dockerfile
        assert 'run-program' in text, dockerfile


def test_compose_has_service_specific_newrelic_app_names():
    text = Path('docker-compose.yml').read_text()
    for app_name in [
        'poc-api-gateway',
        'poc-order-service',
        'poc-inventory-service',
        'poc-payment-service',
        'poc-payment-mock',
        'poc-scenario-controller',
    ]:
        assert app_name in text
