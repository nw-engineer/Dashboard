from datetime import datetime, timedelta, timezone
import json
from urllib.parse import parse_qs

import httpx
import pytest

from agent.splunk.client import SplunkSearchClient, SplunkSearchFailed
from agent.splunk.models import SplunkSearchRequest


@pytest.mark.asyncio
async def test_search_runs_read_only_job_lifecycle():
    calls: list[tuple[str, str]] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        calls.append((request.method, request.url.path))
        if request.method == "POST" and request.url.path == "/services/search/jobs":
            form = parse_qs(request.content.decode())
            assert form["search"] == ['search index=poc_observability request.id="r1"']
            assert form["output_mode"] == ["json"]
            return httpx.Response(201, json={"sid": "sid-123"})
        if request.method == "GET" and request.url.path == "/services/search/jobs/sid-123":
            return httpx.Response(
                200,
                json={"entry": [{"content": {"isDone": True}}]},
            )
        if request.method == "GET" and request.url.path == "/services/search/jobs/sid-123/results":
            assert request.url.params["count"] == "25"
            return httpx.Response(
                200,
                json={"results": [{"request.id": "r1", "event_type": "db.query"}]},
            )
        return httpx.Response(404)

    client = SplunkSearchClient(
        base_url="https://splunk:8089",
        username="ai_search",
        password="secret",
        transport=httpx.MockTransport(handler),
        poll_interval=0,
    )
    latest = datetime(2026, 9, 3, 4, 0, tzinfo=timezone.utc)
    req = SplunkSearchRequest(
        query='request.id="r1"',
        earliest=latest - timedelta(minutes=30),
        latest=latest,
        max_results=25,
    )

    results = await client.search(req)

    assert results == [{"request.id": "r1", "event_type": "db.query"}]
    assert calls == [
        ("POST", "/services/search/jobs"),
        ("GET", "/services/search/jobs/sid-123"),
        ("GET", "/services/search/jobs/sid-123/results"),
    ]


@pytest.mark.asyncio
async def test_search_rejects_forbidden_query_before_network_call():
    calls = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(500)

    client = SplunkSearchClient(
        base_url="https://splunk:8089",
        username="ai_search",
        password="secret",
        transport=httpx.MockTransport(handler),
    )
    now = datetime.now(timezone.utc)
    req = SplunkSearchRequest(
        query="index=poc_observability | delete",
        earliest=now - timedelta(minutes=5),
        latest=now,
    )

    with pytest.raises(ValueError):
        await client.search(req)

    assert calls == 0


@pytest.mark.asyncio
async def test_search_does_not_treat_string_zero_isdone_as_done():
    status_polls = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal status_polls
        if request.method == "POST" and request.url.path == "/services/search/jobs":
            return httpx.Response(201, json={"sid": "sid-string-state"})
        if request.method == "GET" and request.url.path == "/services/search/jobs/sid-string-state":
            status_polls += 1
            return httpx.Response(
                200,
                json={"entry": [{"content": {"isDone": "1" if status_polls >= 2 else "0"}}]},
            )
        if request.method == "GET" and request.url.path == "/services/search/jobs/sid-string-state/results":
            assert status_polls == 2
            return httpx.Response(200, json={"results": [{"event_type": "application.request"}]})
        return httpx.Response(404)

    client = SplunkSearchClient(
        base_url="https://splunk:8089",
        username="ai_search",
        password="secret",
        transport=httpx.MockTransport(handler),
        poll_interval=0,
    )
    latest = datetime(2026, 9, 3, 4, 0, tzinfo=timezone.utc)

    results = await client.search(
        SplunkSearchRequest(
            query='request.id="r1"',
            earliest=latest - timedelta(minutes=5),
            latest=latest,
        )
    )

    assert results == [{"event_type": "application.request"}]
    assert status_polls == 2


@pytest.mark.asyncio
async def test_search_raises_immediately_when_splunk_job_fails():
    calls: list[str] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        calls.append(request.url.path)
        if request.method == "POST" and request.url.path == "/services/search/jobs":
            return httpx.Response(201, json={"sid": "sid-failed"})
        if request.method == "GET" and request.url.path == "/services/search/jobs/sid-failed":
            return httpx.Response(
                200,
                json={
                    "entry": [
                        {
                            "content": {
                                "isDone": "1",
                                "dispatchState": "FAILED",
                                "messages": [{"type": "FATAL", "text": "search failed"}],
                            }
                        }
                    ]
                },
            )
        return httpx.Response(500)

    client = SplunkSearchClient(
        base_url="https://splunk:8089",
        username="ai_search",
        password="secret",
        transport=httpx.MockTransport(handler),
        poll_interval=0,
    )
    latest = datetime(2026, 9, 3, 4, 0, tzinfo=timezone.utc)

    with pytest.raises(SplunkSearchFailed, match="search failed"):
        await client.search(
            SplunkSearchRequest(
                query='request.id="r1"',
                earliest=latest - timedelta(minutes=5),
                latest=latest,
            )
        )

    assert "/services/search/jobs/sid-failed/results" not in calls


@pytest.mark.asyncio
async def test_search_expands_missing_structured_fields_from_raw_json():
    raw_event = {
        "timestamp": "2026-09-03T06:18:43.676297+00:00",
        "event_type": "application.request",
        "service.name": "api-gateway",
        "request.id": "r-json",
        "trace.id": "trace-json",
        "span.id": "span-json",
    }

    async def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST" and request.url.path == "/services/search/jobs":
            return httpx.Response(201, json={"sid": "sid-json-fields"})
        if request.method == "GET" and request.url.path == "/services/search/jobs/sid-json-fields":
            return httpx.Response(200, json={"entry": [{"content": {"isDone": "1"}}]})
        if request.method == "GET" and request.url.path == "/services/search/jobs/sid-json-fields/results":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "_raw": json.dumps(raw_event),
                            "request.id": "r-json",
                            "index": "poc_observability",
                        }
                    ]
                },
            )
        return httpx.Response(404)

    client = SplunkSearchClient(
        base_url="https://splunk:8089",
        username="ai_search",
        password="secret",
        transport=httpx.MockTransport(handler),
        poll_interval=0,
    )
    latest = datetime(2026, 9, 3, 6, 20, tzinfo=timezone.utc)

    results = await client.search(
        SplunkSearchRequest(
            query='request.id="r-json"',
            earliest=latest - timedelta(minutes=5),
            latest=latest,
        )
    )

    assert results[0]["trace.id"] == "trace-json"
    assert results[0]["span.id"] == "span-json"
    assert results[0]["service.name"] == "api-gateway"
    assert results[0]["event_type"] == "application.request"
