import pytest

from console_api.models import InvestigationStreamRequest
from console_api.stream import stream_investigation
from tests.unit.test_ui_presenter import _result


class DictEventFactory:
    def run_started(self, *, thread_id, run_id):
        return {"type": "RUN_STARTED", "threadId": thread_id, "runId": run_id}

    def step_started(self, step_name):
        return {"type": "STEP_STARTED", "stepName": step_name}

    def step_finished(self, step_name):
        return {"type": "STEP_FINISHED", "stepName": step_name}

    def custom(self, *, name, value):
        return {"type": "CUSTOM", "name": name, "value": value}

    def run_finished(self, *, thread_id, run_id, result):
        return {
            "type": "RUN_FINISHED",
            "threadId": thread_id,
            "runId": run_id,
            "result": result,
        }

    def run_error(self, *, message, code):
        return {"type": "RUN_ERROR", "message": message, "code": code}


class FakeOrchestrator:
    def __init__(self, progress, *, error=None):
        self.progress = progress
        self.error = error

    async def investigate_request_id(self, request_id, earliest, latest):
        for step in ["correlation", "splunk", "newrelic", "correlate", "analyze"]:
            await self.progress.step_started(step)
            if self.error is not None and step == "correlation":
                raise self.error
            await self.progress.step_finished(step)
        return _result()


def _request():
    return InvestigationStreamRequest(
        request_id="req-1",
        earliest="2026-09-04T00:00:00Z",
        latest="2026-09-04T00:10:00Z",
    )


@pytest.mark.asyncio
async def test_stream_emits_agui_lifecycle_then_a2ui_custom_events_then_finish():
    events = [
        event
        async for event in stream_investigation(
            _request(),
            lambda progress: FakeOrchestrator(progress),
            event_factory=DictEventFactory(),
            thread_id="thread-1",
            run_id="run-1",
        )
    ]

    assert [event["type"] for event in events] == [
        "RUN_STARTED",
        "STEP_STARTED", "STEP_FINISHED",
        "STEP_STARTED", "STEP_FINISHED",
        "STEP_STARTED", "STEP_FINISHED",
        "STEP_STARTED", "STEP_FINISHED",
        "STEP_STARTED", "STEP_FINISHED",
        "CUSTOM", "CUSTOM", "CUSTOM",
        "RUN_FINISHED",
    ]
    custom = [event for event in events if event["type"] == "CUSTOM"]
    assert [event["name"] for event in custom] == ["a2ui.message"] * 3
    assert [next(k for k in event["value"] if k != "version") for event in custom] == [
        "createSurface",
        "updateComponents",
        "updateDataModel",
    ]
    assert events[-1]["result"] == {"investigationId": "inv-1"}


@pytest.mark.asyncio
async def test_stream_sanitizes_failure_and_never_finishes_successfully():
    events = [
        event
        async for event in stream_investigation(
            _request(),
            lambda progress: FakeOrchestrator(
                progress, error=RuntimeError("password=do-not-leak token=abc123")
            ),
            event_factory=DictEventFactory(),
            thread_id="thread-1",
            run_id="run-1",
        )
    ]

    assert events[-1] == {
        "type": "RUN_ERROR",
        "message": "調査を完了できませんでした。",
        "code": "INVESTIGATION_FAILED",
    }
    assert not any(event["type"] == "RUN_FINISHED" for event in events)
    assert "password" not in str(events).lower()
    assert "abc123" not in str(events)

@pytest.mark.asyncio
async def test_stream_sanitizes_orchestrator_factory_failure_after_run_started():
    def broken_factory(_progress):
        raise RuntimeError("SPLUNK_SEARCH_PASSWORD=do-not-leak")

    events = [
        event
        async for event in stream_investigation(
            _request(),
            broken_factory,
            event_factory=DictEventFactory(),
            thread_id="thread-1",
            run_id="run-1",
        )
    ]

    assert events == [
        {"type": "RUN_STARTED", "threadId": "thread-1", "runId": "run-1"},
        {
            "type": "RUN_ERROR",
            "message": "調査を完了できませんでした。",
            "code": "INVESTIGATION_FAILED",
        },
    ]
    assert "do-not-leak" not in str(events)



@pytest.mark.asyncio
async def test_stream_logs_safe_llm_failure_metadata_without_exception_text(caplog, monkeypatch):
    from agent.analysis.azure_openai_adapter import AzureOpenAIAnalysisError

    monkeypatch.setenv('LLM_PROVIDER', 'azure_openai')
    monkeypatch.setenv('AZURE_OPENAI_MODEL', 'gpt-5.6-sol')

    class AnalyzeFailureOrchestrator:
        def __init__(self, progress):
            self.progress = progress

        async def investigate_request_id(self, request_id, earliest, latest):
            for step in ['correlation', 'splunk', 'newrelic', 'correlate']:
                await self.progress.step_started(step)
                await self.progress.step_finished(step)
            await self.progress.step_started('analyze')
            raise AzureOpenAIAnalysisError(
                'Azure OpenAI Responses API returned HTTP 429 token=do-not-leak'
            )

    with caplog.at_level('ERROR', logger='console_api.stream'):
        events = [
            event
            async for event in stream_investigation(
                _request(),
                lambda progress: AnalyzeFailureOrchestrator(progress),
                event_factory=DictEventFactory(),
                thread_id='thread-1',
                run_id='run-1',
            )
        ]

    assert events[-1] == {
        'type': 'RUN_ERROR',
        'message': 'LLM分析中に一時的なエラーが発生しました。再度実行してください。',
        'code': 'LLM_ANALYSIS_FAILED',
    }
    assert 'step=analyze' in caplog.text
    assert 'provider=azure_openai' in caplog.text
    assert 'model=gpt-5.6-sol' in caplog.text
    assert 'error_type=rate_limit' in caplog.text
    assert 'token=do-not-leak' not in caplog.text
