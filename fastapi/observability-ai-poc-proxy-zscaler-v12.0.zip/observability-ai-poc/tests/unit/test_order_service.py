import pytest
from fastapi.testclient import TestClient

from services.order_service import app as order_module

client = TestClient(order_module.app, raise_server_exceptions=False)


@pytest.fixture(autouse=True)
def default_normal_scenario(monkeypatch):
    from shared.scenario import ScenarioId

    async def fake_get_current():
        return ScenarioId.NORMAL

    monkeypatch.setattr(order_module.scenario, "get_current", fake_get_current)


class FakeInventory:
    def __init__(self, quantity: int = 10):
        self.quantity = quantity
        self.calls = []

    async def get_inventory(self, product_id: str, *, request_id: str | None = None, scenario_id: str | None = None) -> dict:
        self.calls.append(product_id)
        return {"product_id": product_id, "quantity": self.quantity, "service_version": "1.0.0"}


class FakePayment:
    def __init__(self):
        self.calls = []

    async def pay(self, order_id: str, amount: int, *, request_id: str | None = None, scenario_id: str | None = None) -> dict:
        self.calls.append((order_id, amount))
        return {"status": "approved", "order_id": order_id}


def test_bug_product_returns_500(monkeypatch):
    inventory = FakeInventory()
    payment = FakePayment()
    monkeypatch.setattr(order_module, "inventory_dependency", inventory)
    monkeypatch.setattr(order_module, "payment_dependency", payment)

    response = client.post(
        "/orders",
        json={"product_id": "BUG-001", "quantity": 1, "amount": 1200},
    )

    assert response.status_code == 500
    assert inventory.calls == []
    assert payment.calls == []


def test_normal_order_returns_201(monkeypatch):
    inventory = FakeInventory(quantity=10)
    payment = FakePayment()
    monkeypatch.setattr(order_module, "inventory_dependency", inventory)
    monkeypatch.setattr(order_module, "payment_dependency", payment)

    response = client.post(
        "/orders",
        json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
    )

    assert response.status_code == 201
    assert response.json()["order_id"]
    assert inventory.calls == ["SKU-001"]
    assert len(payment.calls) == 1


def test_insufficient_inventory_returns_409(monkeypatch):
    inventory = FakeInventory(quantity=0)
    payment = FakePayment()
    monkeypatch.setattr(order_module, "inventory_dependency", inventory)
    monkeypatch.setattr(order_module, "payment_dependency", payment)

    response = client.post(
        "/orders",
        json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
    )

    assert response.status_code == 409
    assert payment.calls == []


def test_uc04_holds_capacity_slot(monkeypatch):
    from shared.scenario import ScenarioId

    inventory = FakeInventory(quantity=10)
    payment = FakePayment()
    monkeypatch.setattr(order_module, "inventory_dependency", inventory)
    monkeypatch.setattr(order_module, "payment_dependency", payment)

    async def fake_get_current():
        return ScenarioId.UC04_HIGH_LOAD

    monkeypatch.setattr(order_module.scenario, "get_current", fake_get_current)
    slept = []

    async def fake_sleep(seconds: float):
        slept.append(seconds)

    monkeypatch.setattr(order_module.asyncio, "sleep", fake_sleep)

    response = client.post(
        "/orders",
        json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
    )

    assert response.status_code == 201
    assert slept == [0.25]


def test_order_returns_inventory_service_version(monkeypatch):
    inventory = FakeInventory(quantity=10)
    payment = FakePayment()
    monkeypatch.setattr(order_module, "inventory_dependency", inventory)
    monkeypatch.setattr(order_module, "payment_dependency", payment)

    response = client.post(
        "/orders",
        json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
    )

    assert response.status_code == 201
    assert response.json()["inventory_service_version"] == "1.0.0"

class FakeFailingPayment:
    async def pay(self, order_id: str, amount: int, *, request_id: str | None = None, scenario_id: str | None = None) -> dict:
        import httpx

        request = httpx.Request("POST", "http://payment-service:8083/payments")
        response = httpx.Response(502, request=request, json={"detail": "payment dependency failed"})
        raise httpx.HTTPStatusError(
            "Server error '502 Bad Gateway'",
            request=request,
            response=response,
        )


def test_payment_service_502_is_propagated_as_502(monkeypatch):
    inventory = FakeInventory(quantity=10)
    payment = FakeFailingPayment()
    monkeypatch.setattr(order_module, "inventory_dependency", inventory)
    monkeypatch.setattr(order_module, "payment_dependency", payment)

    response = client.post(
        "/orders",
        json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
    )

    assert response.status_code == 502
    assert response.json()["detail"] == "payment service failed"
