from shared.scenario import ScenarioId, ScenarioState


def test_scenario_values_are_stable():
    assert ScenarioId.NORMAL == "NORMAL"
    assert ScenarioId.UC01_DB_SLOW == "UC01_DB_SLOW"
    assert ScenarioId.UC05_BAD_DEPLOYMENT == "UC05_BAD_DEPLOYMENT"


def test_scenario_state_defaults_to_normal():
    state = ScenarioState()
    assert state.scenario is ScenarioId.NORMAL
