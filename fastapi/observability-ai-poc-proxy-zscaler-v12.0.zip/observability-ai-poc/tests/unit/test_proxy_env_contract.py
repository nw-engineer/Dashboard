from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_env_example_declares_proxy_and_ca_contract():
    text = (ROOT / ".env.example").read_text()
    for item in [
        "HTTP_PROXY=",
        "HTTPS_PROXY=",
        "NO_PROXY=",
        "http_proxy=",
        "https_proxy=",
        "no_proxy=",
        "ZSCALER_CA_PATH=/usr/local/share/ca-certificates/zscaler-ca.crt",
        "SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt",
        "REQUESTS_CA_BUNDLE=/etc/ssl/certs/ca-certificates.crt",
        "NODE_EXTRA_CA_CERTS=/usr/local/share/ca-certificates/zscaler-ca.crt",
        "npm_config_cafile=/etc/ssl/certs/ca-certificates.crt",
        "NEW_RELIC_PROXY_HOST=",
        "NEW_RELIC_CA_BUNDLE_PATH=/etc/ssl/certs/ca-certificates.crt",
        "NEW_RELIC_MCP_USER_KEY=",
        "NEW_RELIC_REGION=US",
        "NEW_RELIC_GRAPHQL_URL=",
        "NEW_RELIC_ALLOWED_ACCOUNT_IDS=",
    ]:
        assert item in text


def test_no_proxy_contains_private_ranges_and_compose_service_names():
    text = (ROOT / ".env.example").read_text()
    required = [
        "localhost", "127.0.0.1", "::1",
        "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16",
        "host.docker.internal", "splunk", "postgres", "scenario-controller", "payment-mock",
        "payment-service", "inventory-service", "order-service", "api-gateway",
        "load-generator", "newrelic-mcp", "console-api", "console-ui",
    ]
    for item in required:
        assert item in text
    assert "NO_PROXY_EXTRA=" in text


def test_real_ca_is_ignored_but_documented():
    ignore = (ROOT / ".gitignore").read_text()
    assert "certs/zscaler-ca.crt" in ignore
    assert (ROOT / "certs/README.md").exists()


def test_env_example_contains_no_obvious_real_secret_values():
    text = (ROOT / ".env.example").read_text()
    assignments = [line for line in text.splitlines() if line and not line.startswith("#") and "=" in line]
    values = "\n".join(line.split("=", 1)[1] for line in assignments)
    for forbidden in ["NRAK-", "sk-proj-", "Bearer ", "Splunk "]:
        assert forbidden not in values


def test_docker_build_context_excludes_env_and_generated_artifacts_but_keeps_ca():
    dockerignore = (ROOT / ".dockerignore").read_text()
    for required in [".env", ".venv/", "**/__pycache__/", ".pytest_cache/", "console/node_modules/", "console/dist/", "*.log"]:
        assert required in dockerignore
    assert "certs/zscaler-ca.crt" not in dockerignore


def test_env_example_preserves_host_side_defaults_for_non_proxy_manual_workflow():
    text = (ROOT / ".env.example").read_text()
    assert "SPLUNK_SEARCH_URL=https://localhost:8089" in text
    assert "NEW_RELIC_MCP_URL=http://localhost:8000/mcp" in text
