# Splunk Enterprise Trial setup for the PoC

The PoC uses one Splunk Enterprise standalone instance. The application sends JSON events through HEC, while the troubleshooting agent uses a separate read-only Search REST credential.

## Fixed data contract

- Index: `poc_observability`
- Sourcetype: `poc:app:json`
- HEC container port: `8088`
- Splunk Web container port: `8000`
- Management/Search REST container port: `8089`

The host ports are configurable with `SPLUNK_*_HOST_PORT` in `.env`.

## 1. Add secrets to `.env`

Set a strong temporary Splunk admin password and a UUID-style HEC token. Do not commit `.env`.

```text
SPLUNK_PASSWORD=<strong trial admin password>
SPLUNK_HEC_TOKEN=<random UUID token>
SPLUNK_HEC_ENABLED=true
```

Generate a token if needed:

```bash
python3 - <<'PY'
import uuid
print(uuid.uuid4())
PY
```

## 2. Start Splunk

Splunk is behind the Compose `splunk` profile so Phase 1/2 can still run without it.

```bash
docker compose --profile splunk up -d splunk
docker compose ps splunk
docker compose logs -f splunk
```

The first boot can take several minutes. When healthy, open `http://<VM>:${SPLUNK_WEB_HOST_PORT:-18000}` and sign in as `admin` with `SPLUNK_PASSWORD`.

The mounted `default.yml` creates the `poc_observability` index and enables HEC. The HEC event envelope also fixes the index and sourcetype.

## 3. Verify HEC

From the VM host:

```bash
curl -sS http://localhost:${SPLUNK_HEC_HOST_PORT:-8088}/services/collector/event \
  -H "Authorization: Splunk ${SPLUNK_HEC_TOKEN}" \
  -H 'Content-Type: application/json' \
  -d '{"index":"poc_observability","sourcetype":"poc:app:json","event":{"event_type":"hec.smoke","service.name":"manual-check"}}'
```

Expected HEC response contains `"code":0`.

## 4. Create a search-only credential

Do not use the HEC token or the Splunk `admin` account for agent searches. Create a dedicated `poc_ai_search` role with only the `search` capability and only the `poc_observability` index. Do **not** inherit the built-in `user` role because inherited roles can broaden both capabilities and searchable indexes.

From the VM host, set a temporary password for the agent user without echoing it into shell history if possible, then create the role and user through the Splunk management REST API:

```bash
export SPLUNK_ADMIN_PASSWORD='<current Splunk admin password>'
export SPLUNK_AI_SEARCH_PASSWORD='<new ai_search password>'

curl -ksS -u "admin:${SPLUNK_ADMIN_PASSWORD}" \
  https://localhost:${SPLUNK_MGMT_HOST_PORT:-8089}/services/authorization/roles \
  -d name=poc_ai_search \
  -d capabilities=search \
  -d srchIndexesAllowed=poc_observability \
  -d srchIndexesDefault=poc_observability \
  -d srchTimeWin=7200 \
  -d srchJobsQuota=3 \
  -d cumulativeSrchJobsQuota=6

curl -ksS -u "admin:${SPLUNK_ADMIN_PASSWORD}" \
  https://localhost:${SPLUNK_MGMT_HOST_PORT:-8089}/services/authentication/users \
  -d name=ai_search \
  -d password="${SPLUNK_AI_SEARCH_PASSWORD}" \
  -d roles=poc_ai_search \
  -d force-change-pass=false
```

Splunk Enterprise 10.4.3 enables several capabilities in the global `[default]` role stanza (`edit_own_objects`, `list_all_objects`, `run_collect`, `run_mcollect`, and `schedule_rtsearch`). For this PoC, explicitly override those defaults in `/opt/splunk/etc/system/local/authorize.conf` for `role_poc_ai_search` so that the agent credential has only the `search` capability:

```ini
[role_poc_ai_search]
edit_own_objects = disabled
list_all_objects = disabled
run_collect = disabled
run_mcollect = disabled
schedule_rtsearch = disabled
search = enabled
srchIndexesAllowed = poc_observability
srchIndexesDefault = poc_observability
srchTimeWin = 7200
```

Reload authentication after changing `authorize.conf`:

```bash
docker compose --profile splunk exec -u splunk splunk \
  /opt/splunk/bin/splunk reload auth \
  -auth "admin:${SPLUNK_ADMIN_PASSWORD}"
```

Verify the effective capabilities using the search-only credential. The expected capability list is exactly `search`:

```bash
curl -ksS \
  -u "ai_search:${SPLUNK_AI_SEARCH_PASSWORD}" \
  "https://localhost:${SPLUNK_MGMT_HOST_PORT:-8089}/services/authentication/current-context?output_mode=json"
```

Then store only the search-only credential in `.env`:

```text
SPLUNK_SEARCH_URL=https://localhost:8089
SPLUNK_SEARCH_USERNAME=ai_search
SPLUNK_SEARCH_PASSWORD=<search-only password>
SPLUNK_SEARCH_VERIFY_SSL=false
```

The application-level guard still enforces `index=poc_observability`, a maximum two-hour search range, a maximum 200 returned rows, and rejects SPL commands that can mutate data, trigger alerts, write files, access REST endpoints, execute scripts, invoke saved searches/jobs, use `map`, or expand macros. The Splunk role is the second line of defense.

### Live Search Tool integration test

With Demo Commerce and Splunk running, execute the live correlation test from the VM host with Python 3.11:

```bash
docker run --rm --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e SPLUNK_SEARCH_URL=https://localhost:8089 \
  -e SPLUNK_SEARCH_USERNAME=ai_search \
  -e SPLUNK_SEARCH_PASSWORD \
  -e SPLUNK_SEARCH_VERIFY_SSL=false \
  python:3.11-slim \
  sh -lc "python -m pip install -q -e '.[dev]' && python -m pytest tests/integration/test_splunk_search_integration.py -v"
```

The test creates a fresh order with a unique `request.id`, retrieves the corresponding `trace.id` through `SplunkSearchClient`, then searches that trace and verifies that it contains the original `request.id`.

## 5. Enable HEC in the application services

After Splunk is healthy and `.env` contains the token:

```bash
docker compose up -d --build --force-recreate \
  scenario-controller payment-mock payment-service inventory-service \
  order-service api-gateway load-generator
```

Container-to-container HEC stays `http://splunk:8088`; only host-side ports use the `SPLUNK_*_HOST_PORT` values.

## 6. Useful searches

```spl
index=poc_observability request.id="<request-id>"
```

```spl
index=poc_observability scenario.id="UC01_DB_SLOW" event_type="db.query"
| table _time service.name request.id trace.id db.query_name db.duration_ms
```

```spl
index=poc_observability scenario.id="UC02_PAYMENT_FAILURE"
| table _time event_type request.id trace.id dependency.name dependency.status_code retry_count
```

The application never logs SQL text, passwords, API keys, HEC tokens, or card numbers.
