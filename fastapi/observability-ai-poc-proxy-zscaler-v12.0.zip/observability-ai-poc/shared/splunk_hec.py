from __future__ import annotations

from typing import Any

import httpx

from shared.correlation import get_linking_metadata
from shared.schemas import StructuredEvent


class SplunkHecError(RuntimeError):
    pass


class SplunkHecClient:
    def __init__(
        self,
        *,
        base_url: str,
        token: str,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.transport = transport

    def _enrich(self, event: StructuredEvent) -> StructuredEvent:
        metadata = get_linking_metadata()
        updates: dict[str, Any] = {}
        if event.trace_id is None and metadata.get("trace.id"):
            updates["trace_id"] = metadata["trace.id"]
        if event.span_id is None and metadata.get("span.id"):
            updates["span_id"] = metadata["span.id"]
        if event.entity_guid is None and metadata.get("entity.guid"):
            updates["entity_guid"] = metadata["entity.guid"]
        if event.entity_name is None and metadata.get("entity.name"):
            updates["entity_name"] = metadata["entity.name"]
        return event.model_copy(update=updates) if updates else event

    async def emit(self, event: StructuredEvent) -> None:
        enriched = self._enrich(event)
        payload = enriched.to_splunk_event()
        headers = {"Authorization": f"Splunk {self.token}"}

        async with httpx.AsyncClient(
            timeout=3.0,
            transport=self.transport,
        ) as client:
            for attempt in range(2):
                try:
                    response = await client.post(
                        f"{self.base_url}/services/collector/event",
                        headers=headers,
                        json=payload,
                    )
                    response.raise_for_status()
                    body = response.json()
                    if body.get("code") not in (0, None):
                        raise SplunkHecError(f"Splunk HEC rejected event with code {body.get('code')}")
                    return
                except httpx.TransportError:
                    if attempt == 1:
                        raise
