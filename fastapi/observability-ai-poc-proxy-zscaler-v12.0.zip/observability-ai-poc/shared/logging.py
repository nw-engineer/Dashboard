from __future__ import annotations

import asyncio
import os
from datetime import datetime, timezone
from typing import Any, Mapping

from shared.correlation import get_linking_metadata

_FORBIDDEN_KEY_PARTS = ("password", "api_key", "token", "card_number")
_PENDING_TASKS: set[asyncio.Task] = set()
_MAX_PENDING_TASKS = 256


def sanitize_attributes(attributes: Mapping[str, Any] | None) -> dict[str, Any]:
    if not attributes:
        return {}
    sanitized: dict[str, Any] = {}
    for key, value in attributes.items():
        normalized = str(key).lower()
        if any(part in normalized for part in _FORBIDDEN_KEY_PARTS):
            continue
        sanitized[str(key)] = value
    return sanitized


def build_event(
    event_type: str,
    *,
    level: str = "INFO",
    service_name: str | None = None,
    service_version: str | None = None,
    deployment_environment: str | None = None,
    request_id: str | None = None,
    scenario_id: str | None = None,
    attributes: Mapping[str, Any] | None = None,
):
    from shared.schemas import StructuredEvent

    linking = get_linking_metadata()
    return StructuredEvent(
        timestamp=datetime.now(timezone.utc),
        level=level,
        event_type=event_type,
        service_name=service_name or os.getenv("SERVICE_NAME", "unknown-service"),
        service_version=service_version or os.getenv("SERVICE_VERSION", "1.0.0"),
        deployment_environment=deployment_environment
        or os.getenv("DEPLOYMENT_ENVIRONMENT", "poc"),
        request_id=request_id,
        scenario_id=scenario_id,
        trace_id=linking.get("trace.id"),
        span_id=linking.get("span.id"),
        entity_guid=linking.get("entity.guid"),
        entity_name=linking.get("entity.name"),
        attributes=sanitize_attributes(attributes),
    )


def _consume_task(task: asyncio.Task) -> None:
    _PENDING_TASKS.discard(task)
    try:
        task.result()
    except Exception:
        # Logging failures must never fail the business request. Never print event bodies here.
        pass


def record_event(event) -> bool:
    if os.getenv("SPLUNK_HEC_ENABLED", "false").strip().lower() not in {
        "1",
        "true",
        "yes",
        "on",
    }:
        return False
    token = os.getenv("SPLUNK_HEC_TOKEN", "").strip()
    base_url = os.getenv("SPLUNK_HEC_URL", "http://splunk:8088").strip()
    if not token or len(_PENDING_TASKS) >= _MAX_PENDING_TASKS:
        return False
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return False

    from shared.splunk_hec import SplunkHecClient

    task = loop.create_task(SplunkHecClient(base_url=base_url, token=token).emit(event))
    _PENDING_TASKS.add(task)
    task.add_done_callback(_consume_task)
    return True
