import os
from typing import Any

try:
    import newrelic.agent as _nr_agent
except ModuleNotFoundError:  # Unit-test/local fallback when the optional runtime is absent.
    _nr_agent = None


def _enabled() -> bool:
    return os.getenv("NEW_RELIC_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}


def _agent():
    if _nr_agent is None:
        if _enabled():
            raise RuntimeError("New Relic agent package is required when NEW_RELIC_ENABLED=true")
        return None
    return _nr_agent


def add_transaction_attributes(**values: Any) -> None:
    agent = _agent()
    if agent is None:
        return

    attrs: dict[str, Any] = {}
    service_name = values.pop("service_name", None) or os.getenv("SERVICE_NAME")
    service_version = values.pop("service_version", None) or os.getenv("SERVICE_VERSION")
    deployment_environment = values.pop("deployment_environment", None) or os.getenv(
        "DEPLOYMENT_ENVIRONMENT"
    )

    base = {
        "service.name": service_name,
        "service.version": service_version,
        "deployment.environment": deployment_environment,
    }
    attrs.update({key: value for key, value in base.items() if value is not None})
    attrs.update(
        {
            key.replace("_", "."): value
            for key, value in values.items()
            if value is not None
        }
    )
    if attrs:
        agent.add_custom_attributes(list(attrs.items()))


def get_linking_metadata() -> dict[str, str]:
    agent = _agent()
    if agent is None:
        return {}
    raw = agent.get_linking_metadata()
    return {str(key): str(value) for key, value in raw.items() if value is not None}
