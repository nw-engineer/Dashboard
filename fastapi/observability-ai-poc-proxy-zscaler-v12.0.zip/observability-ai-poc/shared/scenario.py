from enum import StrEnum

from pydantic import BaseModel


class ScenarioId(StrEnum):
    NORMAL = "NORMAL"
    UC01_DB_SLOW = "UC01_DB_SLOW"
    UC02_PAYMENT_FAILURE = "UC02_PAYMENT_FAILURE"
    UC03_APP_EXCEPTION = "UC03_APP_EXCEPTION"
    UC04_HIGH_LOAD = "UC04_HIGH_LOAD"
    UC05_BAD_DEPLOYMENT = "UC05_BAD_DEPLOYMENT"


class ScenarioState(BaseModel):
    scenario: ScenarioId = ScenarioId.NORMAL
