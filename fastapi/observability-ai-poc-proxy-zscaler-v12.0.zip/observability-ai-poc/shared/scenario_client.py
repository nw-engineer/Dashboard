import os

import httpx

from shared.scenario import ScenarioId


class ScenarioClient:
    def __init__(self, base_url: str | None = None):
        self.base_url = base_url or os.getenv(
            "SCENARIO_CONTROLLER_URL", "http://scenario-controller:8090"
        )

    async def get_current(self) -> ScenarioId:
        async with httpx.AsyncClient(timeout=2.0) as client:
            response = await client.get(f"{self.base_url}/scenario")
            response.raise_for_status()
            return ScenarioId(response.json()["scenario"])
