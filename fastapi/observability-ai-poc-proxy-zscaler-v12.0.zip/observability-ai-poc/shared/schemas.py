from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from shared.logging import sanitize_attributes


class StructuredEvent(BaseModel):
    timestamp: datetime
    level: str
    event_type: str
    service_name: str
    service_version: str
    deployment_environment: str
    request_id: str | None = None
    scenario_id: str | None = None
    trace_id: str | None = None
    span_id: str | None = None
    entity_guid: str | None = None
    entity_name: str | None = None
    host: str | None = None
    source: str = "demo-commerce"
    attributes: dict[str, Any] = Field(default_factory=dict)

    def to_splunk_event(self) -> dict[str, Any]:
        event: dict[str, Any] = {
            "timestamp": self.timestamp.isoformat(),
            "level": self.level,
            "event_type": self.event_type,
            "service.name": self.service_name,
            "service.version": self.service_version,
            "deployment.environment": self.deployment_environment,
        }
        optional = {
            "request.id": self.request_id,
            "scenario.id": self.scenario_id,
            "trace.id": self.trace_id,
            "span.id": self.span_id,
            "entity.guid": self.entity_guid,
            "entity.name": self.entity_name,
        }
        event.update({key: value for key, value in optional.items() if value is not None})
        event.update(sanitize_attributes(self.attributes))
        return {
            "time": self.timestamp.timestamp(),
            "host": self.host or self.service_name,
            "source": self.source,
            "sourcetype": "poc:app:json",
            "index": "poc_observability",
            "event": event,
        }
