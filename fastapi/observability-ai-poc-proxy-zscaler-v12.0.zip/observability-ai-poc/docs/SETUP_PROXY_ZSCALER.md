# Proxy + Zscaler CA 環境向け 新規セットアップ手順

この手順は、Phase 5 完了版の Observability AI PoC を **Proxy + Zscaler CA 環境へ1から構築**するためのものです。PoC の安全境界は従来どおり Read Only / Evidence-first で、AI は Observe -> Investigate -> Correlate -> Recommend までを行い、本番変更操作は行いません。

## 1. Scope and prerequisites

前提:

- Linux/Ubuntu VM を想定。
- Docker Engine と Docker Compose v2 が利用可能。
- Docker daemon / `docker pull` 用のProxy設定は **本プロジェクトの対象外**。ベースイメージをpullできる状態を事前に用意する。
- 外部通信は企業Proxyを経由し、TLSインスペクション用Zscaler CAを利用する。
- New Relic、Splunk、選択するLLM Providerの資格情報を利用者側で準備する。
- Python PoC要件は `>=3.11,<3.14`。回帰テストは `python:3.11-slim` を基準とする。

作業ディレクトリ例:

```bash
cd ~/observability-ai-poc
```

## 2. Files to prepare

ZIP展開後、少なくとも以下を確認する。

```bash
ls -l docker-compose.yml compose.proxy.yml .env.example
ls -l docs/SETUP_PROXY_ZSCALER.md docs/TESTING_PROXY_ZSCALER.md
ls -l vendor/newrelic-mcp-server/pyproject.toml
```

Zscaler CAの実体はZIPには含まれない。利用者が `certs/zscaler-ca.crt` を配置する。

## 3. Create .env from .env.example

```bash
cp .env.example .env
chmod 600 .env
```

`.env` はコミット・共有しない。Proxy認証情報、API Key、License Key、Splunk password/tokenを含み得る。

## 4. Configure Proxy and NO_PROXY

`.env` にProxy URLを設定する。

```dotenv
HTTP_PROXY=http://proxy.example.local:8080
HTTPS_PROXY=http://proxy.example.local:8080
```

認証付きProxyの場合は組織ルールに従う。Proxy URLそのものをログや資料へ貼り付けない。

`NO_PROXY` の既定値には次を含める。

```text
localhost
127.0.0.1
::1
10.0.0.0/8
172.16.0.0/12
192.168.0.0/16
host.docker.internal
splunk
postgres
scenario-controller
payment-mock
payment-service
inventory-service
order-service
api-gateway
load-generator
newrelic-mcp
console-api
console-ui
```

追加の社内宛先がある場合は `NO_PROXY_EXTRA` にカンマ区切りで追加する。`.env.example` の `NO_PROXY` は末尾で `${NO_PROXY_EXTRA}` を連結するため、必須範囲を消さずに環境固有の除外先を追加できる。

`NO_PROXY` のCIDR解釈はHTTPクライアント実装ごとに差があるため、RFC1918 CIDRだけに依存せずComposeサービス名も明示している。環境固有の内部FQDN/IPでProxyへ流れてしまう場合は `NO_PROXY_EXTRA` にそのホスト名または具体的なIPを追加する。

Compose内部では以下を直接利用し、Proxyを通さない。

```dotenv
SPLUNK_SEARCH_URL=https://splunk:8089
NEW_RELIC_MCP_URL=http://newrelic-mcp:8000/mcp
```

## 5. Place Zscaler CA

PEM/CRT形式のCAを配置する。

```bash
cp /path/to/your/zscaler-ca.crt certs/zscaler-ca.crt
chmod 644 certs/zscaler-ca.crt
```

最低限の形式確認:

```bash
grep -q -- '-----BEGIN CERTIFICATE-----' certs/zscaler-ca.crt
grep -q -- '-----END CERTIFICATE-----' certs/zscaler-ca.crt
```

実CAは `.gitignore` 対象であり、配布ZIPにも含めない。

## 6. Configure New Relic credentials

`.env` に以下を設定する。

```dotenv
NEW_RELIC_ENABLED=true
NEW_RELIC_LICENSE_KEY=<APM license key>
NEW_RELIC_API_KEY=<change tracking/API key>
NEW_RELIC_ACCOUNT_ID=<account id>
NEW_RELIC_MCP_USER_KEY=<New Relic user key used by the bundled MCP server>
NEW_RELIC_REGION=US
NEW_RELIC_ALLOWED_ACCOUNT_IDS=<account id>
```

必要な場合のみ `NEW_RELIC_GRAPHQL_URL` を設定する。通常は空欄のまま `NEW_RELIC_REGION` を利用する。

Proxy/Zscaler用の既定値:

```dotenv
NEW_RELIC_PROXY_HOST=${HTTPS_PROXY}
NEW_RELIC_CA_BUNDLE_PATH=/etc/ssl/certs/ca-certificates.crt
```

Demo Commerce各PythonサービスのNew Relic AgentもProxy経由で外部送信する。

## 7. Configure Splunk credentials

`.env` に以下を設定する。

```dotenv
SPLUNK_PASSWORD=<Splunk admin password>
SPLUNK_HEC_ENABLED=true
SPLUNK_HEC_TOKEN=<HEC token>
SPLUNK_SEARCH_USERNAME=ai_search
SPLUNK_SEARCH_PASSWORD=<dedicated search-only password>
SPLUNK_SEARCH_VERIFY_SSL=false
```

固定データ契約:

```text
index=poc_observability
sourcetype=poc:app:json
role=poc_ai_search
user=ai_search
effective capability=search only
search time limit=7200 seconds
```

## 8. Configure LLM provider

3 Providerから1つを選択する。自動failoverは行わない。

### Ollama

ホスト上のOllamaを利用する場合:

```dotenv
LLM_PROVIDER=ollama
# Host/manual tests
OLLAMA_BASE_URL=http://localhost:11434
# Console API container in compose.proxy.yml
OLLAMA_CONTAINER_BASE_URL=http://host.docker.internal:11434
OLLAMA_MODEL=gpt-oss:20b
OLLAMA_REASONING_EFFORT=medium
OLLAMA_TIMEOUT_SECONDS=180
RUN_OLLAMA_LIVE_TESTS=1
```

### Azure OpenAI

```dotenv
LLM_PROVIDER=azure_openai
AZURE_OPENAI_API_KEY=<key>
AZURE_OPENAI_BASE_URL=https://<resource>.openai.azure.com/openai/v1
AZURE_OPENAI_MODEL=<deployment name>
AZURE_OPENAI_MAX_OUTPUT_TOKENS=2500
AZURE_OPENAI_TIMEOUT_SECONDS=60
RUN_AZURE_OPENAI_LIVE_TESTS=1
```

### OpenAI

```dotenv
LLM_PROVIDER=openai
OPENAI_API_KEY=<key>
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=<model>
OPENAI_MAX_OUTPUT_TOKENS=2500
```

## 9. Run preflight

```bash
make proxy-preflight
```

期待:

```text
preflight: PASS
```

スクリプトは値を表示せず、変数名とPASS/FAILだけを出力する。完全なPoC検証に必要なため、`SPLUNK_HEC_ENABLED=true` と `NEW_RELIC_ENABLED=true` も必須として検査する。

## 10. Build and start the stack

```bash
make proxy-up
```

内部的には以下のComposeを利用する。通常環境向けの既存 `services/*/Dockerfile` と `load_generator/Dockerfile` は変更しておらず、Proxy環境では `compose.proxy.yml` が `docker/python-service-proxy.Dockerfile` へ差し替える。したがって、実CAが未配置でも通常の `docker compose up --build` には影響しない。


```bash
docker compose -f docker-compose.yml -f compose.proxy.yml --profile splunk up -d --build
```

主なホスト公開ポート:

```text
API Gateway         8085
Scenario Controller 8091
Splunk Web          18000
Splunk HEC          8088
Splunk Management   8089
New Relic MCP       8000
Console API         8095
Console UI          5173
```

## 11. Run scripts/bootstrap_splunk_readonly.sh

Splunkがhealthyになった後に実行する。

```bash
./scripts/bootstrap_splunk_readonly.sh
```

このスクリプトは `poc_ai_search` role と `ai_search` user を作成/更新し、Read Only制約を適用する。

## 12. Verify poc_ai_search and ai_search

Splunk Web (`http://<VM>:18000`) で role/user の存在を確認してよいが、最終判定は次節の実効Capability確認を使う。

```text
Role: poc_ai_search
User: ai_search
Allowed index: poc_observability
Default index: poc_observability
```

## 13. Verify Splunk effective capability is search only

Splunk Enterprise 10.4.3 では新規roleに既定Capabilityが付くことがあるため、`/opt/splunk/etc/system/local/authorize.conf` で明示的に無効化する。

```ini
[role_poc_ai_search]
edit_own_objects = disabled
list_all_objects = disabled
run_collect = disabled
run_mcollect = disabled
schedule_rtsearch = disabled
search = enabled
srchIndexesAllowed = poc_observability
srchIndexesDefault = poc_observability
srchTimeWin = 7200
```

`bootstrap_splunk_readonly.sh` は以下も検査する。

- effective capabilityが `search` のみ。
- `index=_internal` を読み取れない。
- `index=poc_observability` を検索できる。

## 14. Verify Demo Commerce health

```bash
curl -fsS http://localhost:8085/health
curl -fsS http://localhost:8091/health
```

Compose状態:

```bash
make proxy-ps
```

## 15. Verify New Relic APM entities

Demo Commerceで注文を1件発生させる。

```bash
curl -fsS -X POST http://localhost:8085/orders \
  -H 'Content-Type: application/json' \
  -H 'X-Request-ID: proxy-zscaler-apm-check-001' \
  -d '{"product_id":"SKU-001","quantity":1,"amount":1200}'
```

New Relic APMで次のEntityが到着することを確認する。

```text
poc-api-gateway
poc-order-service
poc-inventory-service
poc-payment-service
poc-payment-mock
poc-scenario-controller
```

到着しない場合は `NEW_RELIC_LICENSE_KEY`、Proxy、CA、`NEW_RELIC_PROXY_HOST`、`NEW_RELIC_CA_BUNDLE_PATH` を確認する。秘密値自体はログへ出さない。

## 16. Verify New Relic MCP / tools/list

MCPはstateful Streamable HTTP `/mcp` を利用する。単純GETが400になること自体はMCP session未確立時の既知挙動であり、`tools/list` Integration Testで契約を確認する。

```bash
set -a
. ./.env
set +a
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp

docker run --rm --network host \
  -v "$PWD:/workspace" -w /workspace \
  -v "$PWD/certs/zscaler-ca.crt:/usr/local/share/ca-certificates/zscaler-ca.crt:ro" \
  -e HTTP_PROXY -e HTTPS_PROXY -e NO_PROXY \
  -e NEW_RELIC_MCP_URL \
  python:3.11-slim sh -lc '
    update-ca-certificates >/dev/null &&
    python -m pip install -q -e ".[dev]" &&
    python -m pytest tests/integration/test_newrelic_mcp_transport_integration.py -v
  '
```

期待: `tools/list` が成功し、既存のNew Relic MCP tool contractが維持される。

## 17. Verify Console API and UI

```bash
curl -fsS http://localhost:8095/openapi.json >/dev/null && echo 'Console API: PASS'
curl -fsS http://localhost:5173/ >/dev/null && echo 'Console UI: PASS'
```

ブラウザ:

```text
http://<VM IP or DNS>:5173
```

## 18. Run provider-only LLM test

共通準備:

```bash
set -a
. ./.env
set +a
```

Azure OpenAI:

```bash
docker run --rm --network host \
  -v "$PWD:/workspace" -w /workspace \
  -v "$PWD/certs/zscaler-ca.crt:/usr/local/share/ca-certificates/zscaler-ca.crt:ro" \
  -e HTTP_PROXY -e HTTPS_PROXY -e NO_PROXY \
  -e LLM_PROVIDER -e RUN_AZURE_OPENAI_LIVE_TESTS \
  -e AZURE_OPENAI_API_KEY -e AZURE_OPENAI_BASE_URL -e AZURE_OPENAI_MODEL \
  -e AZURE_OPENAI_MAX_OUTPUT_TOKENS -e AZURE_OPENAI_TIMEOUT_SECONDS \
  python:3.11-slim sh -lc '
    update-ca-certificates >/dev/null &&
    python -m pip install -q -e ".[dev]" &&
    python -m pytest tests/integration/test_phase4_live_azure_openai_analysis.py -v
  '
```

Ollamaの場合は `RUN_OLLAMA_LIVE_TESTS=1` と `tests/integration/test_phase4_live_ollama_analysis.py`、OpenAIの場合は `tests/integration/test_phase4_live_openai_analysis.py` を利用する。

## 19. Run Phase 4 complete live E2E

```bash
set -a
. ./.env
set +a
export SPLUNK_SEARCH_URL=https://localhost:8089
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp

docker run --rm --network host \
  -v "$PWD:/workspace" -w /workspace \
  -v "$PWD/certs/zscaler-ca.crt:/usr/local/share/ca-certificates/zscaler-ca.crt:ro" \
  -e HTTP_PROXY -e HTTPS_PROXY -e NO_PROXY \
  -e SPLUNK_SEARCH_URL -e SPLUNK_SEARCH_USERNAME -e SPLUNK_SEARCH_PASSWORD -e SPLUNK_SEARCH_VERIFY_SSL \
  -e NEW_RELIC_MCP_URL -e NEW_RELIC_ACCOUNT_ID \
  -e LLM_PROVIDER \
  -e OLLAMA_BASE_URL -e OLLAMA_MODEL -e OLLAMA_REASONING_EFFORT -e OLLAMA_TIMEOUT_SECONDS -e RUN_OLLAMA_LIVE_TESTS \
  -e AZURE_OPENAI_API_KEY -e AZURE_OPENAI_BASE_URL -e AZURE_OPENAI_MODEL -e AZURE_OPENAI_MAX_OUTPUT_TOKENS -e AZURE_OPENAI_TIMEOUT_SECONDS -e RUN_AZURE_OPENAI_LIVE_TESTS \
  -e OPENAI_API_KEY -e OPENAI_BASE_URL -e OPENAI_MODEL -e OPENAI_MAX_OUTPUT_TOKENS \
  python:3.11-slim sh -lc '
    update-ca-certificates >/dev/null &&
    python -m pip install -q -e ".[dev]" &&
    python -m pytest tests/integration/test_phase4_live_end_to_end.py -v
  '
```

期待: 実Splunk -> 実New Relic MCP -> EvidenceBundle -> 選択LLM -> `IncidentAnalysis` が参照検証までPASSする。

## 20. Run Phase 5 live Console E2E

```bash
export RUN_PHASE5_LIVE_TESTS=1
```

Phase 4 と同様の `python:3.11-slim` 実行環境へ `RUN_PHASE5_LIVE_TESTS` と `API_GATEWAY_URL=http://localhost:8085` を追加し、次を実行する。

```bash
python -m pytest tests/integration/test_phase5_live_console.py -v
```

期待: AG-UI progress event と A2UI result event が最後まで成立する。

## 21. Browser verification

`http://<VM IP or DNS>:5173` を開き、既知の `request.id` と2時間以内の期間を指定する。

5段階すべてが終了することを確認する。

```text
相関
Splunkの調査
New Relicの調査
証拠の相関
LLM分析
```

終了時刻は選択した「分」の末尾まで含むため、例として `09:25` は `09:25:59.999` まで検索対象となる。

## 22. Stop/restart procedures

停止:

```bash
make proxy-down
```

起動:

```bash
make proxy-up
```

設定値を変更した場合、単純restartでは新しい環境変数が入らないため再作成する。

```bash
docker compose -f docker-compose.yml -f compose.proxy.yml --profile splunk up -d --force-recreate <service>
```

## 23. Troubleshooting

### `CERTIFICATE_VERIFY_FAILED`

- `certs/zscaler-ca.crt` が正しいPEM/CRTか確認。
- `make proxy-preflight` を再実行。
- `./scripts/verify_proxy_ca.sh` を実行。
- Console API / MCP / Demo Commerce内の `/etc/ssl/certs/ca-certificates.crt` が存在するか確認。

### 内部通信がProxyへ流れる

- `NO_PROXY` にRFC1918範囲とCompose service名が残っているか確認。
- 特に `splunk`, `postgres`, `newrelic-mcp`, `console-api`, `host.docker.internal` を確認。

### Azure/OpenAIだけ失敗する

- Console APIコンテナにProxy環境が渡っているかを**値を表示せず**確認する。

```bash
docker compose -f docker-compose.yml -f compose.proxy.yml --profile splunk exec -T console-api \
  sh -lc 'test -n "$HTTPS_PROXY" && echo HTTPS_PROXY=SET; test -s "$SSL_CERT_FILE" && echo SSL_CERT_FILE=OK'
```

### New Relic APMだけ到着しない

- `NEW_RELIC_PROXY_HOST` と `NEW_RELIC_CA_BUNDLE_PATH` の設定名を確認。
- License Keyそのものは表示しない。

### MCP `/mcp` GET が400

Streamable HTTPはsession確立を必要とするため、単純GETの400だけでは異常と判断しない。`test_newrelic_mcp_transport_integration.py` の結果を正とする。

## 24. Security notes

- `.env`、Zscaler CA実体、API Key、License Key、HEC token、Proxy credentialをZIPへ入れない。
- Splunk検索用にはadminを使わず `ai_search` を使用する。
- `ai_search` は `poc_observability` のみ、実効Capability `search` のみ、検索時間最大7200秒。
- アプリ側Splunk guardも index固定、最大2時間、最大200行、危険SPL拒否を維持する。
- New Relic / Splunk / LLMのEvidenceを根拠化してから分析する Evidence-first 方針を維持する。
- Providerの自動failoverは行わない。
- UIはRead Onlyで、推奨対処を表示しても実行ボタンは持たない。
