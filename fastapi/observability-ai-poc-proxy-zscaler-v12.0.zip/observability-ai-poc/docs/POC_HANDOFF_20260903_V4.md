# New Relic + Splunk + A2UI/AG-UI PoC 引継ぎメモ v4

更新日: 2026-09-03

## 1. このPoCの目的

New Relic（APM）とSplunk（ログ）をLLMで横断分析し、最終的にA2UI / AG-UIを使った統一インターフェース上で、障害の可視化・原因候補・根拠（Evidence）・推奨確認事項・推奨対処法を提示する「AI Troubleshooting Console」のPoCを作る。

基本方針:

- New Relicは既存の製品版アカウントを使用
- New RelicはMCP Serverを使用
- SplunkはSplunk Enterprise Trialを使用
- New Relic / SplunkはAgentからRead Only
- AIによる本番変更は行わず Observe → Investigate → Correlate → Recommend まで
- New RelicとSplunkの相関キーは `request.id` / `trace.id`
- LLMに自由推測させる前にEvidenceを正規化する Evidence-first 方針

---

## 2. VM / 作業ディレクトリ

```bash
cd ~/20260903/observability-ai-poc
```

ホストPython:

```text
Python 3.10.12
```

PoC要件:

```text
Python >=3.11,<3.14
```

テストは `python:3.11-slim` コンテナを使用する。

---

## 3. 現在の全体構成

```text
User
 |
 v
AI Troubleshooting Console          ← Phase 5予定
 |
AG-UI / A2UI                         ← Phase 5予定
 |
 v
Investigation Orchestrator           ← Phase 4実装済み
 |                     \
 |                      \
Splunk Read Only Tool          New Relic MCP Gateway
 |                              |
 |                              v
 |                        Streamable HTTP /mcp
 |                              |
 v                              v
Structured Logs              New Relic MCP Server
 |                              |
 +---------- Evidence -----------+
               |
               v
         EvidenceBundle
               |
         IncidentAnalyzer contract
               |
               v
         IncidentAnalysis
```

重要: `IncidentAnalyzer` のProtocol / 出力契約 /参照検証は維持したまま、**v10でOllama（既定）/ Azure OpenAI / OpenAIの3 Providerを切替可能**にした。通常のPoC検証は `LLM_PROVIDER=ollama` + `gpt-oss:20b` を使用し、API creditに依存しない。VMではOllama provider-only live testと、実Splunk＋実New Relic＋実Ollamaの完全E2Eが最終確認待ち。これらがPASSしてからPhase 5へ進む。

---

## 4. Demo Commerce / ポート

サービス:

| Service | Container Port |
|---|---:|
| api-gateway | 8080 |
| order-service | 8081 |
| inventory-service | 8082 |
| payment-service | 8083 |
| payment-mock | 8084 |
| scenario-controller | 8090 |
| PostgreSQL | 5432 |
| Splunk Enterprise | 8000 / 8088 / 8089 |

ホスト公開:

```text
API Gateway             localhost:8085 -> 8080
Scenario Controller     localhost:8091 -> 8090
Splunk Web              localhost:18000 -> 8000
Splunk HEC              localhost:8088 -> 8088
Splunk Management REST  localhost:8089 -> 8089
New Relic MCP            localhost:8000 -> /mcp
```

New Relic MCPがホスト8000を使用するためSplunk Webは18000。

---

## 5. 障害シナリオ

```text
NORMAL
UC01_DB_SLOW
UC02_PAYMENT_FAILURE
UC03_APP_EXCEPTION
UC04_HIGH_LOAD
UC05_BAD_DEPLOYMENT
```

UC05はinventory-service version `1.1.0` の意図的な内部処理遅延。

---

## 6. Phase 1〜2 完了状態

### Phase 1

- Demo Commerce
- Docker Compose
- 5障害シナリオ
- Scenario Controller
- PostgreSQL
- Load Generator / CapacityGate
- Integration Test

完了。

### Phase 2

- New Relic Python Agent
- Distributed Tracing
- `request.id` 相関
- `trace.id` 相関
- Change Tracking
- New Relic MCPを使ったAPM分析

完了。

New Relic APM Entity:

```text
poc-api-gateway
poc-order-service
poc-inventory-service
poc-payment-service
poc-payment-mock
poc-scenario-controller
```

New Relicで実際に使用確認済みの代表MCP Tool:

```text
analyze_golden_metrics
analyze_transactions
analyze_deployment_impact
list_change_events
execute_nrql_query
```

ただし `list_change_events` は2026-09-03実機でNerdGraph schema不整合を確認。詳細は後述。

---

## 7. Phase 3 Splunk 完了状態

### Splunk

```text
index      = poc_observability
sourcetype = poc:app:json
```

代表event_type:

```text
application.request
application.response
db.query
dependency.call
capacity.snapshot
exception
deployment
scenario.change
```

共通属性:

```text
timestamp
event_type
service.name
service.version
deployment.environment
request.id
scenario.id
trace.id
span.id
entity.guid
entity.name
```

`request.id` / `trace.id` のNew Relic ⇔ Splunk相関は実機で成立済み。

---

## 8. Splunk Read Only RBAC

Agent用:

```text
Role: poc_ai_search
User: ai_search
```

検索可能index:

```text
poc_observability のみ
```

検索時間:

```text
最大2時間
```

Splunk 10.4.3では新規Roleへ `/opt/splunk/etc/system/default/authorize.conf` から以下がデフォルト付与された:

```text
edit_own_objects
list_all_objects
run_collect
run_mcollect
schedule_rtsearch
```

これらを `/opt/splunk/etc/system/local/authorize.conf` の `[role_poc_ai_search]` で明示的に `disabled` にして打ち消した。

最終的な `ai_search` 実効Capability:

```text
search
```

のみ。

実機確認:

```text
index=_internal        → 0件
index=poc_observability → 取得可能
```

従ってSplunk側RBACでもRead Onlyが成立。

---

## 9. Splunk Read Only Search Tool

主要ファイル:

```text
agent/splunk/models.py
agent/splunk/guard.py
agent/splunk/client.py
```

制約:

```text
index=poc_observability 固定
最大検索期間 2時間
最大結果 200件
```

危険SPLを拒否。少なくとも以下をブロック:

```text
delete
collect
outputlookup
sendalert
sendemail
outputcsv
tscollect
rest
script
runshellscript
savedsearch
loadjob
map
mcollect / meventcollect 系
macro (`...`) 経由の迂回
```

### Splunk REST resultsの既知仕様

通常のSearch Job `/results` では `_raw` JSONに `trace.id` が存在していても、トップレベルフィールドとして返らないケースを実機確認。

そのため `SplunkSearchClient` は:

```text
Splunk REST result
+
_raw JSON
↓
不足しているトップレベル属性だけ補完
```

する。Splunkが明示的に返したフィールドは上書きしない。

実機Integration Test:

```text
request.id → trace.id → 同一trace検索
PASSED
```

---

## 10. Phase 4 Evidence-first Core

主要ファイル:

```text
agent/evidence/models.py
agent/evidence/correlation.py
agent/evidence/splunk_collector.py
agent/evidence/newrelic_gateway.py
agent/evidence/newrelic_transport.py
agent/evidence/newrelic_collector.py
agent/evidence/correlator.py
agent/analysis/models.py
agent/analysis/prompt.py
agent/analysis/analyzer.py
agent/orchestrator.py
```

設計書:

```text
docs/superpowers/specs/2026-09-03-phase4-evidence-correlation-design.md
```

実装計画:

```text
docs/superpowers/plans/2026-09-03-phase4-evidence-correlation.md
```

### Evidenceモデル

```text
EvidenceItem
EvidenceGap
EvidenceContradiction
QueryDisclosure
CorrelationContext
EvidenceBundle
```

### IncidentAnalysis契約

```text
Incident Summary
Impact
Likely Cause
Confidence
Evidence IDs
Alternative Hypotheses
Recommended Checks
Recommended Actions
New Relic Evidence IDs
Splunk Evidence IDs
Contradiction IDs
Query Disclosure IDs
```

必須ルール:

```text
Evidenceがない原因を断定しない
Correlation != Causation
Spanがない場合、親Transaction durationだけで内部処理原因を断定しない
New Relic / Splunk矛盾はEvidenceContradictionとして残す
存在しないEvidence ID / Query IDをLLMが引用したら拒否
Recommended Actionsは提案のみ
```

---

## 11. New Relic MCP 実Transport

実機:

```text
Container: newrelic-mcp-server-newrelic-mcp-1
Process: /usr/local/bin/python3.12 /usr/local/bin/newrelic-mcp
Server: uvicorn
Endpoint: http://localhost:8000/mcp
```

確認結果:

```text
GET /          → 404
GET /mcp       → 400 Missing session ID + mcp-session-id
GET /sse       → 404
GET /messages  → 404
```

Transportはstateful Streamable HTTP。

Python側:

```text
mcp>=1.12,<2
mcp.client.streamable_http.streamable_http_client
```

`tools/list` 実機Integration Test PASSED。

MCP Server情報:

```text
name    = New Relic MCP
version = 0.1.0
```

---

## 12. 実New Relic MCP Tool schema

### execute_nrql_query

```text
execute_nrql_query(
  nrql_query: str,
  account_id: int
)
```

必須:

```text
nrql_query
account_id
```

PoC account_id:

```text
8292460
```

コードへ固定せず:

```bash
NEW_RELIC_ACCOUNT_ID=8292460
```

で渡す。

### list_change_events

```text
list_change_events(
  entity_guid: str,
  history_period_hours: int = 48
)
```

### analyze_golden_metrics

```text
entity_guid
start_time_ms
end_time_ms optional
```

### analyze_transactions

```text
entity_guid
start_time_ms
end_time_ms optional
error_transaction_limit default 5
```

### analyze_deployment_impact

```text
entity_guid
deployment_timestamp_ms
account_id
```

---

## 13. 実New Relic Transaction 相関

実 `execute_nrql_query` 戻り値:

```json
{
  "ok": true,
  "account_id": 8292460,
  "nrql_query": "SELECT ... FROM Transaction ...",
  "results": [
    {
      "appName": "poc-api-gateway",
      "duration": 0.123,
      "error": null,
      "name": "WebTransaction/...",
      "timestamp": 1788416775502,
      "traceId": "..."
    }
  ]
}
```

`timestamp` はepoch millisecondsなのでUTC datetimeへ正規化する。

実Cross-source Integration Test:

```text
新しい注文
→ 実Splunk request.id検索
→ trace.id解決
→ 実New Relic MCP execute_nrql_query
→ 同一trace Transaction取得
PASSED (1 passed in 7.23s)
```

---

## 14. New Relic Change Tracking の重要な既知事項

inventory-service Entity GUID:

```text
ODI5MjQ2MHxBUE18QVBQTElDQVRJT058MTEwMTMyNDAyOQ
```

### 14.1 list_change_events 専用Toolの不具合

実機で:

```json
{
  "ok": false,
  "error": "NewRelicAPIError",
  "message": "NerdGraph returned errors"
}
```

GraphQL error:

```text
Fragment spread has no type overlap with parent
ApmApplicationEntity vs ApmApplicationEntityOutline 等
```

つまり:

```text
MCP Transport       正常
認証                正常
entity_guid         正常
list_change_events内部NerdGraph query  不整合
```

### 14.2 Read Only NRQL fallback

`execute_nrql_query` のRead OnlyガードはNRQL文字列が `SELECT` で始まることを要求する。

NG:

```text
FROM ChangeTrackingEvent, Deployment
SELECT ...
```

OK:

```text
SELECT ...
FROM ChangeTrackingEvent, Deployment
```

実機成功したChange Tracking検索:

```text
SELECT ...
FROM ChangeTrackingEvent, Deployment
WHERE ...
SINCE 48 hours ago
```

実結果:

```text
eventType()      = ChangeTrackingEvent
category         = Deployment
categoryType     = DEPLOYMENT__BASIC
entity.name      = poc-inventory-service
entity.guid      = ODI5MjQ2MHxBUE18QVBQTElDQVRJT058MTEwMTMyNDAyOQ
version          = 1.1.0
serviceVersion   = 1.1.0
groupId          = uc05-demo-deploy-001
changeTrackingId = 8ee34a1b-d460-4bab-b3a2-48b38c6a6555
gitSha           = local-poc
type             = Basic
```

v8では:

```text
list_change_events
  ↓
成功 → eventsをEvidence化
  ↓失敗 / ok=false / unsupported payload
execute_nrql_query
  ↓
SELECT-first ChangeTrackingEvent + Deployment
  ↓
Deployment Evidence化
```

とした。

FallbackもNew Relic MCP経由なので、直接NerdGraph clientは追加していない。

---

## 15. v8 テスト状態

最新コードローカル検証:

```text
Unit Tests: 137 passed
compileall: OK
```

live integration testsはローカル環境では資格情報がないためskip。

VMで既に実機確認済み:

```text
Phase 3 Splunk request.id→trace.id Integration       PASS
Phase 4 Evidence Core Integration                   PASS
New Relic MCP tools/list                            PASS
実Splunk + 実New Relic Transaction Cross-source     PASS
Change Tracking NRQL fallback 手動実機確認          PASS
```

v8で新規追加した自動テスト:

```text
tests/integration/test_phase4_live_change_tracking.py
```

これはまだv8配布後にVMで最終実行する。

---

## 16. v8 VM最終確認コマンド

環境変数:

```bash
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp
export NEW_RELIC_ACCOUNT_ID=8292460
export NEW_RELIC_ENTITY_GUID='ODI5MjQ2MHxBUE18QVBQTElDQVRJT058MTEwMTMyNDAyOQ'
export NEW_RELIC_ENTITY_NAME=poc-inventory-service
```

実行:

```bash
docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e NEW_RELIC_MCP_URL \
  -e NEW_RELIC_ACCOUNT_ID \
  -e NEW_RELIC_ENTITY_GUID \
  -e NEW_RELIC_ENTITY_NAME \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest \
      tests/integration/test_phase4_live_change_tracking.py \
      -v
  "
```

期待:

```text
test_live_change_tracking_falls_back_to_read_only_nrql PASSED
```

---

## 17. 現在の進捗

```text
Phase 1 Demo Commerce + 5障害                     ✅
Phase 2 New Relic Python Agent                    ✅
Phase 2 Distributed Trace / request.id            ✅
Phase 2 Change Tracking登録                       ✅
Phase 2 New Relic MCP基本分析                     ✅

Phase 3 Splunk Enterprise                         ✅
Phase 3 HEC / Structured JSON                     ✅
Phase 3 Splunk RBAC Read Only                     ✅
Phase 3 Splunk Search Tool                        ✅
Phase 3 request.id / trace.id相関                  ✅
Phase 3 Splunk ⇔ New Relic Trace相関              ✅

Phase 4 Evidence Domain / Correlator               ✅
Phase 4 Splunk Evidence Collector                  ✅
Phase 4 New Relic MCP Streamable HTTP Transport    ✅
Phase 4 実Transaction Cross-source                ✅
Phase 4 Change Tracking NRQL fallback              ✅
Phase 4 Change Tracking 自動live test              ✅ VM実機 1 passed (2026-09-03)
Phase 4 IncidentAnalyzer Protocol                  ✅
Phase 4 OpenAI Provider Adapter                    ✅ v9から継続
Phase 4 Ollama Provider Adapter                    ✅ v10追加
Phase 4 Azure OpenAI Provider Adapter              ✅ v10追加
Phase 4 Provider Factory / LLM_PROVIDER            ✅ v10追加
Phase 4 provider-only unit tests                   ✅
Phase 4 Ollama provider-only live test             ⏳ VMで最終確認待ち
Phase 4 Azure OpenAI provider-only live test       ⏳ 必要時に別環境で確認
Phase 4 Real Sources → Selected LLM full E2E       ⏳ VMで最終確認待ち

Phase 5 AG-UI / A2UI                              ❌ 未着手
Phase 6 End-to-End Demo                           ❌ 未着手
```

---

## 18. Phase 4 v10で次にやること

v10では実LLM層を3 Providerへ拡張した。

```text
InvestigationOrchestrator
        |
        v
IncidentAnalyzer Protocol
        |
        +-------------------------+-------------------------+
        |                         |                         |
        v                         v                         v
OllamaIncidentAnalyzer   AzureOpenAIIncidentAnalyzer  OpenAIIncidentAnalyzer
        |                         |                         |
        v                         v                         v
gpt-oss:20b / Ollama     Azure OpenAI Responses API   OpenAI Responses API
```

Provider選択は環境変数だけで行う。

```text
LLM_PROVIDER=ollama        # v10既定
LLM_PROVIDER=azure_openai
LLM_PROVIDER=openai
```

自動failoverは行わない。意図しない外部送信や課金を避け、障害原因を切り分けやすくするため。

### 18.1 既定構成: Ollama + gpt-oss:20b

環境変数:

```bash
export LLM_PROVIDER=ollama
export OLLAMA_BASE_URL=http://localhost:11434
export OLLAMA_MODEL=gpt-oss:20b
export OLLAMA_REASONING_EFFORT=medium
export OLLAMA_TIMEOUT_SECONDS=180
export RUN_OLLAMA_LIVE_TESTS=1
```

Ollama側では事前にモデルを取得する。

```bash
ollama pull gpt-oss:20b
ollama list
curl http://localhost:11434/api/tags
```

provider-only live test:

```bash
docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e LLM_PROVIDER \
  -e OLLAMA_BASE_URL \
  -e OLLAMA_MODEL \
  -e OLLAMA_REASONING_EFFORT \
  -e OLLAMA_TIMEOUT_SECONDS \
  -e RUN_OLLAMA_LIVE_TESTS \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase4_live_ollama_analysis.py -v
  "
```

期待:

```text
test_live_ollama_analyzer_returns_reference_safe_incident_analysis PASSED
```

Ollama Adapterはnative `POST /api/chat` を使い、`IncidentAnalysis` のJSON Schemaを `format` へ渡す。LLMのthinking/reasoning本文はEvidenceとして保存せず、最終structured outputのみを解析対象にする。

### 18.2 Azure OpenAI（別環境用）

環境変数:

```bash
export LLM_PROVIDER=azure_openai
export AZURE_OPENAI_API_KEY='<Azure OpenAI API Key>'
export AZURE_OPENAI_BASE_URL='https://<resource>.openai.azure.com/openai/v1'
export AZURE_OPENAI_MODEL='<deployment-name>'
export AZURE_OPENAI_MAX_OUTPUT_TOKENS=2500
export AZURE_OPENAI_TIMEOUT_SECONDS=60
export RUN_AZURE_OPENAI_LIVE_TESTS=1
```

provider-only live test:

```bash
docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e LLM_PROVIDER \
  -e AZURE_OPENAI_API_KEY \
  -e AZURE_OPENAI_BASE_URL \
  -e AZURE_OPENAI_MODEL \
  -e AZURE_OPENAI_MAX_OUTPUT_TOKENS \
  -e AZURE_OPENAI_TIMEOUT_SECONDS \
  -e RUN_AZURE_OPENAI_LIVE_TESTS \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase4_live_azure_openai_analysis.py -v
  "
```

Azure OpenAI Adapterはv1 Responses APIを使い、`api-key` ヘッダー、`store=false`、Strict JSON Schema、Pydantic validationを使用する。

### 18.3 OpenAI API（既存互換）

v9のOpenAI Adapterは継続して利用可能。

```bash
export LLM_PROVIDER=openai
export OPENAI_API_KEY='<OpenAI API Key>'
export OPENAI_MODEL=gpt-5.6-luna
export OPENAI_BASE_URL=https://api.openai.com/v1
export OPENAI_MAX_OUTPUT_TOKENS=2500
```

### 18.4 Phase 4完全live E2E（Ollama既定）

Ollama live testがPASSしたら、実Splunk / 実New Relic MCP / 実Ollamaを接続する。

```bash
export SPLUNK_SEARCH_URL=https://localhost:8089
export SPLUNK_SEARCH_USERNAME=ai_search
export SPLUNK_SEARCH_PASSWORD='<ai_search password>'
export SPLUNK_SEARCH_VERIFY_SSL=false
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp
export NEW_RELIC_ACCOUNT_ID=8292460

export LLM_PROVIDER=ollama
export OLLAMA_BASE_URL=http://localhost:11434
export OLLAMA_MODEL=gpt-oss:20b
export OLLAMA_REASONING_EFFORT=medium
export OLLAMA_TIMEOUT_SECONDS=180
export RUN_OLLAMA_LIVE_TESTS=1
```

実行:

```bash
docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e SPLUNK_SEARCH_URL \
  -e SPLUNK_SEARCH_USERNAME \
  -e SPLUNK_SEARCH_PASSWORD \
  -e SPLUNK_SEARCH_VERIFY_SSL \
  -e NEW_RELIC_MCP_URL \
  -e NEW_RELIC_ACCOUNT_ID \
  -e LLM_PROVIDER \
  -e OLLAMA_BASE_URL \
  -e OLLAMA_MODEL \
  -e OLLAMA_REASONING_EFFORT \
  -e OLLAMA_TIMEOUT_SECONDS \
  -e RUN_OLLAMA_LIVE_TESTS \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase4_live_end_to_end.py -v
  "
```

期待:

```text
test_live_phase4_real_sources_to_real_llm_incident_analysis PASSED
```

データフロー:

```text
Demo Commerce request
  ↓
Splunk request.id → trace.id
  ↓
Real Splunk Evidence
  +
Real New Relic MCP Evidence
  ↓
EvidenceBundle
  ↓
create_incident_analyzer_from_env()
  ↓
Selected Provider (default: Ollama / gpt-oss:20b)
  ↓
IncidentAnalysis
  ↓
Pydantic + Evidence/Query/Contradiction reference validation
```

これがPASSしたらPhase 4完了としてPhase 5へ進む。

---
## 19. Phase 5 方針

画面全体をA2UIで生成しない。

固定UI:

```text
Service
Environment
Time Range
質問欄
```

動的結果:

```text
HealthSummary
TimelineChart
EvidenceCard
TraceCard
LogTable
HypothesisCard
RecommendationCard
QueryDisclosure
```

AG-UI:

```text
調査開始
New Relic調査中
Splunk調査中
相関分析中
LLM分析中
原因候補表示
```

---

## 20. セキュリティ

秘密情報は引継ぎに書かない。

`.env` / shell環境のみに保持:

```text
NEW_RELIC_LICENSE_KEY
NEW_RELIC_API_KEY
NEW_RELIC_ENTITY_GUID
SPLUNK_PASSWORD
SPLUNK_HEC_TOKEN
SPLUNK_SEARCH_PASSWORD
AZURE_OPENAI_API_KEY
OPENAI_API_KEY
```

`NEW_RELIC_ACCOUNT_ID` は秘密ではないがコード固定せず環境変数化。

ローカルOllamaを既定にすることで、通常のPoC検証ではEvidenceBundleを外部LLMへ送らずに済む。Azure/OpenAIを選んだ場合のみ外部Providerへ送信する。Providerの自動failoverは禁止。

過去に `docker compose config` でNew Relic License Keyが表示されたことがあるため、未対応ならキーのローテーション推奨。

---

## 21. 新チャットで最初に貼る依頼文

```text
添付の「New Relic + Splunk + A2UI/AG-UI PoC 引継ぎメモ v4」と最新v10 Zipの続きをお願いします。

Phase 1〜3は完了済みです。
Phase 4はEvidence-first Core、Splunk実相関、New Relic MCP Streamable HTTP実接続、実Transaction Cross-source、Change Tracking NRQL fallbackまで実装済みです。
Change Trackingの自動live testは2026-09-03にVM実機で1 passedを確認済みです。

v10では実LLM層をmulti-provider化しました。
- LLM_PROVIDER=ollama（既定）: Ollama native /api/chat + gpt-oss:20b
- LLM_PROVIDER=azure_openai: Azure OpenAI v1 Responses API
- LLM_PROVIDER=openai: 既存OpenAI Responses API

IncidentAnalyzer Protocol、IncidentAnalysis契約、Evidence/Query/Contradiction reference validationは維持しています。Provider自動failoverはありません。

最初にVMでOllamaを起動し、gpt-oss:20bをpullして、tests/integration/test_phase4_live_ollama_analysis.py を実行してください。
これがPASSしたら LLM_PROVIDER=ollama のまま tests/integration/test_phase4_live_end_to_end.py を実行し、実Splunk → 実New Relic MCP → EvidenceBundle → gpt-oss:20b → IncidentAnalysis を確認してください。

full E2EがPASSしたらPhase 4完了としてPhase 5 AG-UI / A2UIへ進んでください。
Azure OpenAIは別環境用として必要時にprovider-only live testを実施してください。

方針:
- New Relic / SplunkはRead Only
- Evidenceがない原因を断定しない
- Correlation != Causation
- Spanがない場合Transaction durationだけで内部原因を断定しない
- 矛盾はEvidenceとして残す
- Recommended Actionsは提案のみ
- LLM Providerの自動failoverはしない
- API key等の秘密情報は.env/shell環境のみ
- TDDで進める
```

---

## 21.5 v10 Multi-provider LLM 実装メモ

追加/変更主要ファイル:

```text
agent/analysis/schema.py
agent/analysis/ollama_adapter.py
agent/analysis/azure_openai_adapter.py
agent/analysis/openai_adapter.py
agent/analysis/factory.py
tests/unit/test_ollama_incident_analyzer.py
tests/unit/test_azure_openai_incident_analyzer.py
tests/unit/test_incident_analyzer_factory.py
tests/integration/test_phase4_live_ollama_analysis.py
tests/integration/test_phase4_live_azure_openai_analysis.py
tests/integration/test_phase4_live_end_to_end.py
.env.example
README.md
docs/superpowers/specs/2026-09-03-phase4-multi-provider-llm-design.md
docs/superpowers/plans/2026-09-03-phase4-multi-provider-llm.md
```

重要な実装境界:

```text
IncidentAnalyzer Protocol      変更なし
IncidentAnalysis model         変更なし
ANALYSIS_CONTRACT              変更なし
validate_analysis_references   変更なし
```

共有Strict Schemaは `agent/analysis/schema.py` で生成する。3 Providerの出力はすべて最終的に `IncidentAnalysis` としてPydantic検証され、その後Orchestrator境界でEvidence/Query/Contradiction参照検証を受ける。

Ollama Adapterは `message.thinking` を保存・Evidence化しない。解析根拠として扱うのはEvidenceBundleと最終structured outputのみ。

ローカル最終検証（v10成果物作成前）:

```text
unit tests: 177 passed
payment flow integration fixture test: 1 passed
compileall: OK
provider-only live tests: 3 skipped（資格情報/明示liveフラグなしのため期待どおり）
full pytest: 178 passed / 10 skipped / 6 failed
```

full pytestの6 failedは、現在の作業コンテナでDemo Commerce / Scenario Controllerを起動できないための `Connection refused` のみ。`test_payment_flow.py` で発見したv9既存のFake clientシグネチャ不整合（`request_id` / `scenario_id` 未対応）はv10でテストfixtureのみ最小修正し、単体で1 passedを確認した。

現在の作業コンテナにはDocker CLIがないため、Demo Commerceを必要とするintegrationとNew Relic MCPを含むfull live E2EはVMで実行する。

---

## 22. 最新成果物

最新デプロイ用Zip:

```text
observability-ai-poc-phase4-multi-provider-v10.zip
```

最新引継ぎ:

```text
newrelic_splunk_a2ui_agui_poc_handoff_20260903_v4.md
```
