# New Relic + Splunk + A2UI/AG-UI PoC 引継ぎメモ v3

更新日: 2026-09-03

## 1. このPoCの目的

New Relic（APM）とSplunk（ログ）をLLMで横断分析し、最終的にA2UI / AG-UIを使った統一インターフェース上で、障害の可視化・原因候補・根拠（Evidence）・推奨確認事項・推奨対処法を提示する「AI Troubleshooting Console」のPoCを作る。

基本方針:

- New Relicは既存の製品版アカウントを使用
- New RelicはMCP Serverを使用
- SplunkはSplunk Enterprise Trialを使用
- New Relic / SplunkはAgentからRead Only
- AIによる本番変更は行わず Observe → Investigate → Correlate → Recommend まで
- New RelicとSplunkの相関キーは `request.id` / `trace.id`
- LLMに自由推測させる前にEvidenceを正規化する Evidence-first 方針

---

## 2. VM / 作業ディレクトリ

```bash
cd ~/20260903/observability-ai-poc
```

ホストPython:

```text
Python 3.10.12
```

PoC要件:

```text
Python >=3.11,<3.14
```

テストは `python:3.11-slim` コンテナを使用する。

---

## 3. 現在の全体構成

```text
User
 |
 v
AI Troubleshooting Console          ← Phase 5予定
 |
AG-UI / A2UI                         ← Phase 5予定
 |
 v
Investigation Orchestrator           ← Phase 4実装済み
 |                     \
 |                      \
Splunk Read Only Tool          New Relic MCP Gateway
 |                              |
 |                              v
 |                        Streamable HTTP /mcp
 |                              |
 v                              v
Structured Logs              New Relic MCP Server
 |                              |
 +---------- Evidence -----------+
               |
               v
         EvidenceBundle
               |
         IncidentAnalyzer contract
               |
               v
         IncidentAnalysis
```

重要: `IncidentAnalyzer` のProtocol / 出力契約 /参照検証に加え、**OpenAI Responses APIを使う実LLM Provider Adapterをv9でTDD実装済み**。ただしOpenAI API Keyが必要なlive testと、実Splunk＋実New Relic＋実OpenAIの完全E2EはVMで最終確認待ち。これらがPASSしてからPhase 5へ進む。

---

## 4. Demo Commerce / ポート

サービス:

| Service | Container Port |
|---|---:|
| api-gateway | 8080 |
| order-service | 8081 |
| inventory-service | 8082 |
| payment-service | 8083 |
| payment-mock | 8084 |
| scenario-controller | 8090 |
| PostgreSQL | 5432 |
| Splunk Enterprise | 8000 / 8088 / 8089 |

ホスト公開:

```text
API Gateway             localhost:8085 -> 8080
Scenario Controller     localhost:8091 -> 8090
Splunk Web              localhost:18000 -> 8000
Splunk HEC              localhost:8088 -> 8088
Splunk Management REST  localhost:8089 -> 8089
New Relic MCP            localhost:8000 -> /mcp
```

New Relic MCPがホスト8000を使用するためSplunk Webは18000。

---

## 5. 障害シナリオ

```text
NORMAL
UC01_DB_SLOW
UC02_PAYMENT_FAILURE
UC03_APP_EXCEPTION
UC04_HIGH_LOAD
UC05_BAD_DEPLOYMENT
```

UC05はinventory-service version `1.1.0` の意図的な内部処理遅延。

---

## 6. Phase 1〜2 完了状態

### Phase 1

- Demo Commerce
- Docker Compose
- 5障害シナリオ
- Scenario Controller
- PostgreSQL
- Load Generator / CapacityGate
- Integration Test

完了。

### Phase 2

- New Relic Python Agent
- Distributed Tracing
- `request.id` 相関
- `trace.id` 相関
- Change Tracking
- New Relic MCPを使ったAPM分析

完了。

New Relic APM Entity:

```text
poc-api-gateway
poc-order-service
poc-inventory-service
poc-payment-service
poc-payment-mock
poc-scenario-controller
```

New Relicで実際に使用確認済みの代表MCP Tool:

```text
analyze_golden_metrics
analyze_transactions
analyze_deployment_impact
list_change_events
execute_nrql_query
```

ただし `list_change_events` は2026-09-03実機でNerdGraph schema不整合を確認。詳細は後述。

---

## 7. Phase 3 Splunk 完了状態

### Splunk

```text
index      = poc_observability
sourcetype = poc:app:json
```

代表event_type:

```text
application.request
application.response
db.query
dependency.call
capacity.snapshot
exception
deployment
scenario.change
```

共通属性:

```text
timestamp
event_type
service.name
service.version
deployment.environment
request.id
scenario.id
trace.id
span.id
entity.guid
entity.name
```

`request.id` / `trace.id` のNew Relic ⇔ Splunk相関は実機で成立済み。

---

## 8. Splunk Read Only RBAC

Agent用:

```text
Role: poc_ai_search
User: ai_search
```

検索可能index:

```text
poc_observability のみ
```

検索時間:

```text
最大2時間
```

Splunk 10.4.3では新規Roleへ `/opt/splunk/etc/system/default/authorize.conf` から以下がデフォルト付与された:

```text
edit_own_objects
list_all_objects
run_collect
run_mcollect
schedule_rtsearch
```

これらを `/opt/splunk/etc/system/local/authorize.conf` の `[role_poc_ai_search]` で明示的に `disabled` にして打ち消した。

最終的な `ai_search` 実効Capability:

```text
search
```

のみ。

実機確認:

```text
index=_internal        → 0件
index=poc_observability → 取得可能
```

従ってSplunk側RBACでもRead Onlyが成立。

---

## 9. Splunk Read Only Search Tool

主要ファイル:

```text
agent/splunk/models.py
agent/splunk/guard.py
agent/splunk/client.py
```

制約:

```text
index=poc_observability 固定
最大検索期間 2時間
最大結果 200件
```

危険SPLを拒否。少なくとも以下をブロック:

```text
delete
collect
outputlookup
sendalert
sendemail
outputcsv
tscollect
rest
script
runshellscript
savedsearch
loadjob
map
mcollect / meventcollect 系
macro (`...`) 経由の迂回
```

### Splunk REST resultsの既知仕様

通常のSearch Job `/results` では `_raw` JSONに `trace.id` が存在していても、トップレベルフィールドとして返らないケースを実機確認。

そのため `SplunkSearchClient` は:

```text
Splunk REST result
+
_raw JSON
↓
不足しているトップレベル属性だけ補完
```

する。Splunkが明示的に返したフィールドは上書きしない。

実機Integration Test:

```text
request.id → trace.id → 同一trace検索
PASSED
```

---

## 10. Phase 4 Evidence-first Core

主要ファイル:

```text
agent/evidence/models.py
agent/evidence/correlation.py
agent/evidence/splunk_collector.py
agent/evidence/newrelic_gateway.py
agent/evidence/newrelic_transport.py
agent/evidence/newrelic_collector.py
agent/evidence/correlator.py
agent/analysis/models.py
agent/analysis/prompt.py
agent/analysis/analyzer.py
agent/orchestrator.py
```

設計書:

```text
docs/superpowers/specs/2026-09-03-phase4-evidence-correlation-design.md
```

実装計画:

```text
docs/superpowers/plans/2026-09-03-phase4-evidence-correlation.md
```

### Evidenceモデル

```text
EvidenceItem
EvidenceGap
EvidenceContradiction
QueryDisclosure
CorrelationContext
EvidenceBundle
```

### IncidentAnalysis契約

```text
Incident Summary
Impact
Likely Cause
Confidence
Evidence IDs
Alternative Hypotheses
Recommended Checks
Recommended Actions
New Relic Evidence IDs
Splunk Evidence IDs
Contradiction IDs
Query Disclosure IDs
```

必須ルール:

```text
Evidenceがない原因を断定しない
Correlation != Causation
Spanがない場合、親Transaction durationだけで内部処理原因を断定しない
New Relic / Splunk矛盾はEvidenceContradictionとして残す
存在しないEvidence ID / Query IDをLLMが引用したら拒否
Recommended Actionsは提案のみ
```

---

## 11. New Relic MCP 実Transport

実機:

```text
Container: newrelic-mcp-server-newrelic-mcp-1
Process: /usr/local/bin/python3.12 /usr/local/bin/newrelic-mcp
Server: uvicorn
Endpoint: http://localhost:8000/mcp
```

確認結果:

```text
GET /          → 404
GET /mcp       → 400 Missing session ID + mcp-session-id
GET /sse       → 404
GET /messages  → 404
```

Transportはstateful Streamable HTTP。

Python側:

```text
mcp>=1.12,<2
mcp.client.streamable_http.streamable_http_client
```

`tools/list` 実機Integration Test PASSED。

MCP Server情報:

```text
name    = New Relic MCP
version = 0.1.0
```

---

## 12. 実New Relic MCP Tool schema

### execute_nrql_query

```text
execute_nrql_query(
  nrql_query: str,
  account_id: int
)
```

必須:

```text
nrql_query
account_id
```

PoC account_id:

```text
8292460
```

コードへ固定せず:

```bash
NEW_RELIC_ACCOUNT_ID=8292460
```

で渡す。

### list_change_events

```text
list_change_events(
  entity_guid: str,
  history_period_hours: int = 48
)
```

### analyze_golden_metrics

```text
entity_guid
start_time_ms
end_time_ms optional
```

### analyze_transactions

```text
entity_guid
start_time_ms
end_time_ms optional
error_transaction_limit default 5
```

### analyze_deployment_impact

```text
entity_guid
deployment_timestamp_ms
account_id
```

---

## 13. 実New Relic Transaction 相関

実 `execute_nrql_query` 戻り値:

```json
{
  "ok": true,
  "account_id": 8292460,
  "nrql_query": "SELECT ... FROM Transaction ...",
  "results": [
    {
      "appName": "poc-api-gateway",
      "duration": 0.123,
      "error": null,
      "name": "WebTransaction/...",
      "timestamp": 1788416775502,
      "traceId": "..."
    }
  ]
}
```

`timestamp` はepoch millisecondsなのでUTC datetimeへ正規化する。

実Cross-source Integration Test:

```text
新しい注文
→ 実Splunk request.id検索
→ trace.id解決
→ 実New Relic MCP execute_nrql_query
→ 同一trace Transaction取得
PASSED (1 passed in 7.23s)
```

---

## 14. New Relic Change Tracking の重要な既知事項

inventory-service Entity GUID:

```text
ODI5MjQ2MHxBUE18QVBQTElDQVRJT058MTEwMTMyNDAyOQ
```

### 14.1 list_change_events 専用Toolの不具合

実機で:

```json
{
  "ok": false,
  "error": "NewRelicAPIError",
  "message": "NerdGraph returned errors"
}
```

GraphQL error:

```text
Fragment spread has no type overlap with parent
ApmApplicationEntity vs ApmApplicationEntityOutline 等
```

つまり:

```text
MCP Transport       正常
認証                正常
entity_guid         正常
list_change_events内部NerdGraph query  不整合
```

### 14.2 Read Only NRQL fallback

`execute_nrql_query` のRead OnlyガードはNRQL文字列が `SELECT` で始まることを要求する。

NG:

```text
FROM ChangeTrackingEvent, Deployment
SELECT ...
```

OK:

```text
SELECT ...
FROM ChangeTrackingEvent, Deployment
```

実機成功したChange Tracking検索:

```text
SELECT ...
FROM ChangeTrackingEvent, Deployment
WHERE ...
SINCE 48 hours ago
```

実結果:

```text
eventType()      = ChangeTrackingEvent
category         = Deployment
categoryType     = DEPLOYMENT__BASIC
entity.name      = poc-inventory-service
entity.guid      = ODI5MjQ2MHxBUE18QVBQTElDQVRJT058MTEwMTMyNDAyOQ
version          = 1.1.0
serviceVersion   = 1.1.0
groupId          = uc05-demo-deploy-001
changeTrackingId = 8ee34a1b-d460-4bab-b3a2-48b38c6a6555
gitSha           = local-poc
type             = Basic
```

v8では:

```text
list_change_events
  ↓
成功 → eventsをEvidence化
  ↓失敗 / ok=false / unsupported payload
execute_nrql_query
  ↓
SELECT-first ChangeTrackingEvent + Deployment
  ↓
Deployment Evidence化
```

とした。

FallbackもNew Relic MCP経由なので、直接NerdGraph clientは追加していない。

---

## 15. v8 テスト状態

最新コードローカル検証:

```text
Unit Tests: 137 passed
compileall: OK
```

live integration testsはローカル環境では資格情報がないためskip。

VMで既に実機確認済み:

```text
Phase 3 Splunk request.id→trace.id Integration       PASS
Phase 4 Evidence Core Integration                   PASS
New Relic MCP tools/list                            PASS
実Splunk + 実New Relic Transaction Cross-source     PASS
Change Tracking NRQL fallback 手動実機確認          PASS
```

v8で新規追加した自動テスト:

```text
tests/integration/test_phase4_live_change_tracking.py
```

これはまだv8配布後にVMで最終実行する。

---

## 16. v8 VM最終確認コマンド

環境変数:

```bash
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp
export NEW_RELIC_ACCOUNT_ID=8292460
export NEW_RELIC_ENTITY_GUID='ODI5MjQ2MHxBUE18QVBQTElDQVRJT058MTEwMTMyNDAyOQ'
export NEW_RELIC_ENTITY_NAME=poc-inventory-service
```

実行:

```bash
docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e NEW_RELIC_MCP_URL \
  -e NEW_RELIC_ACCOUNT_ID \
  -e NEW_RELIC_ENTITY_GUID \
  -e NEW_RELIC_ENTITY_NAME \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest \
      tests/integration/test_phase4_live_change_tracking.py \
      -v
  "
```

期待:

```text
test_live_change_tracking_falls_back_to_read_only_nrql PASSED
```

---

## 17. 現在の進捗

```text
Phase 1 Demo Commerce + 5障害                     ✅
Phase 2 New Relic Python Agent                    ✅
Phase 2 Distributed Trace / request.id            ✅
Phase 2 Change Tracking登録                       ✅
Phase 2 New Relic MCP基本分析                     ✅

Phase 3 Splunk Enterprise                         ✅
Phase 3 HEC / Structured JSON                     ✅
Phase 3 Splunk RBAC Read Only                     ✅
Phase 3 Splunk Search Tool                        ✅
Phase 3 request.id / trace.id相関                  ✅
Phase 3 Splunk ⇔ New Relic Trace相関              ✅

Phase 4 Evidence Domain / Correlator               ✅
Phase 4 Splunk Evidence Collector                  ✅
Phase 4 New Relic MCP Streamable HTTP Transport    ✅
Phase 4 実Transaction Cross-source                ✅
Phase 4 Change Tracking NRQL fallback              ✅ 実装＋手動実機確認
Phase 4 v8自動live Change Tracking Test            ⏳ VMで最終確認待ち
Phase 4 実LLM Provider Adapter                     ✅ OpenAI Adapter実装＋unit test
Phase 4 OpenAI provider-only live test                ⏳ VMで最終確認待ち
Phase 4 Real Sources → Real LLM full E2E               ⏳ VMで最終確認待ち

Phase 5 AG-UI / A2UI                              ❌ 未着手
Phase 6 End-to-End Demo                           ❌ 未着手
```

---

## 18. Phase 4で次にやること

Phase 4 v9ではOpenAI Provider Adapterまで実装済み。ローカル環境ではOpenAI/New Relic/Splunkの実資格情報がないため、残る作業はVM上のlive verification。

実施順序:

```text
1. v8 Change Tracking live test
2. OpenAI provider-only live test
3. Real Splunk + Real New Relic MCP + Real OpenAI full E2E
4. すべてPASSしたらPhase 5 AG-UI / A2UIへ進む
```

### 18.1 v8 Change Tracking live test

```bash
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp
export NEW_RELIC_ACCOUNT_ID=8292460
export NEW_RELIC_ENTITY_GUID='ODI5MjQ2MHxBUE18QVBQTElDQVRJT058MTEwMTMyNDAyOQ'
export NEW_RELIC_ENTITY_NAME=poc-inventory-service

docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e NEW_RELIC_MCP_URL \
  -e NEW_RELIC_ACCOUNT_ID \
  -e NEW_RELIC_ENTITY_GUID \
  -e NEW_RELIC_ENTITY_NAME \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase4_live_change_tracking.py -v
  "
```

期待:

```text
test_live_change_tracking_falls_back_to_read_only_nrql PASSED
```

### 18.2 OpenAI provider-only live test

OpenAI Adapter:

```text
agent/analysis/openai_adapter.py
```

主要仕様:

```text
Responses API /v1/responses
Strict JSON Schema structured output
store=false
Default model = gpt-5.6-luna
OPENAI_MODELで差し替え可能
OPENAI_MAX_OUTPUT_TOKENS default 2500
HTTP body / network detailを例外へ露出しない
Pydantic IncidentAnalysis validate
既存 validate_analysis_references() を最終境界で使用
```

環境変数:

```bash
export OPENAI_API_KEY='<OpenAI API Key>'
export OPENAI_MODEL=gpt-5.6-luna
export OPENAI_BASE_URL=https://api.openai.com/v1
export OPENAI_MAX_OUTPUT_TOKENS=2500
```

実行:

```bash
docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e OPENAI_API_KEY \
  -e OPENAI_MODEL \
  -e OPENAI_BASE_URL \
  -e OPENAI_MAX_OUTPUT_TOKENS \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase4_live_openai_analysis.py -v
  "
```

期待:

```text
test_live_openai_analyzer_returns_reference_safe_incident_analysis PASSED
```

### 18.3 Phase 4完全live E2E

必要環境変数:

```bash
export SPLUNK_SEARCH_URL=https://localhost:8089
export SPLUNK_SEARCH_USERNAME=ai_search
export SPLUNK_SEARCH_PASSWORD='<ai_search password>'
export SPLUNK_SEARCH_VERIFY_SSL=false
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp
export NEW_RELIC_ACCOUNT_ID=8292460
export OPENAI_API_KEY='<OpenAI API Key>'
export OPENAI_MODEL=gpt-5.6-luna
```

実行:

```bash
docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e SPLUNK_SEARCH_URL \
  -e SPLUNK_SEARCH_USERNAME \
  -e SPLUNK_SEARCH_PASSWORD \
  -e SPLUNK_SEARCH_VERIFY_SSL \
  -e NEW_RELIC_MCP_URL \
  -e NEW_RELIC_ACCOUNT_ID \
  -e OPENAI_API_KEY \
  -e OPENAI_MODEL \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase4_live_end_to_end.py -v
  "
```

期待:

```text
test_live_phase4_real_sources_to_real_llm_incident_analysis PASSED
```

このテストは:

```text
Demo Commerce request
  ↓
Splunk request.id → trace.id
  ↓
Real Splunk Evidence
  +
Real New Relic MCP Evidence
  ↓
EvidenceBundle
  ↓
OpenAIIncidentAnalyzer
  ↓
IncidentAnalysis
  ↓
Pydantic + Evidence/Query/Contradiction reference validation
```

まで通す。

ローカル最新unit test:

```text
149 passed
```

これらのlive testがPASSしたらPhase 4完了としてPhase 5へ進む。

---

## 19. Phase 5 方針

画面全体をA2UIで生成しない。

固定UI:

```text
Service
Environment
Time Range
質問欄
```

動的結果:

```text
HealthSummary
TimelineChart
EvidenceCard
TraceCard
LogTable
HypothesisCard
RecommendationCard
QueryDisclosure
```

AG-UI:

```text
調査開始
New Relic調査中
Splunk調査中
相関分析中
LLM分析中
原因候補表示
```

---

## 20. セキュリティ

秘密情報は引継ぎに書かない。

`.env` / shell環境のみに保持:

```text
NEW_RELIC_LICENSE_KEY
NEW_RELIC_API_KEY
NEW_RELIC_ENTITY_GUID
SPLUNK_PASSWORD
SPLUNK_HEC_TOKEN
SPLUNK_SEARCH_PASSWORD
OPENAI_API_KEY
```

`NEW_RELIC_ACCOUNT_ID` は秘密ではないがコード固定せず環境変数化。

過去に `docker compose config` でNew Relic License Keyが表示されたことがあるため、未対応ならキーのローテーション推奨。

---

## 21. 新チャットで最初に貼る依頼文

```text
添付の「New Relic + Splunk + A2UI/AG-UI PoC 引継ぎメモ v3」と最新v9 Zipの続きをお願いします。

Phase 1〜3は完了済みです。
Phase 4はEvidence-first Core、Splunk実相関、New Relic MCP Streamable HTTP実接続、実Transaction Cross-source、Change Tracking NRQL fallbackまで実装済みです。

v9でOpenAI Responses APIを使うOpenAIIncidentAnalyzerをTDD実装済みです。Strict JSON Schema、store=false、Pydantic validation、既存Evidence/Query reference validationを利用します。ローカルunit testは149 passedです。

最初にVMで次の順にlive testしてください。
1. tests/integration/test_phase4_live_change_tracking.py
2. tests/integration/test_phase4_live_openai_analysis.py
3. tests/integration/test_phase4_live_end_to_end.py

3までPASSしたらPhase 4完了としてPhase 5 AG-UI / A2UIへ進んでください。

方針:
- New Relic / SplunkはRead Only
- Evidenceがない原因を断定しない
- Correlation != Causation
- Spanがない場合Transaction durationだけで内部原因を断定しない
- 矛盾はEvidenceとして残す
- Recommended Actionsは提案のみ
- OpenAI API keyなど秘密情報は.env/shell環境のみ
- TDDで進める
```

---

## 21.5 v9 OpenAI Adapter 実装メモ

追加/変更主要ファイル:

```text
agent/analysis/openai_adapter.py
agent/analysis/models.py
tests/unit/test_openai_incident_analyzer.py
tests/integration/test_phase4_live_openai_analysis.py
tests/integration/test_phase4_live_end_to_end.py
.env.example
README.md
```

OpenAI Adapterは既存`IncidentAnalyzer` Protocolを変更せず、composition時に差し込む。従って将来Bedrock等へ置き換える場合もEvidence Collector / Correlator / Orchestratorの基本契約は維持できる。

実OpenAI応答が存在しないEvidence ID、Query Disclosure ID、Contradiction IDを返した場合は、既存`InvestigationOrchestrator`内の`validate_analysis_references()`で拒否する。

---

## 22. 最新成果物

最新デプロイ用Zip:

```text
observability-ai-poc-phase4-openai-live-v9.zip
```

最新引継ぎ:

```text
newrelic_splunk_a2ui_agui_poc_handoff_20260903_v3.md
```

