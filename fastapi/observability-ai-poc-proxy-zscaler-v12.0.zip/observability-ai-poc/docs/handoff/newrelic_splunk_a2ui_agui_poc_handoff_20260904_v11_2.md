# New Relic + Splunk + A2UI/AG-UI PoC 引継ぎメモ v11.2

更新日: 2026-09-04

## 1. 現在地

Phase 1〜4は完了。Phase 5 AG-UI/A2UI Consoleも以下をVM実機で確認済み。

```text
Python unit                   211 passed（v11.1時点）
Phase 5 API integration       2 passed
Frontend node tests           14 passed（VM手修正版）
TypeScript + Vite build       PASS
Phase 5 real live E2E         1 passed in 20.09s
Browser Console表示           PASS
```

ブラウザ実機では、Request IDのTime Rangeをイベント発生時刻に合わせることで、
Correlation → Splunk → New Relic → Evidence correlation → LLM analysis → A2UI result
まで表示できた。

## 2. v11.2 日本語既定化

ユーザー要望により、日本語をアプリケーションの既定言語にした。Chrome等のブラウザ翻訳には依存しない。

対象:

- 固定UI（見出し、フォーム、進捗、エラー、カード見出し）
- Public API error message
- Splunk / New Relic Evidence summary
- EvidenceGap summary
- Evidence contradiction summary
- LLMの人間向け自然言語出力
  - incident_summary
  - impact
  - likely_cause
  - alternative_hypotheses[].summary
  - recommended_checks
  - recommended_actions

技術識別子は翻訳しない:

```text
request.id
trace.id
Evidence ID
Query Disclosure ID
service name
event type
tool name
SPL
NRQL
```

`agent/analysis/prompt.py` の共有 `ANALYSIS_CONTRACT` に日本語出力規則を追加したため、Ollama / Azure OpenAI / OpenAIの全Providerへ共通適用される。

## 3. v11.2 TDD

RED:

```text
Python localization tests: 4 failed
Frontend localization test: 1 failed
```

GREEN:

```text
Python full unit: 215 passed
Frontend node tests: 18 passed / 0 failed
compileall: OK
Phase 5 API integration: 2 passed
```

このChatGPT作業環境ではnpm registryへの名前解決ができず、新規 `npm install` が実行できないため、v11.2の `npm run build` 最終確認はVMで行う。

## 4. VMへの適用

既存 `~/20260903/observability-ai-poc` をバックアップ後、v11.2 Zipを上書き展開するか、同梱patchを適用する。

Pythonはホストではなく従来どおり `python:3.11-slim` コンテナで検証する。

### Python unit

```bash
docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/unit -q
  "
```

期待: fail=0（v11.2基準では215 tests）。

### Phase 5 API integration

```bash
docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase5_console_api.py -v
  "
```

期待: 2 passed。

### Frontend

```bash
docker run --rm \
  -v "$PWD/console:/app" \
  -w /app \
  node:22-slim \
  sh -lc "
    npm test &&
    npm run build
  "
```

期待:

```text
18 tests / fail 0
vite production build exit 0
```

## 5. v11.2 Browser確認

既存backend/UIコンテナを再起動し、ブラウザ翻訳をOFFにした状態で確認する。

期待:

- UIが日本語
- 進捗が日本語
- LLM分析本文が日本語
- Evidence説明文が日本語
- `Request ID`, `Trace ID`, Evidence ID, service名, event type, SPL/NRQLは原文維持
- Recommended actionsは提案表示のみで実行ボタンなし

## 6. 安全境界

変更なし。

- Splunk / New RelicはRead Only
- Evidence-first
- Correlation != Causation
- Evidence/Query/Contradiction reference validation維持
- EvidenceGap IDをEvidence IDとして引用禁止
- Recommended Actionsはadvisory only
- Provider auto-failoverなし
