# New Relic + Splunk + A2UI/AG-UI PoC 引継ぎメモ v11.4

更新日: 2026-09-04

## 1. 現在地

Phase 1〜4は完了。Phase 5「AG-UI / A2UI AI Troubleshooting Console」も、Ollama版・Azure OpenAI版ともに実機E2Eとブラウザ表示まで確認済み。

現在のPoCは以下を満たす。

```text
Demo Commerce
  ↓
Splunk Structured Logs
  +
New Relic APM / MCP
  ↓
request.id / trace.id 相関
  ↓
EvidenceBundle
  ↓
Selected LLM Provider
  ├─ Ollama / gpt-oss:20b
  └─ Azure OpenAI / gpt-5.6-sol
  ↓
IncidentAnalysis
  ↓
Pydantic + Evidence/Query/Contradiction reference validation
  ↓
AG-UI progress stream
  ↓
A2UI v0.9.1 messages
  ↓
React AI Troubleshooting Console
```

Phase 5の安全境界は維持している。

- Splunk / New RelicはRead Only
- Evidence-first
- Correlation != Causation
- EvidenceGap IDをEvidence IDとして引用禁止
- Recommended Actionsはadvisory only
- LLM Providerの自動failoverなし
- 本番変更・再起動・デプロイ等の実行ボタンは持たない

---

## 2. VM / 作業ディレクトリ

```bash
cd ~/20260903/observability-ai-poc
```

ホストPython:

```text
Python 3.10.12
```

PoC要件:

```text
Python >=3.11,<3.14
```

Pythonテストは従来どおり `python:3.11-slim` コンテナで実行する。

Frontendは `node:22-slim` コンテナで検証する。

---

## 3. 主要ポート

```text
API Gateway             localhost:8085
Scenario Controller     localhost:8091
Splunk Web              localhost:18000
Splunk HEC              localhost:8088
Splunk Management REST  localhost:8089
New Relic MCP            localhost:8000/mcp
Console API              localhost:8095
React / Vite Console     localhost:5173
Ollama                    localhost:11434
```

New Relic MCPがホスト8000を使用するためSplunk Webは18000。

---

## 4. Phase 5 最終構成

### 4.1 固定UI

```text
AIトラブルシューティングコンソール
READ ONLY

リクエストID
開始日時
終了日時
調査する
```

実入力は `request_id + earliest + latest`。

Service / Environment / Trace IDは調査結果側のコンテキストとして表示する。

### 4.2 AG-UI進捗

5段階の進捗をストリーミングする。

```text
相関
Splunkの調査
New Relicの調査
証拠の相関
LLM分析
```

使用イベント:

```text
RUN_STARTED
STEP_STARTED
STEP_FINISHED
RUN_FINISHED
RUN_ERROR
CUSTOM (a2ui.message)
```

### 4.3 A2UI

A2UI wire protocolは v0.9.1。

決定論的Presenterで `InvestigationResult` を以下へ変換する。

```text
createSurface
updateComponents
updateDataModel
```

固定カタログの主要コンポーネント:

```text
HealthSummary
TraceCard
TimelineChart
EvidenceCard
EvidenceGapCard
LogTable
HypothesisCard
RecommendationCard
QueryDisclosure
```

LLMにUI構造を自由生成させない。

---

## 5. 日本語既定化

ブラウザ翻訳には依存せず、アプリケーション自身を日本語既定にした。

日本語化対象:

- 固定UI
- AG-UI進捗
- Public API error message
- Splunk / New Relic Evidence summary
- EvidenceGap summary
- Evidence contradiction summary
- LLM人間向け自然言語出力
  - incident_summary
  - impact
  - likely_cause
  - alternative_hypotheses[].summary
  - recommended_checks
  - recommended_actions

技術識別子は翻訳しない。

```text
request.id
trace.id
Evidence ID
Query Disclosure ID
service name
event type
tool name
SPL
NRQL
```

共有 `ANALYSIS_CONTRACT` に日本語出力規則を入れているため、Ollama / Azure OpenAI / OpenAIへ共通適用される。

---

## 6. LLM Provider

### 6.1 Ollama

通常PoCのローカル既定。

```bash
export LLM_PROVIDER=ollama
export OLLAMA_BASE_URL=http://localhost:11434
export OLLAMA_MODEL=gpt-oss:20b
export OLLAMA_REASONING_EFFORT=medium
export OLLAMA_TIMEOUT_SECONDS=180
```

Ollama Adapterはnative `/api/chat` を使用。

Structured output → Pydantic validation → reference validationを行い、必要時のみ同一modelへ最大1回repairする。

### 6.2 Azure OpenAI

実機確認済み:

```text
Provider: azure_openai
Model / deployment: gpt-5.6-sol
Base URL: Azure OpenAI /openai/v1
```

設定例:

```bash
export LLM_PROVIDER=azure_openai
export AZURE_OPENAI_API_KEY='<secret>'
export AZURE_OPENAI_BASE_URL='https://<resource>.openai.azure.com/openai/v1'
export AZURE_OPENAI_MODEL='gpt-5.6-sol'
export AZURE_OPENAI_MAX_OUTPUT_TOKENS=2500
export AZURE_OPENAI_TIMEOUT_SECONDS=60
```

Azure Adapter:

```text
Responses API
  ↓
Strict Structured Output
  ↓
Pydantic IncidentAnalysis validation
  ↓
validate_analysis_references()
  ↓ fail
同一deploymentへ最大1回Reference Repair
  ↓
再validation
```

Provider auto-failoverはしない。

---

## 7. Phase 5 実機確認結果

2026-09-04 VM実機で確認済み。

### 7.1 Backend / Frontend

```text
Python unit                         218 passed
Phase 5 API integration             2 passed
compileall                           OK
Frontend node tests                21 passed / 0 failed
TypeScript / Vite build            production assets生成まで確認
```

Frontend testでは以下を含む。

- A2UI固定read-only catalog
- official v0_9 MessageProcessor接続
- A2UI forwarding型境界
- SSE chunk parser
- AG-UI進捗reducer
- 日本語既定
- 技術識別子維持
- 日本語empty placeholder
- 終了日時selected minute全体包含
- 実効検索窓2時間制限

### 7.2 Ollama

```text
Phase 4 real Splunk + real New Relic + real Ollama E2E  PASS
Phase 5 live E2E                                      PASS
Browser Console result                                PASS
```

### 7.3 Azure OpenAI

```text
Azure OpenAI provider-only live test                  PASS
Phase 5 live E2E                                      PASS
Browser Console result                                PASS
```

Azure OpenAIブラウザ実行では一度だけLLM stepで一時失敗したが、同一コンテナ・同一request/time rangeの直接Orchestrator実行はSUCCESSし、その後ブラウザ再実行もSUCCESSした。

恒常的なcredit/quota枯渇ではなかった。

---

## 8. v11.3で修正した実機バグ

### 8.1 Time Range終了分の境界

実イベント:

```text
2026-09-04 09:25:18 JST
```

旧UI:

```text
終了日時=09:25
→ 09:25:00として送信
→ 09:25:18を検索範囲外として除外
```

修正後:

```text
終了日時=09:25
→ selected minute末尾の09:25:59.999まで包含
```

実ブラウザで `終了日時=09:25` のまま、09:25:18のSplunk eventを相関してAzure OpenAI分析完了まで確認済み。

実効検索窓が2時間を超える場合は従来どおり拒否する。

### 8.2 残存英語プレースホルダー

以下を日本語化済み。

```text
Validated investigation results will appear here.
↓
検証済みの調査結果がここに表示されます。
```

### 8.3 LLM failure observability

ブラウザ/SSEには安全な分類だけを返す。

```text
LLM_ANALYSIS_FAILED
  LLM分析中に一時的なエラーが発生しました。再度実行してください。

LLM_CONFIGURATION_ERROR
  LLM分析サービスの設定を確認してください。
```

Server logには秘密情報やEvidence本文、例外本文を出さず、次の診断metadataだけを残す。

```text
step
provider
model
error_type
exception_type
```

例:

```text
investigation_failed step=analyze provider=azure_openai model=gpt-5.6-sol error_type=rate_limit exception_type=AzureOpenAIAnalysisError
```

---

## 9. 実機で確認した代表Request

```text
request.id = phase5-ja-demo-001
trace.id   = e43ab7627ecd0f7e7a566662ca12e720
```

Splunkでは5 eventsを確認。

```text
application.request    api-gateway
capacity.snapshot      order-service
db.query               inventory-service
dependency.call        payment-service
application.response   api-gateway
```

`scenario.id=UC03_APP_EXCEPTION` が付与されていた一方、実観測ではHTTP 201・New Relic Transaction error=nullで、明示的例外Evidenceはなかった。

LLMはこれを無理に「例外が原因」と断定せず、Evidence-firstに「原因未特定 / 信号の不一致」と評価した。

---

## 10. Console起動

### 10.1 Backend

現在のProvider環境変数をセットした状態で:

```bash
docker rm -f observability-console-api 2>/dev/null || true

docker run -d \
  --name observability-console-api \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e SPLUNK_SEARCH_URL \
  -e SPLUNK_SEARCH_USERNAME \
  -e SPLUNK_SEARCH_PASSWORD \
  -e SPLUNK_SEARCH_VERIFY_SSL \
  -e NEW_RELIC_MCP_URL \
  -e NEW_RELIC_ACCOUNT_ID \
  -e LLM_PROVIDER \
  -e OLLAMA_BASE_URL \
  -e OLLAMA_MODEL \
  -e OLLAMA_REASONING_EFFORT \
  -e OLLAMA_TIMEOUT_SECONDS \
  -e AZURE_OPENAI_API_KEY \
  -e AZURE_OPENAI_BASE_URL \
  -e AZURE_OPENAI_MODEL \
  -e AZURE_OPENAI_MAX_OUTPUT_TOKENS \
  -e AZURE_OPENAI_TIMEOUT_SECONDS \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    uvicorn console_api.app:app --host 0.0.0.0 --port 8095
  "
```

`LLM_PROVIDER` で選ばれたProviderだけが実際に利用される。

### 10.2 Frontend

```bash
docker rm -f observability-console-ui 2>/dev/null || true

docker run -d \
  --name observability-console-ui \
  --network host \
  -v "$PWD/console:/app" \
  -w /app \
  node:22-slim \
  sh -lc "
    npm run dev -- --host 0.0.0.0 --port 5173
  "
```

ブラウザ:

```text
http://<VM-IP>:5173
```

---

## 11. Phase 5の完了判定

Phase 5で狙っていた以下は実機で成立した。

```text
固定React UI
  +
AG-UIによる調査進捗stream
  +
A2UIによる動的結果surface
  +
Splunk / New RelicのEvidence-first調査
  +
実LLM（Ollama / Azure OpenAI）
  +
Reference validation
  +
Read Only / advisory-only安全境界
```

したがって、次作業はPhase 6 End-to-End Demoへ進む。

---

## 12. Phase 6で最初に行うこと

Phase 6は新機能を大量追加するより、Phase 1〜5を「見せられるデモ」として完成させる。

推奨順序:

1. UC01〜UC05の各障害シナリオを再確認
2. デモで使う代表シナリオを2〜3個選ぶ
3. シナリオごとにRequest IDを自動生成してConsoleへ流す導線を整理
4. AG-UI進捗 → A2UI結果 → Evidence → Recommendationの見せ方を確認
5. Ollama / Azure OpenAIを同じEvidenceで比較できるようにする
6. Evidence不足・矛盾・LLM一時失敗などのデモも必要なら用意
7. デモ手順書 / トークスクリプトを作成
8. 最終E2E回帰テストを実行

Phase 6でも次の方針は維持する。

```text
Observe → Investigate → Correlate → Recommend
```

本番変更は実行しない。

---

## 13. Phase 6開始時の確認候補

### 13.1 代表シナリオ候補

```text
UC01_DB_SLOW
UC02_PAYMENT_FAILURE
UC03_APP_EXCEPTION
UC04_HIGH_LOAD
UC05_BAD_DEPLOYMENT
```

UC03では `scenario.id` と実Evidenceの不一致が見えるケースがあり、Evidence-firstの説明に向いている。

一方、明確な根拠と原因候補を見せたいデモではUC01 / UC02 / UC05も比較して選ぶ。

### 13.2 Phase 6で避けること

- AIに本番変更権限を持たせない
- LLMに存在しないEvidenceを補完させない
- `scenario.id` だけで原因を決めつけない
- EvidenceGapをEvidence IDとして扱わない
- Provider自動failoverを追加しない
- デモ都合でEvidence-first validationを緩めない

---

## 14. 新チャットで最初に貼る依頼文

以下をそのまま新しいチャットへ貼る。

```text
添付の「New Relic + Splunk + A2UI/AG-UI PoC 引継ぎメモ v11.4」と最新のPhase 5 v11.3コード一式を前提に、Phase 6 End-to-End Demoから続けたいです。

Phase 1〜5は完了済みです。

Phase 5では、固定React UI + AG-UI進捗stream + A2UI v0.9.1動的結果表示を実装し、実Splunk / 実New Relic MCP / EvidenceBundle / Reference Validation / 実LLMまで接続しています。

実LLMは以下を確認済みです。
- Ollama / gpt-oss:20b: Phase 5 live E2E + Browser PASS
- Azure OpenAI / gpt-5.6-sol: provider-only + Phase 5 live E2E + Browser PASS

UI・Evidence説明文・LLM自然言語出力は日本語既定です。request.id / trace.id / Evidence ID / SPL / NRQLなどの技術識別子は原文維持です。

v11.3では、終了日時のminute境界（09:25指定で09:25:18を取りこぼす問題）を修正し、その分の59.999秒まで包含するようにしました。ブラウザ実機で09:25のまま相関・Azure OpenAI分析完了まで確認済みです。

Read Only / Evidence-first / advisory-only / Provider auto-failoverなしの安全境界は維持しています。

まずPhase 6のデモ設計を確認し、UC01〜UC05のどのシナリオを代表デモにするか整理してから、TDDで必要な追加実装を進めてください。
```

---

## 15. 最新成果物

コード:

```text
observability-ai-poc-phase5-v11.3.zip
```

最終引継ぎ:

```text
newrelic_splunk_a2ui_agui_poc_handoff_20260904_v11_4.md
```

v11.4は引継ぎ文書のみ更新。コードはv11.3と同一。
