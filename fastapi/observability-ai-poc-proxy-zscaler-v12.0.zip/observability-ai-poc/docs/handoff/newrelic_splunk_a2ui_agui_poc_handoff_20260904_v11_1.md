# New Relic + Splunk + A2UI/AG-UI PoC 引継ぎメモ v11

更新日: 2026-09-04

## 1. 現在地

Phase 1〜4は完了済み。

Phase 4の完全実機E2EはユーザーVMで2026-09-03に以下を確認済み。

```text
tests/integration/test_phase4_live_end_to_end.py::test_live_phase4_real_sources_to_real_llm_incident_analysis PASSED
1 passed in 23.21s
```

Phase 5 AG-UI / A2UI は設計承認後、TDDで実装済み。ローカルで検証可能なBackend / frontend core testsはGREEN。実npm依存を使ったReact buildと実Splunk/New Relic/LLMを使うPhase 5 live smokeだけVM最終確認待ち。

```text
Phase 1 Demo Commerce + 5障害              ✅
Phase 2 New Relic APM / Trace              ✅
Phase 3 Splunk / Read Only / Correlation   ✅
Phase 4 Evidence-first + real LLM E2E      ✅
Phase 5 Backend AG-UI / A2UI presenter     ✅ local
Phase 5 React console source               ✅ implemented
Phase 5 npm test / build                    ⏳ VM verification
Phase 5 real live console smoke             ⏳ VM verification
Phase 6 End-to-End Demo                     ❌ not started
```

## 2. Phase 5 設計

設計書:

```text
docs/superpowers/specs/2026-09-03-phase5-agui-a2ui-console-design.md
```

実装計画:

```text
docs/superpowers/plans/2026-09-04-phase5-agui-a2ui-console.md
```

基本構成:

```text
React AI Troubleshooting Console
  |
  | POST + SSE
  v
FastAPI / AG-UI Adapter
  |
  | RUN_STARTED
  | STEP_STARTED / STEP_FINISHED
  | CUSTOM(name="a2ui.message")
  | RUN_FINISHED / RUN_ERROR
  v
InvestigationOrchestrator   # Phase 4契約維持
  |
  v
validated InvestigationResult
  |
  v
Deterministic A2UI Presenter
  |
  v
A2UI v0.9.1
  createSurface
  updateComponents
  updateDataModel
```

重要:

- LLMにReact/HTML/UI構造を自由生成させない。
- `InvestigationResult` -> `TroubleshootingViewModel` -> A2UI はPython側の決定論的変換。
- Phase 4の `EvidenceBundle`, `IncidentAnalysis`, `validate_analysis_references()` は維持。
- New Relic / SplunkはRead Only。
- Recommended Actionsは表示のみ。
- A2UI結果面にはrestart / rollback / deploy / delete等の操作ボタンを置かない。
- `EvidenceGap.gap_id` はEvidence IDとは別namespace。

## 3. Phase 5 入力

最初のvertical sliceではOrchestratorの実契約に合わせて以下だけを入力する。

```text
Request ID
Earliest
Latest
```

制約:

```text
latest > earliest
max window = 2 hours
timezone-aware datetime
```

Service / Environment / Trace IDはEvidenceから導出して結果側に表示する。

## 4. AG-UI Progress

Orchestratorへoptional Progress Reporterを追加。

固定step:

```text
correlation
splunk
newrelic
correlate
analyze
```

正常なEvidenceGapは調査失敗ではないため該当stepはFINISHEDし、後続調査を継続する。

主要ファイル:

```text
agent/progress.py
agent/orchestrator.py
console_api/agui_sdk.py
console_api/stream.py
console_api/app.py
console_api/dependencies.py
console_api/models.py
console_api/errors.py
```

AG-UI Python dependency:

```text
ag-ui-protocol>=0.1.22,<0.2
```

Endpoint:

```text
POST /api/investigations/stream
Accept: text/event-stream
```

A2UI messages are emitted as:

```text
CUSTOM
name = a2ui.message
value = <A2UI v0.9.1 envelope>
```

## 5. Error safety

公開error code:

```text
INVALID_REQUEST
CORRELATION_NOT_FOUND
CORRELATION_AMBIGUOUS
INVESTIGATION_FAILED
```

Backend raw exception text / password / token / upstream bodyはRUN_ERRORへ流さない。

TDD中に追加で発見・修正した境界:

```text
orchestrator_factory(progress) 自体が失敗するケース
```

修正後はRUN_STARTEDの後にsanitized RUN_ERRORを返し、秘密値を露出しない。

## 6. A2UI Presentation

Python:

```text
agent/ui/models.py
agent/ui/presenter.py
agent/ui/a2ui.py
```

A2UI wire version:

```text
v0.9.1
```

Catalog ID:

```text
dev.observability:troubleshooting-v1
```

固定component:

```text
HealthSummary
TimelineChart
TraceCard
EvidenceCard
EvidenceGapCard
LogTable
HypothesisCard
RecommendationCard
QueryDisclosure
```

A2UI message order:

```text
createSurface
updateComponents
updateDataModel
```

## 7. React Console

ディレクトリ:

```text
console/
```

主要ファイル:

```text
console/package.json
console/vite.config.ts
console/tsconfig.json
console/src/app/App.tsx
console/src/api/investigationStream.ts
console/src/state/progress.ts
console/src/components/InvestigationForm.tsx
console/src/components/InvestigationProgress.tsx
console/src/a2ui/catalogContract.ts
console/src/a2ui/componentApis.ts
console/src/a2ui/catalog.tsx
console/src/a2ui/processor.ts
console/src/a2ui/TroubleshootingSurface.tsx
console/src/components/HealthSummary.tsx
console/src/components/TimelineChart.tsx
console/src/components/TraceCard.tsx
console/src/components/EvidenceCard.tsx
console/src/components/EvidenceGapCard.tsx
console/src/components/LogTable.tsx
console/src/components/HypothesisCard.tsx
console/src/components/RecommendationCard.tsx
console/src/components/QueryDisclosure.tsx
```

npm dependencies:

```text
@a2ui/react=0.10.2
@a2ui/web_core=0.10.6
react=19.2.7
react-dom=19.2.7
zod ^3.25.76
```

A2UI renderer API:

```text
MessageProcessor from @a2ui/web_core/v0_9
Catalog from @a2ui/web_core/v0_9
createComponentImplementation from @a2ui/react/v0_9
A2uiSurface from @a2ui/react/v0_9
```

ブラウザのPOST streamはEventSourceではなく`fetch()` + `ReadableStream`を使用する。

## 8. TDD / local verification

Phase 5開始前のunit baseline:

```text
189 passed
```

追加実装後のfresh local verification:

```text
Python unit:                211 passed
Phase 5 API integration:    2 passed
Python compileall:          OK
Frontend core/safety:       14 passed
Phase 5 live smoke:         1 skipped (live envなしのため期待どおり)
```

Frontend dependency-free test:

```bash
cd console
node --experimental-strip-types --test src/**/*.node.test.ts
```

現作業コンテナでは外部npm/PyPI名前解決が利用できず、`npm install`がtimeoutした。そのため以下はまだVMで実行していない。

```text
npm test
npm run build
```

これはPhase 5完了判定前の必須VMチェック。

## 9. VMで次に実行すること

作業ディレクトリ:

```bash
cd ~/20260903/observability-ai-poc
```

### 9.1 Phase 5コードを展開後 Python dependency

```bash
python -m pip install -e '.[dev]'
```

Docker test containerで実行する場合も同様に`.[dev]`をinstallする。これにより`ag-ui-protocol`が入る。

### 9.2 Backend local tests

```bash
python -m pytest tests/unit -q
python -m pytest tests/integration/test_phase5_console_api.py -v
python -m compileall agent console_api shared services load_generator
```

期待:

```text
211 passed
2 passed
compileall OK
```

Pythonバージョン差により依存側テスト件数が変わる場合は、fail=0を優先して確認する。

### 9.3 Frontend install + verification

```bash
cd console
npm install
npm test
npm run build
cd ..
```

最低条件:

```text
npm test: fail=0
npm run build: exit 0
```

### 9.4 Backend launch

既存のSplunk/New Relic/Ollama環境変数をexportしたシェルで:

```bash
uvicorn console_api.app:app --host 0.0.0.0 --port 8095
```

### 9.5 Frontend launch

別シェル:

```bash
cd console
npm run dev -- --host 0.0.0.0
```

Vite proxy:

```text
/api -> http://localhost:8095
```

### 9.6 Phase 5 real live smoke

Phase 4完全E2Eで使った環境変数をそのまま使う。

追加:

```bash
export RUN_PHASE5_LIVE_TESTS=1
```

実行:

```bash
python -m pytest tests/integration/test_phase5_live_console.py -v
```

期待:

```text
test_live_phase5_console_streams_progress_and_a2ui_result PASSED
```

このtestは:

```text
Demo Commerce request
-> Splunk request.id/trace.id
-> New Relic MCP Transaction readiness
-> FastAPI Phase 5 endpoint
-> AG-UI lifecycle/5 steps
-> real Phase 4 Orchestrator
-> real selected LLM
-> validated InvestigationResult
-> A2UI CUSTOM x3+
-> RUN_FINISHED
```

を確認する。

### 9.7 Phase 4 regression

Phase 5 progress hooksが結果を壊していないことを実機で再確認:

```bash
python -m pytest tests/integration/test_phase4_live_end_to_end.py -v
```

期待:

```text
PASSED
```

## 10. 起動後のデモ手順

1. Demo Commerce / Splunk / New Relic MCP / Ollamaを起動。
2. Phase 5 backend `uvicorn ... --port 8095` を起動。
3. `console` でViteを起動。
4. 新しい注文を1件作成し、その`X-Request-ID`を控える。
5. ブラウザでRequest IDと直近Time Rangeを入力。
6. 画面上で以下が順次進むことを確認。

```text
Correlation
Splunk investigation
New Relic investigation
Evidence correlation
LLM analysis
```

7. 最終結果でIncident Summary / Trace / Timeline / Evidence / Gap / Logs / Hypotheses / Recommendations / Query Disclosureを確認。
8. Recommendationは表示のみで、実行ボタンがないことを確認。

## 11. Phase 5完了条件

以下すべてが成立したらPhase 5を完了扱いにする。

```text
[ ] VM npm install success
[ ] npm test fail=0
[ ] npm run build exit 0
[ ] Python Phase 5 API integration pass
[ ] Phase 5 real live smoke pass
[ ] Phase 4 real live E2E regression pass
[ ] ブラウザでA2UI surface表示確認
[ ] Read Only / no remediation control確認
```

## 12. 次のPhase

Phase 5完了後はPhase 6 End-to-End Demo。

候補:

- 各障害シナリオ UC01〜UC05をConsoleからデモできる導線整理
- Service/Environmentを結果コンテキストからfilter UXへ拡張するか検討
- Timeline visual polish
- demo script / screenshot / presentation material

ただし最初にPhase 5 VMチェックを完了する。

---

## v11.1 Phase 5 TypeScript build fix (2026-09-04)

VMで `npm run build` を実行した結果、TypeScript strict buildで2件の型エラーを確認した。

1. `App.tsx` から `forwardA2uiCustomEvent(nextProcessor, event)` を呼ぶ際、`forwarding.ts` が `processMessages(messages: unknown[])` という独自の広すぎる契約を定義していたため、公式 `MessageProcessor<ReactComponentImplementation>` の型付き `processMessages` と反変性で不一致になった。
2. `HealthSummary.tsx` の `props.children.map((childId) => ...)` で `childId` が implicit any になった。

修正:
- `forwarding.ts` は `TroubleshootingProcessor['processMessages']` の第一引数から配列variantを `Extract<..., unknown[]>` で導出し、その要素型へCUSTOMイベント値を境界castして公式processorへ渡す。
- `HealthSummary.tsx` は `childId: string` を明示。
- 2件の回帰テストを `rendererSafety.node.test.ts` に追加。

TDD:
- RED: frontend node tests 14 pass / 2 fail
- GREEN: frontend node tests 16 pass / 0 fail

この作業環境ではnpm registryへのアクセスがタイムアウトするため、`npm run build` の最終確認はVMで実施する。VMではv11.1 patch適用後にNode 22コンテナで `npm test && npm run build` を再実行する。
