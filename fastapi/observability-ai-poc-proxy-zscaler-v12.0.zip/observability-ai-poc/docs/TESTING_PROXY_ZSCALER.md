# Proxy + Zscaler CA 環境向け テスト手順

本書は `docs/SETUP_PROXY_ZSCALER.md` 完了後の検証マトリクスである。秘密値は出力しない。

## テストマトリクス

| Layer | Test | Expected |
|---|---|---|
| Static/unit | Python unit suite | 0 failed |
| Static/unit | Python offline integration subset | 0 failed |
| Static/unit | Console Node tests | 0 failed |
| Static/unit | Console production build | exit 0 |
| Static/unit | Vendored MCP unit tests | 0 failed |
| Proxy/CA | `make proxy-preflight` | PASS |
| Proxy/CA | `scripts/verify_proxy_ca.sh` | PASS |
| Proxy/CA | external HTTPS TLS probe through proxy | HTTP status obtained without TLS error |
| Proxy/CA | internal service URLs | NO_PROXY経由、Proxyを通さない |
| Splunk | HEC smoke | `code=0` |
| Splunk | `ai_search` current-context | capability=`search` only |
| Splunk | `test_splunk_search_integration.py` | PASS |
| New Relic MCP | `test_newrelic_mcp_transport_integration.py` | PASS |
| LLM | selected provider-only live test | PASS |
| E2E | `test_phase4_live_end_to_end.py` | PASS |
| E2E | `test_phase5_live_console.py` | PASS |
| Browser | investigation | 5 progress steps finish |


## 0. Base workflow non-regression

Proxy対応は `compose.proxy.yml` とProxy専用Dockerfileに閉じ込めている。実CAがない通常環境で、既存DockerfileがCAを要求しないことを静的テストで確認する。

```bash
python -m pytest tests/unit/test_proxy_dockerfiles.py -v
```

期待: `test_base_python_images_remain_ca_agnostic_for_non_proxy_workflow` を含めPASS。

## 1. Proxy/CA preflight

```bash
make proxy-preflight
./scripts/verify_proxy_ca.sh
./scripts/verify_stack.sh
```

期待: すべてexit 0。

外部HTTPSのTLS/Proxy確認例。レスポンス本文や認証情報は表示しない。

```bash
docker compose -f docker-compose.yml -f compose.proxy.yml --profile splunk exec -T console-api \
  python -c "import httpx; r=httpx.get('https://api.newrelic.com', timeout=15); print('external-tls-probe:', r.status_code)"
```

401/404等でもHTTP statusを取得できればTLS/Proxy経路は成立している。TLS例外やProxy接続例外はFAIL。

内部URLの設定確認:

```bash
grep -F 'SPLUNK_SEARCH_URL: https://splunk:8089' compose.proxy.yml
grep -F 'NEW_RELIC_MCP_URL: http://newrelic-mcp:8000/mcp' compose.proxy.yml
```

## 2. Python unit suite

ターゲット環境では必ずPython 3.11を使用する。

```bash
set -a
. ./.env
set +a

docker run --rm \
  -v "$PWD:/workspace" -w /workspace \
  -v "$PWD/certs/zscaler-ca.crt:/usr/local/share/ca-certificates/zscaler-ca.crt:ro" \
  -e HTTP_PROXY -e HTTPS_PROXY -e NO_PROXY \
  python:3.11-slim sh -lc '
    update-ca-certificates >/dev/null &&
    python -m pip install -q -e ".[dev]" &&
    python -m pytest tests/unit -q
  '
```

期待: 0 failed。

## 3. Python offline integration subset

サービス起動を必要としないsubsetのみをここで実行する。`test_demo_app.py`、`test_trace_context.py`、`test_phase4_evidence_integration.py` は実サービス/Splunkを必要とするため、後続のstack/live検証で実行する。

```bash
set -a
. ./.env
set +a

docker run --rm \
  -v "$PWD:/workspace" -w /workspace \
  -v "$PWD/certs/zscaler-ca.crt:/usr/local/share/ca-certificates/zscaler-ca.crt:ro" \
  -e HTTP_PROXY -e HTTPS_PROXY -e NO_PROXY \
  python:3.11-slim sh -lc '
    update-ca-certificates >/dev/null &&
    python -m pip install -q -e ".[dev]" &&
    python -m pytest -q \
      tests/integration/test_payment_flow.py \
      tests/integration/test_phase5_console_api.py
  '
```

期待: 0 failed。

Demo Commerce stack起動後は次も実行する。

```bash
python -m pytest -q tests/integration/test_demo_app.py tests/integration/test_trace_context.py
```

Splunk bootstrap後は `tests/integration/test_phase4_evidence_integration.py` を実行する。

## 4. Console Node tests and production build

```bash
set -a
. ./.env
set +a

docker run --rm \
  -v "$PWD/console:/app" -w /app \
  -v "$PWD/certs/zscaler-ca.crt:/certs/zscaler-ca.crt:ro" \
  -e HTTP_PROXY -e HTTPS_PROXY -e NO_PROXY \
  -e NODE_EXTRA_CA_CERTS=/certs/zscaler-ca.crt \
  -e npm_config_cafile=/certs/zscaler-ca.crt \
  node:22-slim sh -lc 'npm install && npm test && npm run build'
```

期待: Node tests 0 failed、Vite production build exit 0。

## 5. Vendored New Relic MCP tests

```bash
set -a
. ./.env
set +a

docker run --rm \
  -v "$PWD/vendor/newrelic-mcp-server:/workspace" -w /workspace \
  -v "$PWD/certs/zscaler-ca.crt:/usr/local/share/ca-certificates/zscaler-ca.crt:ro" \
  -e HTTP_PROXY -e HTTPS_PROXY -e NO_PROXY \
  python:3.12-slim sh -lc '
    update-ca-certificates >/dev/null &&
    python -m pip install -q -e ".[dev]" &&
    python -m pytest -q
  '
```

期待: 0 failed。

## 6. Static Compose validation

資格情報が補間された完全configを標準出力へ出さない。

```bash
docker compose -f docker-compose.yml -f compose.proxy.yml --profile splunk config --quiet
docker compose -f docker-compose.yml -f compose.proxy.yml --profile splunk config --services
```

期待: exit 0。service listに `splunk`, Demo Commerce各service, `newrelic-mcp`, `console-api`, `console-ui` を含む。

## 7. Splunk HEC and read-only verification

```bash
./scripts/bootstrap_splunk_readonly.sh
./scripts/verify_stack.sh
```

期待:

```text
HEC -> code 0
ai_search -> effective capability search only
_internal -> inaccessible
poc_observability -> searchable
```

Live Search integration:

```bash
set -a
. ./.env
set +a
export SPLUNK_SEARCH_URL=https://localhost:8089

docker run --rm --network host \
  -v "$PWD:/workspace" -w /workspace \
  -v "$PWD/certs/zscaler-ca.crt:/usr/local/share/ca-certificates/zscaler-ca.crt:ro" \
  -e HTTP_PROXY -e HTTPS_PROXY -e NO_PROXY \
  -e SPLUNK_SEARCH_URL -e SPLUNK_SEARCH_USERNAME -e SPLUNK_SEARCH_PASSWORD -e SPLUNK_SEARCH_VERIFY_SSL \
  python:3.11-slim sh -lc '
    update-ca-certificates >/dev/null &&
    python -m pip install -q -e ".[dev]" &&
    python -m pytest tests/integration/test_splunk_search_integration.py -v
  '
```

期待: PASS。

## 8. New Relic MCP transport contract

```bash
set -a
. ./.env
set +a
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp
```

Python 3.11 test containerで次を実行する。

```bash
python -m pytest tests/integration/test_newrelic_mcp_transport_integration.py -v
```

期待: `tools/list` PASS。MCP endpointはStreamable HTTP `/mcp`。

## 9. Selected LLM provider-only live test

- Azure OpenAI: `tests/integration/test_phase4_live_azure_openai_analysis.py`
- Ollama: `tests/integration/test_phase4_live_ollama_analysis.py`
- OpenAI: `tests/integration/test_phase4_live_openai_analysis.py`

期待: selected provider test PASS、TLS/Proxy errorなし。

## 10. Phase 4 complete live E2E

必要な `.env` をshellへexportし、host-side endpointsを使う。

```bash
export SPLUNK_SEARCH_URL=https://localhost:8089
export NEW_RELIC_MCP_URL=http://localhost:8000/mcp
python -m pytest tests/integration/test_phase4_live_end_to_end.py -v
```

実際は `python:3.11-slim --network host` で実行する。期待: `IncidentAnalysis` がPydanticおよびEvidence/Query/Contradiction reference validationをPASS。

## 11. Phase 5 live Console E2E

```bash
export RUN_PHASE5_LIVE_TESTS=1
export API_GATEWAY_URL=http://localhost:8085
python -m pytest tests/integration/test_phase5_live_console.py -v
```

実際はPhase 4同様に `python:3.11-slim --network host` で実行する。期待: PASS、AG-UI progress + A2UI result。

## 12. Browser verification

ブラウザで:

```text
http://TARGET_VM_IP_OR_DNS:5173
```

既知のrequest IDと2時間以内の期間を入力し、以下すべてが終了することを確認する。

```text
相関
Splunkの調査
New Relicの調査
証拠の相関
LLM分析
```

表示は日本語既定、technical IDは原文維持、Read Only、Evidence-firstであることを確認する。

## 13. Secret marker check

ログを一時ファイルへ保存し、**値ではなく変数名形式のみ**を検査する。

```bash
docker compose -f docker-compose.yml -f compose.proxy.yml --profile splunk logs --no-color > /tmp/poc-proxy-logs.txt
python3 - <<'PY'
from pathlib import Path
text = Path('/tmp/poc-proxy-logs.txt').read_text(errors='replace')
for marker in [
    'AZURE_OPENAI_API_KEY=',
    'OPENAI_API_KEY=',
    'NEW_RELIC_LICENSE_KEY=',
    'SPLUNK_HEC_TOKEN=',
    'SPLUNK_SEARCH_PASSWORD=',
]:
    assert marker not in text, marker
print('secret-marker-check: PASS')
PY
rm -f /tmp/poc-proxy-logs.txt
```
