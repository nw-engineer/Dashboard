# Phase 4 Evidence Correlation Design

Date: 2026-09-03
Status: Proposed for implementation
Project: New Relic + Splunk + A2UI/AG-UI Observability AI PoC

## 1. Goal

Phase 4 adds an evidence-first correlation layer between the already-validated observability data plane and the later AG-UI/A2UI presentation layer.

The first supported investigation starts from a `request.id`, resolves the corresponding `trace.id` from Splunk, collects evidence from both Splunk and New Relic MCP, normalizes that evidence into one model, detects conflicts and evidence gaps, and produces a structured incident analysis.

The phase must preserve the PoC safety boundary:

- observe, investigate, correlate, recommend only;
- no production/environment changes;
- Splunk remains read-only through both tool guard and RBAC;
- New Relic access remains through MCP and is treated as read-only;
- no root-cause assertion without supporting evidence.

## 2. Confirmed Preconditions

Phase 4 assumes the following Phase 1-3 capabilities are already working and must not be redesigned:

- Demo Commerce and five fault scenarios;
- New Relic Python Agent and distributed trace correlation;
- New Relic Change Tracking and MCP analysis;
- Splunk HEC structured JSON logging;
- `request.id` propagation;
- `trace.id` correlation between Splunk and New Relic `Transaction.traceId`;
- Splunk Read Only Search Tool;
- Splunk RBAC restricted to `search` on `poc_observability`;
- maximum Splunk search window of two hours;
- maximum Splunk result count of 200;
- dangerous SPL commands rejected by the tool guard;
- integration test proving `request.id -> trace.id -> same trace` resolution.

Important New Relic constraint: a correlated trace may be available through `Transaction.traceId` even when no matching `Span` event is available. Phase 4 must therefore distinguish observed Transaction evidence from observed Span evidence.

## 3. Scope

### 3.1 In scope

The first Phase 4 vertical slice supports:

1. user/request supplies a `request.id`;
2. Splunk resolves the `trace.id`;
3. Splunk evidence for the request/trace is collected;
4. New Relic MCP evidence for the same trace and relevant services is collected;
5. evidence is normalized;
6. contradictions and gaps are identified deterministically;
7. the normalized bundle is passed to an analyzer;
8. a structured `IncidentAnalysis` is returned.

The evidence model must be reusable for later investigation entry points, including service/time-range investigations, but those entry points are not part of the first vertical slice.

### 3.2 Out of scope

- AG-UI/A2UI rendering (Phase 5);
- automated remediation or environment mutation;
- autonomous rollback/restart/configuration changes;
- replacing New Relic MCP with direct New Relic API calls;
- replacing Splunk Search Tool with arbitrary Splunk administrative access;
- generic open-ended observability query planning;
- long-term evidence storage/database;
- a vendor-specific LLM dependency in the Phase 4 core model.

## 4. Architectural Approach

Use an Evidence-first Adapter architecture.

```text
User / API
    |
    v
InvestigationOrchestrator
    |
    +--> CorrelationResolver ------> SplunkSearchClient
    |                                  |
    |                               trace.id
    |
    +--> SplunkEvidenceCollector --> SplunkSearchClient
    |
    +--> NewRelicEvidenceCollector -> NewRelicMcpGateway
    |
    v
EvidenceCorrelator
    |
    +--> contradiction detection
    +--> evidence-gap detection
    |
    v
EvidenceBundle
    |
    v
IncidentAnalyzer
    |
    v
IncidentAnalysis
```

The orchestrator coordinates calls. Collectors do not call one another. The correlator does not perform I/O. The analyzer receives only a normalized evidence bundle rather than raw tool responses as its primary input.

This separation makes data acquisition, evidence interpretation, and natural-language reasoning independently testable.

## 5. Package Layout

```text
agent/
├── splunk/                     # existing Phase 3 code
│   ├── client.py
│   ├── guard.py
│   └── models.py
│
├── evidence/
│   ├── __init__.py
│   ├── models.py               # shared evidence schemas
│   ├── correlation.py          # request.id -> trace.id resolution
│   ├── splunk_collector.py
│   ├── newrelic_collector.py
│   └── correlator.py           # deterministic merge/conflict/gap logic
│
├── analysis/
│   ├── __init__.py
│   ├── models.py               # IncidentAnalysis output schema
│   ├── prompt.py               # analysis contract and safety rules
│   └── analyzer.py             # provider-neutral analyzer interface
│
└── orchestrator.py

tests/
├── unit/
│   ├── test_evidence_models.py
│   ├── test_correlation_resolver.py
│   ├── test_splunk_evidence_collector.py
│   ├── test_newrelic_evidence_collector.py
│   ├── test_evidence_correlator.py
│   ├── test_incident_analysis.py
│   └── test_investigation_orchestrator.py
│
└── integration/
    ├── test_splunk_search_integration.py       # existing
    └── test_phase4_evidence_integration.py     # new
```

## 6. Evidence Data Model

### 6.1 EvidenceSource

```text
newrelic
splunk
```

### 6.2 EvidenceCategory

Initial categories:

```text
transaction
span
golden_metric
db
dependency
exception
capacity
deployment
application
correlation
```

The enum may be expanded later without changing the orchestrator contract.

### 6.3 EvidenceItem

Each observable fact exposed to the analyzer is represented as one `EvidenceItem`.

Required fields:

```text
evidence_id        stable ID inside one investigation
source             newrelic | splunk
category           EvidenceCategory
summary            concise factual description
facts              dict[str, JSON-compatible value]
query_or_tool       exact SPL disclosure or New Relic MCP tool name/NRQL disclosure
```

Optional correlation fields:

```text
service_name
observed_at
request_id
trace_id
entity_guid
```

Rules:

- `summary` must describe observed evidence, not infer a root cause;
- `facts` preserves machine-usable values such as duration, status code, retry count, deployment version, or query duration;
- evidence IDs are referenced by hypotheses and contradictions;
- credentials, tokens, passwords, card data, and other secrets are never copied into evidence;
- raw SQL text is not introduced by Phase 4.

### 6.4 QueryDisclosure

Every external observation must be traceable to how it was obtained.

For Splunk:

```text
source=splunk
operation=search
query=<normalized safe SPL>
earliest=<timestamp>
latest=<timestamp>
```

For New Relic:

```text
source=newrelic
operation=<MCP tool name>
arguments=<non-secret arguments or NRQL disclosure>
```

The user-facing `Queries Used` section is built from these disclosures.

### 6.5 EvidenceBundle

```text
investigation_id
request_id
trace_id
evidence: list[EvidenceItem]
contradictions: list[EvidenceContradiction]
gaps: list[EvidenceGap]
queries_used: list[QueryDisclosure]
```

The bundle is the only primary input to the incident analyzer.

## 7. Correlation Resolver

### 7.1 Initial contract

```python
resolve_request(request_id, earliest, latest) -> CorrelationContext
```

`CorrelationContext` contains:

```text
request_id
trace_id
services
```

### 7.2 Resolution behavior

The resolver searches Splunk through the existing `SplunkSearchClient`.

It must:

- stay within the two-hour limit;
- use only `poc_observability` through the existing guard;
- find matching request events;
- collect non-empty `trace.id` values;
- require exactly one unique `trace.id` for the initial vertical slice;
- return observed service names where available.

Failure cases are explicit:

```text
CorrelationNotFound       no matching request evidence
TraceIdNotFound           request found but no trace.id
AmbiguousTraceId          more than one trace.id for one request.id
```

The resolver must not guess which trace is correct.

## 8. Splunk Evidence Collector

The collector uses the existing safe search client rather than direct HTTP calls.

For the initial vertical slice it collects the correlated trace and normalizes meaningful structured events:

```text
application.request / application.response -> application
db.query                           -> db
dependency.call                    -> dependency
capacity.snapshot                  -> capacity
exception                          -> exception
deployment                         -> deployment
```

The collector should prefer a single trace-oriented query and normalize each returned structured log row into evidence items.

Representative `facts`:

- `http.status_code`;
- `duration_ms`;
- `db.system`;
- `db.query_name`;
- `db.duration_ms`;
- `dependency.name`;
- `dependency.status_code`;
- `dependency.duration_ms`;
- `retry_count`;
- `queue_wait_ms`;
- `active_workers`;
- `inflight_requests`;
- `error.type`;
- `error.message`;
- `service.version`;
- `scenario.id`.

The `_raw` JSON expansion already implemented by the Phase 3 client remains the normalization boundary for missing Splunk result fields.

## 9. New Relic MCP Gateway and Collector

### 9.1 Transport boundary

Phase 4 core code must not depend directly on a specific MCP transport implementation. Introduce a small gateway protocol:

```python
class NewRelicMcpGateway(Protocol):
    async def call_tool(self, name: str, arguments: dict[str, object]) -> object: ...
```

The real gateway can later bind to the MCP transport used in the deployment. Unit tests use a fake gateway.

No New Relic API key or direct REST client is introduced into the collector.

### 9.2 Tool strategy

Observed working New Relic MCP tools include:

```text
execute_nrql_query
analyze_transactions
analyze_golden_metrics
analyze_deployment_impact
list_change_events
```

The first vertical slice uses a conservative sequence:

1. trace correlation through `Transaction.traceId` using `execute_nrql_query` or an equivalent MCP-supported transaction lookup;
2. transaction evidence for correlated services;
3. golden metrics only when useful for impact/context;
4. deployment/change evidence when timing or service version makes it relevant.

Because matching `Span` events are not guaranteed, Span evidence is optional. The collector records an evidence gap when span-level data is requested/needed but unavailable.

### 9.3 New Relic evidence categories

Typical normalized items:

```text
Transaction duration/status        -> transaction
Golden metric latency/error rate   -> golden_metric
Matching Span facts, when present  -> span
Change Tracking event              -> deployment
Deployment impact comparison       -> deployment
```

MCP output is never copied blindly into a root-cause statement. The collector extracts factual observations and records the MCP operation that produced them.

## 10. Deterministic Correlator

The correlator merges evidence without invoking an LLM.

Responsibilities:

- group evidence by service and category;
- verify `request_id`/`trace_id` consistency where present;
- identify known contradictions;
- identify evidence gaps relevant to later reasoning;
- preserve all source-specific evidence rather than choosing a preferred source.

### 10.1 Initial contradiction rules

Examples:

```text
Splunk dependency.status_code >= 500
but New Relic reports no error in the corresponding transaction window
    -> contradiction/degraded agreement

Splunk db.duration_ms is low
while a hypothesis claims DB latency
    -> evidence against DB-latency hypothesis

New Relic deployment/change evidence occurs near latency regression
while Splunk reports normal DB/dependency timings
    -> mutually supporting observations, not automatic proof of causation
```

A contradiction object contains:

```text
summary
left_evidence_ids
right_evidence_ids
```

### 10.2 Evidence gaps

Examples:

```text
span evidence unavailable
no deployment event in requested window
no exception evidence
request matched but service-level timing field absent
```

Absence of a log/event is recorded carefully as "not observed in the searched evidence," not as proof the event never happened.

## 11. Incident Analysis Model

The analyzer returns structured data, not free-form text only.

```text
incident_summary
impact
likely_cause
confidence
supporting_evidence_ids
alternative_hypotheses
recommended_checks
recommended_actions
new_relic_evidence_ids
splunk_evidence_ids
contradictions
queries_used
```

`confidence` is initially:

```text
low
medium
high
```

A high-confidence likely cause must cite evidence IDs from the bundle. If no sufficient evidence supports a cause, `likely_cause` must explicitly state that the cause is undetermined rather than inventing one.

Recommended actions are advisory only.

## 12. Analyzer Contract and Safety Prompt

Phase 4 core remains provider-neutral:

```python
class IncidentAnalyzer(Protocol):
    async def analyze(self, bundle: EvidenceBundle) -> IncidentAnalysis: ...
```

The prompt/contract enforces:

1. do not assert a cause without cited evidence;
2. correlation is not causation;
3. if Span evidence is unavailable, do not infer internal service bottleneck solely from parent Transaction duration;
4. expose contradictions rather than hiding them;
5. distinguish observations from hypotheses;
6. actions are recommendations only;
7. use only evidence present in the supplied bundle;
8. every likely cause and alternative hypothesis must reference supporting or opposing evidence IDs;
9. never fabricate a query/tool call that is not present in `queries_used`.

A deterministic/fake analyzer is used in unit tests. A concrete LLM provider adapter can be connected without changing collectors or the correlator.

## 13. Investigation Orchestrator

Initial method:

```python
investigate_request_id(
    request_id: str,
    earliest: datetime,
    latest: datetime,
) -> IncidentAnalysis
```

Sequence:

```text
1. validate time range
2. resolve request.id -> trace.id and service set
3. collect Splunk evidence for trace
4. collect New Relic evidence for trace/services
5. correlate evidence and create gaps/contradictions
6. call IncidentAnalyzer
7. validate output references only known evidence/query IDs
8. return IncidentAnalysis
```

The orchestrator is the future integration boundary for Phase 5 AG-UI events.

## 14. Error Handling

External-system errors must remain distinguishable:

```text
CorrelationNotFound
TraceIdNotFound
AmbiguousTraceId
SplunkEvidenceUnavailable
NewRelicEvidenceUnavailable
AnalysisUnavailable
InvalidAnalysisReference
```

Partial evidence behavior:

- Splunk correlation failure stops the initial `request.id` flow because `trace.id` cannot be established safely;
- after correlation succeeds, one evidence source may fail and the investigation may continue with a recorded gap and reduced confidence;
- the final analysis must disclose unavailable evidence sources;
- credentials and raw secrets must never appear in exception messages returned to the analyzer/UI.

## 15. Testing Strategy

All implementation follows RED -> GREEN -> REFACTOR.

### 15.1 Model tests

- valid EvidenceItem creation;
- evidence/query ID uniqueness requirements where enforced;
- JSON-compatible facts;
- IncidentAnalysis cannot reference unknown evidence IDs.

### 15.2 Correlation tests

- one request / one trace succeeds;
- request not found;
- request present but no trace ID;
- multiple trace IDs rejected;
- service names collected without requiring them.

### 15.3 Splunk collector tests

- each known event type maps to the correct evidence category;
- expected fields are preserved in `facts`;
- unknown structured events are ignored or mapped conservatively without inventing meaning;
- query disclosure is recorded.

### 15.4 New Relic collector tests

Using a fake MCP gateway:

- `Transaction.traceId` evidence normalizes correctly;
- unavailable Span data produces a gap, not a fabricated Span;
- deployment/change output normalizes to deployment evidence;
- MCP tool errors are surfaced as evidence-source availability errors;
- tool names and non-secret arguments are disclosed.

### 15.5 Correlator tests

- matching observations are retained;
- contradictions are represented, not resolved by deletion;
- gaps use "not observed" semantics;
- no causal conclusion is produced by the correlator.

### 15.6 Analyzer contract tests

- likely cause cites valid evidence IDs;
- unknown evidence references are rejected;
- empty/insufficient bundle permits an "undetermined" conclusion;
- recommended actions remain advisory.

### 15.7 Orchestrator tests

- executes the expected sequence;
- refuses ambiguous trace correlation;
- supports partial New Relic failure after correlation with reduced evidence;
- does not bypass the existing SplunkSearchClient guard.

### 15.8 Integration test

On the VM, the first Phase 4 integration test uses a real Demo Commerce request and real Splunk, plus the configured New Relic MCP transport when available:

```text
request.id
 -> Splunk trace.id
 -> Splunk EvidenceItem[]
 -> New Relic Transaction.traceId evidence
 -> EvidenceBundle
```

The LLM provider does not need to be part of the first data-correlation integration test; analyzer integration can be tested separately once its provider adapter is configured.

## 16. Initial Acceptance Criteria

Phase 4 core is complete when:

1. `request.id` resolves to exactly one trace or fails explicitly;
2. correlated Splunk structured logs normalize into EvidenceItems;
3. New Relic MCP transaction evidence normalizes into EvidenceItems;
4. New Relic and Splunk evidence are preserved together in one EvidenceBundle;
5. missing Span evidence is represented as a gap;
6. contradictions can be represented without suppressing either source;
7. the analyzer cannot legally reference evidence or queries not in the bundle;
8. likely cause output is evidence-referenced or explicitly undetermined;
9. recommended actions are advisory and no mutation tool exists in the Phase 4 surface;
10. all new unit tests pass;
11. VM integration proves the correlation bundle using real Splunk and New Relic MCP data.

## 17. Phase 5 Compatibility

Phase 5 must consume `IncidentAnalysis` rather than raw MCP/Splunk responses.

Suggested mapping:

```text
incident_summary / impact      -> HealthSummary
supporting evidence            -> EvidenceCard / TraceCard / LogTable
likely cause / confidence      -> HypothesisCard
recommended checks/actions     -> RecommendationCard
queries_used                   -> QueryDisclosure
```

AG-UI can expose investigation state transitions without changing Phase 4 contracts:

```text
correlating_request
searching_splunk
searching_newrelic
correlating_evidence
analyzing
completed / partial / failed
```

## 18. Implementation Order

The implementation plan should preserve this dependency order:

```text
Evidence models
 -> Correlation resolver
 -> Splunk collector
 -> MCP gateway protocol + New Relic collector
 -> Deterministic correlator
 -> IncidentAnalysis model/validation
 -> Orchestrator
 -> Analyzer provider adapter
 -> VM integration
```

This keeps each layer testable before adding the next external dependency.
