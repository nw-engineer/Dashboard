# Phase 5 AG-UI / A2UI Troubleshooting Console Design

Updated: 2026-09-03

## 1. Goal

Build the Phase 5 AI Troubleshooting Console on top of the completed Phase 4 Evidence-first investigation pipeline.

Phase 5 must provide two things without weakening Phase 4 contracts:

1. AG-UI lifecycle/progress streaming while an investigation is running.
2. A2UI v0.9.1 rendering of the validated `InvestigationResult` as a troubleshooting console.

The Phase 4 path is already complete and proven by the real-source full E2E test. Phase 5 therefore treats `InvestigationOrchestrator` and `InvestigationResult` as the trusted application boundary and adds presentation/transport behavior around them.

## 2. Non-goals

- Do not change Splunk collection semantics or read-only RBAC.
- Do not change New Relic MCP collection semantics or add direct New Relic write APIs.
- Do not change `EvidenceBundle`, `IncidentAnalysis`, `IncidentAnalyzer`, or reference-validation semantics.
- Do not let the LLM generate arbitrary executable frontend code.
- Do not expose model chain-of-thought/reasoning messages.
- Do not add restart, rollback, deploy, delete, configuration mutation, or any other remediation action.
- Do not implement provider failover.
- Do not build a general-purpose chat product in Phase 5.
- Do not add persistence, authentication, multi-user tenancy, or investigation history in this PoC phase.

## 3. Existing Phase 4 contract to preserve

The current orchestration entry point remains the primary investigation API:

```python
async def investigate_request_id(
    self,
    request_id: str,
    earliest: datetime,
    latest: datetime,
) -> InvestigationResult:
    ...
```

The result remains:

```python
class InvestigationResult(BaseModel):
    bundle: EvidenceBundle
    analysis: IncidentAnalysis
```

The safety boundary remains:

```text
EvidenceBundle
  -> IncidentAnalyzer
  -> IncidentAnalysis
  -> validate_analysis_references(bundle, analysis)
  -> InvestigationResult
```

Phase 5 must never bypass `validate_analysis_references()` and must never manufacture replacement Evidence IDs, Query IDs, Contradiction IDs, or Gap IDs.

## 4. Protocol versions and SDK choices

### 4.1 A2UI

Target A2UI **v0.9.1**, the current production release as of 2026-09-03.

For the web client:

```text
@a2ui/react
@a2ui/web_core
```

Use the v0.9 API surface (`@a2ui/web_core/v0_9`) rather than implementing message parsing, surface state, data binding, and schema processing from scratch.

The React renderer is an official stable renderer for v0.9.1.

### 4.2 AG-UI

Use the official Python package:

```text
ag-ui-protocol
```

Use official lifecycle event types from `ag_ui.core`:

```text
RUN_STARTED
RUN_FINISHED
RUN_ERROR
STEP_STARTED
STEP_FINISHED
```

The transport endpoint is a FastAPI streaming endpoint using Server-Sent Events (SSE). AG-UI events carry investigation lifecycle/progress. For this PoC, A2UI messages are carried in an **application-defined AG-UI binding** using `CUSTOM` events. This is our explicit bridge between the two protocols: AG-UI supplies ordered event transport, while the nested payload remains an unmodified A2UI envelope for the browser renderer. We do not claim the `CUSTOM` event name below is a universal AG-UI/A2UI wire standard.

## 5. Target architecture

```text
Browser
  |
  v
React AI Troubleshooting Console
  |
  | POST /api/investigations/stream
  | AG-UI event stream over SSE
  v
Phase 5 FastAPI Endpoint
  |
  +--> AG-UI Run/Step Events
  |
  v
InvestigationOrchestrator
  |
  +--> CorrelationResolver
  +--> SplunkEvidenceCollector
  +--> NewRelicEvidenceCollector
  +--> EvidenceCorrelator
  +--> IncidentAnalyzer
  +--> validate_analysis_references()
  |
  v
InvestigationResult
  |
  v
Deterministic A2UI Presenter
  |
  +--> A2UI createSurface
  +--> A2UI updateComponents
  +--> A2UI updateDataModel
  |
  v
AG-UI CUSTOM events containing A2UI payloads
  |
  v
@a2ui/web_core + @a2ui/react
  |
  v
Troubleshooting Result UI
```

## 6. Input UI for the Phase 5 vertical slice

The current Phase 4 orchestrator is request-ID centric, so Phase 5 must not expose controls that appear functional but are ignored.

The first working console uses:

```text
Request ID   required
Time Range   required: earliest/latest
```

The result header displays derived context:

```text
Service(s)   derived from correlated evidence/context
Environment  derived from evidence facts when available, otherwise "unknown"
Trace ID     derived from CorrelationContext / EvidenceBundle
```

A free-form investigation question is deferred until a later phase because the current trusted application boundary is `investigate_request_id(...)`; adding an unconstrained question now would create semantics not implemented by Phase 4.

This is a deliberate YAGNI decision for the PoC. It keeps the UI truthful while still matching the intended troubleshooting-console experience.

## 7. Progress reporting without changing Phase 4 result contracts

### 7.1 New progress boundary

Add an optional progress reporter to the orchestrator. The reporter is observational only and must never alter control flow.

```python
class InvestigationProgressReporter(Protocol):
    async def step_started(self, step_name: str) -> None:
        ...

    async def step_finished(self, step_name: str) -> None:
        ...
```

Provide a no-op implementation so existing callers need no behavior change.

### 7.2 Stable step names

Use exactly these machine-readable names:

```text
correlation
splunk
newrelic
correlate
analyze
```

Expected success sequence:

```text
STEP_STARTED correlation
STEP_FINISHED correlation
STEP_STARTED splunk
STEP_FINISHED splunk
STEP_STARTED newrelic
STEP_FINISHED newrelic
STEP_STARTED correlate
STEP_FINISHED correlate
STEP_STARTED analyze
STEP_FINISHED analyze
```

The endpoint wraps the complete run with:

```text
RUN_STARTED
...
RUN_FINISHED
```

If the run fails before `InvestigationResult` is produced:

```text
RUN_STARTED
...
RUN_ERROR
```

No `RUN_FINISHED` follows `RUN_ERROR`.

### 7.3 Partial evidence is not a transport failure

Existing Phase 4 behavior converts certain Splunk/New Relic collection failures into `EvidenceGap` objects and continues analysis.

Therefore:

- a collector becoming an `EvidenceGap` still receives `STEP_FINISHED`;
- it does not emit `RUN_ERROR` merely because one evidence source was unavailable;
- the resulting A2UI must visibly show the gap.

Only an exception that escapes the orchestrator becomes AG-UI `RUN_ERROR`.

## 8. Deterministic A2UI presentation boundary

### 8.1 Core rule

The LLM does not author the Phase 5 UI structure.

The server transforms the already-validated `InvestigationResult` into a fixed A2UI surface with deterministic component selection and data binding.

```text
InvestigationResult
  -> TroubleshootingViewModel
  -> A2UI Presenter
  -> A2UI v0.9.1 messages
```

The presenter is pure/deterministic: equal input produces semantically equal view-model and A2UI output apart from generated transport/run identifiers.

### 8.2 View-model

Introduce a presentation model independent of A2UI wire syntax:

```python
class TroubleshootingViewModel(BaseModel):
    investigation_id: str
    request_id: str
    trace_id: str
    services: list[str]
    environment: str
    incident_summary: str
    impact: str
    likely_cause: str
    confidence: str
    timeline: list[TimelineEntry]
    evidence: list[EvidenceView]
    evidence_gaps: list[EvidenceGapView]
    contradictions: list[ContradictionView]
    hypotheses: list[HypothesisView]
    recommended_checks: list[str]
    recommended_actions: list[str]
    queries: list[QueryDisclosureView]
```

This extra boundary prevents React/A2UI details from leaking into the Evidence and Analysis domain models.

### 8.3 Evidence IDs and gap IDs

`EvidenceGap.gap_id` is never placed in an Evidence-ID field.

The presenter preserves these namespaces separately:

```text
EvidenceItem.evidence_id           -> evidence views
EvidenceGap.gap_id                 -> gap views
EvidenceContradiction.contradiction_id -> contradiction views
QueryDisclosure.disclosure_id     -> query views
```

The UI may display a gap ID as a gap identifier, but must never label it as Evidence.

## 9. A2UI surface and custom catalog

Use one surface per investigation result:

```text
surfaceId = investigation_id
```

The application registers a small troubleshooting catalog instead of exposing arbitrary components.

Phase 5 custom components:

```text
HealthSummary
TimelineChart
TraceCard
EvidenceCard
EvidenceGapCard
LogTable
HypothesisCard
RecommendationCard
QueryDisclosure
```

### 9.1 HealthSummary

Displays:

```text
Incident Summary
Impact
Likely Cause
Confidence
```

It is informational only.

### 9.2 TraceCard

Displays:

```text
request.id
trace.id
services
investigation_id
```

### 9.3 TimelineChart

Uses `EvidenceItem.observed_at` entries only.

Entries without `observed_at` are excluded from the chart but remain available in Evidence cards/tables.

Each point carries:

```text
evidence_id
source
category
service_name
observed_at
summary
```

The chart represents temporal correlation only. UI copy must not imply causation merely because events are adjacent.

### 9.4 EvidenceCard

Displays normalized `EvidenceItem` fields:

```text
evidence_id
source
category
summary
service_name
observed_at
query_or_tool
facts
```

Facts are rendered as data, never executed as HTML/JavaScript.

### 9.5 EvidenceGapCard

Displays:

```text
gap_id
source/category when present
summary
```

The visual treatment must clearly distinguish "missing/unavailable evidence" from supporting evidence.

### 9.6 LogTable

Contains Splunk-origin Evidence items only.

It provides compact tabular access to normalized fields and selected facts; it does not expose a writable SPL console.

### 9.7 HypothesisCard

Displays:

```text
likely cause
supporting Evidence IDs
alternative hypotheses
supporting/opposing Evidence IDs
contradiction IDs when relevant
```

Evidence references remain clickable/display references only in Phase 5; no mutation action is attached.

### 9.8 RecommendationCard

Displays separately:

```text
Recommended Checks
Recommended Actions
```

The card includes an explicit advisory label such as:

```text
Recommendation only - no action is executed automatically.
```

No action button invokes infrastructure changes.

### 9.9 QueryDisclosure

Displays the read-only collection/query record:

```text
disclosure_id
source
operation
arguments
```

Sensitive values must already be absent from these Phase 4 models. The Phase 5 error path must not append process environment or secret-bearing exception text.

## 10. A2UI message sequence

For a successful result, emit A2UI v0.9.1 messages in this logical order:

```text
createSurface
updateComponents
updateDataModel
```

A2UI v0.9/v0.9.1 does **not** use the v0.8 `beginRendering` message. `createSurface` initializes the surface and rendering lifecycle. `deleteSurface` is emitted only when the application explicitly replaces/removes a prior result surface.

The implementation must use the official v0.9.1 schema/types from the installed A2UI packages rather than hand-maintaining a second copy of the protocol schema.

For this PoC binding, A2UI payloads travel inside AG-UI `CUSTOM` events with a stable application-defined name:

```text
a2ui.message
```

Example envelope shape:

```json
{
  "type": "CUSTOM",
  "name": "a2ui.message",
  "value": {
    "createSurface": {
      "surfaceId": "inv-..."
    }
  }
}
```

The final A2UI rendering messages must be emitted after Phase 4 reference validation has succeeded.

## 11. AG-UI endpoint contract

Create a dedicated Phase 5 FastAPI application/route rather than placing console concerns in Demo Commerce services.

Endpoint:

```text
POST /api/investigations/stream
```

Request body:

```json
{
  "request_id": "manual-trace-check-001",
  "earliest": "2026-09-03T04:00:00Z",
  "latest": "2026-09-03T04:10:00Z"
}
```

Validation rules:

- `request_id` must be non-empty after trimming.
- datetimes must be timezone-aware.
- `earliest < latest`.
- maximum requested window remains consistent with the existing Splunk safety limit; the UI/API must not become a bypass for Phase 3/4 search bounds.

Response:

```text
Content-Type: text/event-stream
```

AG-UI run identity:

```text
thread_id = stable frontend-provided/generated console thread ID
run_id    = unique per investigation submission
```

The Phase 5 PoC may generate `thread_id` client-side and `run_id` server-side if not supplied.

## 12. Error handling and sanitization

### 12.1 Public error contract

Map escaped investigation failures to a small stable set of public codes, for example:

```text
INVALID_REQUEST
CORRELATION_NOT_FOUND
CORRELATION_AMBIGUOUS
INVESTIGATION_FAILED
```

`RUN_ERROR.message` must be sanitized user-facing text.

Do not stream:

- raw exception `repr`;
- stack traces;
- process environment;
- API keys;
- Splunk passwords/tokens;
- New Relic credentials;
- raw upstream provider response bodies.

### 12.2 Existing partial-source behavior

`SplunkEvidenceUnavailable` and `NewRelicEvidenceUnavailable` already become gaps within the orchestrator. Phase 5 preserves that behavior and renders the gap instead of reclassifying it as a run failure.

## 13. Frontend structure

Create a standalone frontend directory:

```text
console/
```

Suggested structure:

```text
console/
  package.json
  src/
    app/
      App.tsx
    api/
      investigationStream.ts
    a2ui/
      processor.ts
      catalog.ts
      TroubleshootingSurface.tsx
    components/
      InvestigationForm.tsx
      InvestigationProgress.tsx
      HealthSummary.tsx
      TimelineChart.tsx
      TraceCard.tsx
      EvidenceCard.tsx
      EvidenceGapCard.tsx
      LogTable.tsx
      HypothesisCard.tsx
      RecommendationCard.tsx
      QueryDisclosure.tsx
```

Responsibilities remain separate:

- `investigationStream.ts`: AG-UI/SSE transport parsing only.
- `processor.ts`: forwards nested `a2ui.message` payloads to A2UI `MessageProcessor`.
- `catalog.ts`: only approved troubleshooting components.
- React components: visual rendering only; no observability querying.

## 14. Backend structure

Suggested files:

```text
agent/
  progress.py
  orchestrator.py

agent/ui/
  __init__.py
  models.py
  presenter.py
  a2ui.py

console_api/
  __init__.py
  app.py
  models.py
  stream.py
  errors.py
```

Responsibilities:

- `agent/progress.py`: progress protocol + no-op reporter.
- `agent/orchestrator.py`: emit optional progress callbacks around existing steps.
- `agent/ui/models.py`: `TroubleshootingViewModel` and child presentation models.
- `agent/ui/presenter.py`: deterministic `InvestigationResult -> TroubleshootingViewModel` mapping.
- `agent/ui/a2ui.py`: deterministic `TroubleshootingViewModel -> A2UI messages` mapping.
- `console_api/models.py`: input validation models.
- `console_api/stream.py`: maps progress/result/error to AG-UI events.
- `console_api/app.py`: FastAPI composition only.
- `console_api/errors.py`: sanitized public error mapping.

## 15. TDD strategy

Implementation must proceed RED -> GREEN -> REFACTOR.

### 15.1 Orchestrator progress tests

Add tests proving:

- exact happy-path step order;
- progress is optional and existing callers still work;
- a correlation exception stops later step events;
- a Splunk/New Relic evidence-unavailable condition still finishes that step and completes the run as partial evidence.

### 15.2 Presenter tests

Add tests proving:

- Phase 4 result maps to the expected view-model;
- environment fallback is `unknown` when absent;
- only Splunk evidence enters `LogTable` data;
- timeline excludes items without timestamps;
- gaps are kept separate from evidence;
- gap IDs never enter Evidence-ID collections;
- recommendations remain strings/advisory output only.

### 15.3 A2UI generation tests

Add tests proving:

- one surface is created using `investigation_id`;
- only catalog-approved component types are emitted;
- all evidence references originate from `EvidenceBundle.evidence`;
- A2UI data includes gap records under a separate namespace;
- render messages appear only after a complete validated `InvestigationResult` is available.

### 15.4 AG-UI stream tests

Add tests proving:

- `RUN_STARTED` is first;
- lifecycle step events preserve orchestrator order;
- A2UI `CUSTOM(name="a2ui.message")` events occur after analysis succeeds;
- `RUN_FINISHED` is last on success;
- `RUN_ERROR` is last on failure;
- public errors do not contain injected secret-like exception strings.

### 15.5 FastAPI endpoint tests

Add integration tests proving:

- valid request returns `text/event-stream`;
- invalid time range is rejected before invoking the orchestrator;
- endpoint stream is valid AG-UI event data;
- existing Phase 4 domain tests stay green.

### 15.6 Frontend tests

Use a lightweight React unit/integration setup and test:

- request form validation;
- AG-UI step display;
- nested A2UI custom events are forwarded to the A2UI message processor;
- only registered catalog components render;
- EvidenceGap has distinct presentation;
- RecommendationCard has no execute/remediate action control.

## 16. Security constraints

Phase 5 inherits all earlier constraints and adds UI-specific defense in depth:

- New Relic and Splunk remain read-only.
- No browser credential receives Splunk/New Relic/provider secrets.
- Browser calls only the Phase 5 console API.
- A2UI renderer accepts only the registered catalog.
- Evidence facts are rendered as text/data, not HTML.
- No arbitrary JavaScript or server-supplied component implementation is executed.
- No chain-of-thought/reasoning stream is exposed.
- No remediation tool or mutation endpoint exists.
- Recommendation display is clearly advisory.
- AG-UI error messages are sanitized.
- Existing search time-window limits are not bypassed.

## 17. Observability of the console itself

Keep Phase 5 self-observability minimal:

- log `run_id`, `investigation_id`, request ID, step name, and success/failure state;
- do not log full `EvidenceBundle` by default;
- do not log secret-bearing environment values;
- do not add a second telemetry platform in Phase 5.

This is sufficient for PoC troubleshooting without creating a recursive observability project.

## 18. Acceptance criteria

Phase 5 is complete when all of the following are true:

1. Existing Phase 4 unit/integration tests remain green.
2. An investigation can be submitted from the browser using request ID and time range.
3. The browser receives AG-UI lifecycle events while the investigation executes.
4. Progress visibly advances through correlation, Splunk, New Relic, correlation/build, and LLM analysis.
5. A successful validated `InvestigationResult` is converted to A2UI v0.9.1 messages.
6. The official React/web-core A2UI stack renders the troubleshooting result.
7. Health, trace, timeline, evidence, gaps, hypotheses, recommendations, and query disclosure are visible.
8. Gap IDs are never presented as Evidence IDs.
9. Partial source unavailability renders as EvidenceGap and does not incorrectly become `RUN_ERROR`.
10. Escaped failures produce sanitized `RUN_ERROR` events.
11. No write/remediation operation is exposed.
12. A Phase 5 integration test proves Browser/API-equivalent request -> AG-UI -> real orchestrator boundary -> A2UI result event ordering with test doubles, followed by a VM live smoke test against the already-proven real Phase 4 sources.

## 19. Explicit implementation order

The implementation plan should preserve this order so each boundary is testable before the next is added:

```text
1. ProgressReporter + orchestrator progress hooks
2. TroubleshootingViewModel + deterministic presenter
3. A2UI message builder
4. AG-UI event stream adapter
5. FastAPI console endpoint
6. React console + official A2UI renderer/catalog
7. Backend/frontend integration tests
8. VM live Phase 5 smoke test
```

## 20. Official references checked for this design

- A2UI Renderer Development Guide: https://a2ui.org/guides/renderer-development/
- A2UI Renderers: https://a2ui.org/renderers/
- A2UI Roadmap: https://a2ui.org/roadmap/
- A2UI Client Setup: https://a2ui.org/guides/client-setup/
- AG-UI Python SDK Overview: https://docs.ag-ui.com/sdk/python/core/overview
- AG-UI Python Events: https://docs.ag-ui.com/sdk/python/core/events
