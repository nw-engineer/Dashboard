# Phase 4 Multi-Provider LLM Design

Updated: 2026-09-03

## 1. Goal

Extend the existing Phase 4 real-LLM boundary so the same Evidence-first investigation flow can use one of three providers without changing `InvestigationOrchestrator`, collectors, correlation, or `IncidentAnalysis`:

- `ollama` — default, local `gpt-oss:20b`
- `azure_openai` — portable enterprise deployment option
- `openai` — retain the existing v9 OpenAI Responses API adapter

Provider selection is performed only at composition/configuration time via `LLM_PROVIDER`.

## 2. Non-goals

- Do not change Splunk or New Relic collection behavior.
- Do not add write/remediation actions.
- Do not allow provider-specific response objects beyond the adapter boundary.
- Do not add automatic provider failover in v10.
- Do not add Microsoft Entra ID authentication in v10; Azure OpenAI v10 uses API-key authentication only.
- Do not expose chain-of-thought/reasoning text in `IncidentAnalysis` or UI contracts.

## 3. Existing contract to preserve

The existing protocol remains unchanged:

```python
class IncidentAnalyzer(Protocol):
    async def analyze(self, bundle: EvidenceBundle) -> IncidentAnalysis:
        ...
```

`InvestigationOrchestrator` remains responsible for post-analysis reference validation:

```python
analysis = await self.analyzer.analyze(bundle)
validate_analysis_references(bundle, analysis)
```

Therefore every provider must return a validated `IncidentAnalysis` and never bypass Evidence ID / Query ID / Contradiction ID validation.

## 4. Target architecture

```text
InvestigationOrchestrator
        |
        v
IncidentAnalyzer Protocol
        |
        +----------------------+----------------------+
        |                      |                      |
        v                      v                      v
OllamaIncidentAnalyzer   AzureOpenAIIncidentAnalyzer OpenAIIncidentAnalyzer
        |                      |                      |
        v                      v                      v
Ollama /api/chat         Azure /openai/v1/responses  OpenAI /v1/responses
        |                      |                      |
        v                      v                      v
   gpt-oss:20b          deployment/model name         configured model
```

A small factory isolates provider selection:

```python
create_incident_analyzer_from_env() -> IncidentAnalyzer
```

## 5. Provider selection

Environment variable:

```text
LLM_PROVIDER=ollama | azure_openai | openai
```

Default:

```text
LLM_PROVIDER=ollama
```

Unknown values fail fast with a provider configuration error. There is no silent fallback because an unnoticed provider switch could change cost, data residency, and security properties.

## 6. Shared structured-output schema

The v9 `build_incident_analysis_schema()` helper currently lives in the OpenAI adapter. It becomes provider-neutral:

```text
agent/analysis/schema.py
```

It continues to:

- derive the schema from `IncidentAnalysis.model_json_schema()`;
- set `additionalProperties: false` on every object;
- mark every object property as required for strict structured-output compatibility;
- leave final semantic validation to Pydantic.

Both OpenAI-family adapters and Ollama reuse this schema.

## 7. Ollama adapter

### 7.1 Configuration

```text
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=gpt-oss:20b
OLLAMA_REASONING_EFFORT=medium
OLLAMA_TIMEOUT_SECONDS=180
```

No API key is required for the default local Ollama configuration.

### 7.2 HTTP contract

Use the native endpoint:

```text
POST {OLLAMA_BASE_URL}/api/chat
```

Request shape:

```json
{
  "model": "gpt-oss:20b",
  "stream": false,
  "think": "medium",
  "messages": [
    {"role": "system", "content": "<ANALYSIS_CONTRACT + schema grounding>"},
    {"role": "user", "content": "<EvidenceBundle JSON>"}
  ],
  "format": {"...": "IncidentAnalysis JSON Schema"},
  "options": {"temperature": 0}
}
```

The JSON Schema is also serialized into the system instruction because Ollama documentation recommends including the schema in the prompt as grounding in addition to passing it in `format`.

### 7.3 Response handling

Accept only a completed non-streaming response where:

```text
done == true
message.content is a non-empty string
```

Then:

```python
IncidentAnalysis.model_validate_json(message_content)
```

HTTP errors, connection errors, malformed JSON, incomplete responses, missing content, or Pydantic validation errors are wrapped as `OllamaAnalysisError` without including request secrets or arbitrary upstream response bodies.

The separate `message.thinking` field is ignored and not persisted.

## 8. Azure OpenAI adapter

### 8.1 Configuration

```text
AZURE_OPENAI_API_KEY=<secret>
AZURE_OPENAI_BASE_URL=https://<resource>.openai.azure.com/openai/v1
AZURE_OPENAI_MODEL=<deployment/model name>
AZURE_OPENAI_MAX_OUTPUT_TOKENS=2500
AZURE_OPENAI_TIMEOUT_SECONDS=60
```

`AZURE_OPENAI_MODEL` is deliberately named as a model/deployment selector because Azure requests use the configured deployed model name.

### 8.2 HTTP contract

Use:

```text
POST {AZURE_OPENAI_BASE_URL}/responses
```

Authentication:

```text
api-key: <AZURE_OPENAI_API_KEY>
```

Payload semantics match the existing OpenAI Responses API adapter:

- `model`
- `store: false`
- `max_output_tokens`
- `instructions: ANALYSIS_CONTRACT`
- `input: EvidenceBundle JSON`
- strict JSON Schema in `text.format`

Azure's current Responses API supports structured outputs through `text.format`, so the same schema is reused.

### 8.3 Response handling

Reuse provider-neutral Responses API parsing where practical, but preserve provider-specific error classes/messages so operational diagnostics identify whether OpenAI or Azure failed.

No raw API-key value or upstream response body is included in raised errors.

## 9. Existing OpenAI adapter

Keep v9 behavior and configuration compatible:

```text
OPENAI_API_KEY
OPENAI_MODEL
OPENAI_BASE_URL
OPENAI_MAX_OUTPUT_TOKENS
```

Refactor only shared schema/Responses parsing helpers as needed. Existing unit tests must remain semantically equivalent.

## 10. Factory

Create:

```text
agent/analysis/factory.py
```

Interface:

```python
class LLMProviderConfigurationError(RuntimeError):
    pass


def create_incident_analyzer_from_env() -> IncidentAnalyzer:
    ...
```

Behavior:

```text
LLM_PROVIDER unset/ollama -> OllamaIncidentAnalyzer.from_env()
LLM_PROVIDER=azure_openai -> AzureOpenAIIncidentAnalyzer.from_env()
LLM_PROVIDER=openai -> OpenAIIncidentAnalyzer.from_env()
anything else -> LLMProviderConfigurationError
```

Provider names are normalized with `.strip().lower()` only. Aliases are intentionally not supported in v10.

## 11. Live tests

### 11.1 Ollama provider-only

```text
tests/integration/test_phase4_live_ollama_analysis.py
```

Skip unless `RUN_OLLAMA_LIVE_TESTS=1`.

The test uses `OllamaIncidentAnalyzer.from_env()` against a real local Ollama endpoint and verifies:

- returned value is a non-empty `IncidentAnalysis`;
- all referenced Evidence/Query/Contradiction IDs pass `validate_analysis_references`;
- no external observability source is needed for this provider-only test.

### 11.2 Azure provider-only

```text
tests/integration/test_phase4_live_azure_openai_analysis.py
```

Skip unless `RUN_AZURE_OPENAI_LIVE_TESTS=1` and required Azure variables exist.

### 11.3 Existing OpenAI provider-only

Keep the v9 OpenAI live test and make any naming/configuration updates required by shared helpers only.

### 11.4 Full Phase 4 end-to-end

Refactor the existing live E2E test to call:

```python
create_incident_analyzer_from_env()
```

instead of `OpenAIIncidentAnalyzer.from_env()`.

This makes the same E2E path provider-independent:

```text
Demo Commerce
 -> Splunk
 -> request.id / trace.id correlation
 -> New Relic MCP
 -> EvidenceBundle
 -> selected IncidentAnalyzer
 -> IncidentAnalysis
 -> reference validation
```

For the local PoC, the intended invocation is `LLM_PROVIDER=ollama`.

## 12. Security and privacy

- Default provider is local Ollama, so Phase 4 LLM analysis can run without OpenAI/Azure API credits.
- No provider receives credentials from another provider.
- Real secrets remain in shell / `.env` only.
- Errors must not include API keys or raw upstream response bodies.
- `store=false` remains set for OpenAI/Azure Responses API requests.
- No model may trigger write actions; `RecommendedActions` remain advisory strings.
- Reasoning/thinking content is not copied into the evidence bundle, result model, logs, or UI contract.

## 13. Operational behavior

There is intentionally no automatic fallback between providers.

Examples:

```text
Ollama unavailable -> fail with OllamaAnalysisError
Azure quota exceeded -> fail with AzureOpenAIAnalysisError
OpenAI unavailable -> fail with OpenAIAnalysisError
```

The operator must explicitly change `LLM_PROVIDER` to use a different provider.

## 14. Documentation and VM flow

`.env.example` and README gain provider-specific examples.

Local default:

```bash
ollama pull gpt-oss:20b
export LLM_PROVIDER=ollama
export OLLAMA_BASE_URL=http://localhost:11434
export OLLAMA_MODEL=gpt-oss:20b
export OLLAMA_REASONING_EFFORT=medium
```

Azure example:

```bash
export LLM_PROVIDER=azure_openai
export AZURE_OPENAI_BASE_URL='https://<resource>.openai.azure.com/openai/v1'
export AZURE_OPENAI_API_KEY='...'
export AZURE_OPENAI_MODEL='<deployment-name>'
```

Existing OpenAI example remains available but is no longer the default path.

## 15. Success criteria

v10 is ready for VM verification when:

1. Existing unit/integration tests remain green or expected live tests skip without credentials.
2. New Ollama, Azure, and factory unit tests pass.
3. `compileall` succeeds.
4. Local provider-only Ollama test passes on the VM with `gpt-oss:20b` installed.
5. Full Phase 4 E2E passes with `LLM_PROVIDER=ollama`.
6. Azure adapter has unit coverage and a credential-gated live test so it can be verified in a separate Azure environment.
7. Existing OpenAI provider remains usable through `LLM_PROVIDER=openai`.

## 16. Authoritative API references checked for this design

- Ollama Structured Outputs: https://docs.ollama.com/capabilities/structured-outputs
- Ollama Chat API: https://docs.ollama.com/api/chat
- Ollama gpt-oss:20b: https://ollama.com/library/gpt-oss:20b
- Azure OpenAI Structured Outputs: https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/structured-outputs
- Azure OpenAI Responses API: https://learn.microsoft.com/en-us/azure/ai-foundry/openai/how-to/responses
- OpenAI Structured Outputs: https://developers.openai.com/api/docs/guides/structured-outputs
