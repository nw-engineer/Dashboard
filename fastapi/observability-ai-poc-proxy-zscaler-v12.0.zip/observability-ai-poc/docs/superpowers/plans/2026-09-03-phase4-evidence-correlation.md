# Phase 4 Evidence Correlation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the Phase 4 core evidence-correlation pipeline: start from `request.id`, resolve `trace.id` in Splunk, normalize Splunk and New Relic MCP-shaped evidence behind a transport-neutral gateway, detect contradictions/gaps deterministically, and return a validated structured incident analysis.

**Architecture:** Preserve the existing Phase 3 `SplunkSearchClient` as the only Splunk I/O boundary. Add focused evidence adapters, a transport-neutral New Relic MCP gateway protocol, a deterministic correlator, a validated analysis contract, and an orchestrator. The analyzer receives only `EvidenceBundle`; it never receives credentials or raw tool clients.

**Tech Stack:** Python 3.11-3.13, Pydantic 2.x, httpx 0.27+, pytest 8-9, pytest-asyncio, existing Splunk Search REST wrapper, New Relic MCP through an injected gateway protocol.

**Spec:** `docs/superpowers/specs/2026-09-03-phase4-evidence-correlation-design.md`

## Global Constraints

- Python requirement remains `>=3.11,<3.14`.
- Splunk access remains read-only and must continue through the existing `SplunkSearchClient` guard.
- Splunk index remains fixed to `poc_observability`; search window remains at most two hours; results remain at most 200.
- New Relic access remains MCP-only; do not add a direct New Relic REST/NerdGraph client to Phase 4 evidence collection.
- Phase 4 performs Observe -> Investigate -> Correlate -> Recommend only; no mutation/remediation tool is added.
- `Transaction.traceId` may exist even when matching `Span` evidence does not; missing Span data must be a gap, not a causal inference.
- No root-cause assertion is valid without references to evidence IDs present in the same `EvidenceBundle`.
- Correlation is not causation; contradiction and evidence-gap information must be preserved.
- Secrets, passwords, tokens, card data, and raw SQL must never be copied into evidence or user-facing analysis.
- All production behavior changes follow RED -> GREEN -> REFACTOR.

---

## File Structure

Files created by this plan:

```text
agent/
├── evidence/
│   ├── __init__.py
│   ├── models.py              # evidence/query/correlation/gap/contradiction schemas
│   ├── correlation.py         # request.id -> trace.id resolution via SplunkSearchClient
│   ├── splunk_collector.py    # structured Splunk rows -> EvidenceItem
│   ├── newrelic_gateway.py    # transport-neutral MCP gateway protocol + callable adapter
│   ├── newrelic_collector.py  # MCP observations -> EvidenceItem / EvidenceGap
│   └── correlator.py          # pure deterministic bundle/conflict/gap logic
├── analysis/
│   ├── __init__.py
│   ├── models.py              # IncidentAnalysis and hypothesis schemas
│   ├── prompt.py              # provider-neutral safety/analysis contract text
│   └── analyzer.py            # analyzer protocol + reference validation
└── orchestrator.py            # Phase 4 request-id investigation workflow

tests/unit/
├── test_evidence_models.py
├── test_correlation_resolver.py
├── test_splunk_evidence_collector.py
├── test_newrelic_evidence_collector.py
├── test_evidence_correlator.py
├── test_incident_analysis.py
└── test_investigation_orchestrator.py

tests/integration/
└── test_phase4_evidence_integration.py
```

Existing files modified by this plan:

```text
README.md                       # Phase 4 usage and VM verification commands
.env.example                    # only if a concrete VM MCP adapter needs non-secret endpoint settings
```

No Phase 1-3 service code is modified unless a failing Phase 4 integration test demonstrates a concrete compatibility defect.

---

### Task 1: Evidence Domain Models

**Files:**
- Create: `agent/evidence/__init__.py`
- Create: `agent/evidence/models.py`
- Test: `tests/unit/test_evidence_models.py`

**Interfaces:**
- Consumes: Pydantic 2.x and standard-library `datetime`, `enum`, `typing`.
- Produces: `EvidenceSource`, `EvidenceCategory`, `EvidenceItem`, `QueryDisclosure`, `EvidenceGap`, `EvidenceContradiction`, `CorrelationContext`, `EvidenceBundle`.

- [ ] **Step 1: Write failing model tests**

Create `tests/unit/test_evidence_models.py`:

```python
from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from agent.evidence.models import (
    CorrelationContext,
    EvidenceBundle,
    EvidenceCategory,
    EvidenceContradiction,
    EvidenceGap,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)


def test_evidence_item_accepts_json_compatible_facts():
    item = EvidenceItem(
        evidence_id="splunk-001",
        source=EvidenceSource.SPLUNK,
        category=EvidenceCategory.DB,
        summary="Inventory DB query completed in 1.2 ms",
        facts={"db.query_name": "get_inventory", "db.duration_ms": 1.2},
        query_or_tool="query-001",
        service_name="inventory-service",
        request_id="req-1",
        trace_id="trace-1",
        observed_at=datetime(2026, 9, 3, 6, 0, tzinfo=timezone.utc),
    )

    assert item.facts["db.duration_ms"] == 1.2
    assert item.source is EvidenceSource.SPLUNK


def test_evidence_item_rejects_non_json_compatible_fact():
    with pytest.raises(ValidationError, match="JSON-compatible"):
        EvidenceItem(
            evidence_id="splunk-001",
            source=EvidenceSource.SPLUNK,
            category=EvidenceCategory.APPLICATION,
            summary="bad fact",
            facts={"bad": object()},
            query_or_tool="query-001",
        )


def test_evidence_bundle_rejects_duplicate_evidence_ids():
    item = EvidenceItem(
        evidence_id="ev-1",
        source=EvidenceSource.SPLUNK,
        category=EvidenceCategory.CORRELATION,
        summary="request resolved",
        facts={"trace.id": "trace-1"},
        query_or_tool="query-1",
    )
    query = QueryDisclosure(
        disclosure_id="query-1",
        source=EvidenceSource.SPLUNK,
        operation="search",
        arguments={"query": 'request.id="req-1"'},
    )

    with pytest.raises(ValidationError, match="duplicate evidence_id"):
        EvidenceBundle(
            investigation_id="inv-1",
            request_id="req-1",
            trace_id="trace-1",
            evidence=[item, item.model_copy()],
            contradictions=[],
            gaps=[],
            queries_used=[query],
        )


def test_correlation_context_deduplicates_services_preserving_order():
    context = CorrelationContext(
        request_id="req-1",
        trace_id="trace-1",
        services=["api-gateway", "order-service", "api-gateway"],
    )

    assert context.services == ["api-gateway", "order-service"]
```

- [ ] **Step 2: Run tests and verify RED**

Run:

```bash
python -m pytest tests/unit/test_evidence_models.py -v
```

Expected: collection/import failure because `agent.evidence.models` does not exist.

- [ ] **Step 3: Implement the evidence models minimally**

Create `agent/evidence/__init__.py` as an empty package marker.

Create `agent/evidence/models.py` with these public types and names:

```python
from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator


class EvidenceSource(StrEnum):
    SPLUNK = "splunk"
    NEW_RELIC = "newrelic"


class EvidenceCategory(StrEnum):
    TRANSACTION = "transaction"
    SPAN = "span"
    GOLDEN_METRIC = "golden_metric"
    DB = "db"
    DEPENDENCY = "dependency"
    EXCEPTION = "exception"
    CAPACITY = "capacity"
    DEPLOYMENT = "deployment"
    APPLICATION = "application"
    CORRELATION = "correlation"


_JSON_SCALARS = (str, int, float, bool, type(None))


def _is_json_compatible(value: Any) -> bool:
    if isinstance(value, _JSON_SCALARS):
        return True
    if isinstance(value, list):
        return all(_is_json_compatible(item) for item in value)
    if isinstance(value, dict):
        return all(isinstance(key, str) and _is_json_compatible(item) for key, item in value.items())
    return False


class QueryDisclosure(BaseModel):
    disclosure_id: str = Field(min_length=1)
    source: EvidenceSource
    operation: str = Field(min_length=1)
    arguments: dict[str, Any]

    @field_validator("arguments")
    @classmethod
    def validate_arguments(cls, value: dict[str, Any]) -> dict[str, Any]:
        if not _is_json_compatible(value):
            raise ValueError("arguments must be JSON-compatible")
        return value


class EvidenceItem(BaseModel):
    evidence_id: str = Field(min_length=1)
    source: EvidenceSource
    category: EvidenceCategory
    summary: str = Field(min_length=1)
    facts: dict[str, Any]
    query_or_tool: str = Field(min_length=1)
    service_name: str | None = None
    observed_at: datetime | None = None
    request_id: str | None = None
    trace_id: str | None = None
    entity_guid: str | None = None

    @field_validator("facts")
    @classmethod
    def validate_facts(cls, value: dict[str, Any]) -> dict[str, Any]:
        if not _is_json_compatible(value):
            raise ValueError("facts must be JSON-compatible")
        return value


class EvidenceGap(BaseModel):
    gap_id: str = Field(min_length=1)
    summary: str = Field(min_length=1)
    source: EvidenceSource | None = None
    category: EvidenceCategory | None = None


class EvidenceContradiction(BaseModel):
    contradiction_id: str = Field(min_length=1)
    summary: str = Field(min_length=1)
    left_evidence_ids: list[str]
    right_evidence_ids: list[str]


class CorrelationContext(BaseModel):
    request_id: str = Field(min_length=1)
    trace_id: str = Field(min_length=1)
    services: list[str] = Field(default_factory=list)

    @field_validator("services")
    @classmethod
    def unique_services(cls, value: list[str]) -> list[str]:
        return list(dict.fromkeys(service for service in value if service))


class EvidenceBundle(BaseModel):
    investigation_id: str = Field(min_length=1)
    request_id: str = Field(min_length=1)
    trace_id: str = Field(min_length=1)
    evidence: list[EvidenceItem]
    contradictions: list[EvidenceContradiction]
    gaps: list[EvidenceGap]
    queries_used: list[QueryDisclosure]

    @model_validator(mode="after")
    def validate_unique_ids(self):
        evidence_ids = [item.evidence_id for item in self.evidence]
        if len(evidence_ids) != len(set(evidence_ids)):
            raise ValueError("duplicate evidence_id")
        disclosure_ids = [item.disclosure_id for item in self.queries_used]
        if len(disclosure_ids) != len(set(disclosure_ids)):
            raise ValueError("duplicate disclosure_id")
        return self
```

- [ ] **Step 4: Run the model tests and verify GREEN**

Run:

```bash
python -m pytest tests/unit/test_evidence_models.py -v
```

Expected: all tests in this file PASS.

- [ ] **Step 5: Run existing Splunk unit tests for regression**

Run:

```bash
python -m pytest tests/unit/test_splunk_search_client.py tests/unit/test_splunk_query_guard.py -v
```

Expected: PASS with no Phase 3 regression.

- [ ] **Step 6: Commit**

```bash
git add agent/evidence tests/unit/test_evidence_models.py
git commit -m "feat: add phase4 evidence domain models"
```

---

### Task 2: Correlation Resolver

**Files:**
- Create: `agent/evidence/correlation.py`
- Test: `tests/unit/test_correlation_resolver.py`

**Interfaces:**
- Consumes: `SplunkSearchClient.search(SplunkSearchRequest) -> list[dict[str, Any]]` and `CorrelationContext`.
- Produces: `CorrelationResolver.resolve_request(request_id: str, earliest: datetime, latest: datetime) -> CorrelationContext`.
- Produces exceptions: `CorrelationNotFound`, `TraceIdNotFound`, `AmbiguousTraceId`.

- [ ] **Step 1: Write failing resolver tests**

Create `tests/unit/test_correlation_resolver.py` using a small fake client:

```python
from datetime import datetime, timedelta, timezone

import pytest

from agent.evidence.correlation import (
    AmbiguousTraceId,
    CorrelationNotFound,
    CorrelationResolver,
    TraceIdNotFound,
)


class FakeSplunkClient:
    def __init__(self, rows):
        self.rows = rows
        self.requests = []

    async def search(self, request):
        self.requests.append(request)
        return list(self.rows)


@pytest.mark.asyncio
async def test_resolve_request_returns_one_trace_and_services():
    client = FakeSplunkClient([
        {"request.id": "req-1", "trace.id": "trace-1", "service.name": "api-gateway"},
        {"request.id": "req-1", "trace.id": "trace-1", "service.name": "order-service"},
    ])
    resolver = CorrelationResolver(client)
    latest = datetime(2026, 9, 3, 6, 0, tzinfo=timezone.utc)

    context = await resolver.resolve_request("req-1", latest - timedelta(minutes=10), latest)

    assert context.trace_id == "trace-1"
    assert context.services == ["api-gateway", "order-service"]
    assert client.requests[0].query == 'request.id="req-1"'


@pytest.mark.asyncio
async def test_resolve_request_rejects_missing_request():
    resolver = CorrelationResolver(FakeSplunkClient([]))
    now = datetime.now(timezone.utc)

    with pytest.raises(CorrelationNotFound):
        await resolver.resolve_request("missing", now - timedelta(minutes=5), now)


@pytest.mark.asyncio
async def test_resolve_request_rejects_rows_without_trace_id():
    resolver = CorrelationResolver(FakeSplunkClient([{"request.id": "req-1"}]))
    now = datetime.now(timezone.utc)

    with pytest.raises(TraceIdNotFound):
        await resolver.resolve_request("req-1", now - timedelta(minutes=5), now)


@pytest.mark.asyncio
async def test_resolve_request_rejects_multiple_trace_ids():
    resolver = CorrelationResolver(FakeSplunkClient([
        {"request.id": "req-1", "trace.id": "trace-1"},
        {"request.id": "req-1", "trace.id": "trace-2"},
    ]))
    now = datetime.now(timezone.utc)

    with pytest.raises(AmbiguousTraceId, match="trace-1.*trace-2"):
        await resolver.resolve_request("req-1", now - timedelta(minutes=5), now)
```

- [ ] **Step 2: Run the resolver tests and verify RED**

```bash
python -m pytest tests/unit/test_correlation_resolver.py -v
```

Expected: import failure because the resolver does not exist.

- [ ] **Step 3: Implement the resolver**

Create `agent/evidence/correlation.py` with explicit exceptions and this behavior:

```python
from __future__ import annotations

from datetime import datetime

from agent.evidence.models import CorrelationContext
from agent.splunk.client import SplunkSearchClient
from agent.splunk.models import SplunkSearchRequest


class CorrelationNotFound(LookupError):
    pass


class TraceIdNotFound(LookupError):
    pass


class AmbiguousTraceId(LookupError):
    pass


class CorrelationResolver:
    def __init__(self, splunk: SplunkSearchClient) -> None:
        self.splunk = splunk

    async def resolve_request(
        self,
        request_id: str,
        earliest: datetime,
        latest: datetime,
    ) -> CorrelationContext:
        rows = await self.splunk.search(
            SplunkSearchRequest(
                query=f'request.id="{request_id}"',
                earliest=earliest,
                latest=latest,
                max_results=200,
            )
        )
        if not rows:
            raise CorrelationNotFound(f"request.id not found: {request_id}")

        trace_ids = sorted({str(row["trace.id"]) for row in rows if row.get("trace.id")})
        if not trace_ids:
            raise TraceIdNotFound(f"trace.id not found for request.id={request_id}")
        if len(trace_ids) != 1:
            raise AmbiguousTraceId(
                f"multiple trace.id values for request.id={request_id}: {', '.join(trace_ids)}"
            )

        services = [str(row["service.name"]) for row in rows if row.get("service.name")]
        return CorrelationContext(
            request_id=request_id,
            trace_id=trace_ids[0],
            services=services,
        )
```

- [ ] **Step 4: Run resolver tests and verify GREEN**

```bash
python -m pytest tests/unit/test_correlation_resolver.py -v
```

Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add agent/evidence/correlation.py tests/unit/test_correlation_resolver.py
git commit -m "feat: resolve request ids to splunk traces"
```

---

### Task 3: Splunk Evidence Collector

**Files:**
- Create: `agent/evidence/splunk_collector.py`
- Test: `tests/unit/test_splunk_evidence_collector.py`

**Interfaces:**
- Consumes: `CorrelationContext`, `SplunkSearchClient`, `SplunkSearchRequest`.
- Produces: `SplunkEvidenceResult(evidence: list[EvidenceItem], query: QueryDisclosure)`.
- Public method: `collect(context: CorrelationContext, earliest: datetime, latest: datetime) -> SplunkEvidenceResult`.

- [ ] **Step 1: Write failing collector tests**

Tests must cover these mappings exactly:

```text
db.query              -> db
dependency.call        -> dependency
exception              -> exception
capacity.snapshot      -> capacity
deployment             -> deployment
application.request    -> application
application.response   -> application
unknown event          -> application
```

Create tests that assert:

```python
assert item.facts["db.duration_ms"] == 1.2
assert item.request_id == "req-1"
assert item.trace_id == "trace-1"
assert result.query.arguments["query"] == 'trace.id="trace-1"'
```

Also add a test proving secret-like keys are removed from facts:

```python
row = {
    "event_type": "application.request",
    "trace.id": "trace-1",
    "request.id": "req-1",
    "token": "must-not-leak",
    "password": "must-not-leak",
    "service.name": "api-gateway",
}
assert "token" not in item.facts
assert "password" not in item.facts
```

- [ ] **Step 2: Run collector tests and verify RED**

```bash
python -m pytest tests/unit/test_splunk_evidence_collector.py -v
```

Expected: import failure.

- [ ] **Step 3: Implement collector with explicit allow-listed facts**

Use these fact keys; do not copy arbitrary Splunk row content:

```python
_FACT_KEYS = {
    "event_type",
    "service.version",
    "scenario.id",
    "http.method",
    "http.route",
    "http.status_code",
    "duration_ms",
    "db.system",
    "db.query_name",
    "db.duration_ms",
    "dependency.name",
    "dependency.type",
    "dependency.status_code",
    "dependency.duration_ms",
    "retry_count",
    "error.type",
    "error.message",
    "operation",
    "queue_wait_ms",
    "active_workers",
    "inflight_requests",
    "order.id",
    "product.id",
}
```

Create a Pydantic `SplunkEvidenceResult` in the collector module and generate stable investigation-local IDs using row order:

```text
splunk-001
splunk-002
splunk-003
```

The exact search passed to the client must be only:

```python
query=f'trace.id="{context.trace_id}"'
```

The existing Splunk guard adds the fixed index.

- [ ] **Step 4: Run collector tests and verify GREEN**

```bash
python -m pytest tests/unit/test_splunk_evidence_collector.py -v
```

Expected: all PASS.

- [ ] **Step 5: Run Phase 3 Splunk unit regression tests**

```bash
python -m pytest \
  tests/unit/test_splunk_search_client.py \
  tests/unit/test_splunk_query_guard.py \
  tests/unit/test_splunk_evidence_collector.py -v
```

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add agent/evidence/splunk_collector.py tests/unit/test_splunk_evidence_collector.py
git commit -m "feat: normalize splunk trace evidence"
```

---

### Task 4: New Relic MCP Gateway and Evidence Collector

**Files:**
- Create: `agent/evidence/newrelic_gateway.py`
- Create: `agent/evidence/newrelic_collector.py`
- Test: `tests/unit/test_newrelic_evidence_collector.py`

**Interfaces:**
- Consumes: `CorrelationContext`.
- Produces protocol: `NewRelicMcpGateway.call_tool(name: str, arguments: dict[str, object]) -> object`.
- Produces adapter: `CallableNewRelicMcpGateway(caller)` where `caller` is an injected async callable.
- Produces: `NewRelicEvidenceResult(evidence, gaps, queries)`.

- [ ] **Step 1: Write gateway and collector RED tests**

Define a fake gateway in tests that records calls and returns deterministic dictionaries. Cover:

1. transaction lookup normalizes `Transaction.traceId`, app name, duration, error status;
2. a matching transaction result produces category `transaction`;
3. absent span rows produce `EvidenceGap(category=span)` rather than fake evidence;
4. deployment/change data produces category `deployment`;
5. gateway exception raises `NewRelicEvidenceUnavailable` without embedding arguments/secrets in the exception text;
6. query disclosures contain tool name and non-secret arguments.

Representative fake responses:

```python
TRANSACTION_RESPONSE = {
    "results": [
        {
            "traceId": "trace-1",
            "appName": "poc-api-gateway",
            "name": "WebTransaction/Uri/orders",
            "duration": 0.098,
            "error": False,
        }
    ]
}

SPAN_RESPONSE = {"results": []}

CHANGE_RESPONSE = {
    "events": [
        {
            "entityName": "poc-inventory-service",
            "category": "Deployment",
            "version": "1.1.0",
            "timestamp": "2026-09-03T05:00:00Z",
        }
    ]
}
```

- [ ] **Step 2: Verify RED**

```bash
python -m pytest tests/unit/test_newrelic_evidence_collector.py -v
```

Expected: import failure.

- [ ] **Step 3: Implement transport-neutral gateway**

Create `agent/evidence/newrelic_gateway.py`:

```python
from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Protocol


class NewRelicMcpGateway(Protocol):
    async def call_tool(self, name: str, arguments: dict[str, object]) -> object:
        pass


class CallableNewRelicMcpGateway:
    def __init__(
        self,
        caller: Callable[[str, dict[str, object]], Awaitable[object]],
    ) -> None:
        self._caller = caller

    async def call_tool(self, name: str, arguments: dict[str, object]) -> object:
        return await self._caller(name, arguments)
```

- [ ] **Step 4: Implement conservative New Relic collector**

Create `agent/evidence/newrelic_collector.py` with:

```python
class NewRelicEvidenceUnavailable(RuntimeError):
    pass


class NewRelicEvidenceResult(BaseModel):
    evidence: list[EvidenceItem]
    gaps: list[EvidenceGap]
    queries: list[QueryDisclosure]
```

Use `execute_nrql_query` as the first mandatory observation for `Transaction.traceId`. The collector must construct explicit NRQL that selects only factual fields:

```text
SELECT appName, name, duration, error, timestamp, traceId
FROM Transaction
WHERE traceId = '<trace-id>'
SINCE <minutes> minutes ago
LIMIT 200
```

Do not place credentials in arguments. Always attempt a Span lookup using the same gateway after the Transaction lookup. If the MCP implementation rejects or returns no Span data, record:

```text
summary = "Span evidence was not observed for the correlated trace"
source = newrelic
category = span
```

For every service present in `CorrelationContext.services`, call `list_change_events` with only service/entity identifiers and searched window parameters; normalize any observed deployment events and preserve an empty result without inventing a deployment.

Parsing must be defensive but deterministic: accept a top-level `results` list, and reject unsupported scalar payloads as `NewRelicEvidenceUnavailable` rather than inventing values.

- [ ] **Step 5: Run New Relic collector tests and verify GREEN**

```bash
python -m pytest tests/unit/test_newrelic_evidence_collector.py -v
```

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add agent/evidence/newrelic_gateway.py agent/evidence/newrelic_collector.py tests/unit/test_newrelic_evidence_collector.py
git commit -m "feat: normalize new relic mcp evidence"
```

---

### Task 5: Deterministic Evidence Correlator

**Files:**
- Create: `agent/evidence/correlator.py`
- Test: `tests/unit/test_evidence_correlator.py`

**Interfaces:**
- Consumes: correlation context plus Splunk/New Relic evidence results.
- Produces: `EvidenceCorrelator.build_bundle(*, investigation_id: str, context: CorrelationContext, splunk: SplunkEvidenceResult, newrelic: NewRelicEvidenceResult) -> EvidenceBundle`.
- Pure function/class: no HTTP, MCP, filesystem, or LLM calls.

- [ ] **Step 1: Write RED tests for deterministic rules**

Required tests:

```text
A. all evidence from both sources remains in the bundle
B. trace/request mismatch creates a contradiction and does not delete evidence
C. Splunk db.duration_ms <= 20 plus no supporting slow DB evidence records an against-DB observation only; it never creates a likely cause
D. missing Span gap survives into the bundle
E. duplicate disclosure IDs are prevented by prefixing collector-local IDs before bundle construction
```

For mismatch, assert both evidence IDs appear:

```python
assert contradiction.left_evidence_ids == ["splunk-001"]
assert contradiction.right_evidence_ids == ["newrelic-001"]
```

- [ ] **Step 2: Verify RED**

```bash
python -m pytest tests/unit/test_evidence_correlator.py -v
```

Expected: import failure.

- [ ] **Step 3: Implement pure correlator**

Implement `EvidenceCorrelator.build_bundle(*, investigation_id: str, context: CorrelationContext, splunk: SplunkEvidenceResult, newrelic: NewRelicEvidenceResult)` with these deterministic behaviors:

- concatenate evidence from both sources without preferring either source;
- verify any non-null `request_id` equals the investigation request ID;
- verify any non-null `trace_id` equals the correlation trace ID;
- create `EvidenceContradiction` for source-to-context mismatches;
- retain upstream `EvidenceGap` items;
- copy all `QueryDisclosure` items into `queries_used`;
- never emit `likely_cause`, confidence, or recommendations.

Use the caller-provided `investigation_id`; do not generate random IDs in the correlator so tests remain deterministic.

- [ ] **Step 4: Verify GREEN**

```bash
python -m pytest tests/unit/test_evidence_correlator.py -v
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add agent/evidence/correlator.py tests/unit/test_evidence_correlator.py
git commit -m "feat: correlate evidence deterministically"
```

---

### Task 6: Incident Analysis Contract and Reference Validation

**Files:**
- Create: `agent/analysis/__init__.py`
- Create: `agent/analysis/models.py`
- Create: `agent/analysis/prompt.py`
- Create: `agent/analysis/analyzer.py`
- Test: `tests/unit/test_incident_analysis.py`

**Interfaces:**
- Consumes: `EvidenceBundle`.
- Produces: `IncidentAnalysis`, `Hypothesis`, `Confidence`, `IncidentAnalyzer` protocol, `validate_analysis_references(bundle, analysis)`.
- Produces exception: `InvalidAnalysisReference`.

- [ ] **Step 1: Write RED analysis contract tests**

Tests must cover:

```python
analysis = IncidentAnalysis(
    incident_summary="The request completed slowly.",
    impact="One correlated request was affected.",
    likely_cause="The exact root cause is undetermined from available evidence.",
    confidence="low",
    supporting_evidence_ids=[],
    alternative_hypotheses=[],
    recommended_checks=["Inspect application processing around the trace window."],
    recommended_actions=["Review the deployment diff before making any change."],
    new_relic_evidence_ids=["newrelic-001"],
    splunk_evidence_ids=["splunk-001"],
    contradiction_ids=[],
    query_disclosure_ids=["query-splunk-001"],
)
```

Add tests proving:

- unknown evidence ID raises `InvalidAnalysisReference`;
- unknown query disclosure ID raises `InvalidAnalysisReference`;
- `confidence=high` with no supporting evidence is rejected;
- recommended actions are strings only and there is no execution/action callable in this module;
- prompt text contains the exact rules `Correlation is not causation` and `Span` limitation language.

- [ ] **Step 2: Verify RED**

```bash
python -m pytest tests/unit/test_incident_analysis.py -v
```

Expected: import failure.

- [ ] **Step 3: Implement analysis schemas**

Create `agent/analysis/models.py`:

```python
from enum import StrEnum

from pydantic import BaseModel, Field, model_validator


class Confidence(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class Hypothesis(BaseModel):
    summary: str = Field(min_length=1)
    supporting_evidence_ids: list[str] = Field(default_factory=list)
    opposing_evidence_ids: list[str] = Field(default_factory=list)


class IncidentAnalysis(BaseModel):
    incident_summary: str
    impact: str
    likely_cause: str
    confidence: Confidence
    supporting_evidence_ids: list[str]
    alternative_hypotheses: list[Hypothesis]
    recommended_checks: list[str]
    recommended_actions: list[str]
    new_relic_evidence_ids: list[str]
    splunk_evidence_ids: list[str]
    contradiction_ids: list[str]
    query_disclosure_ids: list[str]

    @model_validator(mode="after")
    def high_confidence_requires_evidence(self):
        if self.confidence is Confidence.HIGH and not self.supporting_evidence_ids:
            raise ValueError("high confidence requires supporting evidence")
        return self
```

- [ ] **Step 4: Implement prompt contract**

Create `agent/analysis/prompt.py` as a constant string containing all nine safety requirements from the design. It must explicitly say:

```text
- Correlation is not causation.
- If Span evidence is unavailable, do not infer an internal service bottleneck solely from parent Transaction duration.
- Use only evidence IDs and query disclosures present in the supplied EvidenceBundle.
- Recommendations are advisory; do not claim to have executed changes.
```

- [ ] **Step 5: Implement analyzer protocol and validator**

Create `agent/analysis/analyzer.py`:

```python
from typing import Protocol

from agent.analysis.models import IncidentAnalysis
from agent.evidence.models import EvidenceBundle


class InvalidAnalysisReference(ValueError):
    pass


class IncidentAnalyzer(Protocol):
    async def analyze(self, bundle: EvidenceBundle) -> IncidentAnalysis:
        pass


def validate_analysis_references(bundle: EvidenceBundle, analysis: IncidentAnalysis) -> None:
    known_evidence = {item.evidence_id for item in bundle.evidence}
    known_queries = {item.disclosure_id for item in bundle.queries_used}
    known_contradictions = {item.contradiction_id for item in bundle.contradictions}

    referenced_evidence = set(analysis.supporting_evidence_ids)
    referenced_evidence.update(analysis.new_relic_evidence_ids)
    referenced_evidence.update(analysis.splunk_evidence_ids)
    for hypothesis in analysis.alternative_hypotheses:
        referenced_evidence.update(hypothesis.supporting_evidence_ids)
        referenced_evidence.update(hypothesis.opposing_evidence_ids)

    unknown_evidence = sorted(referenced_evidence - known_evidence)
    if unknown_evidence:
        raise InvalidAnalysisReference(f"unknown evidence IDs: {', '.join(unknown_evidence)}")

    unknown_queries = sorted(set(analysis.query_disclosure_ids) - known_queries)
    if unknown_queries:
        raise InvalidAnalysisReference(f"unknown query IDs: {', '.join(unknown_queries)}")

    unknown_contradictions = sorted(set(analysis.contradiction_ids) - known_contradictions)
    if unknown_contradictions:
        raise InvalidAnalysisReference(
            f"unknown contradiction IDs: {', '.join(unknown_contradictions)}"
        )
```

- [ ] **Step 6: Run analysis tests and verify GREEN**

```bash
python -m pytest tests/unit/test_incident_analysis.py -v
```

Expected: PASS.

- [ ] **Step 7: Commit**

```bash
git add agent/analysis tests/unit/test_incident_analysis.py
git commit -m "feat: add evidence-referenced incident analysis contract"
```

---

### Task 7: Investigation Orchestrator

**Files:**
- Create: `agent/orchestrator.py`
- Test: `tests/unit/test_investigation_orchestrator.py`

**Interfaces:**
- Consumes: `CorrelationResolver`, `SplunkEvidenceCollector`, `NewRelicEvidenceCollector`, `EvidenceCorrelator`, `IncidentAnalyzer`.
- Produces: `InvestigationOrchestrator.investigate_request_id(request_id: str, earliest: datetime, latest: datetime) -> InvestigationResult`.
- Produces: `InvestigationResult(bundle: EvidenceBundle, analysis: IncidentAnalysis)` so Phase 5 can render both analysis and underlying evidence.

- [ ] **Step 1: Write RED orchestrator tests with fakes**

Required cases:

1. happy path call order is correlation -> Splunk -> New Relic -> correlate -> analyze;
2. `AmbiguousTraceId` stops before collectors/analyzer;
3. New Relic collection failure after correlation becomes an evidence gap and analysis continues;
4. Splunk evidence collection failure after correlation produces a partial bundle only if correlation data was already established; otherwise it stops;
5. analyzer output with unknown evidence ID is rejected by `validate_analysis_references`;
6. exact caller-provided earliest/latest are passed to both collectors.

Use a list such as `events.append("splunk")` in fakes and assert sequence.

- [ ] **Step 2: Verify RED**

```bash
python -m pytest tests/unit/test_investigation_orchestrator.py -v
```

Expected: import failure.

- [ ] **Step 3: Implement orchestrator and partial-source policy**

Create `agent/orchestrator.py` with:

```python
class InvestigationResult(BaseModel):
    bundle: EvidenceBundle
    analysis: IncidentAnalysis
```

Constructor dependencies are injected. `investigate_request_id()` must:

```text
1. resolver.resolve_request
2. splunk_collector.collect
3. newrelic_collector.collect
4. correlator.build_bundle
5. analyzer.analyze
6. validate_analysis_references
7. return InvestigationResult
```

When New Relic evidence collection raises `NewRelicEvidenceUnavailable`, replace that source result with:

```text
evidence=[]
gaps=[EvidenceGap(
  gap_id="gap-newrelic-unavailable",
  summary="New Relic evidence was unavailable for this investigation",
  source=newrelic,
)]
queries=[]
```

Do not include the original exception text in the gap.

- [ ] **Step 4: Verify orchestrator GREEN**

```bash
python -m pytest tests/unit/test_investigation_orchestrator.py -v
```

Expected: PASS.

- [ ] **Step 5: Run all new Phase 4 unit tests together**

```bash
python -m pytest \
  tests/unit/test_evidence_models.py \
  tests/unit/test_correlation_resolver.py \
  tests/unit/test_splunk_evidence_collector.py \
  tests/unit/test_newrelic_evidence_collector.py \
  tests/unit/test_evidence_correlator.py \
  tests/unit/test_incident_analysis.py \
  tests/unit/test_investigation_orchestrator.py \
  -v
```

Expected: all Phase 4 tests PASS.

- [ ] **Step 6: Run all existing unit tests**

```bash
python -m pytest tests/unit -v
```

Expected: all unit tests PASS. Do not use integration failures from unavailable external services to judge this command because this command is unit-only.

- [ ] **Step 7: Commit**

```bash
git add agent/orchestrator.py tests/unit/test_investigation_orchestrator.py
git commit -m "feat: orchestrate evidence-first request investigations"
```

---

### Task 8: Phase 4 Core Integration Slice and Operational Documentation

**Files:**
- Create: `tests/integration/test_phase4_evidence_integration.py`
- Modify: `README.md`

**Interfaces:**
- Consumes real Demo Commerce + real Splunk Search Tool.
- Consumes a deterministic `CallableNewRelicMcpGateway` fake with MCP-shaped payloads; this tests the Phase 4 core independently of the deployment-specific MCP transport.
- Produces an `EvidenceBundle` containing both `splunk` and `newrelic` evidence categories for the same trace.

**Scope boundary:** the Phase 3 repository does not contain the concrete New Relic MCP transport/launcher contract. Binding the already-working VM New Relic MCP server is therefore a separate deployment-adapter change, to be planned after inspecting that server's actual transport (stdio, SSE, Streamable HTTP, or another launcher). This core plan does not invent a transport API.

- [ ] **Step 1: Write the integration test using real Splunk and an MCP-shaped fake gateway**

Create `tests/integration/test_phase4_evidence_integration.py` that:

1. skips only when `SPLUNK_SEARCH_PASSWORD` is absent;
2. posts one order with `X-Request-ID=phase4-it-<uuid>`;
3. constructs the real `SplunkSearchClient`;
4. polls `CorrelationResolver` for up to 20 seconds using a monotonic deadline and 1-second intervals;
5. after Splunk resolves the live trace ID, constructs a fake async MCP caller whose `execute_nrql_query` response uses that exact live trace ID;
6. uses `CallableNewRelicMcpGateway(fake_caller)` and the real Phase 4 collectors/correlator;
7. asserts exactly one `bundle.trace_id`;
8. asserts at least one real Splunk evidence item with the same trace;
9. asserts at least one New Relic transaction evidence item with the same trace;
10. asserts every evidence item's `query_or_tool` points to a disclosure ID in `bundle.queries_used`.

The fake caller must return exactly these shapes:

```python
async def fake_call_tool(name: str, arguments: dict[str, object]) -> object:
    if name == "execute_nrql_query":
        query = str(arguments.get("query", ""))
        if "FROM Span" in query:
            return {"results": []}
        return {
            "results": [
                {
                    "traceId": resolved_trace_id,
                    "appName": "poc-api-gateway",
                    "name": "WebTransaction/Uri/orders",
                    "duration": 0.1,
                    "error": False,
                }
            ]
        }
    if name == "list_change_events":
        return {"events": []}
    raise AssertionError(f"unexpected MCP tool: {name}")
```

- [ ] **Step 2: Run the core integration test on the VM**

```bash
docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e SPLUNK_SEARCH_URL=https://localhost:8089 \
  -e SPLUNK_SEARCH_USERNAME=ai_search \
  -e SPLUNK_SEARCH_PASSWORD \
  -e SPLUNK_SEARCH_VERIFY_SSL=false \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase4_evidence_integration.py -v
  "
```

Expected: `test_phase4_request_builds_cross_source_evidence_bundle PASSED`.

- [ ] **Step 3: Add README verification section**

Document:

```text
Phase 4 core flow:
request.id -> real Splunk trace.id -> real Splunk evidence + MCP-shaped New Relic evidence -> EvidenceBundle

Safety:
- Splunk ai_search remains search-only
- existing Splunk guard remains mandatory
- New Relic evidence goes through NewRelicMcpGateway
- no mutation/remediation action exists
- missing Span is displayed as an evidence gap

Deployment note:
- live New Relic MCP transport binding is a separate adapter task because the Phase 3 zip does not contain that transport contract
```

- [ ] **Step 4: Final core verification**

Run fresh commands:

```bash
python -m pytest tests/unit -v
python -m compileall -q agent
```

On the VM additionally run:

```bash
python -m pytest tests/integration/test_splunk_search_integration.py -v
python -m pytest tests/integration/test_phase4_evidence_integration.py -v
```

Expected:

```text
all unit tests pass
compileall exits 0
Phase 3 Splunk correlation integration passes
Phase 4 core evidence integration passes
```

- [ ] **Step 5: Inspect the VM New Relic MCP transport for the follow-up adapter plan**

Record, without secrets, these facts from the already-working MCP deployment:

```text
launcher command/process
transport type
endpoint or stdio command
authentication mechanism name (not secret value)
Python/Node package used to call tools, if any
working tool-call path for execute_nrql_query
```

Do not alter the MCP deployment in this step. These facts become the inputs to a separate bounded implementation plan for `deployment/newrelic_mcp_adapter.py`.

- [ ] **Step 6: Commit**

```bash
git add tests/integration/test_phase4_evidence_integration.py README.md
git commit -m "test: verify phase4 core evidence correlation"
```

---

## Implementation Review Checklist

Before declaring Phase 4 core complete, verify all of these against the design spec:

- [ ] `request.id` resolves to exactly one `trace.id` or raises an explicit correlation error.
- [ ] Splunk evidence uses the existing guarded `SplunkSearchClient` only.
- [ ] Splunk evidence is normalized into allow-listed factual fields.
- [ ] New Relic evidence is obtained through `NewRelicMcpGateway`, not direct API access.
- [ ] `Transaction.traceId` works even when Span evidence is unavailable.
- [ ] Missing Span evidence is represented as `EvidenceGap`.
- [ ] Both sources remain present when evidence conflicts.
- [ ] Deterministic correlator produces no causal conclusion.
- [ ] Analyzer output can reference only known evidence, contradiction, and query IDs.
- [ ] High confidence cannot be returned without supporting evidence.
- [ ] Recommended actions are advisory strings only.
- [ ] No Phase 4 module exposes restart, rollback, delete, write, deploy, or configuration mutation tools.
- [ ] All new unit tests pass.
- [ ] Existing unit suite passes.
- [ ] Existing Phase 3 Splunk integration still passes on VM.
- [ ] Phase 4 VM integration produces one cross-source `EvidenceBundle` for a real request.

