# Phase 5 AG-UI / A2UI Troubleshooting Console Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a browser-based troubleshooting console that streams investigation progress with AG-UI and renders the already-validated Phase 4 `InvestigationResult` through deterministic A2UI v0.9.1 messages without weakening Evidence-first safety guarantees.

**Architecture:** Preserve `InvestigationOrchestrator`, `EvidenceBundle`, `IncidentAnalysis`, and reference validation as the trusted domain boundary. Add an observational progress reporter around existing orchestration steps, a pure presenter that maps `InvestigationResult` to a presentation model, a deterministic A2UI message builder, an AG-UI/SSE FastAPI adapter, and a standalone React console that consumes the stream with the official A2UI v0.9 renderer stack.

**Tech Stack:** Python 3.11+, FastAPI, Pydantic 2, `ag-ui-protocol>=0.1.22,<0.2`, pytest/pytest-asyncio, React + TypeScript + Vite, Node 22 built-in test runner for local frontend TDD, `@a2ui/react@0.10.2`, `@a2ui/web_core@0.10.6`, A2UI wire protocol v0.9.1.

**Spec:** `docs/superpowers/specs/2026-09-03-phase5-agui-a2ui-console-design.md`

> **Execution note (2026-09-04):** The supplied archive has no `.git`, so no worktree/commit steps can be performed here. The implementation container also cannot reach the npm/PyPI registries. Frontend behavior was therefore developed test-first with Node 22 built-in tests (`npm test`) while the React/A2UI package type-check/build remains an explicit VM gate after `npm install`. Product architecture and public A2UI/AG-UI APIs remain unchanged.

## Global Constraints

- Phase 4 is complete and its existing tests/behavior must remain green.
- Do not change `EvidenceBundle`, `IncidentAnalysis`, `IncidentAnalyzer`, or `validate_analysis_references()` semantics.
- New Relic and Splunk remain read-only; Phase 5 exposes no remediation/write endpoint.
- The LLM does not generate arbitrary frontend code or UI structure.
- Do not expose chain-of-thought/reasoning.
- A2UI wire messages use version `v0.9.1`; frontend imports the supported v0.9 API surface from `@a2ui/web_core/v0_9` and `@a2ui/react/v0_9`.
- AG-UI lifecycle events use the official Python SDK event classes and `EventEncoder`; A2UI envelopes ride inside `CUSTOM` events named `a2ui.message`.
- Stable progress step names are exactly: `correlation`, `splunk`, `newrelic`, `correlate`, `analyze`.
- Collector unavailability that Phase 4 converts to `EvidenceGap` is a successful step, not `RUN_ERROR`.
- Escaping exceptions are converted to sanitized public error codes/messages and never include raw credentials, environment values, upstream response bodies, or stack traces.
- `EvidenceGap.gap_id` must never enter an Evidence-ID collection.
- Input window must not exceed the existing two-hour Splunk safety limit.
- Existing Python requirement remains `>=3.11,<3.14`.

---

## File Map

### Backend files to create

- `agent/progress.py` — progress reporter protocol, no-op implementation, helper wrapper.
- `agent/ui/__init__.py` — presentation package marker.
- `agent/ui/models.py` — A2UI-independent troubleshooting view models.
- `agent/ui/presenter.py` — pure `InvestigationResult -> TroubleshootingViewModel` mapper.
- `agent/ui/a2ui.py` — deterministic A2UI v0.9.1 envelope builder.
- `console_api/__init__.py` — console API package marker.
- `console_api/models.py` — validated request model.
- `console_api/errors.py` — public error mapping/sanitization.
- `console_api/dependencies.py` — environment-driven construction of the existing Phase 4 orchestrator.
- `console_api/stream.py` — progress reporter queue + AG-UI event generator.
- `console_api/app.py` — FastAPI app and `/api/investigations/stream` endpoint.

### Backend files to modify

- `agent/orchestrator.py` — optional progress reporter hooks only; result contract unchanged.
- `pyproject.toml` — add `ag-ui-protocol>=0.1.22,<0.2` and include `console_api*` packages.
- `.env.example` — document console API host/port only if needed; no secrets added.
- `README.md` — Phase 5 run/test instructions.

### Backend tests to create/modify

- Modify `tests/unit/test_investigation_orchestrator.py` — exact progress sequence and partial-evidence behavior.
- Create `tests/unit/test_ui_presenter.py` — deterministic presentation mapping and ID namespace tests.
- Create `tests/unit/test_a2ui_presenter.py` — A2UI envelope/component whitelist tests.
- Create `tests/unit/test_console_request.py` — input validation/window constraints.
- Create `tests/unit/test_console_errors.py` — sanitized public errors.
- Create `tests/unit/test_agui_stream.py` — AG-UI lifecycle/custom-event ordering.
- Create `tests/integration/test_phase5_console_api.py` — FastAPI SSE contract with test-double orchestrator.
- Create `tests/integration/test_phase5_live_console.py` — opt-in VM smoke test using real Phase 4 dependencies.

### Frontend files to create

- `console/package.json`, `console/tsconfig.json`, `console/vite.config.ts`, `console/index.html`.
- `console/src/main.tsx`, `console/src/app/App.tsx`, `console/src/styles.css`.
- `console/src/api/investigationStream.ts` — POST + incremental SSE parser.
- `console/src/a2ui/processor.ts` — `MessageProcessor` ownership and A2UI `CUSTOM` forwarding.
- `console/src/a2ui/catalog.tsx` — approved troubleshooting catalog/render mappings.
- `console/src/a2ui/TroubleshootingSurface.tsx` — surface subscription/render boundary.
- `console/src/components/InvestigationForm.tsx`.
- `console/src/components/InvestigationProgress.tsx`.
- `console/src/components/HealthSummary.tsx`.
- `console/src/components/TimelineChart.tsx`.
- `console/src/components/TraceCard.tsx`.
- `console/src/components/EvidenceCard.tsx`.
- `console/src/components/EvidenceGapCard.tsx`.
- `console/src/components/LogTable.tsx`.
- `console/src/components/HypothesisCard.tsx`.
- `console/src/components/RecommendationCard.tsx`.
- `console/src/components/QueryDisclosure.tsx`.
- `console/src/test/setup.ts` and focused `*.test.ts(x)` files beside transport/catalog/form/progress components.

---

### Task 1: Progress Reporter and Orchestrator Hooks

**Files:**
- Create: `agent/progress.py`
- Modify: `agent/orchestrator.py`
- Modify: `tests/unit/test_investigation_orchestrator.py`

**Interfaces:**
- Produces: `InvestigationProgressReporter`, `NullInvestigationProgressReporter`.
- Changes constructor to accept `progress: InvestigationProgressReporter | None = None` while preserving all existing call sites.
- Emits `step_started(name)` / `step_finished(name)` around the five existing orchestration stages.

- [ ] **Step 1: Write failing progress-order tests**

Add a recording reporter to `tests/unit/test_investigation_orchestrator.py`:

```python
class RecordingProgress:
    def __init__(self):
        self.events: list[tuple[str, str]] = []

    async def step_started(self, step_name: str) -> None:
        self.events.append(("started", step_name))

    async def step_finished(self, step_name: str) -> None:
        self.events.append(("finished", step_name))
```

Add assertions for the exact happy-path sequence:

```python
assert progress.events == [
    ("started", "correlation"),
    ("finished", "correlation"),
    ("started", "splunk"),
    ("finished", "splunk"),
    ("started", "newrelic"),
    ("finished", "newrelic"),
    ("started", "correlate"),
    ("finished", "correlate"),
    ("started", "analyze"),
    ("finished", "analyze"),
]
```

Add separate tests that correlation failure produces only `("started", "correlation")`, and that `SplunkEvidenceUnavailable` / `NewRelicEvidenceUnavailable` still end their respective steps and the run continues.

- [ ] **Step 2: Run RED**

Run:

```bash
python -m pytest tests/unit/test_investigation_orchestrator.py -v
```

Expected: new progress tests fail because the constructor/reporting hooks do not exist.

- [ ] **Step 3: Add progress protocol and no-op reporter**

Create `agent/progress.py`:

```python
from __future__ import annotations

from typing import Protocol


class InvestigationProgressReporter(Protocol):
    async def step_started(self, step_name: str) -> None: ...
    async def step_finished(self, step_name: str) -> None: ...


class NullInvestigationProgressReporter:
    async def step_started(self, step_name: str) -> None:
        return None

    async def step_finished(self, step_name: str) -> None:
        return None
```

- [ ] **Step 4: Add minimal orchestration hooks**

In `agent/orchestrator.py`, accept optional `progress` and normalize it to the no-op reporter. Wrap each existing stage without changing error semantics:

```python
await self.progress.step_started("correlation")
context = await self.resolver.resolve_request(request_id, earliest, latest)
await self.progress.step_finished("correlation")
```

For collector stages, call `step_finished` after either successful collection or conversion to the existing gap result. Do not put `step_finished` in a `finally` block for exceptions that are not handled by Phase 4.

- [ ] **Step 5: Run GREEN and Phase 4 regression tests**

Run:

```bash
python -m pytest tests/unit/test_investigation_orchestrator.py -v
python -m pytest tests/unit -q
```

Expected: all pass.

- [ ] **Step 6: Commit**

```bash
git add agent/progress.py agent/orchestrator.py tests/unit/test_investigation_orchestrator.py
git commit -m "feat: add investigation progress reporting"
```

If the workspace has no `.git`, record the task as completed without a commit and preserve the same file boundary.

---

### Task 2: Troubleshooting Presentation Model and Pure Presenter

**Files:**
- Create: `agent/ui/__init__.py`
- Create: `agent/ui/models.py`
- Create: `agent/ui/presenter.py`
- Create: `tests/unit/test_ui_presenter.py`

**Interfaces:**
- Consumes: `InvestigationResult`.
- Produces: `TroubleshootingViewModel`, `present_investigation(result) -> TroubleshootingViewModel`.

- [ ] **Step 1: Write presenter tests first**

Build a fixture `InvestigationResult` containing:
- one Splunk application evidence item with `observed_at`;
- one New Relic transaction evidence item without `observed_at`;
- one `EvidenceGap(gap_id="gap-newrelic-span-unavailable")`;
- one contradiction;
- two query disclosures;
- one alternative hypothesis.

Test:

```python
view = present_investigation(result)
assert view.investigation_id == result.bundle.investigation_id
assert view.request_id == result.bundle.request_id
assert view.trace_id == result.bundle.trace_id
assert [row.evidence_id for row in view.log_rows] == ["splunk-001"]
assert [row.evidence_id for row in view.timeline] == ["splunk-001"]
assert [gap.gap_id for gap in view.evidence_gaps] == ["gap-newrelic-span-unavailable"]
assert "gap-newrelic-span-unavailable" not in view.all_evidence_ids
```

Add environment derivation cases: first non-empty `deployment.environment` in evidence facts wins; otherwise `"unknown"`.

- [ ] **Step 2: Run RED**

```bash
python -m pytest tests/unit/test_ui_presenter.py -v
```

Expected: import/module failures.

- [ ] **Step 3: Implement focused Pydantic presentation models**

Create models such as:

```python
class TimelineEntry(BaseModel):
    evidence_id: str
    source: EvidenceSource
    category: EvidenceCategory
    service_name: str | None
    observed_at: datetime
    summary: str

class EvidenceView(BaseModel):
    evidence_id: str
    source: EvidenceSource
    category: EvidenceCategory
    summary: str
    service_name: str | None
    observed_at: datetime | None
    query_or_tool: str
    facts: dict[str, Any]

class EvidenceGapView(BaseModel):
    gap_id: str
    source: EvidenceSource | None
    category: EvidenceCategory | None
    summary: str

class TroubleshootingViewModel(BaseModel):
    investigation_id: str
    request_id: str
    trace_id: str
    services: list[str]
    environment: str
    incident_summary: str
    impact: str
    likely_cause: str
    confidence: str
    timeline: list[TimelineEntry]
    evidence: list[EvidenceView]
    evidence_gaps: list[EvidenceGapView]
    contradictions: list[ContradictionView]
    hypotheses: list[HypothesisView]
    recommended_checks: list[str]
    recommended_actions: list[str]
    queries: list[QueryDisclosureView]
    log_rows: list[EvidenceView]

    @property
    def all_evidence_ids(self) -> set[str]:
        return {item.evidence_id for item in self.evidence}
```

Keep gap/query/contradiction namespaces separate.

- [ ] **Step 4: Implement deterministic mapping**

`present_investigation()` must sort timeline entries by `observed_at`, preserve evidence list order otherwise, build `services` from non-empty evidence service names in first-seen order, derive environment only from evidence facts, and copy recommendations as plain strings.

- [ ] **Step 5: Run GREEN**

```bash
python -m pytest tests/unit/test_ui_presenter.py -v
python -m pytest tests/unit -q
```

Expected: pass.

- [ ] **Step 6: Commit**

```bash
git add agent/ui tests/unit/test_ui_presenter.py
git commit -m "feat: add deterministic troubleshooting presenter"
```

---

### Task 3: Deterministic A2UI v0.9.1 Message Builder

**Files:**
- Create: `agent/ui/a2ui.py`
- Create: `tests/unit/test_a2ui_presenter.py`

**Interfaces:**
- Consumes: `TroubleshootingViewModel`.
- Produces: `build_a2ui_messages(view) -> list[dict[str, Any]]`.
- Catalog ID: `dev.observability:troubleshooting-v1`.
- Approved component names: `HealthSummary`, `TimelineChart`, `TraceCard`, `EvidenceCard`, `EvidenceGapCard`, `LogTable`, `HypothesisCard`, `RecommendationCard`, `QueryDisclosure`, plus root `Column` only if required by the installed renderer catalog composition.

- [ ] **Step 1: Write A2UI message tests**

Test exact envelope ordering and version:

```python
messages = build_a2ui_messages(view)
assert [next(key for key in m if key != "version") for m in messages] == [
    "createSurface",
    "updateComponents",
    "updateDataModel",
]
assert all(message["version"] == "v0.9.1" for message in messages)
assert messages[0]["createSurface"]["surfaceId"] == view.investigation_id
assert messages[0]["createSurface"]["catalogId"] == TROUBLESHOOTING_CATALOG_ID
```

Test that the component list has `id="root"`, only approved types, and that the data model has separate `/evidence` and `/evidenceGaps` collections. Explicitly assert that no gap ID appears inside any field whose name ends with `evidenceIds`.

- [ ] **Step 2: Run RED**

```bash
python -m pytest tests/unit/test_a2ui_presenter.py -v
```

Expected: module/function missing.

- [ ] **Step 3: Implement the A2UI message builder**

Use official v0.9.1 envelope semantics:

```python
A2UI_VERSION = "v0.9.1"
TROUBLESHOOTING_CATALOG_ID = "dev.observability:troubleshooting-v1"


def build_a2ui_messages(view: TroubleshootingViewModel) -> list[dict[str, Any]]:
    surface_id = view.investigation_id
    return [
        {
            "version": A2UI_VERSION,
            "createSurface": {
                "surfaceId": surface_id,
                "catalogId": TROUBLESHOOTING_CATALOG_ID,
                "sendDataModel": False,
            },
        },
        {
            "version": A2UI_VERSION,
            "updateComponents": {
                "surfaceId": surface_id,
                "components": _build_components(),
            },
        },
        {
            "version": A2UI_VERSION,
            "updateDataModel": {
                "surfaceId": surface_id,
                "path": "/",
                "value": view.model_dump(mode="json"),
            },
        },
    ]
```

The component tree is fixed and data-bound. The server never accepts a component type from LLM output.

- [ ] **Step 4: Add defensive namespace validation**

Before returning messages, verify that analysis evidence references are a subset of `view.all_evidence_ids` and that gap IDs are disjoint from evidence IDs. This does not replace Phase 4 validation; it catches presentation regressions.

- [ ] **Step 5: Run GREEN**

```bash
python -m pytest tests/unit/test_a2ui_presenter.py -v
python -m pytest tests/unit -q
```

- [ ] **Step 6: Commit**

```bash
git add agent/ui/a2ui.py tests/unit/test_a2ui_presenter.py
git commit -m "feat: build deterministic A2UI investigation messages"
```

---

### Task 4: Console Request Validation and Sanitized Errors

**Files:**
- Create: `console_api/__init__.py`
- Create: `console_api/models.py`
- Create: `console_api/errors.py`
- Create: `tests/unit/test_console_request.py`
- Create: `tests/unit/test_console_errors.py`

**Interfaces:**
- Produces: `InvestigationStreamRequest`.
- Produces: `PublicInvestigationError(code: str, message: str)` and `to_public_error(exc)`.

- [ ] **Step 1: Write request-validation RED tests**

Cover trimming, timezone-awareness, `earliest < latest`, and `latest - earliest <= 2 hours`.

```python
with pytest.raises(ValidationError):
    InvestigationStreamRequest(
        request_id="   ",
        earliest="2026-09-03T04:00:00Z",
        latest="2026-09-03T04:10:00Z",
    )
```

Also reject naive datetimes and windows over two hours.

- [ ] **Step 2: Write error-sanitization RED tests**

Map:
- `CorrelationNotFound` / `TraceIdNotFound` -> `CORRELATION_NOT_FOUND`.
- `AmbiguousTraceId` -> `CORRELATION_AMBIGUOUS`.
- all other escaped exceptions -> `INVESTIGATION_FAILED`.

Inject an exception string like `password=do-not-leak token=abc123` and assert neither substring appears in the public message.

- [ ] **Step 3: Run RED**

```bash
python -m pytest tests/unit/test_console_request.py tests/unit/test_console_errors.py -v
```

- [ ] **Step 4: Implement request model**

Use Pydantic validators to normalize the ID and enforce the exact window constraints.

- [ ] **Step 5: Implement closed public-error mapping**

Do not interpolate `str(exc)` into public messages. Example:

```python
_GENERIC = PublicInvestigationError(
    code="INVESTIGATION_FAILED",
    message="The investigation could not be completed.",
)
```

- [ ] **Step 6: Run GREEN**

```bash
python -m pytest tests/unit/test_console_request.py tests/unit/test_console_errors.py -v
```

- [ ] **Step 7: Commit**

```bash
git add console_api tests/unit/test_console_request.py tests/unit/test_console_errors.py
git commit -m "feat: validate console requests and sanitize errors"
```

---

### Task 5: AG-UI Stream Adapter and SSE Endpoint

**Files:**
- Modify: `pyproject.toml`
- Create: `console_api/stream.py`
- Create: `console_api/app.py`
- Create: `console_api/dependencies.py`
- Create: `tests/unit/test_agui_stream.py`
- Create: `tests/integration/test_phase5_console_api.py`

**Interfaces:**
- Consumes: `InvestigationStreamRequest`, `InvestigationOrchestrator`.
- Produces: async iterator of official AG-UI events.
- HTTP endpoint: `POST /api/investigations/stream`, content type `text/event-stream`.

- [ ] **Step 1: Add dependency constraint**

In `pyproject.toml` add:

```toml
"ag-ui-protocol>=0.1.22,<0.2",
```

and update package discovery:

```toml
include = ["shared*", "services*", "load_generator*", "agent*", "console_api*"]
```

Install in the test environment before running stream tests.

- [ ] **Step 2: Write AG-UI stream RED tests**

Use a fake orchestrator that calls progress callbacks and returns a validated fixture result. Assert decoded event types are:

```python
[
    "RUN_STARTED",
    "STEP_STARTED", "STEP_FINISHED",
    "STEP_STARTED", "STEP_FINISHED",
    "STEP_STARTED", "STEP_FINISHED",
    "STEP_STARTED", "STEP_FINISHED",
    "STEP_STARTED", "STEP_FINISHED",
    "CUSTOM", "CUSTOM", "CUSTOM",
    "RUN_FINISHED",
]
```

Assert all `CUSTOM` events have `name == "a2ui.message"` and values in create/update/update order. Add a failure case that ends with one sanitized `RUN_ERROR` and never emits `RUN_FINISHED`.

- [ ] **Step 3: Run RED**

```bash
python -m pytest tests/unit/test_agui_stream.py -v
```

- [ ] **Step 4: Implement queue-backed progress reporter**

In `console_api/stream.py`, implement a reporter that writes official `StepStartedEvent` / `StepFinishedEvent` objects into an `asyncio.Queue`. Run the orchestrator in an `asyncio.create_task` so progress can be yielded while the investigation is in flight.

Use official event classes:

```python
from ag_ui.core import (
    CustomEvent,
    RunErrorEvent,
    RunFinishedEvent,
    RunStartedEvent,
    StepFinishedEvent,
    StepStartedEvent,
)
```

- [ ] **Step 5: Implement successful result emission**

After the task returns `InvestigationResult`:

```python
view = present_investigation(result)
for message in build_a2ui_messages(view):
    yield CustomEvent(name="a2ui.message", value=message)
yield RunFinishedEvent(thread_id=thread_id, run_id=run_id, result={"investigationId": result.bundle.investigation_id})
```

Never emit A2UI messages before the orchestrator has returned the already-reference-validated result.

- [ ] **Step 6: Implement error emission**

Map escaping errors through `to_public_error()` and emit only `RunErrorEvent(message=public.message, code=public.code)`.

- [ ] **Step 7: Write FastAPI endpoint RED test**

Use `httpx.ASGITransport` and dependency injection/test app factory. Assert:
- 200 for a valid request;
- `content-type` begins with `text/event-stream`;
- encoded lines begin `data: ` and decode to AG-UI events;
- invalid time windows receive 422 before orchestrator invocation.

- [ ] **Step 8: Implement FastAPI app using official encoder**

Use:

```python
from ag_ui.encoder import EventEncoder
from fastapi.responses import StreamingResponse

encoder = EventEncoder(accept="text/event-stream")

async def body():
    async for event in stream_investigation(...):
        yield encoder.encode(event)

return StreamingResponse(
    body(),
    media_type=encoder.get_content_type(),
    headers={
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",
    },
)
```

- [ ] **Step 9: Add production dependency composition**

`console_api/dependencies.py` constructs the same Phase 4 components used by the live E2E test from environment variables: `SplunkSearchClient`, `CorrelationResolver`, `SplunkEvidenceCollector`, `StreamableHttpNewRelicMcpGateway`, `NewRelicEvidenceCollector`, `EvidenceCorrelator`, and `create_incident_analyzer_from_env()`. Do not introduce alternate data paths.

- [ ] **Step 10: Run GREEN and backend regression**

```bash
python -m pytest tests/unit/test_agui_stream.py tests/integration/test_phase5_console_api.py -v
python -m pytest tests/unit -q
```

- [ ] **Step 11: Commit**

```bash
git add pyproject.toml console_api tests/unit/test_agui_stream.py tests/integration/test_phase5_console_api.py
git commit -m "feat: stream investigations with AG-UI over SSE"
```

---

### Task 6: React Console Transport and Progress UI

**Files:**
- Create: `console/package.json`
- Create: `console/tsconfig.json`
- Create: `console/vite.config.ts`
- Create: `console/index.html`
- Create: `console/src/main.tsx`
- Create: `console/src/app/App.tsx`
- Create: `console/src/api/investigationStream.ts`
- Create: `console/src/components/InvestigationForm.tsx`
- Create: `console/src/components/InvestigationProgress.tsx`
- Create: `console/src/test/setup.ts`
- Create focused tests beside these modules.

**Interfaces:**
- Produces: `streamInvestigation(input, onEvent, signal)`.
- Consumes AG-UI camelCase JSON emitted by the official encoder.

- [ ] **Step 1: Scaffold only the dependencies needed by the approved design**

Create `console/package.json` with scripts `dev`, `build`, `test`, and dependencies including:

```json
{
  "react": "^19.0.0",
  "react-dom": "^19.0.0",
  "@a2ui/react": "0.10.2",
  "@a2ui/web_core": "0.10.6"
}
```

Dev dependencies: TypeScript, Vite, React plugin, Vitest, jsdom, `@testing-library/react`, `@testing-library/jest-dom`, and React type packages.

- [ ] **Step 2: Write SSE parser tests first**

Feed deliberately split byte chunks so a JSON event spans chunk boundaries. Assert the parser emits two complete event objects and ignores comments/blank lines.

- [ ] **Step 3: Run frontend RED**

```bash
cd console
npm install
npm test -- --run src/api/investigationStream.test.ts
```

Expected: fail until transport exists.

- [ ] **Step 4: Implement POST streaming transport**

Use `fetch()` with `response.body.getReader()` rather than browser `EventSource`, because the endpoint is POST with a JSON request body. Incrementally decode UTF-8, split complete SSE events on double newlines, join `data:` lines, and `JSON.parse` only complete event payloads.

- [ ] **Step 5: Write form/progress component tests**

Test that empty Request ID cannot submit, valid ISO/Z datetimes submit, and incoming step events map to visible labels such as `Splunk investigation` without exposing raw backend exception text.

- [ ] **Step 6: Implement minimal fixed UI**

`InvestigationForm` exposes only Request ID, earliest, and latest. `InvestigationProgress` maps the five stable machine step names to display labels and completion state.

- [ ] **Step 7: Run GREEN**

```bash
npm test -- --run
npm run build
```

- [ ] **Step 8: Commit**

```bash
git add console
git commit -m "feat: add console investigation stream client"
```

---

### Task 7: A2UI Processor, Approved Catalog, and Result Components

**Files:**
- Create: `console/src/a2ui/processor.ts`
- Create: `console/src/a2ui/catalog.tsx`
- Create: `console/src/a2ui/TroubleshootingSurface.tsx`
- Create: result component files listed in the File Map.
- Create tests for processor/catalog/gap/recommendation behavior.

**Interfaces:**
- Consumes only AG-UI `CUSTOM` events whose `name` is `a2ui.message`.
- Passes the nested value unchanged to `MessageProcessor`.
- Catalog ID must equal backend `dev.observability:troubleshooting-v1`.

- [ ] **Step 1: Write forwarding test**

Inject an unrelated `CUSTOM` event and an `a2ui.message` event. Assert only the latter calls `processor.processMessages([event.value])`.

- [ ] **Step 2: Write catalog safety tests**

Assert the exported catalog contains exactly the approved troubleshooting component names and no generic executable/action component. Add a RecommendationCard test asserting there is no `button`, `execute`, `remediate`, `deploy`, `restart`, or `rollback` control.

- [ ] **Step 3: Run RED**

```bash
npm test -- --run src/a2ui
```

- [ ] **Step 4: Implement A2UI message processor wrapper**

Use the official v0.9 API:

```ts
import { MessageProcessor } from '@a2ui/web_core/v0_9';
```

The wrapper owns one processor instance for the console session and forwards nested A2UI envelopes exactly once.

- [ ] **Step 5: Implement the approved catalog against installed official types**

Use the installed `@a2ui/react/v0_9` and `@a2ui/web_core/v0_9` catalog/renderer APIs, with catalog ID `dev.observability:troubleshooting-v1`. Define only the approved components and typed data bindings needed by the deterministic server-generated tree. Do not enable arbitrary inline catalogs received from the server.

The first implementation must use package-exported APIs/types discovered from the installed package; do not copy internal A2UI source into this repository. If the official renderer requires composition with its Basic Catalog for structural `Column`, register only that specific built-in catalog dependency plus the fixed troubleshooting catalog and keep all result-domain component names fixed.

- [ ] **Step 6: Implement visual components as pure renderers**

Each component renders supplied data as React text/DOM. `EvidenceCard` and `QueryDisclosure` render JSON-ish facts/arguments with escaped text (`<pre>{JSON.stringify(..., null, 2)}</pre>` is acceptable). Never use `dangerouslySetInnerHTML`.

`TimelineChart` for the PoC may be a semantic timeline/list if no chart library is already present; do not add a charting dependency solely for visual polish.

- [ ] **Step 7: Implement surface subscription**

Subscribe to `MessageProcessor` surface creation/update notifications and render the target investigation surface with official `A2uiSurface`/surface model APIs. Dispose subscriptions on unmount.

- [ ] **Step 8: Run GREEN and build**

```bash
npm test -- --run
npm run build
```

- [ ] **Step 9: Commit**

```bash
git add console/src/a2ui console/src/components
git commit -m "feat: render troubleshooting results with A2UI"
```

---

### Task 8: End-to-End Console Wiring and Live Smoke Test

**Files:**
- Modify: `console/src/app/App.tsx`
- Create: `tests/integration/test_phase5_live_console.py`
- Modify: `README.md`
- Modify: `.env.example` only for non-secret console settings if required.

**Interfaces:**
- Full vertical slice: Browser-equivalent POST -> FastAPI SSE -> AG-UI progress -> real `InvestigationOrchestrator` -> validated `InvestigationResult` -> A2UI `CUSTOM` events -> A2UI renderer.

- [ ] **Step 1: Wire App state**

On submit:
1. clear previous progress/result surface state;
2. start POST stream;
3. route lifecycle events to progress state;
4. route `CUSTOM/a2ui.message` events to the A2UI processor;
5. show sanitized `RUN_ERROR` text on failure;
6. stop busy state on `RUN_FINISHED` or `RUN_ERROR`.

- [ ] **Step 2: Add backend live smoke test first**

`tests/integration/test_phase5_live_console.py` uses the same environment readiness gates as Phase 4 live E2E, generates a fresh order request ID, waits for Splunk/New Relic availability, then calls the Phase 5 stream generator/ASGI endpoint. Assert:
- lifecycle starts with `RUN_STARTED`;
- all five steps appear in order;
- at least three `a2ui.message` custom events appear after analysis;
- final event is `RUN_FINISHED`;
- A2UI surface ID equals the emitted investigation ID.

Mark/skip unless the same live environment variables used by Phase 4 are present.

- [ ] **Step 3: Run all local verification**

Backend:

```bash
python -m pytest tests/unit -q
python -m pytest tests/integration/test_phase5_console_api.py -v
python -m compileall agent console_api shared services load_generator
```

Frontend:

```bash
cd console
npm test -- --run
npm run build
```

Expected: all local tests pass; live tests may skip without credentials/explicit flags.

- [ ] **Step 4: VM live smoke**

With the already-proven Phase 4 environment exported, run:

```bash
export RUN_PHASE5_LIVE_TESTS=1

docker run --rm \
  --network host \
  -v "$PWD:/workspace" \
  -w /workspace \
  -e SPLUNK_SEARCH_URL \
  -e SPLUNK_SEARCH_USERNAME \
  -e SPLUNK_SEARCH_PASSWORD \
  -e SPLUNK_SEARCH_VERIFY_SSL \
  -e NEW_RELIC_MCP_URL \
  -e NEW_RELIC_ACCOUNT_ID \
  -e LLM_PROVIDER \
  -e OLLAMA_BASE_URL \
  -e OLLAMA_MODEL \
  -e OLLAMA_REASONING_EFFORT \
  -e OLLAMA_TIMEOUT_SECONDS \
  -e RUN_OLLAMA_LIVE_TESTS \
  -e RUN_PHASE5_LIVE_TESTS \
  python:3.11-slim \
  sh -lc "
    python -m pip install -q -e '.[dev]' &&
    python -m pytest tests/integration/test_phase5_live_console.py -v
  "
```

Expected:

```text
test_live_phase5_console_streams_progress_and_a2ui_result PASSED
```

- [ ] **Step 5: Document run commands**

Add backend launch:

```bash
uvicorn console_api.app:app --host 0.0.0.0 --port 8095
```

Add frontend launch:

```bash
cd console
npm install
npm run dev -- --host 0.0.0.0
```

Document the Vite dev proxy `/api -> http://localhost:8095` so the browser receives no observability credentials.

- [ ] **Step 6: Final full regression**

Run all non-live Python tests plus frontend tests/build. On the VM, also re-run the previously-passing Phase 4 live E2E once after Phase 5 is installed to prove progress hooks did not alter its result behavior.

- [ ] **Step 7: Commit**

```bash
git add console tests/integration/test_phase5_live_console.py README.md .env.example
git commit -m "feat: complete Phase 5 troubleshooting console"
```

---

## Final Verification Checklist

- [ ] Existing Phase 4 tests remain green.
- [ ] Progress events are observational only and preserve exact Phase 4 control flow.
- [ ] Partial Splunk/New Relic unavailability is rendered as gaps, not `RUN_ERROR`.
- [ ] A2UI messages are emitted only after a validated `InvestigationResult` exists.
- [ ] A2UI version is `v0.9.1`; no v0.8 `beginRendering`/`surfaceUpdate` messages exist.
- [ ] Backend custom-event bridge is explicitly `CUSTOM(name="a2ui.message")`.
- [ ] Frontend accepts only the approved catalog; no arbitrary inline catalog is executed.
- [ ] No `dangerouslySetInnerHTML`.
- [ ] No execute/remediate/restart/deploy/rollback UI control exists.
- [ ] Gap IDs and Evidence IDs remain separate namespaces in presenter, A2UI data model, and UI labels.
- [ ] Public errors contain no injected secret-like strings.
- [ ] Request windows over two hours are rejected before the orchestrator runs.
- [ ] Backend unit/integration tests pass.
- [ ] Frontend unit tests and production build pass.
- [ ] Phase 5 VM live smoke passes against real Splunk + real New Relic MCP + selected real LLM.
