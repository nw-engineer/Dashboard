# Phase 4 Multi-Provider LLM Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Phase 4 use local Ollama `gpt-oss:20b` by default while retaining OpenAI and adding Azure OpenAI through the unchanged `IncidentAnalyzer` contract.

**Architecture:** Keep `InvestigationOrchestrator` and the Evidence-first domain provider-neutral. Move strict `IncidentAnalysis` schema handling into a shared helper, add native Ollama and Azure Responses adapters, and select a concrete analyzer through a small environment-driven factory with no automatic failover.

**Tech Stack:** Python 3.11+, `httpx`, Pydantic v2, pytest/pytest-asyncio, Ollama native `/api/chat`, OpenAI/Azure Responses API.

**Spec:** `docs/superpowers/specs/2026-09-03-phase4-multi-provider-llm-design.md`

## Global Constraints

- Python requirement remains `>=3.11,<3.14`.
- `IncidentAnalyzer.analyze(EvidenceBundle) -> IncidentAnalysis` remains unchanged.
- `InvestigationOrchestrator` remains responsible for `validate_analysis_references`.
- Default provider is `ollama`; there is no automatic failover.
- Ollama default model is exactly `gpt-oss:20b`.
- New Relic and Splunk remain Read Only.
- Recommended actions remain advisory only.
- No provider adapter may expose or persist reasoning/thinking content.
- Provider secrets remain environment-only and must not appear in error messages.

---

## File Structure

**Create**
- `agent/analysis/schema.py` — provider-neutral strict `IncidentAnalysis` JSON Schema helper.
- `agent/analysis/ollama_adapter.py` — native Ollama `/api/chat` analyzer.
- `agent/analysis/azure_openai_adapter.py` — Azure OpenAI Responses analyzer.
- `agent/analysis/factory.py` — `LLM_PROVIDER` selection.
- `tests/unit/test_ollama_incident_analyzer.py` — Ollama request/response/error/config unit coverage.
- `tests/unit/test_azure_openai_incident_analyzer.py` — Azure request/response/error/config unit coverage.
- `tests/unit/test_incident_analyzer_factory.py` — provider selection coverage.
- `tests/unit/analysis_fixtures.py` — shared EvidenceBundle / IncidentAnalysis fixture builders if duplication warrants extraction.
- `tests/integration/test_phase4_live_ollama_analysis.py` — real local Ollama provider-only test.
- `tests/integration/test_phase4_live_azure_openai_analysis.py` — credential-gated Azure provider-only test.

**Modify**
- `agent/analysis/openai_adapter.py` — import shared schema helper; keep v9 OpenAI behavior.
- `tests/unit/test_openai_incident_analyzer.py` — update imports only where schema helper moved; preserve behavioral coverage.
- `tests/integration/test_phase4_live_end_to_end.py` — use analyzer factory instead of hard-coded OpenAI analyzer.
- `.env.example` — document all three providers with local Ollama defaults.
- `README.md` — v10 provider architecture, setup, tests, and VM commands.

---

### Task 1: Extract provider-neutral strict schema helper

**Files:**
- Create: `agent/analysis/schema.py`
- Modify: `agent/analysis/openai_adapter.py`
- Modify: `tests/unit/test_openai_incident_analyzer.py`
- Test: `tests/unit/test_incident_analysis.py`
- Test: `tests/unit/test_openai_incident_analyzer.py`

**Interfaces:**
- Consumes: `IncidentAnalysis.model_json_schema()`.
- Produces: `build_incident_analysis_schema() -> dict`.

- [ ] **Step 1: Write/adjust the failing schema test against the new module**

```python
def test_strict_schema_requires_every_hypothesis_property():
    from agent.analysis.schema import build_incident_analysis_schema

    schema = build_incident_analysis_schema()
    hypothesis = schema["$defs"]["Hypothesis"]
    assert hypothesis["required"] == list(hypothesis["properties"])
    assert hypothesis["additionalProperties"] is False
```

- [ ] **Step 2: Run the focused test and verify RED**

Run:

```bash
python -m pytest tests/unit/test_openai_incident_analyzer.py::test_strict_schema_requires_every_hypothesis_property -v
```

Expected: FAIL because `agent.analysis.schema` does not exist.

- [ ] **Step 3: Create the minimal shared schema helper**

```python
from __future__ import annotations

import copy

from agent.analysis.models import IncidentAnalysis


def build_incident_analysis_schema() -> dict:
    schema = copy.deepcopy(IncidentAnalysis.model_json_schema())
    _make_object_properties_required(schema)
    return schema


def _make_object_properties_required(node) -> None:
    if isinstance(node, dict):
        properties = node.get("properties")
        if node.get("type") == "object" and isinstance(properties, dict):
            node["additionalProperties"] = False
            node["required"] = list(properties)
        for value in node.values():
            _make_object_properties_required(value)
    elif isinstance(node, list):
        for item in node:
            _make_object_properties_required(item)
```

Update `openai_adapter.py` to import `build_incident_analysis_schema` from the new module and remove the duplicate implementation.

- [ ] **Step 4: Run focused OpenAI/schema tests and verify GREEN**

```bash
python -m pytest tests/unit/test_incident_analysis.py tests/unit/test_openai_incident_analyzer.py -v
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add agent/analysis/schema.py agent/analysis/openai_adapter.py tests/unit/test_openai_incident_analyzer.py
git commit -m "refactor: share incident analysis schema"
```

---

### Task 2: Add native Ollama analyzer with `gpt-oss:20b` defaults

**Files:**
- Create: `agent/analysis/ollama_adapter.py`
- Create: `tests/unit/test_ollama_incident_analyzer.py`

**Interfaces:**
- Consumes: `EvidenceBundle`, `ANALYSIS_CONTRACT`, `build_incident_analysis_schema()`.
- Produces: `OllamaIncidentAnalyzer.from_env()` and `async analyze(bundle) -> IncidentAnalysis`.

- [ ] **Step 1: Write the first failing request-contract test**

```python
@pytest.mark.asyncio
async def test_ollama_analyzer_uses_native_chat_with_schema_and_no_streaming():
    captured = {}

    async def handler(request: httpx.Request) -> httpx.Response:
        captured["request"] = request
        captured["payload"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={
                "model": "gpt-oss:20b",
                "message": {"role": "assistant", "content": json.dumps(_analysis_payload())},
                "done": True,
                "done_reason": "stop",
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OllamaIncidentAnalyzer(
            base_url="http://localhost:11434",
            model="gpt-oss:20b",
            reasoning_effort="medium",
            client=client,
        )
        analysis = await analyzer.analyze(_bundle())

    assert analysis == IncidentAnalysis(**_analysis_payload())
    assert str(captured["request"].url) == "http://localhost:11434/api/chat"
    payload = captured["payload"]
    assert payload["model"] == "gpt-oss:20b"
    assert payload["stream"] is False
    assert payload["think"] == "medium"
    assert payload["format"] == build_incident_analysis_schema()
    assert payload["options"]["temperature"] == 0
```

- [ ] **Step 2: Run the test and verify RED**

```bash
python -m pytest tests/unit/test_ollama_incident_analyzer.py::test_ollama_analyzer_uses_native_chat_with_schema_and_no_streaming -v
```

Expected: FAIL because `OllamaIncidentAnalyzer` does not exist.

- [ ] **Step 3: Implement the minimal Ollama adapter**

```python
class OllamaConfigurationError(RuntimeError):
    pass


class OllamaAnalysisError(RuntimeError):
    pass


class OllamaIncidentAnalyzer:
    def __init__(
        self,
        *,
        base_url: str = "http://localhost:11434",
        model: str = "gpt-oss:20b",
        reasoning_effort: str = "medium",
        client: httpx.AsyncClient | None = None,
        timeout_seconds: float = 180.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.reasoning_effort = reasoning_effort
        self.client = client
        self.timeout_seconds = timeout_seconds

    @classmethod
    def from_env(cls) -> "OllamaIncidentAnalyzer":
        reasoning_effort = os.getenv("OLLAMA_REASONING_EFFORT", "medium").strip().lower()
        if reasoning_effort not in {"low", "medium", "high"}:
            raise OllamaConfigurationError(
                "OLLAMA_REASONING_EFFORT must be one of: low, medium, high"
            )
        return cls(
            base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
            model=os.getenv("OLLAMA_MODEL", "gpt-oss:20b"),
            reasoning_effort=reasoning_effort,
            timeout_seconds=_read_positive_float("OLLAMA_TIMEOUT_SECONDS", 180.0),
        )
```

`analyze()` posts `messages`, `stream=false`, `think`, `format`, and `options.temperature=0`; it parses `message.content` using `IncidentAnalysis.model_validate_json()`.

- [ ] **Step 4: Add failing tests one behavior at a time**

Add and RED/GREEN each of:

```text
from_env defaults to http://localhost:11434 + gpt-oss:20b + medium
invalid reasoning effort -> OllamaConfigurationError
invalid/non-positive timeout -> OllamaConfigurationError
connection failure -> OllamaAnalysisError
HTTP non-2xx -> OllamaAnalysisError without raw body
invalid top-level JSON -> OllamaAnalysisError
`done != true` -> OllamaAnalysisError
missing/empty message.content -> OllamaAnalysisError
invalid structured content -> OllamaAnalysisError
message.thinking is ignored
```

For every case run the individual test first and observe RED before adding production code.

- [ ] **Step 5: Run the complete Ollama unit file**

```bash
python -m pytest tests/unit/test_ollama_incident_analyzer.py -v
```

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add agent/analysis/ollama_adapter.py tests/unit/test_ollama_incident_analyzer.py
git commit -m "feat: add local ollama incident analyzer"
```

---

### Task 3: Add Azure OpenAI Responses analyzer

**Files:**
- Create: `agent/analysis/azure_openai_adapter.py`
- Create: `tests/unit/test_azure_openai_incident_analyzer.py`

**Interfaces:**
- Consumes: `EvidenceBundle`, `ANALYSIS_CONTRACT`, shared schema helper.
- Produces: `AzureOpenAIIncidentAnalyzer.from_env()` and `async analyze(bundle) -> IncidentAnalysis`.

- [ ] **Step 1: Write the failing Azure request-contract test**

```python
@pytest.mark.asyncio
async def test_azure_analyzer_uses_responses_api_with_api_key_and_strict_schema():
    captured = {}

    async def handler(request: httpx.Request) -> httpx.Response:
        captured["request"] = request
        captured["payload"] = json.loads(request.content)
        return httpx.Response(200, json=_completed_response(_analysis_payload()))

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = AzureOpenAIIncidentAnalyzer(
            api_key="azure-test-key",
            model="poc-analysis-deployment",
            base_url="https://example.openai.azure.com/openai/v1",
            client=client,
        )
        analysis = await analyzer.analyze(_bundle())

    assert analysis == IncidentAnalysis(**_analysis_payload())
    request = captured["request"]
    payload = captured["payload"]
    assert str(request.url) == "https://example.openai.azure.com/openai/v1/responses"
    assert request.headers["api-key"] == "azure-test-key"
    assert "authorization" not in request.headers
    assert payload["model"] == "poc-analysis-deployment"
    assert payload["store"] is False
    assert payload["text"]["format"]["strict"] is True
```

- [ ] **Step 2: Run and verify RED**

```bash
python -m pytest tests/unit/test_azure_openai_incident_analyzer.py::test_azure_analyzer_uses_responses_api_with_api_key_and_strict_schema -v
```

Expected: FAIL because the Azure adapter does not exist.

- [ ] **Step 3: Implement minimal Azure adapter**

Implement provider-specific config/error classes and the same Responses structured-output payload shape used by v9, but authenticate with `api-key` and use `AZURE_OPENAI_*` configuration.

Required environment validation:

```python
AZURE_OPENAI_API_KEY       # required
AZURE_OPENAI_BASE_URL      # required
AZURE_OPENAI_MODEL         # required
AZURE_OPENAI_MAX_OUTPUT_TOKENS  # integer > 0, default 2500
AZURE_OPENAI_TIMEOUT_SECONDS    # float > 0, default 60
```

- [ ] **Step 4: RED/GREEN provider-specific error/config behaviors**

Cover individually:

```text
missing API key -> AzureOpenAIConfigurationError
missing base URL -> AzureOpenAIConfigurationError
missing model -> AzureOpenAIConfigurationError
invalid token/timeout config -> AzureOpenAIConfigurationError
connection error -> AzureOpenAIAnalysisError
HTTP non-2xx -> safe AzureOpenAIAnalysisError
refusal -> AzureOpenAIAnalysisError
incomplete response -> AzureOpenAIAnalysisError
invalid structured output -> AzureOpenAIAnalysisError
```

- [ ] **Step 5: Run Azure tests**

```bash
python -m pytest tests/unit/test_azure_openai_incident_analyzer.py -v
```

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add agent/analysis/azure_openai_adapter.py tests/unit/test_azure_openai_incident_analyzer.py
git commit -m "feat: add azure openai incident analyzer"
```

---

### Task 4: Add environment-driven analyzer factory

**Files:**
- Create: `agent/analysis/factory.py`
- Create: `tests/unit/test_incident_analyzer_factory.py`

**Interfaces:**
- Consumes: the three adapters' `from_env()` constructors.
- Produces: `create_incident_analyzer_from_env() -> IncidentAnalyzer`.

- [ ] **Step 1: Write the failing default-provider test**

```python
def test_factory_defaults_to_ollama(monkeypatch):
    monkeypatch.delenv("LLM_PROVIDER", raising=False)
    analyzer = create_incident_analyzer_from_env()
    assert isinstance(analyzer, OllamaIncidentAnalyzer)
```

- [ ] **Step 2: Run and verify RED**

```bash
python -m pytest tests/unit/test_incident_analyzer_factory.py::test_factory_defaults_to_ollama -v
```

Expected: FAIL because `factory.py` does not exist.

- [ ] **Step 3: Implement minimal factory**

```python
class LLMProviderConfigurationError(RuntimeError):
    pass


def create_incident_analyzer_from_env() -> IncidentAnalyzer:
    provider = os.getenv("LLM_PROVIDER", "ollama").strip().lower()
    if provider == "ollama":
        return OllamaIncidentAnalyzer.from_env()
    if provider == "azure_openai":
        return AzureOpenAIIncidentAnalyzer.from_env()
    if provider == "openai":
        return OpenAIIncidentAnalyzer.from_env()
    raise LLMProviderConfigurationError(
        "LLM_PROVIDER must be one of: ollama, azure_openai, openai"
    )
```

- [ ] **Step 4: Add selection tests**

Write isolated tests for:

```text
explicit ollama
azure_openai
openai
case/whitespace normalization
unknown value rejected
```

Use monkeypatch to replace each adapter's `from_env()` so the factory test verifies selection without requiring real credentials.

- [ ] **Step 5: Run factory tests**

```bash
python -m pytest tests/unit/test_incident_analyzer_factory.py -v
```

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add agent/analysis/factory.py tests/unit/test_incident_analyzer_factory.py
git commit -m "feat: select incident analyzer by provider"
```

---

### Task 5: Make the full Phase 4 live E2E provider-neutral

**Files:**
- Modify: `tests/integration/test_phase4_live_end_to_end.py`
- Test: `tests/unit/test_investigation_orchestrator.py`

**Interfaces:**
- Consumes: `create_incident_analyzer_from_env()`.
- Produces: one E2E test whose LLM backend is selected only by environment.

- [ ] **Step 1: Write the failing composition expectation**

Change the E2E test import/construction from:

```python
analyzer=OpenAIIncidentAnalyzer.from_env()
```

to:

```python
analyzer=create_incident_analyzer_from_env()
```

and add a small unit-level composition test if needed to prove the factory is called rather than OpenAI directly.

- [ ] **Step 2: Run the relevant unit tests**

```bash
python -m pytest tests/unit/test_investigation_orchestrator.py tests/unit/test_incident_analyzer_factory.py -v
```

Expected after implementation: PASS.

- [ ] **Step 3: Preserve existing orchestration assertions**

Do not weaken assertions that require both Splunk and New Relic evidence and non-empty `incident_summary`, `impact`, and `likely_cause`.

- [ ] **Step 4: Commit**

```bash
git add tests/integration/test_phase4_live_end_to_end.py tests/unit/test_investigation_orchestrator.py
git commit -m "test: make phase4 live e2e provider neutral"
```

---

### Task 6: Add real provider-only live tests

**Files:**
- Create: `tests/integration/test_phase4_live_ollama_analysis.py`
- Create: `tests/integration/test_phase4_live_azure_openai_analysis.py`
- Modify: `tests/integration/test_phase4_live_openai_analysis.py` only if shared fixtures/imports require it.

**Interfaces:**
- Consumes: concrete provider adapters and `validate_analysis_references`.
- Produces: real provider boundary checks independent of Splunk/New Relic.

- [ ] **Step 1: Add the Ollama live test**

Gate explicitly:

```python
if os.getenv("RUN_OLLAMA_LIVE_TESTS") != "1":
    pytest.skip("RUN_OLLAMA_LIVE_TESTS=1 is required")
```

Use the same deterministic in-memory EvidenceBundle used by the OpenAI live test and execute:

```python
analyzer = OllamaIncidentAnalyzer.from_env()
analysis = await analyzer.analyze(bundle)
validate_analysis_references(bundle, analysis)
assert analysis.incident_summary
assert analysis.impact
assert analysis.likely_cause
```

- [ ] **Step 2: Add the Azure live test**

Gate with `RUN_AZURE_OPENAI_LIVE_TESTS=1` and the required `AZURE_OPENAI_*` values. Execute the same contract assertions.

- [ ] **Step 3: Verify local no-credential behavior is SKIP, not FAIL**

```bash
python -m pytest \
  tests/integration/test_phase4_live_ollama_analysis.py \
  tests/integration/test_phase4_live_azure_openai_analysis.py \
  tests/integration/test_phase4_live_openai_analysis.py \
  -v
```

Expected in a credential-free build environment: all corresponding live tests SKIP cleanly.

- [ ] **Step 4: Commit**

```bash
git add tests/integration/test_phase4_live_ollama_analysis.py tests/integration/test_phase4_live_azure_openai_analysis.py tests/integration/test_phase4_live_openai_analysis.py
git commit -m "test: add multi provider live llm checks"
```

---

### Task 7: Document provider configuration and local `gpt-oss:20b` workflow

**Files:**
- Modify: `.env.example`
- Modify: `README.md`

**Interfaces:**
- Consumes: exact environment variable names implemented in Tasks 2-4.
- Produces: copy/paste VM commands for Ollama, Azure, and OpenAI.

- [ ] **Step 1: Update `.env.example`**

Add:

```text
# Phase 4 real LLM provider
LLM_PROVIDER=ollama

# Local Ollama (default)
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=gpt-oss:20b
OLLAMA_REASONING_EFFORT=medium
OLLAMA_TIMEOUT_SECONDS=180

# Azure OpenAI Responses API
AZURE_OPENAI_API_KEY=
AZURE_OPENAI_BASE_URL=
AZURE_OPENAI_MODEL=
AZURE_OPENAI_MAX_OUTPUT_TOKENS=2500
AZURE_OPENAI_TIMEOUT_SECONDS=60

# OpenAI Responses API (optional provider)
OPENAI_API_KEY=
OPENAI_MODEL=gpt-5.6-luna
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MAX_OUTPUT_TOKENS=2500
```

- [ ] **Step 2: Add README v10 architecture and commands**

Include these local steps verbatim in intent:

```bash
ollama pull gpt-oss:20b
ollama list
curl http://localhost:11434/api/tags

export LLM_PROVIDER=ollama
export OLLAMA_BASE_URL=http://localhost:11434
export OLLAMA_MODEL=gpt-oss:20b
export OLLAMA_REASONING_EFFORT=medium
export RUN_OLLAMA_LIVE_TESTS=1

python -m pytest tests/integration/test_phase4_live_ollama_analysis.py -v
python -m pytest tests/integration/test_phase4_live_end_to_end.py -v
```

Also document Azure and OpenAI environment examples and state explicitly that no automatic provider fallback exists.

- [ ] **Step 3: Run documentation/config regression tests**

```bash
python -m pytest tests/unit/test_newrelic_env.py tests/unit/test_external_ports_config.py -v
```

Expected: PASS.

- [ ] **Step 4: Commit**

```bash
git add .env.example README.md
git commit -m "docs: add multi provider llm setup"
```

---

### Task 8: Full verification and v10 packaging

**Files:**
- Verify all source/tests/docs.
- Create deployment archive outside the project directory.
- Update handoff documentation only after verified results are known.

**Interfaces:**
- Consumes: all prior tasks.
- Produces: verified v10 Zip + SHA256 + updated handoff.

- [ ] **Step 1: Run all unit tests fresh**

```bash
python -m pytest tests/unit -q
```

Expected: zero failures.

- [ ] **Step 2: Run compile verification**

```bash
python -m compileall -q agent shared services load_generator
```

Expected: exit code 0.

- [ ] **Step 3: Run live-test collection in no-secret mode**

```bash
python -m pytest \
  tests/integration/test_phase4_live_change_tracking.py \
  tests/integration/test_phase4_live_cross_source.py \
  tests/integration/test_phase4_live_ollama_analysis.py \
  tests/integration/test_phase4_live_azure_openai_analysis.py \
  tests/integration/test_phase4_live_openai_analysis.py \
  tests/integration/test_phase4_live_end_to_end.py \
  -v
```

Expected locally: credential/service-gated tests SKIP rather than error. On the VM, run the applicable tests with real services and variables.

- [ ] **Step 4: Scan packaged source for accidental secret values**

Inspect `.env.example`, source, docs, and generated archive content. Test fixture placeholder strings are allowed; real credential values are not.

- [ ] **Step 5: Update handoff with actual verification results**

Record only observed PASS/SKIP results. Do not claim Ollama or Azure live PASS until run in the corresponding real environment.

- [ ] **Step 6: Create archive and checksum**

```bash
cd ..
zip -qr observability-ai-poc-phase4-multi-provider-v10.zip observability-ai-poc \
  -x 'observability-ai-poc/.venv/*' \
     'observability-ai-poc/.pytest_cache/*' \
     'observability-ai-poc/**/__pycache__/*'
sha256sum observability-ai-poc-phase4-multi-provider-v10.zip \
  > observability-ai-poc-phase4-multi-provider-v10.sha256
```

- [ ] **Step 7: Final verification before completion claim**

Re-run the exact unit and compile commands after all documentation/handoff changes. Report the fresh counts and distinguish local verification from VM live verification.
