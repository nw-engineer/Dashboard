from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo

import pytest

from newrelic_mcp.errors import ValidationError
from newrelic_mcp.utils import (
    entity_guid_predicate,
    parse_time_period,
    percent_change,
    quote_nrql,
    validate_nrql,
    validate_window,
)


def test_quote_nrql_escapes_quotes_and_slashes() -> None:
    assert quote_nrql("a'b\\c") == "'a\\'b\\\\c'"


def test_entity_guid_predicate_covers_common_attributes() -> None:
    result = entity_guid_predicate("ABC")
    assert "`entity.guid`" in result
    assert "entityGuid" in result


def test_read_only_nrql_rejects_delete() -> None:
    with pytest.raises(ValidationError):
        validate_nrql("DELETE FROM Log", read_only=True, max_length=1000)


def test_read_only_nrql_accepts_select() -> None:
    assert validate_nrql(
        " SELECT count(*) FROM Transaction ", read_only=True, max_length=1000
    ) == "SELECT count(*) FROM Transaction"


def test_validate_window_defaults_to_one_hour() -> None:
    start, end = validate_window(1_700_000_000_000, None)
    assert end - start == 3_600_000


def test_percent_change() -> None:
    assert percent_change(100, 120) == 20
    assert percent_change(0, 0) is None
    assert percent_change(0, 5) == 100


def test_parse_last_24_hours() -> None:
    result = parse_time_period("last 24 hours", ZoneInfo("Asia/Tokyo"))
    assert result["end_time_ms"] - result["start_time_ms"] == 24 * 3_600_000
    assert result["parse_strategy"] == "relative_range"


def test_parse_epoch_range() -> None:
    result = parse_time_period(
        "from 1767690300000 until 1767691800000", ZoneInfo("UTC")
    )
    assert result["start_time_ms"] == 1767690300000
    assert result["end_time_ms"] == 1767691800000
