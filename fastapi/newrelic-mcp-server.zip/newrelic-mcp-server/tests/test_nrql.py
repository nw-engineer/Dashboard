from __future__ import annotations

from newrelic_mcp.nrql import infer_nrql, transaction_queries


def test_infer_japanese_error_rate() -> None:
    result = infer_nrql("order-apiの直近1時間のエラー率を見せて")
    assert result["category"] == "transaction_error_rate"
    assert "percentage" in result["nrql_query"]


def test_infer_logs() -> None:
    result = infer_nrql("last 30 minutes error logs")
    assert result["category"] == "logs"
    assert "FROM Log" in result["nrql_query"]


def test_transaction_queries_contain_guid_and_windows() -> None:
    queries = transaction_queries("GUID", 1000, 2000, 5)
    assert set(queries) == {
        "summary",
        "top_transactions",
        "slow_transactions",
        "errors",
        "throughput_chart",
        "duration_chart",
        "tail_chart",
    }
    assert "GUID" in queries["summary"]
    assert "SINCE 1000 UNTIL 2000" in queries["summary"]
