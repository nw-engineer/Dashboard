from __future__ import annotations

import json

import httpx
import pytest

from newrelic_mcp.client import NewRelicClient
from newrelic_mcp.config import Settings


def settings() -> Settings:
    return Settings(
        user_key="test-key",
        graphql_url="https://example.invalid/graphql",
        region="US",
        timezone_name="UTC",
        http_timeout_seconds=10,
        allowed_account_ids=frozenset({123}),
        max_time_window_days=30,
        read_only_nrql=True,
        max_nrql_length=20_000,
        mcp_transport="stdio",
        mcp_host="127.0.0.1",
        mcp_port=8000,
    )


@pytest.mark.asyncio
async def test_nrql_parses_results() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        assert body["variables"]["accountId"] == 123
        return httpx.Response(
            200,
            json={
                "data": {
                    "actor": {
                        "account": {"nrql": {"results": [{"count": 42}]}}
                    }
                }
            },
        )

    http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    client = NewRelicClient(settings(), http=http)
    result = await client.nrql(123, "SELECT count(*) FROM Transaction")
    assert result["results"] == [{"count": 42}]
    await http.aclose()


@pytest.mark.asyncio
async def test_entity_search_parses_cursor() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "data": {
                    "actor": {
                        "entitySearch": {
                            "query": "name LIKE '%api%'",
                            "results": {
                                "nextCursor": "next",
                                "entities": [{"guid": "G", "accountId": 123}],
                            },
                        }
                    }
                }
            },
        )

    http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    client = NewRelicClient(settings(), http=http)
    result = await client.entity_search("name LIKE '%api%'")
    assert result["next_cursor"] == "next"
    assert result["entities"][0]["guid"] == "G"
    await http.aclose()
