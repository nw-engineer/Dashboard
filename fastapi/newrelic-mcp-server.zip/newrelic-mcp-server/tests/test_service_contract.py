from __future__ import annotations

from newrelic_mcp.service import NewRelicToolService


EXPECTED_TOOLS = {
    "list_available_new_relic_accounts",
    "list_recent_issues",
    "list_change_events",
    "list_recent_logs",
    "search_entity_with_tag",
    "execute_nrql_query",
    "list_synthetic_monitors",
    "list_alert_policies",
    "list_dashboards",
    "natural_language_to_nrql_query",
    "generate_alert_insights_report",
    "analyze_deployment_impact",
    "generate_user_impact_report",
    "analyze_entity_logs",
    "analyze_golden_metrics",
    "analyze_kafka_metrics",
    "analyze_threads",
    "analyze_transactions",
    "convert_time_period_to_epoch_ms",
    "get_entity",
    "list_entity_error_groups",
    "list_garbage_collection_metrics",
    "list_related_entities",
    "search_incident",
    "get_dashboard",
    "list_alert_conditions",
}


def test_all_26_tool_methods_exist() -> None:
    methods = {
        name
        for name in dir(NewRelicToolService)
        if not name.startswith("_") and callable(getattr(NewRelicToolService, name))
    }
    assert EXPECTED_TOOLS <= methods
    assert len(EXPECTED_TOOLS) == 26
