from __future__ import annotations

import asyncio
import json
from typing import Any

import httpx

from .config import Settings
from .errors import NewRelicAPIError
from .utils import validate_account_id, validate_nrql


class NewRelicClient:
    """Small async client for NerdGraph and NRQL."""

    def __init__(self, settings: Settings, http: httpx.AsyncClient | None = None) -> None:
        self.settings = settings
        self._owns_http = http is None
        self.http = http or httpx.AsyncClient(
            timeout=httpx.Timeout(settings.http_timeout_seconds),
            headers={
                "API-Key": settings.user_key,
                "Content-Type": "application/json",
                "User-Agent": "newrelic-mcp-server/0.1.0",
            },
        )

    async def close(self) -> None:
        if self._owns_http:
            await self.http.aclose()

    async def graphql(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        *,
        retries: int = 2,
    ) -> dict[str, Any]:
        payload = {"query": query, "variables": variables or {}}
        last_error: Exception | None = None
        for attempt in range(retries + 1):
            try:
                response = await self.http.post(self.settings.graphql_url, json=payload)
                if response.status_code in {429, 502, 503, 504} and attempt < retries:
                    await asyncio.sleep(0.5 * (2**attempt))
                    continue
                response.raise_for_status()
                body = response.json()
                if body.get("errors"):
                    raise NewRelicAPIError("NerdGraph returned errors", details=body["errors"])
                data = body.get("data")
                if not isinstance(data, dict):
                    raise NewRelicAPIError("NerdGraph response did not contain a data object")
                return data
            except (httpx.HTTPError, ValueError, NewRelicAPIError) as exc:
                last_error = exc
                if attempt < retries and not isinstance(exc, NewRelicAPIError):
                    await asyncio.sleep(0.5 * (2**attempt))
                    continue
                break
        if isinstance(last_error, NewRelicAPIError):
            raise last_error
        raise NewRelicAPIError(f"NerdGraph request failed: {last_error}") from last_error

    async def nrql(self, account_id: int, query: str) -> dict[str, Any]:
        validate_account_id(account_id, self.settings.allowed_account_ids)
        query = validate_nrql(
            query,
            read_only=self.settings.read_only_nrql,
            max_length=self.settings.max_nrql_length,
        )
        # Embed the validated NRQL as a JSON-escaped GraphQL string literal. This avoids
        # depending on an implementation-specific GraphQL scalar name for NRQL variables.
        document = f"""
        query RunNrql($accountId: Int!) {{
          actor {{
            account(id: $accountId) {{
              nrql(query: {json.dumps(query)}, timeout: 70) {{
                results
              }}
            }}
          }}
        }}
        """
        data = await self.graphql(document, {"accountId": account_id})
        node = data.get("actor", {}).get("account", {}).get("nrql", {})
        return {
            "account_id": account_id,
            "nrql_query": query,
            "results": node.get("results", []),
        }

    async def get_entity(self, guid: str) -> dict[str, Any] | None:
        document = """
        query GetEntity($guid: EntityGuid!) {
          actor {
            entity(guid: $guid) {
              guid
              name
              accountId
              domain
              entityType
              reporting
              tags { key values }
              ... on AlertableEntityOutline { alertSeverity }
            }
          }
        }
        """
        data = await self.graphql(document, {"guid": guid})
        entity = data.get("actor", {}).get("entity")
        return entity if isinstance(entity, dict) else None

    async def entity_search(self, query: str, cursor: str | None = None) -> dict[str, Any]:
        document = """
        query SearchEntities($query: String!, $cursor: String) {
          actor {
            entitySearch(query: $query) {
              query
              results(cursor: $cursor) {
                nextCursor
                entities {
                  guid
                  name
                  accountId
                  domain
                  entityType
                  reporting
                  tags { key values }
                  ... on AlertableEntityOutline { alertSeverity }
                  ... on SyntheticMonitorEntityOutline { monitorId monitorType }
                }
              }
            }
          }
        }
        """
        data = await self.graphql(document, {"query": query, "cursor": cursor})
        search = data.get("actor", {}).get("entitySearch", {})
        results = search.get("results", {}) if isinstance(search, dict) else {}
        return {
            "query": search.get("query", query) if isinstance(search, dict) else query,
            "entities": results.get("entities", []),
            "next_cursor": results.get("nextCursor"),
        }
