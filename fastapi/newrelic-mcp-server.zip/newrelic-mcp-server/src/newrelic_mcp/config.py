from __future__ import annotations

import os
from dataclasses import dataclass
from zoneinfo import ZoneInfo

from dotenv import load_dotenv

from .errors import ConfigurationError


REGION_ENDPOINTS = {
    "US": "https://api.newrelic.com/graphql",
    "EU": "https://api.eu.newrelic.com/graphql",
    "JP": "https://api.jp.newrelic.com/graphql",
}


def _bool_env(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _int_env(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None or not value.strip():
        return default
    try:
        return int(value)
    except ValueError as exc:
        raise ConfigurationError(f"{name} must be an integer") from exc


def _float_env(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None or not value.strip():
        return default
    try:
        return float(value)
    except ValueError as exc:
        raise ConfigurationError(f"{name} must be numeric") from exc


@dataclass(frozen=True, slots=True)
class Settings:
    user_key: str
    graphql_url: str
    region: str
    timezone_name: str
    http_timeout_seconds: float
    allowed_account_ids: frozenset[int]
    max_time_window_days: int
    read_only_nrql: bool
    max_nrql_length: int
    mcp_transport: str
    mcp_host: str
    mcp_port: int

    @property
    def timezone(self) -> ZoneInfo:
        try:
            return ZoneInfo(self.timezone_name)
        except Exception as exc:
            raise ConfigurationError(
                f"Unknown NEW_RELIC_TIMEZONE: {self.timezone_name}"
            ) from exc

    @classmethod
    def from_env(cls, *, require_key: bool = True) -> "Settings":
        load_dotenv()
        user_key = os.getenv("NEW_RELIC_USER_KEY", "").strip()
        if require_key and not user_key:
            raise ConfigurationError("NEW_RELIC_USER_KEY is required")

        region = os.getenv("NEW_RELIC_REGION", "US").strip().upper()
        custom_url = os.getenv("NEW_RELIC_GRAPHQL_URL", "").strip()
        if custom_url:
            graphql_url = custom_url
        else:
            try:
                graphql_url = REGION_ENDPOINTS[region]
            except KeyError as exc:
                raise ConfigurationError(
                    "NEW_RELIC_REGION must be US, EU, or JP, or set NEW_RELIC_GRAPHQL_URL"
                ) from exc

        allow_raw = os.getenv("NEW_RELIC_ALLOWED_ACCOUNT_IDS", "")
        allowed: set[int] = set()
        for item in allow_raw.split(","):
            item = item.strip()
            if not item:
                continue
            try:
                allowed.add(int(item))
            except ValueError as exc:
                raise ConfigurationError(
                    "NEW_RELIC_ALLOWED_ACCOUNT_IDS must be comma-separated integers"
                ) from exc

        transport = os.getenv("MCP_TRANSPORT", "stdio").strip().lower()
        if transport not in {"stdio", "streamable-http"}:
            raise ConfigurationError("MCP_TRANSPORT must be stdio or streamable-http")

        return cls(
            user_key=user_key,
            graphql_url=graphql_url,
            region=region,
            timezone_name=os.getenv("NEW_RELIC_TIMEZONE", "Asia/Tokyo").strip(),
            http_timeout_seconds=_float_env("NEW_RELIC_HTTP_TIMEOUT_SECONDS", 75.0),
            allowed_account_ids=frozenset(allowed),
            max_time_window_days=_int_env("NEW_RELIC_MAX_TIME_WINDOW_DAYS", 30),
            read_only_nrql=_bool_env("NEW_RELIC_READ_ONLY_NRQL", True),
            max_nrql_length=_int_env("NEW_RELIC_MAX_NRQL_LENGTH", 20_000),
            mcp_transport=transport,
            mcp_host=os.getenv("MCP_HOST", "127.0.0.1").strip(),
            mcp_port=_int_env("MCP_PORT", 8000),
        )
