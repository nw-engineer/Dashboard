from __future__ import annotations

from .config import Settings
from .server import mcp


def main() -> None:
    settings = Settings.from_env(require_key=True)
    if settings.mcp_transport == "streamable-http":
        mcp.run(
            transport="streamable-http",
            host=settings.mcp_host,
            port=settings.mcp_port,
        )
    else:
        mcp.run()


if __name__ == "__main__":
    main()
