from __future__ import annotations

from typing import Any

from mcp.server import MCPServer

from .client import NewRelicClient
from .config import Settings
from .errors import NewRelicMCPError
from .service import NewRelicToolService

mcp = MCPServer(
    "New Relic MCP",
    version="0.1.0",
    instructions=(
        "Read-only New Relic observability tools. Resolve account IDs and entity GUIDs before "
        "calling analysis tools. Prefer specialized analysis tools over arbitrary NRQL."
    ),
)

_service: NewRelicToolService | None = None


def get_service() -> NewRelicToolService:
    global _service
    if _service is None:
        settings = Settings.from_env(require_key=True)
        _service = NewRelicToolService(NewRelicClient(settings))
    return _service


async def _call(method_name: str, **kwargs: Any) -> dict[str, Any]:
    try:
        method = getattr(get_service(), method_name)
        result = await method(**kwargs)
        return {"ok": True, **result}
    except NewRelicMCPError as exc:
        details = getattr(exc, "details", None)
        return {
            "ok": False,
            "error": type(exc).__name__,
            "message": str(exc),
            "details": details,
        }
    except Exception as exc:  # Defensive boundary for MCP clients.
        return {
            "ok": False,
            "error": type(exc).__name__,
            "message": str(exc),
        }


@mcp.tool()
async def list_available_new_relic_accounts() -> dict[str, Any]:
    """List New Relic account IDs and names accessible to the authenticated user."""
    return await _call("list_available_new_relic_accounts")


@mcp.tool()
async def list_recent_issues(
    account_id: int,
    cursor: str | None = None,
    start_time_ms: int | None = None,
    end_time_ms: int | None = None,
    priorities: list[str] | None = None,
    skip_time_filter: bool = False,
) -> dict[str, Any]:
    """List New Relic issues, normally within the last 24 hours, with optional priority filters."""
    return await _call(
        "list_recent_issues",
        account_id=account_id,
        cursor=cursor,
        start_time_ms=start_time_ms,
        end_time_ms=end_time_ms,
        priorities=priorities,
        skip_time_filter=skip_time_filter,
    )


@mcp.tool()
async def list_change_events(entity_guid: str, history_period_hours: int = 48) -> dict[str, Any]:
    """Retrieve deployment and change-tracking events for an entity."""
    return await _call(
        "list_change_events",
        entity_guid=entity_guid,
        history_period_hours=history_period_hours,
    )


@mcp.tool()
async def list_recent_logs(
    account_id: int,
    number_of_logs: int = 100,
    history_period_minutes: int = 60,
    entity_guid: str = "",
    start_time_ms: int | None = None,
    end_time_ms: int | None = None,
) -> dict[str, Any]:
    """Retrieve recent log records, optionally scoped to a New Relic entity GUID."""
    return await _call(
        "list_recent_logs",
        account_id=account_id,
        number_of_logs=number_of_logs,
        history_period_minutes=history_period_minutes,
        entity_guid=entity_guid,
        start_time_ms=start_time_ms,
        end_time_ms=end_time_ms,
    )


@mcp.tool()
async def search_entity_with_tag(
    tag_key: str,
    tag_value: str,
    limit: int = 50,
    cursor: str | None = None,
) -> dict[str, Any]:
    """Search New Relic entities by an exact tag key and value."""
    return await _call(
        "search_entity_with_tag",
        tag_key=tag_key,
        tag_value=tag_value,
        limit=limit,
        cursor=cursor,
    )


@mcp.tool()
async def execute_nrql_query(nrql_query: str, account_id: int) -> dict[str, Any]:
    """Execute a read-only NRQL SELECT query for telemetry not covered by specialized tools."""
    return await _call("execute_nrql_query", nrql_query=nrql_query, account_id=account_id)


@mcp.tool()
async def list_synthetic_monitors(
    account_id: int,
    limit: int = 50,
    cursor: str | None = None,
) -> dict[str, Any]:
    """List synthetic monitors for a New Relic account."""
    return await _call(
        "list_synthetic_monitors", account_id=account_id, limit=limit, cursor=cursor
    )


@mcp.tool()
async def list_alert_policies(
    account_id: int,
    policy_name: str | None = None,
    cursor: str | None = None,
) -> dict[str, Any]:
    """List alert policies, optionally filtering by a partial policy name."""
    return await _call(
        "list_alert_policies",
        account_id=account_id,
        policy_name=policy_name,
        cursor=cursor,
    )


@mcp.tool()
async def list_dashboards(
    account_id: int,
    limit: int = 50,
    cursor: str | None = None,
) -> dict[str, Any]:
    """List dashboard entities for a New Relic account."""
    return await _call("list_dashboards", account_id=account_id, limit=limit, cursor=cursor)


@mcp.tool()
async def natural_language_to_nrql_query(user_request: str, account_id: int) -> dict[str, Any]:
    """Convert common English or Japanese observability requests to NRQL and execute them."""
    return await _call(
        "natural_language_to_nrql_query",
        user_request=user_request,
        account_id=account_id,
    )


@mcp.tool()
async def generate_alert_insights_report(
    issue_id: str,
    account_id: int,
    start_time_ms: int | None = None,
    end_time_ms: int | None = None,
    details: str | None = None,
) -> dict[str, Any]:
    """Generate a deterministic issue report using incident events and affected entities."""
    return await _call(
        "generate_alert_insights_report",
        issue_id=issue_id,
        account_id=account_id,
        start_time_ms=start_time_ms,
        end_time_ms=end_time_ms,
        details=details,
    )


@mcp.tool()
async def analyze_deployment_impact(
    entity_guid: str,
    deployment_timestamp_ms: int,
    account_id: int,
) -> dict[str, Any]:
    """Compare transaction metrics for 30 minutes before and after a deployment."""
    return await _call(
        "analyze_deployment_impact",
        entity_guid=entity_guid,
        deployment_timestamp_ms=deployment_timestamp_ms,
        account_id=account_id,
    )


@mcp.tool()
async def generate_user_impact_report(
    issue_id: str,
    account_id: int,
    entity_guid: str,
    deployment_start_timestamp_ms: int,
    relationship_depth: int = 1,
) -> dict[str, Any]:
    """Estimate end-user impact from browser telemetry and related entities."""
    return await _call(
        "generate_user_impact_report",
        issue_id=issue_id,
        account_id=account_id,
        entity_guid=entity_guid,
        deployment_start_timestamp_ms=deployment_start_timestamp_ms,
        relationship_depth=relationship_depth,
    )


@mcp.tool()
async def analyze_entity_logs(
    entity_guid: str,
    start_time_ms: int,
    end_time_ms: int | None = None,
) -> dict[str, Any]:
    """Analyze log volume, patterns, errors, and error timelines for up to one day."""
    return await _call(
        "analyze_entity_logs",
        entity_guid=entity_guid,
        start_time_ms=start_time_ms,
        end_time_ms=end_time_ms,
    )


@mcp.tool()
async def analyze_golden_metrics(
    entity_guid: str,
    start_time_ms: int,
    end_time_ms: int | None = None,
) -> dict[str, Any]:
    """Analyze APM or infrastructure golden signals for an entity."""
    return await _call(
        "analyze_golden_metrics",
        entity_guid=entity_guid,
        start_time_ms=start_time_ms,
        end_time_ms=end_time_ms,
    )


@mcp.tool()
async def analyze_kafka_metrics(
    entity_guid: str,
    start_time_ms: int,
    end_time_ms: int | None = None,
    timeseries_bucket: int = 1,
    issue_account_id: int | None = None,
    issue_id: str | None = None,
) -> dict[str, Any]:
    """Analyze Kafka-related Metric data, including lag, throughput, and latency."""
    return await _call(
        "analyze_kafka_metrics",
        entity_guid=entity_guid,
        start_time_ms=start_time_ms,
        end_time_ms=end_time_ms,
        timeseries_bucket=timeseries_bucket,
        issue_account_id=issue_account_id,
        issue_id=issue_id,
    )


@mcp.tool()
async def analyze_threads(
    entity_guid: str,
    start_time_ms: int,
    end_time_ms: int | None = None,
) -> dict[str, Any]:
    """Retrieve thread-related metrics for diagnosing deadlocks and resource pressure."""
    return await _call(
        "analyze_threads",
        entity_guid=entity_guid,
        start_time_ms=start_time_ms,
        end_time_ms=end_time_ms,
    )


@mcp.tool()
async def analyze_transactions(
    entity_guid: str,
    start_time_ms: int,
    end_time_ms: int | None = None,
    error_transaction_limit: int = 5,
) -> dict[str, Any]:
    """Analyze APM transaction latency, errors, throughput, Apdex, and top endpoints."""
    return await _call(
        "analyze_transactions",
        entity_guid=entity_guid,
        start_time_ms=start_time_ms,
        end_time_ms=end_time_ms,
        error_transaction_limit=error_transaction_limit,
    )


@mcp.tool()
async def convert_time_period_to_epoch_ms(text_input: str) -> dict[str, Any]:
    """Convert common natural-language time periods into epoch milliseconds."""
    return await _call("convert_time_period_to_epoch_ms", text_input=text_input)


@mcp.tool()
async def get_entity(
    entity_guid: str | None = None,
    name_pattern: str | None = None,
    domains: list[str] | None = None,
    types: list[str] | None = None,
) -> dict[str, Any]:
    """Find an entity by exact GUID or search by name, domain, and entity type."""
    return await _call(
        "get_entity",
        entity_guid=entity_guid,
        name_pattern=name_pattern,
        domains=domains,
        types=types,
    )


@mcp.tool()
async def list_entity_error_groups(
    entity_guid: str,
    start_time_ms: int,
    end_time_ms: int | None = None,
) -> dict[str, Any]:
    """Group transaction errors by error group, class, and message."""
    return await _call(
        "list_entity_error_groups",
        entity_guid=entity_guid,
        start_time_ms=start_time_ms,
        end_time_ms=end_time_ms,
    )


@mcp.tool()
async def list_garbage_collection_metrics(
    entity_guid: str,
    start_time_ms: int | None = None,
    end_time_ms: int | None = None,
) -> dict[str, Any]:
    """Retrieve language-sensitive garbage collection and heap metrics."""
    return await _call(
        "list_garbage_collection_metrics",
        entity_guid=entity_guid,
        start_time_ms=start_time_ms,
        end_time_ms=end_time_ms,
    )


@mcp.tool()
async def list_related_entities(
    entity_guid: str,
    domain_filter: list[dict[str, str]] | None = None,
) -> dict[str, Any]:
    """Discover entities directly related to a root entity."""
    return await _call(
        "list_related_entities",
        entity_guid=entity_guid,
        domain_filter=domain_filter,
    )


@mcp.tool()
async def search_incident(
    account_id: int,
    entity_guid: str | None = None,
    issue_id: str | None = None,
    policy_id: int | None = None,
    condition_id: int | None = None,
    start_time_ms: int | None = None,
    end_time_ms: int | None = None,
) -> dict[str, Any]:
    """Search alert incident open/close events by issue, entity, policy, or condition."""
    return await _call(
        "search_incident",
        account_id=account_id,
        entity_guid=entity_guid,
        issue_id=issue_id,
        policy_id=policy_id,
        condition_id=condition_id,
        start_time_ms=start_time_ms,
        end_time_ms=end_time_ms,
    )


@mcp.tool()
async def get_dashboard(entityGuid: str) -> dict[str, Any]:  # noqa: N803
    """Retrieve a dashboard, its pages, widgets, variables, owner, and configuration."""
    return await _call("get_dashboard", entityGuid=entityGuid)


@mcp.tool()
async def list_alert_conditions(account_id: int, policyId: int) -> dict[str, Any]:  # noqa: N803
    """Retrieve NRQL alert conditions for a New Relic alert policy."""
    return await _call("list_alert_conditions", account_id=account_id, policyId=policyId)


# ASGI application for uvicorn/gunicorn deployments. Endpoint: /mcp
app = mcp.streamable_http_app()
