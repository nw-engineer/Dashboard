from __future__ import annotations

import re
from typing import Any

from .utils import entity_guid_predicate, epoch_clause, quote_nrql


def infer_nrql(user_request: str) -> dict[str, Any]:
    """Deterministic, conservative natural-language to NRQL fallback."""
    text = user_request.strip()
    lower = text.lower()
    since = _infer_since(lower)
    app_name = _infer_app_name(text)
    where = f" WHERE appName = {quote_nrql(app_name)}" if app_name else ""

    if any(k in lower for k in ["log", "ログ"]):
        if any(k in lower for k in ["error", "exception", "エラー", "例外"]):
            query = (
                "SELECT count(*) AS errorCount, latest(message) AS example "
                "FROM Log WHERE (level IN ('error','ERROR','fatal','FATAL') "
                "OR message LIKE '%error%' OR message LIKE '%exception%') "
                f"{since} FACET level LIMIT 50"
            )
        else:
            query = f"SELECT timestamp, level, message FROM Log {since} LIMIT 100"
        return _translation(text, query, "logs")

    if any(k in lower for k in ["incident", "issue", "障害", "インシデント"]):
        query = (
            "SELECT latest(title) AS title, latest(priority) AS priority, "
            "latest(state) AS state, latest(entity.name) AS entityName "
            f"FROM NrAiIncident {since} FACET incidentId LIMIT 100"
        )
        return _translation(text, query, "incidents")

    if any(k in lower for k in ["cpu", "プロセッサ"]):
        query = f"SELECT average(cpuPercent) AS cpuPercent FROM SystemSample {since} TIMESERIES AUTO"
        return _translation(text, query, "infrastructure_cpu")

    if any(k in lower for k in ["memory", "メモリ"]):
        query = (
            "SELECT average(memoryUsedPercent) AS memoryUsedPercent "
            f"FROM SystemSample {since} TIMESERIES AUTO"
        )
        return _translation(text, query, "infrastructure_memory")

    if any(k in lower for k in ["slow", "latency", "response time", "遅", "レスポンス"]):
        query = (
            "SELECT average(duration) AS averageDuration, "
            "percentile(duration, 95, 99) FROM Transaction"
            f"{where} {since} FACET name LIMIT 20"
        )
        return _translation(text, query, "transaction_latency")

    if any(k in lower for k in ["error rate", "エラー率"]):
        query = (
            "SELECT percentage(count(*), WHERE error IS true) AS errorRate "
            f"FROM Transaction{where} {since} TIMESERIES AUTO"
        )
        return _translation(text, query, "transaction_error_rate")

    if any(k in lower for k in ["throughput", "rpm", "request", "リクエスト", "スループット"]):
        query = f"SELECT rate(count(*), 1 minute) AS rpm FROM Transaction{where} {since} TIMESERIES AUTO"
        return _translation(text, query, "transaction_throughput")

    query = f"SELECT count(*) AS transactionCount FROM Transaction{where} {since}"
    return {
        **_translation(text, query, "fallback_transaction_count"),
        "warning": "The request did not match a specialized template; generated a transaction count query.",
    }


def transaction_queries(entity_guid: str, start_ms: int, end_ms: int, error_limit: int) -> dict[str, str]:
    predicate = entity_guid_predicate(entity_guid)
    window = epoch_clause(start_ms, end_ms)
    return {
        "summary": (
            "SELECT count(*) AS totalTransactions, average(duration) AS averageDuration, "
            "percentile(duration, 50, 75, 95, 99), "
            "percentage(count(*), WHERE error IS true) AS errorRate, "
            "rate(count(*), 1 minute) AS throughputRpm, apdex(duration, t: 0.5) AS apdex "
            f"FROM Transaction WHERE {predicate} {window}"
        ),
        "top_transactions": (
            "SELECT count(*) AS callCount, average(duration) AS averageDuration, "
            "percentage(count(*), WHERE error IS true) AS errorRate "
            f"FROM Transaction WHERE {predicate} {window} FACET name, appName LIMIT 10"
        ),
        "slow_transactions": (
            "SELECT percentile(duration, 99) AS p99, average(duration) AS averageDuration, count(*) AS callCount "
            f"FROM Transaction WHERE {predicate} {window} FACET name, appName LIMIT 5"
        ),
        "errors": (
            "SELECT timestamp, name, appName, error.class, error.message, http.statusCode, duration "
            f"FROM TransactionError WHERE {predicate} {window} LIMIT {max(1, min(error_limit, 100))}"
        ),
        "throughput_chart": (
            "SELECT rate(count(*), 1 minute) AS rpm FROM Transaction "
            f"WHERE {predicate} {window} TIMESERIES AUTO"
        ),
        "duration_chart": (
            "SELECT average(duration) AS averageDuration FROM Transaction "
            f"WHERE {predicate} {window} TIMESERIES AUTO"
        ),
        "tail_chart": (
            "SELECT percentile(duration, 95, 99) FROM Transaction "
            f"WHERE {predicate} {window} TIMESERIES AUTO"
        ),
    }


def _translation(request: str, query: str, category: str) -> dict[str, Any]:
    return {"user_request": request, "category": category, "nrql_query": query, "generator": "template"}


def _infer_since(text: str) -> str:
    patterns = [
        (r"(?:last|past|過去|直近)\s*(\d+)\s*(?:minutes?|mins?|分)", "MINUTES"),
        (r"(?:last|past|過去|直近)\s*(\d+)\s*(?:hours?|時間)", "HOURS"),
        (r"(?:last|past|過去|直近)\s*(\d+)\s*(?:days?|日)", "DAYS"),
    ]
    for pattern, unit in patterns:
        match = re.search(pattern, text)
        if match:
            return f"SINCE {int(match.group(1))} {unit} AGO"
    if "yesterday" in text or "昨日" in text:
        return "SINCE yesterday UNTIL today"
    return "SINCE 1 HOUR AGO"


def _infer_app_name(text: str) -> str | None:
    quoted = re.search(r"['\"]([^'\"]{2,100})['\"]", text)
    if quoted:
        return quoted.group(1)
    match = re.search(r"(?:app|application|service|アプリ|サービス)\s*[:=]?\s*([\w.\-/]+)", text, re.I)
    return match.group(1) if match else None
