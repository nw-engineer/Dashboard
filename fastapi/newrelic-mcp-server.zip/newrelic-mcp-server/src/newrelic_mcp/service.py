from __future__ import annotations

import asyncio
import base64
import json
from collections import Counter, deque
from datetime import datetime
from typing import Any

from .client import NewRelicClient
from .errors import NewRelicAPIError, ValidationError
from .nrql import infer_nrql, transaction_queries
from .utils import (
    clamp_limit,
    entity_guid_predicate,
    epoch_clause,
    first_number,
    now_ms,
    parse_time_period,
    percent_change,
    quote_nrql,
    validate_account_id,
    validate_window,
)


class NewRelicToolService:
    def __init__(self, client: NewRelicClient) -> None:
        self.client = client
        self.settings = client.settings

    async def list_available_new_relic_accounts(self) -> dict[str, Any]:
        """List all New Relic accounts accessible to the configured User API key."""
        document = """
        query ListAccounts {
          actor {
            organization {
              accountManagement {
                managedAccounts { id name regionCode }
              }
            }
          }
        }
        """
        try:
            data = await self.client.graphql(document)
            accounts = (
                data.get("actor", {})
                .get("organization", {})
                .get("accountManagement", {})
                .get("managedAccounts", [])
            )
        except NewRelicAPIError:
            if not self.settings.allowed_account_ids:
                raise
            accounts = [
                {"id": account_id, "name": None, "regionCode": None}
                for account_id in sorted(self.settings.allowed_account_ids)
            ]

        if self.settings.allowed_account_ids:
            accounts = [
                account
                for account in accounts
                if int(account.get("id", 0)) in self.settings.allowed_account_ids
            ]
        return {"accounts": accounts, "count": len(accounts)}

    async def list_recent_issues(
        self,
        account_id: int,
        cursor: str | None = None,
        start_time_ms: int | None = None,
        end_time_ms: int | None = None,
        priorities: list[str] | None = None,
        skip_time_filter: bool = False,
    ) -> dict[str, Any]:
        validate_account_id(account_id, self.settings.allowed_account_ids)
        end = end_time_ms or now_ms()
        start = start_time_ms or end - 24 * 60 * 60 * 1000
        priority_values = [p.upper() for p in (priorities or [])]
        invalid = sorted(set(priority_values) - {"LOW", "MEDIUM", "HIGH", "CRITICAL"})
        if invalid:
            raise ValidationError(f"Invalid priorities: {invalid}")

        offset = self._decode_cursor(cursor)
        where_parts: list[str] = []
        if priority_values:
            joined = ", ".join(quote_nrql(value) for value in priority_values)
            where_parts.append(f"priority IN ({joined})")
        where = f"WHERE {' AND '.join(where_parts)} " if where_parts else ""
        time_clause = "" if skip_time_filter else f"SINCE {start} UNTIL {end} "
        query = (
            "SELECT latest(title) AS title, latest(description) AS description, "
            "latest(priority) AS priority, latest(state) AS state, "
            "latest(activatedAt) AS activatedAt, latest(closedAt) AS closedAt, "
            "latest(entityGuids) AS entityGuids, latest(incidentIds) AS incidentIds "
            f"FROM NrAiIssue {where}{time_clause}FACET issueId LIMIT 100 OFFSET {offset}"
        )
        result = await self.client.nrql(account_id, query)
        rows = result["results"]
        next_cursor = self._encode_cursor(offset + len(rows)) if len(rows) == 100 else None
        return {
            "issues": rows,
            "next_cursor": next_cursor,
            "returned_count": len(rows),
            "account_id": account_id,
            "time_range": None if skip_time_filter else {"start_time_ms": start, "end_time_ms": end},
            "query": query,
        }

    async def list_change_events(
        self,
        entity_guid: str,
        history_period_hours: int = 48,
    ) -> dict[str, Any]:
        if history_period_hours <= 0 or history_period_hours > 24 * self.settings.max_time_window_days:
            raise ValidationError("history_period_hours is outside the configured safety window")
        entity, account_id = await self._entity_context(entity_guid)
        predicate = entity_guid_predicate(entity_guid)
        query = (
            "SELECT timestamp, category, type, summary, description, version, commit, user, "
            "repository, deepLink, deploymentId, groupId "
            f"FROM ChangeTracking WHERE {predicate} SINCE {history_period_hours} HOURS AGO "
            "LIMIT MAX"
        )
        result = await self.client.nrql(account_id, query)
        return {
            "entity": entity,
            "change_events": result["results"],
            "history_period_hours": history_period_hours,
            "query": query,
        }

    async def list_recent_logs(
        self,
        account_id: int,
        number_of_logs: int = 100,
        history_period_minutes: int = 60,
        entity_guid: str = "",
        start_time_ms: int | None = None,
        end_time_ms: int | None = None,
    ) -> dict[str, Any]:
        validate_account_id(account_id, self.settings.allowed_account_ids)
        limit = max(1, min(number_of_logs, 1000))
        if start_time_ms is not None or end_time_ms is not None:
            end = end_time_ms or now_ms()
            start = start_time_ms or end - history_period_minutes * 60_000
            start, end = validate_window(
                start, end, max_days=self.settings.max_time_window_days
            )
            time_clause = epoch_clause(start, end)
        else:
            if history_period_minutes <= 0:
                raise ValidationError("history_period_minutes must be positive")
            time_clause = f"SINCE {history_period_minutes} MINUTES AGO"
            start, end = None, None
        where = f"WHERE {entity_guid_predicate(entity_guid)} " if entity_guid else ""
        query = (
            "SELECT timestamp, message, level, logtype, hostname, service.name, trace.id, span.id "
            f"FROM Log {where}{time_clause} LIMIT {limit}"
        )
        result = await self.client.nrql(account_id, query)
        return {
            "logs": result["results"],
            "returned_count": len(result["results"]),
            "time_range": {"start_time_ms": start, "end_time_ms": end},
            "query": query,
        }

    async def search_entity_with_tag(
        self,
        tag_key: str,
        tag_value: str,
        limit: int = 50,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        safe_key = tag_key.replace("'", "\\'")
        safe_value = tag_value.replace("'", "\\'")
        search = await self.client.entity_search(
            f"tags.{safe_key} = '{safe_value}'", cursor
        )
        entities = self._filter_allowed_accounts(search["entities"])
        max_items = clamp_limit(limit)
        entities = entities[:max_items]
        return {
            "entities": entities,
            "next_cursor": search["next_cursor"],
            "returned_count": len(entities),
            "query": search["query"],
        }

    async def execute_nrql_query(self, nrql_query: str, account_id: int) -> dict[str, Any]:
        return await self.client.nrql(account_id, nrql_query)

    async def list_synthetic_monitors(
        self,
        account_id: int,
        limit: int = 50,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        validate_account_id(account_id, self.settings.allowed_account_ids)
        search = await self.client.entity_search(
            f"domain = 'SYNTH' AND type = 'MONITOR' AND accountId = {account_id}", cursor
        )
        max_items = clamp_limit(limit)
        monitors = []
        for entity in search["entities"][:max_items]:
            tags = self._tags_dict(entity.get("tags", []))
            monitors.append(
                {
                    "guid": entity.get("guid"),
                    "name": entity.get("name"),
                    "account_id": entity.get("accountId"),
                    "monitor_id": entity.get("monitorId"),
                    "monitor_type": entity.get("monitorType"),
                    "status": self._first_tag(tags, "status", "monitorStatus"),
                    "url": self._first_tag(tags, "url", "monitoredUrl", "uri"),
                    "tags": entity.get("tags", []),
                }
            )
        return {
            "monitors": monitors,
            "next_cursor": search["next_cursor"],
            "returned_count": len(monitors),
        }

    async def list_alert_policies(
        self,
        account_id: int,
        policy_name: str | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        validate_account_id(account_id, self.settings.allowed_account_ids)
        document = """
        query AlertPolicies($accountId: Int!, $cursor: String, $nameLike: String) {
          actor {
            account(id: $accountId) {
              alerts {
                policiesSearch(cursor: $cursor, searchCriteria: { nameLike: $nameLike }) {
                  nextCursor
                  totalCount
                  policies { id name incidentPreference }
                }
              }
            }
          }
        }
        """
        variables = {
            "accountId": account_id,
            "cursor": cursor,
            "nameLike": policy_name,
        }
        data = await self.client.graphql(document, variables)
        node = (
            data.get("actor", {})
            .get("account", {})
            .get("alerts", {})
            .get("policiesSearch", {})
        )
        policies = node.get("policies", [])
        return {
            "policies": policies,
            "next_cursor": node.get("nextCursor"),
            "metadata": {
                "returned_count": len(policies),
                "total_count": node.get("totalCount"),
                "has_more": bool(node.get("nextCursor")),
            },
        }

    async def list_dashboards(
        self,
        account_id: int,
        limit: int = 50,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        validate_account_id(account_id, self.settings.allowed_account_ids)
        search = await self.client.entity_search(
            f"domain = 'VIZ' AND type = 'DASHBOARD' AND accountId = {account_id}", cursor
        )
        max_items = clamp_limit(limit)
        dashboards = [
            {
                "guid": item.get("guid"),
                "name": item.get("name"),
                "account_id": item.get("accountId"),
                "owner": self._first_tag(self._tags_dict(item.get("tags", [])), "owner", "createdBy"),
                "permalink": self._dashboard_permalink(item.get("guid")),
                "tags": item.get("tags", []),
            }
            for item in search["entities"][:max_items]
        ]
        return {
            "dashboards": dashboards,
            "next_cursor": search["next_cursor"],
            "returned_count": len(dashboards),
        }

    async def natural_language_to_nrql_query(
        self,
        user_request: str,
        account_id: int,
    ) -> dict[str, Any]:
        translation = infer_nrql(user_request)
        execution = await self.client.nrql(account_id, translation["nrql_query"])
        return {**translation, "account_id": account_id, "results": execution["results"]}

    async def generate_alert_insights_report(
        self,
        issue_id: str,
        account_id: int,
        start_time_ms: int | None = None,
        end_time_ms: int | None = None,
        details: str | None = None,
    ) -> dict[str, Any]:
        end = end_time_ms or now_ms()
        start = start_time_ms or end - 30 * 24 * 60 * 60 * 1000
        start, end = validate_window(
            start, end, max_days=self.settings.max_time_window_days
        )
        incidents = await self.search_incident(
            account_id=account_id,
            issue_id=issue_id,
            start_time_ms=start,
            end_time_ms=end,
        )
        rows = incidents["incidents"]
        states = Counter(str(row.get("state") or row.get("event") or "UNKNOWN") for row in rows)
        priorities = Counter(str(row.get("priority") or "UNKNOWN") for row in rows)
        entity_guids = sorted(
            {
                str(row.get("entityGuid"))
                for row in rows
                if row.get("entityGuid")
            }
        )
        entities = []
        for guid in entity_guids[:20]:
            try:
                entity = await self.client.get_entity(guid)
                if entity:
                    entities.append(entity)
            except NewRelicAPIError:
                continue

        recommendations: list[str] = []
        if priorities.get("CRITICAL", 0) or priorities.get("HIGH", 0):
            recommendations.append("Prioritize affected production entities and confirm customer impact.")
        if any(key.upper() in {"OPEN", "ACTIVATE", "ACTIVATED"} for key in states):
            recommendations.append("Review recent deployments and logs around the first incident activation.")
        if len(entity_guids) > 1:
            recommendations.append("Inspect entity relationships to identify a shared upstream dependency.")
        if not recommendations:
            recommendations.append("Validate alert condition thresholds and compare telemetry before and after the issue window.")

        return {
            "issue_id": issue_id,
            "account_id": account_id,
            "time_range": {"start_time_ms": start, "end_time_ms": end},
            "summary": {
                "incident_event_count": len(rows),
                "states": dict(states),
                "priorities": dict(priorities),
                "affected_entity_count": len(entity_guids),
            },
            "affected_entities": entities,
            "incident_events": rows,
            "details": details,
            "recommendations": recommendations,
            "analysis_note": "Recommendations are deterministic heuristics based on returned telemetry, not New Relic AI output.",
        }

    async def analyze_deployment_impact(
        self,
        entity_guid: str,
        deployment_timestamp_ms: int,
        account_id: int,
    ) -> dict[str, Any]:
        validate_account_id(account_id, self.settings.allowed_account_ids)
        entity = await self.client.get_entity(entity_guid)
        if entity and int(entity.get("accountId", account_id)) != account_id:
            raise ValidationError("entity_guid belongs to a different account_id")
        window_ms = 30 * 60 * 1000
        before_start, before_end = deployment_timestamp_ms - window_ms, deployment_timestamp_ms
        after_start, after_end = deployment_timestamp_ms, deployment_timestamp_ms + window_ms
        predicate = entity_guid_predicate(entity_guid)

        def summary_query(start: int, end: int) -> str:
            return (
                "SELECT count(*) AS transactions, average(duration) AS averageDuration, "
                "percentile(duration, 95) AS p95, "
                "percentage(count(*), WHERE error IS true) AS errorRate, "
                "rate(count(*), 1 minute) AS throughputRpm "
                f"FROM Transaction WHERE {predicate} {epoch_clause(start, end)}"
            )

        before_result, after_result = await asyncio.gather(
            self.client.nrql(account_id, summary_query(before_start, before_end)),
            self.client.nrql(account_id, summary_query(after_start, after_end)),
        )
        before = before_result["results"][0] if before_result["results"] else {}
        after = after_result["results"][0] if after_result["results"] else {}
        metrics = {}
        for key in ["transactions", "averageDuration", "p95", "errorRate", "throughputRpm"]:
            b = float(before.get(key) or 0)
            a = float(after.get(key) or 0)
            metrics[key] = {"before": b, "after": a, "percent_change": percent_change(b, a)}

        regressions = []
        if (metrics["errorRate"]["percent_change"] or 0) > 20:
            regressions.append("Error rate increased by more than 20% after deployment.")
        if (metrics["p95"]["percent_change"] or 0) > 20:
            regressions.append("p95 response time increased by more than 20% after deployment.")
        return {
            "entity": entity or {"guid": entity_guid},
            "deployment_timestamp_ms": deployment_timestamp_ms,
            "comparison_window_minutes": 30,
            "metrics": metrics,
            "assessment": "regression_detected" if regressions else "no_clear_regression",
            "findings": regressions or ["No threshold-based regression was detected in the 30-minute comparison windows."],
            "queries": {
                "before": summary_query(before_start, before_end),
                "after": summary_query(after_start, after_end),
            },
        }

    async def generate_user_impact_report(
        self,
        issue_id: str,
        account_id: int,
        entity_guid: str,
        deployment_start_timestamp_ms: int,
        relationship_depth: int = 1,
    ) -> dict[str, Any]:
        if relationship_depth < 1 or relationship_depth > 3:
            raise ValidationError("relationship_depth must be between 1 and 3")
        end = now_ms()
        start = deployment_start_timestamp_ms
        start, end = validate_window(start, end, max_days=self.settings.max_time_window_days)
        predicate = entity_guid_predicate(entity_guid)
        impact_query = (
            "SELECT uniqueCount(session) AS affectedSessions, uniqueCount(user) AS affectedUsers, "
            "count(*) AS interactions, percentage(count(*), WHERE error IS true) AS errorRate "
            f"FROM BrowserInteraction WHERE {predicate} {epoch_clause(start, end)}"
        )
        page_query = (
            "SELECT uniqueCount(session) AS pageSessions, average(duration) AS pageLoadDuration "
            f"FROM PageView WHERE {predicate} {epoch_clause(start, end)}"
        )
        impact, pages, incidents, relationships = await asyncio.gather(
            self.client.nrql(account_id, impact_query),
            self.client.nrql(account_id, page_query),
            self.search_incident(
                account_id=account_id,
                issue_id=issue_id,
                start_time_ms=start,
                end_time_ms=end,
            ),
            self._relationship_bfs(entity_guid, relationship_depth),
        )
        browser = impact["results"][0] if impact["results"] else {}
        page = pages["results"][0] if pages["results"] else {}
        affected_users = first_number(browser, ["affectedUsers", "affectedSessions"])
        severity = "high" if affected_users >= 1000 else "medium" if affected_users >= 100 else "low"
        return {
            "issue_id": issue_id,
            "root_entity_guid": entity_guid,
            "time_range": {"start_time_ms": start, "end_time_ms": end},
            "impact": {
                "affected_users": browser.get("affectedUsers"),
                "affected_sessions": browser.get("affectedSessions"),
                "interactions": browser.get("interactions"),
                "browser_error_rate": browser.get("errorRate"),
                "page_sessions": page.get("pageSessions"),
                "page_load_duration": page.get("pageLoadDuration"),
                "severity_indicator": severity,
            },
            "related_entities": relationships,
            "incident_events": incidents["incidents"],
            "queries": [impact_query, page_query],
            "analysis_note": "User counts depend on Browser telemetry and available session/user attributes.",
        }

    async def analyze_entity_logs(
        self,
        entity_guid: str,
        start_time_ms: int,
        end_time_ms: int | None = None,
    ) -> dict[str, Any]:
        start, end = validate_window(start_time_ms, end_time_ms, default_minutes=60, max_days=1)
        entity, account_id = await self._entity_context(entity_guid)
        predicate = entity_guid_predicate(entity_guid)
        window = epoch_clause(start, end)
        volume_query = (
            "SELECT count(*) AS totalLogs FROM Log "
            f"WHERE {predicate} {window} FACET level, logtype LIMIT 50"
        )
        patterns_query = (
            "SELECT count(*) AS occurrences, latest(message) AS example FROM Log "
            f"WHERE {predicate} {window} FACET message LIMIT 20"
        )
        error_query = (
            "SELECT count(*) AS errorCount, latest(message) AS example FROM Log "
            f"WHERE {predicate} AND (level IN ('error','ERROR','fatal','FATAL') "
            "OR message LIKE '%error%' OR message LIKE '%exception%') "
            f"{window} FACET level, error.class LIMIT 50"
        )
        timeline_query = (
            "SELECT count(*) AS errorCount FROM Log "
            f"WHERE {predicate} AND (level IN ('error','ERROR','fatal','FATAL') "
            "OR message LIKE '%error%' OR message LIKE '%exception%') "
            f"{window} TIMESERIES 1 hour"
        )
        volume, patterns, errors, timeline = await asyncio.gather(
            self.client.nrql(account_id, volume_query),
            self.client.nrql(account_id, patterns_query),
            self.client.nrql(account_id, error_query),
            self.client.nrql(account_id, timeline_query),
        )
        total_logs = sum(first_number(row, ["totalLogs"]) for row in volume["results"])
        total_errors = sum(first_number(row, ["errorCount"]) for row in errors["results"])
        insights = []
        if total_logs > 100_000:
            insights.append("Log volume is high for the selected window.")
        if total_logs and total_errors / total_logs > 0.05:
            insights.append("More than 5% of classified log records appear error-related.")
        if not insights:
            insights.append("No threshold-based log anomaly was identified.")
        return {
            "entity": entity,
            "time_range": {"start_time_ms": start, "end_time_ms": end},
            "volume": {"total": total_logs, "distribution": volume["results"], "top_patterns": patterns["results"]},
            "errors": {"total": total_errors, "groups": errors["results"], "timeline": timeline["results"]},
            "insights": insights,
            "query": {
                "volume": volume_query,
                "patterns": patterns_query,
                "errors": error_query,
                "timeline": timeline_query,
            },
        }

    async def analyze_golden_metrics(
        self,
        entity_guid: str,
        start_time_ms: int,
        end_time_ms: int | None = None,
    ) -> dict[str, Any]:
        start, end = validate_window(
            start_time_ms,
            end_time_ms,
            default_minutes=60,
            max_days=self.settings.max_time_window_days,
        )
        entity, account_id = await self._entity_context(entity_guid)
        domain = str(entity.get("domain") or "").upper()
        predicate = entity_guid_predicate(entity_guid)
        window = epoch_clause(start, end)
        if domain == "APM":
            query = (
                "SELECT rate(count(*), 1 minute) AS throughputRpm, average(duration) AS responseTime, "
                "percentile(duration, 95, 99), percentage(count(*), WHERE error IS true) AS errorRate, "
                "apdex(duration, t: 0.5) AS apdex FROM Transaction "
                f"WHERE {predicate} {window} TIMESERIES AUTO"
            )
            signal_type = "apm"
        elif domain == "INFRA":
            query = (
                "SELECT average(cpuPercent) AS cpuPercent, average(memoryUsedPercent) AS memoryUsedPercent, "
                "average(diskUsedPercent) AS diskUsedPercent, average(loadAverageOneMinute) AS loadAverage "
                f"FROM SystemSample WHERE {predicate} {window} TIMESERIES AUTO"
            )
            signal_type = "infrastructure"
        else:
            query = (
                "SELECT average(newrelic.timeslice.value) AS value FROM Metric "
                f"WHERE {predicate} {window} FACET metricName LIMIT 25"
            )
            signal_type = "generic_metric"
        result = await self.client.nrql(account_id, query)
        return {
            "entity": entity,
            "signal_type": signal_type,
            "time_range": {"start_time_ms": start, "end_time_ms": end},
            "metrics": result["results"],
            "insights": self._golden_metric_insights(result["results"]),
            "query": query,
        }

    async def analyze_kafka_metrics(
        self,
        entity_guid: str,
        start_time_ms: int,
        end_time_ms: int | None = None,
        timeseries_bucket: int = 1,
        issue_account_id: int | None = None,
        issue_id: str | None = None,
    ) -> dict[str, Any]:
        start, end = validate_window(
            start_time_ms,
            end_time_ms,
            default_minutes=60,
            max_days=self.settings.max_time_window_days,
        )
        if timeseries_bucket <= 0:
            raise ValidationError("timeseries_bucket must be positive")
        entity, account_id = await self._entity_context(entity_guid)
        predicate = entity_guid_predicate(entity_guid)
        window = epoch_clause(start, end)
        bucket = min(timeseries_bucket, 60)
        queries = {
            "kafka_metrics": (
                "SELECT average(newrelic.timeslice.value) AS value FROM Metric "
                f"WHERE {predicate} AND metricName LIKE '%kafka%' {window} "
                f"FACET metricName TIMESERIES {bucket} minutes"
            ),
            "consumer_lag": (
                "SELECT average(newrelic.timeslice.value) AS lag FROM Metric "
                f"WHERE {predicate} AND (metricName LIKE '%consumer%lag%' "
                "OR metricName LIKE '%ConsumerLag%') "
                f"{window} FACET metricName TIMESERIES {bucket} minutes"
            ),
            "throughput_latency": (
                "SELECT average(newrelic.timeslice.value) AS value FROM Metric "
                f"WHERE {predicate} AND (metricName LIKE '%Messages%' OR metricName LIKE '%Bytes%' "
                "OR metricName LIKE '%latency%') "
                f"{window} FACET metricName TIMESERIES {bucket} minutes"
            ),
        }
        results = await asyncio.gather(*(self.client.nrql(account_id, query) for query in queries.values()))
        data = {name: result["results"] for name, result in zip(queries, results, strict=True)}
        incident_context = None
        if issue_account_id and issue_id:
            incident_context = await self.search_incident(
                account_id=issue_account_id, issue_id=issue_id, start_time_ms=start, end_time_ms=end
            )
        return {
            "entity": entity,
            "time_range": {"start_time_ms": start, "end_time_ms": end},
            "timeseries_bucket_minutes": bucket,
            "metrics": data,
            "incident_context": incident_context,
            "insights": self._timeseries_presence_insights(data, "Kafka"),
            "queries": queries,
            "analysis_note": "Kafka metric names vary by integration; adjust templates in service.py for your telemetry schema.",
        }

    async def analyze_threads(
        self,
        entity_guid: str,
        start_time_ms: int,
        end_time_ms: int | None = None,
    ) -> dict[str, Any]:
        start, end = validate_window(
            start_time_ms,
            end_time_ms,
            default_minutes=60,
            max_days=self.settings.max_time_window_days,
        )
        entity, account_id = await self._entity_context(entity_guid)
        predicate = entity_guid_predicate(entity_guid)
        window = epoch_clause(start, end)
        query = (
            "SELECT average(newrelic.timeslice.value) AS value, max(newrelic.timeslice.value) AS maximum "
            f"FROM Metric WHERE {predicate} AND (metricName LIKE '%thread%' "
            "OR metricName LIKE '%Thread%') "
            f"{window} FACET metricName TIMESERIES AUTO"
        )
        result = await self.client.nrql(account_id, query)
        return {
            "entity": entity,
            "language": self._entity_language(entity),
            "time_range": {"start_time_ms": start, "end_time_ms": end},
            "thread_metrics": result["results"],
            "insights": self._timeseries_presence_insights({"threads": result["results"]}, "Thread"),
            "query": query,
        }

    async def analyze_transactions(
        self,
        entity_guid: str,
        start_time_ms: int,
        end_time_ms: int | None = None,
        error_transaction_limit: int = 5,
    ) -> dict[str, Any]:
        start, end = validate_window(start_time_ms, end_time_ms, default_minutes=60, max_days=1)
        entity, account_id = await self._entity_context(entity_guid)
        queries = transaction_queries(entity_guid, start, end, error_transaction_limit)
        names = ["summary", "top_transactions", "slow_transactions", "errors"]
        results = await asyncio.gather(*(self.client.nrql(account_id, queries[name]) for name in names))
        data = {name: result["results"] for name, result in zip(names, results, strict=True)}
        summary = data["summary"][0] if data["summary"] else {}
        insights = self._transaction_insights(summary, data["top_transactions"], data["slow_transactions"])
        return {
            "entity": entity,
            "time_range": {"start_time_ms": start, "end_time_ms": end},
            "analysis": {
                **summary,
                "error_transactions": data["errors"],
                "top_transactions": data["top_transactions"],
                "slow_transactions": data["slow_transactions"],
            },
            "chart_queries": {
                "throughput": queries["throughput_chart"],
                "average_duration": queries["duration_chart"],
                "p95_p99_latency": queries["tail_chart"],
            },
            "insights": insights,
            "links": {
                "entity": self._entity_permalink(entity_guid),
            },
        }

    async def convert_time_period_to_epoch_ms(self, text_input: str) -> dict[str, Any]:
        return parse_time_period(text_input, self.settings.timezone)

    async def get_entity(
        self,
        entity_guid: str | None = None,
        name_pattern: str | None = None,
        domains: list[str] | None = None,
        types: list[str] | None = None,
    ) -> dict[str, Any]:
        if entity_guid:
            if name_pattern or domains or types:
                raise ValidationError("entity_guid cannot be combined with search parameters")
            entity = await self.client.get_entity(entity_guid)
            if not entity:
                return {"entities": [], "count": 0, "message": "No entity found for the GUID."}
            if not self._account_allowed(entity.get("accountId")):
                raise ValidationError("The entity belongs to an account outside the allow-list")
            return {"entities": [entity], "count": 1}

        if not name_pattern:
            raise ValidationError("Provide entity_guid or name_pattern")
        pattern = name_pattern.strip()
        if "%" not in pattern:
            pattern = f"%{pattern}%"
        clauses = [f"name LIKE {quote_nrql(pattern)}"]
        if domains:
            domain_values = ", ".join(quote_nrql(v.upper()) for v in domains)
            clauses.append(f"domain IN ({domain_values})")
        if types:
            type_values = ", ".join(quote_nrql(v.upper()) for v in types)
            clauses.append(f"type IN ({type_values})")
        search = await self.client.entity_search(" AND ".join(clauses))
        entities = self._filter_allowed_accounts(search["entities"])
        return {
            "entities": entities,
            "count": len(entities),
            "next_cursor": search["next_cursor"],
            "query": search["query"],
            "suggestion": "Add domains/types filters when multiple entities match." if len(entities) > 1 else None,
        }

    async def list_entity_error_groups(
        self,
        entity_guid: str,
        start_time_ms: int,
        end_time_ms: int | None = None,
    ) -> dict[str, Any]:
        start, end = validate_window(
            start_time_ms,
            end_time_ms,
            default_minutes=60,
            max_days=self.settings.max_time_window_days,
        )
        entity, account_id = await self._entity_context(entity_guid)
        predicate = entity_guid_predicate(entity_guid)
        query = (
            "SELECT count(*) AS occurrences, uniqueCount(session) AS affectedSessions, "
            "latest(error.message) AS message, latest(error.class) AS errorClass, "
            "latest(timestamp) AS lastSeen, earliest(timestamp) AS firstSeen "
            f"FROM TransactionError WHERE {predicate} {epoch_clause(start, end)} "
            "FACET error.group.guid, error.class, error.message LIMIT 100"
        )
        result = await self.client.nrql(account_id, query)
        groups = sorted(
            result["results"],
            key=lambda row: (
                float(row.get("affectedSessions") or 0),
                float(row.get("occurrences") or 0),
            ),
            reverse=True,
        )
        return {
            "entity": entity,
            "error_groups": groups,
            "returned_count": len(groups),
            "time_range": {"start_time_ms": start, "end_time_ms": end},
            "query": query,
        }

    async def list_garbage_collection_metrics(
        self,
        entity_guid: str,
        start_time_ms: int | None = None,
        end_time_ms: int | None = None,
    ) -> dict[str, Any]:
        end = end_time_ms or now_ms()
        start = start_time_ms or end - 30 * 24 * 60 * 60 * 1000
        start, end = validate_window(
            start, end, max_days=self.settings.max_time_window_days
        )
        entity, account_id = await self._entity_context(entity_guid)
        language = self._entity_language(entity)
        if language.lower() in {"c", "c++", "cpp", "rust", "assembly", "fortran", "pascal"}:
            return {
                "entity": entity,
                "language": language,
                "warning": f"{language} does not normally expose managed-runtime garbage collection metrics.",
                "metrics": [],
            }
        predicate = entity_guid_predicate(entity_guid)
        language_filters = {
            "java": "(metricName LIKE '%GC%' OR metricName LIKE '%Heap%' OR metricName LIKE '%NonHeap%')",
            "go": "(metricName LIKE '%Go%Pause%' OR metricName LIKE '%runtime.gc%')",
        }
        metric_filter = language_filters.get(
            language.lower(),
            "(metricName LIKE '%gc%' OR metricName LIKE '%GC%' OR metricName LIKE '%heap%')",
        )
        query = (
            "SELECT average(newrelic.timeslice.value) AS average, "
            "max(newrelic.timeslice.value) AS maximum, sum(newrelic.timeslice.value) AS total "
            f"FROM Metric WHERE {predicate} AND {metric_filter} {epoch_clause(start, end)} "
            "FACET metricName TIMESERIES AUTO"
        )
        result = await self.client.nrql(account_id, query)
        return {
            "entity": entity,
            "language": language,
            "time_range": {"start_time_ms": start, "end_time_ms": end},
            "metrics": result["results"],
            "query": query,
            "analysis_note": "Metric names vary by New Relic agent language and version.",
        }

    async def list_related_entities(
        self,
        entity_guid: str,
        domain_filter: list[dict[str, str]] | None = None,
    ) -> dict[str, Any]:
        document = """
        query RelatedEntities($guid: EntityGuid!) {
          actor {
            entity(guid: $guid) {
              guid
              relatedEntities {
                results {
                  type
                  source { entity { guid name accountId domain entityType } }
                  target { entity { guid name accountId domain entityType } }
                }
              }
            }
          }
        }
        """
        try:
            data = await self.client.graphql(document, {"guid": entity_guid})
            results = (
                data.get("actor", {})
                .get("entity", {})
                .get("relatedEntities", {})
                .get("results", [])
            )
        except NewRelicAPIError:
            results = await self._related_entities_fallback(entity_guid)

        if domain_filter:
            allowed_pairs = {
                (str(item.get("domain", "")).upper(), str(item.get("type", "")).upper())
                for item in domain_filter
            }
            filtered = []
            for relationship in results:
                candidates = []
                for side in ("source", "target"):
                    node = relationship.get(side, {})
                    entity = node.get("entity", node) if isinstance(node, dict) else {}
                    candidates.append(
                        (str(entity.get("domain", "")).upper(), str(entity.get("entityType", "")).upper())
                    )
                if any(pair in allowed_pairs for pair in candidates):
                    filtered.append(relationship)
            results = filtered
        return {"entity_guid": entity_guid, "relationships": results, "count": len(results)}

    async def search_incident(
        self,
        account_id: int,
        entity_guid: str | None = None,
        issue_id: str | None = None,
        policy_id: int | None = None,
        condition_id: int | None = None,
        start_time_ms: int | None = None,
        end_time_ms: int | None = None,
    ) -> dict[str, Any]:
        validate_account_id(account_id, self.settings.allowed_account_ids)
        if not any([entity_guid, issue_id, policy_id, condition_id]):
            raise ValidationError("Provide issue_id, entity_guid, policy_id, or condition_id")
        end = end_time_ms or now_ms()
        start = start_time_ms or end - 30 * 24 * 60 * 60 * 1000
        start, end = validate_window(start, end, max_days=self.settings.max_time_window_days)
        filters = []
        if issue_id:
            filters.append(f"issueId = {quote_nrql(issue_id)}")
        else:
            if entity_guid:
                filters.append(f"entityGuid = {quote_nrql(entity_guid)}")
            if policy_id is not None:
                filters.append(f"policyId = {int(policy_id)}")
            if condition_id is not None:
                filters.append(f"conditionId = {int(condition_id)}")
        where = " AND ".join(filters)
        query = (
            "SELECT timestamp, event, state, priority, title, description, incidentId, issueId, "
            "entityGuid, entityName, policyId, policyName, conditionId, conditionName "
            f"FROM NrAiIncident WHERE {where} {epoch_clause(start, end)} LIMIT MAX"
        )
        result = await self.client.nrql(account_id, query)
        return {
            "incidents": result["results"],
            "returned_count": len(result["results"]),
            "time_range": {"start_time_ms": start, "end_time_ms": end},
            "query": query,
        }

    async def get_dashboard(self, entityGuid: str) -> dict[str, Any]:  # noqa: N803 - compatibility
        document = """
        query GetDashboard($guid: EntityGuid!) {
          actor {
            entity(guid: $guid) {
              ... on DashboardEntity {
                guid
                name
                description
                createdAt
                updatedAt
                owner { email userId }
                permissions
                pages {
                  guid
                  name
                  description
                  createdAt
                  updatedAt
                  widgets {
                    id
                    visualization { id }
                    layout { column row height width }
                    title
                    linkedEntities { guid }
                    rawConfiguration
                  }
                }
                variables {
                  name
                  items { title value }
                  defaultValues { value { string } }
                  nrqlQuery { accountIds query }
                  options { excluded ignoreTimeRange showApplyAction hiddenOnVariablesBar }
                  title
                  type
                  isMultiSelection
                  replacementStrategy
                }
              }
            }
          }
        }
        """
        data = await self.client.graphql(document, {"guid": entityGuid})
        dashboard = data.get("actor", {}).get("entity")
        if not dashboard:
            return {"dashboard": None, "message": "Dashboard not found or inaccessible."}
        return {
            "dashboard": dashboard,
            "permalink": self._dashboard_permalink(entityGuid),
        }

    async def list_alert_conditions(self, account_id: int, policyId: int) -> dict[str, Any]:  # noqa: N803
        validate_account_id(account_id, self.settings.allowed_account_ids)
        document = """
        query AlertConditions($accountId: Int!, $policyId: ID!) {
          actor {
            account(id: $accountId) {
              alerts {
                nrqlConditionsSearch(searchCriteria: { policyId: $policyId }) {
                  nrqlConditions {
                    id
                    name
                    description
                    enabled
                    policyId
                    type
                    runbookUrl
                    nrql { query }
                    signal {
                      aggregationWindow
                      aggregationMethod
                      aggregationDelay
                      aggregationTimer
                    }
                    terms {
                      operator
                      thresholdDuration
                      threshold
                      priority
                      thresholdOccurrences
                    }
                    violationTimeLimitSeconds
                  }
                }
              }
            }
          }
        }
        """
        data = await self.client.graphql(
            document, {"accountId": account_id, "policyId": str(policyId)}
        )
        conditions = (
            data.get("actor", {})
            .get("account", {})
            .get("alerts", {})
            .get("nrqlConditionsSearch", {})
            .get("nrqlConditions", [])
        )
        return {
            "conditions": conditions,
            "returned_count": len(conditions),
            "account_id": account_id,
            "policy_id": policyId,
            "note": "This implementation retrieves NRQL alert conditions. Add other condition APIs if your policies use non-NRQL condition types.",
        }

    async def _entity_context(self, entity_guid: str) -> tuple[dict[str, Any], int]:
        entity = await self.client.get_entity(entity_guid)
        if not entity:
            raise ValidationError(f"Entity not found: {entity_guid}")
        account_id = int(entity.get("accountId") or 0)
        validate_account_id(account_id, self.settings.allowed_account_ids)
        return entity, account_id

    async def _related_entities_fallback(self, entity_guid: str) -> list[dict[str, Any]]:
        entity, account_id = await self._entity_context(entity_guid)
        predicate = entity_guid_predicate(entity_guid)
        query = (
            "SELECT count(*) AS spanCount FROM Span "
            f"WHERE {predicate} SINCE 1 hour ago FACET peer.service, peer.hostname, destination.service.name LIMIT 100"
        )
        result = await self.client.nrql(account_id, query)
        return [
            {
                "type": "INFERRED_FROM_SPAN",
                "source": {"entity": entity},
                "target": {"entity": {"name": row.get("facet")}},
                "evidence": row,
            }
            for row in result["results"]
        ]

    async def _relationship_bfs(self, root_guid: str, depth: int) -> list[dict[str, Any]]:
        queue: deque[tuple[str, int]] = deque([(root_guid, 0)])
        visited = {root_guid}
        collected: list[dict[str, Any]] = []
        while queue:
            guid, current_depth = queue.popleft()
            if current_depth >= depth:
                continue
            related = await self.list_related_entities(guid)
            for relationship in related["relationships"]:
                collected.append({"depth": current_depth + 1, **relationship})
                for side in ("source", "target"):
                    node = relationship.get(side, {})
                    entity = node.get("entity", node) if isinstance(node, dict) else {}
                    next_guid = entity.get("guid") if isinstance(entity, dict) else None
                    if next_guid and next_guid not in visited:
                        visited.add(next_guid)
                        queue.append((next_guid, current_depth + 1))
            if len(collected) >= 500:
                break
        return collected[:500]

    def _filter_allowed_accounts(self, entities: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return [item for item in entities if self._account_allowed(item.get("accountId"))]

    def _account_allowed(self, account_id: object) -> bool:
        if not self.settings.allowed_account_ids:
            return True
        try:
            return int(account_id) in self.settings.allowed_account_ids
        except (TypeError, ValueError):
            return False

    @staticmethod
    def _tags_dict(tags: list[dict[str, Any]]) -> dict[str, list[str]]:
        return {
            str(tag.get("key")): [str(v) for v in tag.get("values", [])]
            for tag in tags
            if tag.get("key")
        }

    @staticmethod
    def _first_tag(tags: dict[str, list[str]], *keys: str) -> str | None:
        lower = {key.lower(): values for key, values in tags.items()}
        for key in keys:
            values = lower.get(key.lower())
            if values:
                return values[0]
        return None

    def _entity_language(self, entity: dict[str, Any]) -> str:
        tags = self._tags_dict(entity.get("tags", []))
        return self._first_tag(tags, "language", "agent.language", "runtime") or "unknown"

    @staticmethod
    def _transaction_insights(
        summary: dict[str, Any],
        top: list[dict[str, Any]],
        slow: list[dict[str, Any]],
    ) -> list[str]:
        insights = []
        error_rate = first_number(summary, ["errorRate"])
        p95 = first_number(summary, ["95.0", "p95"])
        p99 = first_number(summary, ["99.0", "p99"])
        if error_rate > 5:
            insights.append(f"Error rate is elevated at approximately {error_rate:.2f}%.")
        if p95 > 1:
            insights.append(f"p95 latency is above one second ({p95:.3f}s).")
        if p99 > p95 * 2 and p95 > 0:
            insights.append("Tail latency is substantially higher than p95 latency.")
        if top:
            insights.append(f"Highest-volume transaction: {top[0].get('facet') or top[0].get('name')}.")
        if slow:
            insights.append(f"Slowest p99 transaction: {slow[0].get('facet') or slow[0].get('name')}.")
        return insights or ["No threshold-based transaction anomaly was identified."]

    @staticmethod
    def _golden_metric_insights(rows: list[dict[str, Any]]) -> list[str]:
        if not rows:
            return ["No golden metric data was returned for this entity and time window."]
        return [
            "Golden metrics were returned. Review peaks and sustained changes in the timeseries; thresholds are environment-specific."
        ]

    @staticmethod
    def _timeseries_presence_insights(data: dict[str, list[dict[str, Any]]], label: str) -> list[str]:
        nonempty = [name for name, rows in data.items() if rows]
        if not nonempty:
            return [f"No {label} metrics matched the default metric-name templates."]
        return [f"{label} data was found in: {', '.join(nonempty)}."]

    @staticmethod
    def _entity_permalink(guid: str) -> str:
        return f"https://one.newrelic.com/redirect/entity/{guid}"

    @staticmethod
    def _dashboard_permalink(guid: object) -> str | None:
        return f"https://one.newrelic.com/redirect/entity/{guid}" if guid else None

    @staticmethod
    def _encode_cursor(offset: int) -> str:
        return base64.urlsafe_b64encode(json.dumps({"offset": offset}).encode()).decode()

    @staticmethod
    def _decode_cursor(cursor: str | None) -> int:
        if not cursor:
            return 0
        try:
            data = json.loads(base64.urlsafe_b64decode(cursor.encode()).decode())
            return max(0, int(data.get("offset", 0)))
        except Exception as exc:
            raise ValidationError("Invalid pagination cursor") from exc
