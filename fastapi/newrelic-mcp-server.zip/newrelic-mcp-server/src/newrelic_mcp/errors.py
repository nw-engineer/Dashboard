from __future__ import annotations


class NewRelicMCPError(RuntimeError):
    """Base error returned by this package."""


class ConfigurationError(NewRelicMCPError):
    """Invalid or missing server configuration."""


class NewRelicAPIError(NewRelicMCPError):
    """NerdGraph or NRQL request failed."""

    def __init__(self, message: str, *, details: object | None = None) -> None:
        super().__init__(message)
        self.details = details


class ValidationError(NewRelicMCPError):
    """A tool argument violates a safety or compatibility rule."""
