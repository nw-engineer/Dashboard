"""New Relic MCP server package."""

__version__ = "0.1.0"
