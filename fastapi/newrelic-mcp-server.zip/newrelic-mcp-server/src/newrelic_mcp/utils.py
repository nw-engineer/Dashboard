from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Any, Iterable
from zoneinfo import ZoneInfo

from dateutil import parser as date_parser

from .errors import ValidationError


WRITE_NRQL_PATTERN = re.compile(
    r"(?:^|\s)(DELETE|DROP|INSERT|UPDATE|CREATE|ALTER|TRUNCATE)(?:\s|$)",
    re.IGNORECASE,
)


def now_ms() -> int:
    return int(datetime.now().timestamp() * 1000)


def quote_nrql(value: str) -> str:
    """Return a safely escaped single-quoted NRQL string literal."""
    return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"


def entity_guid_predicate(entity_guid: str) -> str:
    value = quote_nrql(entity_guid)
    return f"(`entity.guid` = {value} OR entityGuid = {value})"


def validate_account_id(account_id: int, allowed: frozenset[int]) -> None:
    if account_id <= 0:
        raise ValidationError("account_id must be a positive integer")
    if allowed and account_id not in allowed:
        raise ValidationError(f"account_id {account_id} is not in the configured allow-list")


def validate_nrql(query: str, *, read_only: bool, max_length: int) -> str:
    cleaned = query.strip()
    if not cleaned:
        raise ValidationError("NRQL query must not be empty")
    if len(cleaned) > max_length:
        raise ValidationError(f"NRQL query exceeds maximum length {max_length}")
    if read_only:
        if WRITE_NRQL_PATTERN.search(cleaned):
            raise ValidationError("Only read-only NRQL queries are allowed")
        if not cleaned.upper().startswith("SELECT"):
            raise ValidationError("Read-only mode requires an NRQL SELECT query")
        if ";" in cleaned:
            raise ValidationError("Multiple NRQL statements are not allowed")
    return cleaned


def validate_window(
    start_time_ms: int,
    end_time_ms: int | None,
    *,
    default_minutes: int = 60,
    max_days: int = 30,
) -> tuple[int, int]:
    if start_time_ms <= 0:
        raise ValidationError("start_time_ms must be a positive epoch-millisecond value")
    end = end_time_ms if end_time_ms is not None else start_time_ms + default_minutes * 60_000
    if end <= start_time_ms:
        raise ValidationError("end_time_ms must be greater than start_time_ms")
    if end - start_time_ms > max_days * 86_400_000:
        raise ValidationError(f"Time window must not exceed {max_days} days")
    return start_time_ms, end


def epoch_clause(start_time_ms: int, end_time_ms: int) -> str:
    return f"SINCE {start_time_ms} UNTIL {end_time_ms}"


def clamp_limit(limit: int, *, default: int = 50, maximum: int = 200) -> int:
    if limit == -1:
        return maximum
    if limit <= 0:
        return default
    return min(limit, maximum)


def first_number(row: dict[str, Any], keys: Iterable[str], default: float = 0.0) -> float:
    for key in keys:
        value = row.get(key)
        if isinstance(value, (int, float)):
            return float(value)
    for value in row.values():
        if isinstance(value, (int, float)):
            return float(value)
    return default


def percent_change(before: float, after: float) -> float | None:
    if before == 0:
        return None if after == 0 else 100.0
    return ((after - before) / abs(before)) * 100.0


def parse_time_period(text_input: str, timezone: ZoneInfo) -> dict[str, Any]:
    """Parse common English/Japanese natural-language periods into epoch milliseconds."""
    raw = (text_input or "").strip()
    now = datetime.now(timezone)
    if not raw:
        start, end = now - timedelta(hours=24), now
        return _time_result(start, end, timezone, raw, "default_last_24_hours")

    text = raw.strip()
    lower = text.lower()

    epochs = [int(x) for x in re.findall(r"\b(\d{13})\b", text)]
    if len(epochs) >= 2:
        return _millisecond_result(epochs[0], epochs[1], timezone, raw, "epoch_range")
    if len(epochs) == 1 and (lower.startswith("at ") or text.startswith("時刻")):
        return _millisecond_result(epochs[0], epochs[0], timezone, raw, "epoch_point")

    rel = re.search(
        r"(?:last|過去|直近)\s*(\d+)\s*(minutes?|mins?|分|hours?|時間|days?|日|weeks?|週間)",
        lower,
    )
    if rel:
        amount = int(rel.group(1))
        delta = _duration(amount, rel.group(2))
        return _time_result(now - delta, now, timezone, raw, "relative_range")

    ago = re.search(
        r"(\d+)\s*(minutes?|mins?|分|hours?|時間|days?|日|weeks?|週間)\s*(?:ago|前)",
        lower,
    )
    if ago:
        point = now - _duration(int(ago.group(1)), ago.group(2))
        return _time_result(point, now, timezone, raw, "relative_ago")

    if lower in {"yesterday", "昨日"}:
        day = (now - timedelta(days=1)).date()
        start = datetime.combine(day, datetime.min.time(), timezone)
        return _time_result(start, start + timedelta(days=1), timezone, raw, "yesterday")
    if lower in {"today", "今日"}:
        start = datetime.combine(now.date(), datetime.min.time(), timezone)
        return _time_result(start, now, timezone, raw, "today")
    if lower in {"last week", "先週"}:
        this_monday = datetime.combine(
            now.date() - timedelta(days=now.weekday()), datetime.min.time(), timezone
        )
        return _time_result(
            this_monday - timedelta(days=7), this_monday, timezone, raw, "last_week"
        )

    before = re.match(
        r"from\s+(\d+)\s*(minutes?|hours?|days?)\s+before\s+(.+?)\s+(?:until|to)\s+now$",
        lower,
    )
    if before:
        anchor = _parse_datetime(before.group(3), timezone, now)
        start = anchor - _duration(int(before.group(1)), before.group(2))
        return _time_result(start, now, timezone, raw, "relative_before_anchor")

    range_parts = re.split(r"\s+(?:until|to|から|〜|～)\s+", text, maxsplit=1, flags=re.I)
    if len(range_parts) == 2:
        left = re.sub(r"^(?:from|since|開始|から)\s+", "", range_parts[0], flags=re.I)
        right = range_parts[1]
        start = _parse_datetime(left, timezone, now)
        if right.strip().lower() in {"now", "現在", "いま", "今"}:
            end = now
        else:
            later = re.match(r"(\d+)\s*(minutes?|hours?|days?)\s+later", right, re.I)
            end = start + _duration(int(later.group(1)), later.group(2)) if later else _parse_datetime(right, timezone, now)
        return _time_result(start, end, timezone, raw, "explicit_range")

    if lower.startswith("since "):
        start = _parse_datetime(text[6:], timezone, now)
        return _time_result(start, now, timezone, raw, "since")

    try:
        point = _parse_datetime(text, timezone, now)
        return _time_result(point, now, timezone, raw, "parsed_point_to_now")
    except Exception:
        start, end = now - timedelta(hours=24), now
        result = _time_result(start, end, timezone, raw, "fallback_last_24_hours")
        result["warning"] = "Input could not be parsed reliably; defaulted to the last 24 hours."
        return result


def _duration(amount: int, unit: str) -> timedelta:
    unit = unit.lower()
    if unit.startswith("min") or unit == "分":
        return timedelta(minutes=amount)
    if unit.startswith("hour") or unit == "時間":
        return timedelta(hours=amount)
    if unit.startswith("week") or unit == "週間":
        return timedelta(weeks=amount)
    return timedelta(days=amount)


def _parse_datetime(value: str, timezone: ZoneInfo, now: datetime) -> datetime:
    cleaned = value.strip()
    aliases = {
        "now": now,
        "現在": now,
        "today": datetime.combine(now.date(), datetime.min.time(), timezone),
        "今日": datetime.combine(now.date(), datetime.min.time(), timezone),
        "yesterday": datetime.combine(now.date() - timedelta(days=1), datetime.min.time(), timezone),
        "昨日": datetime.combine(now.date() - timedelta(days=1), datetime.min.time(), timezone),
    }
    if cleaned.lower() in aliases:
        return aliases[cleaned.lower()]
    parsed = date_parser.parse(cleaned, default=now.replace(hour=0, minute=0, second=0, microsecond=0))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone)
    return parsed.astimezone(timezone)


def _time_result(
    start: datetime,
    end: datetime,
    timezone: ZoneInfo,
    input_text: str,
    strategy: str,
) -> dict[str, Any]:
    return _millisecond_result(
        int(start.timestamp() * 1000),
        int(end.timestamp() * 1000),
        timezone,
        input_text,
        strategy,
    )


def _millisecond_result(
    start_ms: int,
    end_ms: int,
    timezone: ZoneInfo,
    input_text: str,
    strategy: str,
) -> dict[str, Any]:
    start = datetime.fromtimestamp(start_ms / 1000, timezone)
    end = datetime.fromtimestamp(end_ms / 1000, timezone)
    return {
        "start_time_ms": start_ms,
        "end_time_ms": end_ms,
        "start_iso": start.isoformat(),
        "end_iso": end.isoformat(),
        "timezone": str(timezone),
        "input": input_text,
        "parse_strategy": strategy,
    }
