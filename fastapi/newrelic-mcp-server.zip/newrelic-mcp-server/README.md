# New Relic MCP Server

添付のツール一覧を基準に、New RelicのNerdGraph APIとNRQLを利用して26個のMCPツールを公開する、セルフホスト用Pythonサーバです。

## 対応範囲

- MCP Python SDK v2
- stdio（ローカルのVS Code / GitHub Copilot向け）
- Streamable HTTP（共有サーバ向け、`/mcp`）
- New Relic NerdGraph / NRQL
- Account IDの許可リスト
- 読み取り専用NRQL制限
- 英語・日本語の基本的な自然言語時刻変換
- テンプレート方式の自然言語→NRQL変換
- ログ、APMトランザクション、Golden Metrics、Kafka、Thread、GC、デプロイ前後比較などの分析

元の仕様は `docs/original_tool_catalog.txt` に収録しています。

## 重要な前提

このリポジトリは、元MCPサーバの入力仕様をもとに再実装したものです。元サーバのソースコードや戻り値スキーマは提供されていないため、**ツール名と入力引数は合わせていますが、戻り値や高度な分析ロジックの完全互換を保証するものではありません**。

特に次の機能は、New Relicアカウントに実際に存在するイベント名、属性名、エージェント言語、インテグレーションに依存します。

- `analyze_kafka_metrics`
- `analyze_threads`
- `list_garbage_collection_metrics`
- `generate_user_impact_report`
- `generate_alert_insights_report`

NRQLテンプレートは `src/newrelic_mcp/service.py` と `src/newrelic_mcp/nrql.py` に分離してあり、環境に合わせて変更できます。

## 必要条件

- Python 3.11以上
- New Relic User API key
- 対象アカウント・機能に対する読み取り権限
- `uv` または `pip`

データ投入用のLicense keyではなく、NerdGraphを利用できるUser API keyを使用してください。

## セットアップ

```bash
cp .env.example .env
# .env の NEW_RELIC_USER_KEY を設定（起動時に自動読込）

python -m venv .venv
. .venv/bin/activate
pip install -e ".[dev]"
pytest
```

`uv`を利用する場合は次のとおりです。

```bash
cp .env.example .env
uv sync --extra dev
uv run pytest
```

## stdioで起動

ローカルのGitHub Copilotから呼び出す場合に適しています。

```bash
export NEW_RELIC_USER_KEY='NRAK-...'
newrelic-mcp
```

何も表示されずプロセスが待機するのは正常です。stdioでは標準入出力がMCP通信に使われます。

### VS Code / GitHub Copilot設定

`.vscode/mcp.json` に以下を置きます。絶対パスを実際のパスへ変更してください。

```json
{
  "servers": {
    "newRelic": {
      "type": "stdio",
      "command": "uv",
      "args": [
        "run",
        "--project",
        "/ABSOLUTE/PATH/TO/newrelic-mcp-server",
        "newrelic-mcp"
      ],
      "envFile": "/ABSOLUTE/PATH/TO/newrelic-mcp-server/.env"
    }
  }
}
```

同じ内容を `examples/vscode-mcp-stdio.json` に収録しています。Copilot ChatをAgentモードにし、New Relicツールを有効化して自然言語で問い合わせます。

## Streamable HTTPで起動

```bash
cat >> .env <<'ENV'
MCP_TRANSPORT=streamable-http
MCP_HOST=0.0.0.0
MCP_PORT=8000
ENV

newrelic-mcp
```

MCPエンドポイント:

```text
http://127.0.0.1:8000/mcp
```

VS Code設定例:

```json
{
  "servers": {
    "newRelic": {
      "type": "http",
      "url": "http://127.0.0.1:8000/mcp"
    }
  }
}
```

共有環境へ公開する場合は、TLSとOAuth 2.1またはリバースプロキシ認証を追加してください。New Relic APIキーをMCPクライアントへ返さないでください。

## Docker

```bash
cp .env.example .env
# .envを編集
docker compose up --build
```

## 環境変数

| 変数 | 既定値 | 説明 |
|---|---:|---|
| `NEW_RELIC_USER_KEY` | 必須 | New Relic User API key |
| `NEW_RELIC_REGION` | `US` | `US` / `EU` / `JP` |
| `NEW_RELIC_GRAPHQL_URL` | 空 | NerdGraph URLを直接上書き |
| `NEW_RELIC_ALLOWED_ACCOUNT_IDS` | 空 | カンマ区切りのAccount ID許可リスト |
| `NEW_RELIC_TIMEZONE` | `Asia/Tokyo` | 自然言語時刻の既定タイムゾーン |
| `NEW_RELIC_HTTP_TIMEOUT_SECONDS` | `75` | NerdGraph HTTPタイムアウト |
| `NEW_RELIC_MAX_TIME_WINDOW_DAYS` | `30` | ツールの最大検索期間 |
| `NEW_RELIC_READ_ONLY_NRQL` | `true` | `SELECT`以外を拒否 |
| `NEW_RELIC_MAX_NRQL_LENGTH` | `20000` | NRQL文字数上限 |
| `MCP_TRANSPORT` | `stdio` | `stdio` / `streamable-http` |
| `MCP_HOST` | `127.0.0.1` | HTTP待受アドレス |
| `MCP_PORT` | `8000` | HTTP待受ポート |

## 公開される26ツール

1. `list_available_new_relic_accounts`
2. `list_recent_issues`
3. `list_change_events`
4. `list_recent_logs`
5. `search_entity_with_tag`
6. `execute_nrql_query`
7. `list_synthetic_monitors`
8. `list_alert_policies`
9. `list_dashboards`
10. `natural_language_to_nrql_query`
11. `generate_alert_insights_report`
12. `analyze_deployment_impact`
13. `generate_user_impact_report`
14. `analyze_entity_logs`
15. `analyze_golden_metrics`
16. `analyze_kafka_metrics`
17. `analyze_threads`
18. `analyze_transactions`
19. `convert_time_period_to_epoch_ms`
20. `get_entity`
21. `list_entity_error_groups`
22. `list_garbage_collection_metrics`
23. `list_related_entities`
24. `search_incident`
25. `get_dashboard`
26. `list_alert_conditions`

## 自然言語問い合わせ例

```text
利用できるNew Relicアカウントを一覧にしてください。
```

```text
productionタグが付いているAPMアプリを探してください。
```

```text
order-apiの直近1時間について、エラー率、p95、p99、遅いエンドポイントを調べてください。
```

```text
直近24時間のHIGHまたはCRITICALのIssueを一覧にし、影響が大きいものを分析してください。
```

Copilot側のLLMが自然言語からツールと引数を選択します。`natural_language_to_nrql_query`は補助機能であり、自然言語利用そのものに必須ではありません。

## 実装上の補足

### 自然言語→NRQL

この初期版は外部LLMを呼ばず、保守的なテンプレート方式を採用しています。ログ、エラー率、レイテンシ、スループット、CPU、メモリ、Issue/Incidentなどを判定します。自由度の高いNRQLはCopilot自身に生成させ、`execute_nrql_query`を呼ぶ方が柔軟です。

### Account一覧

公式のOrganization Account Managementクエリを利用します。このクエリ権限がない場合、`NEW_RELIC_ALLOWED_ACCOUNT_IDS`が設定されていれば、そのIDをフォールバックとして返します。

### Alert Condition

初期版の`list_alert_conditions`はNRQL Alert Conditionを取得します。Infrastructure、Syntheticsなど別形式のConditionを利用する場合は、それぞれのNerdGraph APIを追加してください。

### Entity relationships

NerdGraphのEntity Relationship APIを最初に試し、利用できない場合はSpanのpeer属性から依存先を推定します。推定結果には`INFERRED_FROM_SPAN`と表示されます。

### 高度な分析

分析結果はNew Relic AIの出力ではなく、取得データに対する決定論的な集計・閾値判定です。元MCPと同じレポートを再現するには、元MCPの正常系・0件・エラー時の戻り値サンプルをGolden Testとして追加してください。

## テスト

```bash
pytest
python -m compileall -q src
```

ユニットテストは、時刻解析、NRQL安全性、自然言語テンプレート、NerdGraphレスポンス解析、26ツールの存在を確認します。

実際のNew Relicアカウントを使った統合テストは、APIキーやデータ構造が環境固有のため含めていません。
