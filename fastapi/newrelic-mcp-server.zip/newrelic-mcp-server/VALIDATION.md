# Validation Report

Validated on 2026-07-30.

## Completed checks

- Python byte-code compilation: passed
- Unit tests: 14 passed
- MCP tool wrapper count: 26
- Service contract method count: 26 expected methods present
- Read-only NRQL validation tests: passed
- Time-period parsing tests: passed
- Mocked NerdGraph response parsing tests: passed

## Not performed

A live New Relic integration test was not performed because no New Relic User API key,
account ID, entity GUID, or account-specific telemetry schema was supplied.

The advanced analysis tools are implemented with deterministic NRQL templates and
heuristics. Kafka, thread, GC, browser-user-impact, alert-event, and change-tracking
attributes can vary by New Relic agent and integration. Validate and tune those templates
against the target account before production use.
