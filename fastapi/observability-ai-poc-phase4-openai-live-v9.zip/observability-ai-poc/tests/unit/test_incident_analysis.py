import pytest
from pydantic import ValidationError

from agent.analysis.analyzer import InvalidAnalysisReference, validate_analysis_references
from agent.analysis.models import Confidence, Hypothesis, IncidentAnalysis
from agent.analysis.prompt import ANALYSIS_CONTRACT
from agent.evidence.models import (
    EvidenceBundle,
    EvidenceCategory,
    EvidenceContradiction,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)


def _bundle():
    return EvidenceBundle(
        investigation_id="inv-1",
        request_id="req-1",
        trace_id="trace-1",
        evidence=[
            EvidenceItem(
                evidence_id="newrelic-001",
                source=EvidenceSource.NEW_RELIC,
                category=EvidenceCategory.TRANSACTION,
                summary="Transaction observed",
                facts={"duration": 0.1},
                query_or_tool="query-newrelic-001",
            ),
            EvidenceItem(
                evidence_id="splunk-001",
                source=EvidenceSource.SPLUNK,
                category=EvidenceCategory.DB,
                summary="DB query observed",
                facts={"db.duration_ms": 1.2},
                query_or_tool="query-splunk-001",
            ),
        ],
        contradictions=[
            EvidenceContradiction(
                contradiction_id="contradiction-001",
                summary="example",
                left_evidence_ids=["splunk-001"],
                right_evidence_ids=["newrelic-001"],
            )
        ],
        gaps=[],
        queries_used=[
            QueryDisclosure(
                disclosure_id="query-newrelic-001",
                source=EvidenceSource.NEW_RELIC,
                operation="execute_nrql_query",
                arguments={"query": "SELECT duration FROM Transaction"},
            ),
            QueryDisclosure(
                disclosure_id="query-splunk-001",
                source=EvidenceSource.SPLUNK,
                operation="search",
                arguments={"query": 'trace.id="trace-1"'},
            ),
        ],
    )


def _analysis(**overrides):
    values = dict(
        incident_summary="The request completed slowly.",
        impact="One correlated request was affected.",
        likely_cause="The exact root cause is undetermined from available evidence.",
        confidence="low",
        supporting_evidence_ids=[],
        alternative_hypotheses=[],
        recommended_checks=["Inspect application processing around the trace window."],
        recommended_actions=["Review the deployment diff before making any change."],
        new_relic_evidence_ids=["newrelic-001"],
        splunk_evidence_ids=["splunk-001"],
        contradiction_ids=["contradiction-001"],
        query_disclosure_ids=["query-splunk-001"],
    )
    values.update(overrides)
    return IncidentAnalysis(**values)


def test_valid_analysis_references_known_bundle_ids():
    validate_analysis_references(_bundle(), _analysis())


def test_unknown_evidence_id_is_rejected():
    analysis = _analysis(supporting_evidence_ids=["missing-999"])
    with pytest.raises(InvalidAnalysisReference, match="missing-999"):
        validate_analysis_references(_bundle(), analysis)


def test_unknown_query_disclosure_id_is_rejected():
    analysis = _analysis(query_disclosure_ids=["query-missing"])
    with pytest.raises(InvalidAnalysisReference, match="query-missing"):
        validate_analysis_references(_bundle(), analysis)


def test_unknown_contradiction_id_is_rejected():
    analysis = _analysis(contradiction_ids=["contradiction-missing"])
    with pytest.raises(InvalidAnalysisReference, match="contradiction-missing"):
        validate_analysis_references(_bundle(), analysis)


def test_high_confidence_without_supporting_evidence_is_rejected():
    with pytest.raises(ValidationError, match="high confidence requires supporting evidence"):
        _analysis(confidence=Confidence.HIGH, supporting_evidence_ids=[])


def test_alternative_hypothesis_references_are_validated():
    analysis = _analysis(
        alternative_hypotheses=[
            Hypothesis(summary="Alternative", supporting_evidence_ids=["missing-777"])
        ]
    )
    with pytest.raises(InvalidAnalysisReference, match="missing-777"):
        validate_analysis_references(_bundle(), analysis)


def test_recommended_actions_are_advisory_strings_only():
    analysis = _analysis()
    assert analysis.recommended_actions == ["Review the deployment diff before making any change."]
    assert all(isinstance(item, str) for item in analysis.recommended_actions)


def test_prompt_contains_correlation_and_span_safety_rules():
    assert "Correlation is not causation" in ANALYSIS_CONTRACT
    assert "Span evidence is unavailable" in ANALYSIS_CONTRACT
    assert "parent Transaction duration" in ANALYSIS_CONTRACT
    assert "do not claim to have executed changes" in ANALYSIS_CONTRACT


def test_definitive_likely_cause_without_supporting_evidence_is_rejected():
    with pytest.raises(ValidationError, match="likely cause requires supporting evidence"):
        _analysis(likely_cause="The database is the root cause.", supporting_evidence_ids=[])


def test_alternative_hypothesis_requires_supporting_or_opposing_evidence():
    with pytest.raises(ValidationError, match="hypothesis requires evidence references"):
        Hypothesis(summary="Alternative with no evidence")


def test_incident_analysis_json_schema_forbids_unknown_object_properties():
    schema = IncidentAnalysis.model_json_schema()
    assert schema["additionalProperties"] is False
    assert schema["$defs"]["Hypothesis"]["additionalProperties"] is False
