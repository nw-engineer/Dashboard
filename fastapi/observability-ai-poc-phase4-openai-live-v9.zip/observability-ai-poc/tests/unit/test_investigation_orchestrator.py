from datetime import datetime, timedelta, timezone

import pytest

from agent.analysis.models import IncidentAnalysis
from agent.evidence.correlation import AmbiguousTraceId
from agent.evidence.correlator import EvidenceCorrelator
from agent.evidence.models import (
    CorrelationContext,
    EvidenceCategory,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)
from agent.evidence.newrelic_collector import (
    NewRelicEvidenceResult,
    NewRelicEvidenceUnavailable,
)
from agent.evidence.splunk_collector import (
    SplunkEvidenceResult,
    SplunkEvidenceUnavailable,
)
from agent.orchestrator import InvestigationOrchestrator


def _splunk_result():
    return SplunkEvidenceResult(
        evidence=[
            EvidenceItem(
                evidence_id="splunk-001",
                source=EvidenceSource.SPLUNK,
                category=EvidenceCategory.APPLICATION,
                summary="application event",
                facts={"event_type": "application.request"},
                query_or_tool="query-splunk-001",
                request_id="req-1",
                trace_id="trace-1",
            )
        ],
        query=QueryDisclosure(
            disclosure_id="query-splunk-001",
            source=EvidenceSource.SPLUNK,
            operation="search",
            arguments={"query": 'trace.id="trace-1"'},
        ),
    )


def _newrelic_result():
    return NewRelicEvidenceResult(
        evidence=[
            EvidenceItem(
                evidence_id="newrelic-001",
                source=EvidenceSource.NEW_RELIC,
                category=EvidenceCategory.TRANSACTION,
                summary="transaction event",
                facts={"duration": 0.1},
                query_or_tool="query-newrelic-001",
                request_id="req-1",
                trace_id="trace-1",
            )
        ],
        gaps=[],
        queries=[
            QueryDisclosure(
                disclosure_id="query-newrelic-001",
                source=EvidenceSource.NEW_RELIC,
                operation="execute_nrql_query",
                arguments={"query": "SELECT duration FROM Transaction"},
            )
        ],
    )


def _valid_analysis(bundle):
    return IncidentAnalysis(
        incident_summary="Correlated evidence was collected.",
        impact="One request was investigated.",
        likely_cause="The exact root cause is undetermined from available evidence.",
        confidence="low",
        supporting_evidence_ids=[],
        alternative_hypotheses=[],
        recommended_checks=["Inspect the evidence bundle."],
        recommended_actions=["Review before making any change."],
        new_relic_evidence_ids=[
            item.evidence_id for item in bundle.evidence if item.source is EvidenceSource.NEW_RELIC
        ],
        splunk_evidence_ids=[
            item.evidence_id for item in bundle.evidence if item.source is EvidenceSource.SPLUNK
        ],
        contradiction_ids=[item.contradiction_id for item in bundle.contradictions],
        query_disclosure_ids=[item.disclosure_id for item in bundle.queries_used],
    )


class FakeResolver:
    def __init__(self, events, *, error=None):
        self.events = events
        self.error = error

    async def resolve_request(self, request_id, earliest, latest):
        self.events.append("correlation")
        if self.error:
            raise self.error
        return CorrelationContext(
            request_id=request_id,
            trace_id="trace-1",
            services=["api-gateway"],
        )


class FakeSplunkCollector:
    def __init__(self, events, *, error=None):
        self.events = events
        self.error = error
        self.windows = []

    async def collect(self, context, earliest, latest):
        self.events.append("splunk")
        self.windows.append((earliest, latest))
        if self.error:
            raise self.error
        return _splunk_result()


class FakeNewRelicCollector:
    def __init__(self, events, *, error=None):
        self.events = events
        self.error = error
        self.windows = []

    async def collect(self, context, earliest, latest):
        self.events.append("newrelic")
        self.windows.append((earliest, latest))
        if self.error:
            raise self.error
        return _newrelic_result()


class RecordingCorrelator:
    def __init__(self, events):
        self.events = events
        self.inner = EvidenceCorrelator()

    def build_bundle(self, **kwargs):
        self.events.append("correlate")
        return self.inner.build_bundle(**kwargs)


class FakeAnalyzer:
    def __init__(self, events, *, invalid=False):
        self.events = events
        self.invalid = invalid

    async def analyze(self, bundle):
        self.events.append("analyze")
        if not self.invalid:
            return _valid_analysis(bundle)
        return IncidentAnalysis(
            incident_summary="bad",
            impact="bad",
            likely_cause="A cause backed by a fabricated ID.",
            confidence="medium",
            supporting_evidence_ids=["fabricated-999"],
            alternative_hypotheses=[],
            recommended_checks=[],
            recommended_actions=[],
            new_relic_evidence_ids=[],
            splunk_evidence_ids=[],
            contradiction_ids=[],
            query_disclosure_ids=[],
        )


@pytest.mark.asyncio
async def test_happy_path_call_order_and_exact_time_window():
    events = []
    splunk = FakeSplunkCollector(events)
    newrelic = FakeNewRelicCollector(events)
    orchestrator = InvestigationOrchestrator(
        resolver=FakeResolver(events),
        splunk_collector=splunk,
        newrelic_collector=newrelic,
        correlator=RecordingCorrelator(events),
        analyzer=FakeAnalyzer(events),
    )
    latest = datetime(2026, 9, 3, 6, 0, tzinfo=timezone.utc)
    earliest = latest - timedelta(minutes=10)

    result = await orchestrator.investigate_request_id("req-1", earliest, latest)

    assert events == ["correlation", "splunk", "newrelic", "correlate", "analyze"]
    assert splunk.windows == [(earliest, latest)]
    assert newrelic.windows == [(earliest, latest)]
    assert result.bundle.trace_id == "trace-1"


@pytest.mark.asyncio
async def test_ambiguous_trace_stops_before_collectors_and_analyzer():
    events = []
    orchestrator = InvestigationOrchestrator(
        resolver=FakeResolver(events, error=AmbiguousTraceId("two traces")),
        splunk_collector=FakeSplunkCollector(events),
        newrelic_collector=FakeNewRelicCollector(events),
        correlator=RecordingCorrelator(events),
        analyzer=FakeAnalyzer(events),
    )
    now = datetime.now(timezone.utc)

    with pytest.raises(AmbiguousTraceId):
        await orchestrator.investigate_request_id("req-1", now - timedelta(minutes=5), now)

    assert events == ["correlation"]


@pytest.mark.asyncio
async def test_newrelic_failure_becomes_gap_and_analysis_continues():
    events = []
    orchestrator = InvestigationOrchestrator(
        resolver=FakeResolver(events),
        splunk_collector=FakeSplunkCollector(events),
        newrelic_collector=FakeNewRelicCollector(
            events, error=NewRelicEvidenceUnavailable("password=do-not-leak")
        ),
        correlator=RecordingCorrelator(events),
        analyzer=FakeAnalyzer(events),
    )
    now = datetime.now(timezone.utc)

    result = await orchestrator.investigate_request_id("req-1", now - timedelta(minutes=5), now)

    assert events == ["correlation", "splunk", "newrelic", "correlate", "analyze"]
    gap = next(g for g in result.bundle.gaps if g.source is EvidenceSource.NEW_RELIC)
    assert gap.summary == "New Relic evidence was unavailable for this investigation"
    assert "password" not in gap.summary.lower()


@pytest.mark.asyncio
async def test_splunk_evidence_failure_after_correlation_becomes_partial_gap():
    events = []
    orchestrator = InvestigationOrchestrator(
        resolver=FakeResolver(events),
        splunk_collector=FakeSplunkCollector(
            events, error=SplunkEvidenceUnavailable("token=do-not-leak")
        ),
        newrelic_collector=FakeNewRelicCollector(events),
        correlator=RecordingCorrelator(events),
        analyzer=FakeAnalyzer(events),
    )
    now = datetime.now(timezone.utc)

    result = await orchestrator.investigate_request_id("req-1", now - timedelta(minutes=5), now)

    gap = next(g for g in result.bundle.gaps if g.source is EvidenceSource.SPLUNK)
    assert gap.summary == "Splunk evidence was unavailable after correlation was established"
    assert [item.source for item in result.bundle.evidence] == [EvidenceSource.NEW_RELIC]
    assert events == ["correlation", "splunk", "newrelic", "correlate", "analyze"]


@pytest.mark.asyncio
async def test_analyzer_output_with_unknown_evidence_is_rejected():
    from agent.analysis.analyzer import InvalidAnalysisReference

    events = []
    orchestrator = InvestigationOrchestrator(
        resolver=FakeResolver(events),
        splunk_collector=FakeSplunkCollector(events),
        newrelic_collector=FakeNewRelicCollector(events),
        correlator=RecordingCorrelator(events),
        analyzer=FakeAnalyzer(events, invalid=True),
    )
    now = datetime.now(timezone.utc)

    with pytest.raises(InvalidAnalysisReference, match="fabricated-999"):
        await orchestrator.investigate_request_id("req-1", now - timedelta(minutes=5), now)
