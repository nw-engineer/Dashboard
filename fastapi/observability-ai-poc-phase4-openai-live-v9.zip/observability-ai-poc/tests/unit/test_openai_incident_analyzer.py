import json

import httpx
import pytest

from agent.analysis.models import IncidentAnalysis
from agent.analysis.prompt import ANALYSIS_CONTRACT
from agent.evidence.models import (
    EvidenceBundle,
    EvidenceCategory,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)


def _bundle() -> EvidenceBundle:
    return EvidenceBundle(
        investigation_id="inv-openai-1",
        request_id="req-1",
        trace_id="trace-1",
        evidence=[
            EvidenceItem(
                evidence_id="newrelic-001",
                source=EvidenceSource.NEW_RELIC,
                category=EvidenceCategory.TRANSACTION,
                summary="Transaction duration increased after deployment.",
                facts={"duration": 1.8, "error": False},
                query_or_tool="query-newrelic-001",
                request_id="req-1",
                trace_id="trace-1",
            ),
            EvidenceItem(
                evidence_id="splunk-001",
                source=EvidenceSource.SPLUNK,
                category=EvidenceCategory.DEPLOYMENT,
                summary="inventory-service version 1.1.0 was deployed.",
                facts={"service.version": "1.1.0"},
                query_or_tool="query-splunk-001",
                request_id="req-1",
                trace_id="trace-1",
            ),
        ],
        contradictions=[],
        gaps=[],
        queries_used=[
            QueryDisclosure(
                disclosure_id="query-newrelic-001",
                source=EvidenceSource.NEW_RELIC,
                operation="execute_nrql_query",
                arguments={"nrql_query": "SELECT duration FROM Transaction"},
            ),
            QueryDisclosure(
                disclosure_id="query-splunk-001",
                source=EvidenceSource.SPLUNK,
                operation="search",
                arguments={"query": 'trace.id="trace-1"'},
            ),
        ],
    )


def _analysis_payload() -> dict:
    return {
        "incident_summary": "The correlated request was slow after a deployment.",
        "impact": "One request was observed with elevated latency.",
        "likely_cause": "Deployment 1.1.0 is a supported cause candidate, not proven causation.",
        "confidence": "medium",
        "supporting_evidence_ids": ["newrelic-001", "splunk-001"],
        "alternative_hypotheses": [],
        "recommended_checks": ["Compare latency before and after deployment 1.1.0."],
        "recommended_actions": ["Review the deployment diff before making any change."],
        "new_relic_evidence_ids": ["newrelic-001"],
        "splunk_evidence_ids": ["splunk-001"],
        "contradiction_ids": [],
        "query_disclosure_ids": ["query-newrelic-001", "query-splunk-001"],
    }


@pytest.mark.asyncio
async def test_openai_analyzer_uses_responses_api_with_strict_schema_and_no_storage():
    from agent.analysis.openai_adapter import OpenAIIncidentAnalyzer

    captured = {}

    async def handler(request: httpx.Request) -> httpx.Response:
        captured["request"] = request
        captured["payload"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={
                "id": "resp_test",
                "status": "completed",
                "output": [
                    {
                        "type": "message",
                        "content": [
                            {
                                "type": "output_text",
                                "text": json.dumps(_analysis_payload()),
                                "annotations": [],
                            }
                        ],
                    }
                ],
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OpenAIIncidentAnalyzer(
            api_key="test-key",
            model="gpt-5.6-luna",
            client=client,
        )
        analysis = await analyzer.analyze(_bundle())

    assert analysis == IncidentAnalysis(**_analysis_payload())
    request = captured["request"]
    payload = captured["payload"]
    assert str(request.url) == "https://api.openai.com/v1/responses"
    assert request.headers["authorization"] == "Bearer test-key"
    assert payload["model"] == "gpt-5.6-luna"
    assert payload["store"] is False
    assert payload["max_output_tokens"] == 2500
    assert payload["instructions"] == ANALYSIS_CONTRACT
    assert '"evidence_id":"newrelic-001"' in payload["input"]
    assert payload["text"]["format"]["type"] == "json_schema"
    assert payload["text"]["format"]["strict"] is True
    assert payload["text"]["format"]["name"] == "incident_analysis"
    from agent.analysis.openai_adapter import build_incident_analysis_schema

    assert payload["text"]["format"]["schema"] == build_incident_analysis_schema()


def test_openai_analyzer_from_env_uses_cost_sensitive_default_model(monkeypatch):
    from agent.analysis.openai_adapter import OpenAIIncidentAnalyzer

    monkeypatch.setenv("OPENAI_API_KEY", "env-key")
    monkeypatch.delenv("OPENAI_MODEL", raising=False)
    analyzer = OpenAIIncidentAnalyzer.from_env()

    assert analyzer.api_key == "env-key"
    assert analyzer.model == "gpt-5.6-luna"


def test_openai_analyzer_from_env_requires_api_key(monkeypatch):
    from agent.analysis.openai_adapter import OpenAIConfigurationError, OpenAIIncidentAnalyzer

    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    with pytest.raises(OpenAIConfigurationError, match="OPENAI_API_KEY"):
        OpenAIIncidentAnalyzer.from_env()


@pytest.mark.asyncio
async def test_openai_analyzer_rejects_refusal_response():
    from agent.analysis.openai_adapter import OpenAIAnalysisError, OpenAIIncidentAnalyzer

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "resp_refusal",
                "status": "completed",
                "output": [
                    {
                        "type": "message",
                        "content": [
                            {"type": "refusal", "refusal": "Cannot comply with request."}
                        ],
                    }
                ],
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OpenAIIncidentAnalyzer(api_key="test-key", client=client)
        with pytest.raises(OpenAIAnalysisError, match="refused"):
            await analyzer.analyze(_bundle())


@pytest.mark.asyncio
async def test_openai_analyzer_rejects_incomplete_response_even_with_partial_text():
    from agent.analysis.openai_adapter import OpenAIAnalysisError, OpenAIIncidentAnalyzer

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "resp_incomplete",
                "status": "incomplete",
                "incomplete_details": {"reason": "max_output_tokens"},
                "output": [
                    {
                        "type": "message",
                        "content": [
                            {
                                "type": "output_text",
                                "text": json.dumps(_analysis_payload()),
                                "annotations": [],
                            }
                        ],
                    }
                ],
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OpenAIIncidentAnalyzer(api_key="test-key", client=client)
        with pytest.raises(OpenAIAnalysisError, match="incomplete"):
            await analyzer.analyze(_bundle())


@pytest.mark.asyncio
async def test_openai_analyzer_wraps_http_error_without_response_body():
    from agent.analysis.openai_adapter import OpenAIAnalysisError, OpenAIIncidentAnalyzer

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            401,
            text='{"error":{"message":"secret-ish upstream detail"}}',
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OpenAIIncidentAnalyzer(api_key="test-key", client=client)
        with pytest.raises(OpenAIAnalysisError) as exc_info:
            await analyzer.analyze(_bundle())

    message = str(exc_info.value)
    assert "401" in message
    assert "secret-ish upstream detail" not in message
    assert "test-key" not in message


def test_openai_strict_schema_requires_every_hypothesis_property():
    from agent.analysis.openai_adapter import build_incident_analysis_schema

    schema = build_incident_analysis_schema()
    hypothesis = schema["$defs"]["Hypothesis"]
    assert hypothesis["required"] == list(hypothesis["properties"])
    assert hypothesis["additionalProperties"] is False


@pytest.mark.asyncio
async def test_openai_analyzer_wraps_invalid_structured_output():
    from agent.analysis.openai_adapter import OpenAIAnalysisError, OpenAIIncidentAnalyzer

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "resp_bad_json",
                "status": "completed",
                "output": [
                    {
                        "type": "message",
                        "content": [
                            {"type": "output_text", "text": "{not-json", "annotations": []}
                        ],
                    }
                ],
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OpenAIIncidentAnalyzer(api_key="test-key", client=client)
        with pytest.raises(OpenAIAnalysisError, match="structured output"):
            await analyzer.analyze(_bundle())


@pytest.mark.asyncio
async def test_openai_analyzer_wraps_network_error():
    from agent.analysis.openai_adapter import OpenAIAnalysisError, OpenAIIncidentAnalyzer

    async def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("network unavailable", request=request)

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OpenAIIncidentAnalyzer(api_key="test-key", client=client)
        with pytest.raises(OpenAIAnalysisError, match="request failed") as exc_info:
            await analyzer.analyze(_bundle())

    assert "network unavailable" not in str(exc_info.value)


def test_openai_analyzer_from_env_rejects_invalid_max_output_tokens(monkeypatch):
    from agent.analysis.openai_adapter import OpenAIConfigurationError, OpenAIIncidentAnalyzer

    monkeypatch.setenv("OPENAI_API_KEY", "env-key")
    monkeypatch.setenv("OPENAI_MAX_OUTPUT_TOKENS", "not-an-int")

    with pytest.raises(OpenAIConfigurationError, match="OPENAI_MAX_OUTPUT_TOKENS"):
        OpenAIIncidentAnalyzer.from_env()


@pytest.mark.asyncio
async def test_openai_analyzer_wraps_non_json_api_response():
    from agent.analysis.openai_adapter import OpenAIAnalysisError, OpenAIIncidentAnalyzer

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text="not-json")

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        analyzer = OpenAIIncidentAnalyzer(api_key="test-key", client=client)
        with pytest.raises(OpenAIAnalysisError, match="invalid JSON response"):
            await analyzer.analyze(_bundle())
