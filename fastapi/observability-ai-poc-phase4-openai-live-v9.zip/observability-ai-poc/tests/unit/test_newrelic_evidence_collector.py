from datetime import datetime, timedelta, timezone

import pytest

from agent.evidence.models import CorrelationContext, EvidenceCategory, EvidenceSource
from agent.evidence.newrelic_collector import (
    NewRelicEvidenceCollector,
    NewRelicEvidenceUnavailable,
)


TRANSACTION_RESPONSE = {
    "results": [
        {
            "traceId": "trace-1",
            "appName": "poc-api-gateway",
            "name": "WebTransaction/Uri/orders",
            "duration": 0.098,
            "error": False,
            "timestamp": 1788415200000,
        }
    ]
}
SPAN_RESPONSE = {"results": []}
CHANGE_RESPONSE = {
    "events": [
        {
            "entityName": "poc-inventory-service",
            "category": "Deployment",
            "version": "1.1.0",
            "timestamp": "2026-09-03T05:00:00Z",
        }
    ]
}


class FakeGateway:
    def __init__(self, *, transaction=TRANSACTION_RESPONSE, span=SPAN_RESPONSE, change=CHANGE_RESPONSE):
        self.transaction = transaction
        self.span = span
        self.change = change
        self.calls = []

    async def call_tool(self, name, arguments):
        self.calls.append((name, arguments))
        if name == "execute_nrql_query":
            query = str(arguments.get("nrql_query", ""))
            return self.span if "FROM Span" in query else self.transaction
        if name == "list_change_events":
            return self.change
        raise AssertionError(name)


@pytest.mark.asyncio
async def test_transaction_lookup_normalizes_factual_transaction_evidence():
    gateway = FakeGateway(change={"events": []})
    collector = NewRelicEvidenceCollector(gateway, account_id=8292460)
    context = CorrelationContext(
        request_id="req-1", trace_id="trace-1", services=["poc-api-gateway"]
    )
    latest = datetime(2026, 9, 3, 6, 5, tzinfo=timezone.utc)

    result = await collector.collect(context, latest - timedelta(minutes=10), latest)

    transaction = next(item for item in result.evidence if item.category is EvidenceCategory.TRANSACTION)
    assert transaction.source is EvidenceSource.NEW_RELIC
    assert transaction.trace_id == "trace-1"
    assert transaction.service_name == "poc-api-gateway"
    assert transaction.facts["duration"] == 0.098
    assert transaction.facts["error"] is False
    assert transaction.observed_at == datetime(2026, 9, 3, 6, 0, tzinfo=timezone.utc)

    nrql_calls = [call for call in gateway.calls if call[0] == "execute_nrql_query"]
    assert nrql_calls
    assert nrql_calls[0][1]["account_id"] == 8292460
    assert "FROM Transaction" in str(nrql_calls[0][1]["nrql_query"])
    assert "query" not in nrql_calls[0][1]


@pytest.mark.asyncio
async def test_absent_span_rows_are_recorded_as_gap_not_evidence():
    collector = NewRelicEvidenceCollector(FakeGateway(change={"events": []}), account_id=8292460)
    context = CorrelationContext(request_id="req-1", trace_id="trace-1")
    latest = datetime(2026, 9, 3, 6, 5, tzinfo=timezone.utc)

    result = await collector.collect(context, latest - timedelta(minutes=10), latest)

    assert not [item for item in result.evidence if item.category is EvidenceCategory.SPAN]
    assert any(gap.category is EvidenceCategory.SPAN for gap in result.gaps)
    assert any("Span evidence was not observed" in gap.summary for gap in result.gaps)


@pytest.mark.asyncio
async def test_change_events_normalize_to_deployment_evidence():
    collector = NewRelicEvidenceCollector(FakeGateway(), account_id=8292460)
    context = CorrelationContext(
        request_id="req-1",
        trace_id="trace-1",
        services=["poc-inventory-service"],
        entity_guids={"poc-inventory-service": "guid-inventory"},
    )
    latest = datetime(2026, 9, 3, 6, 5, tzinfo=timezone.utc)

    result = await collector.collect(context, latest - timedelta(hours=1), latest)

    deployment = next(item for item in result.evidence if item.category is EvidenceCategory.DEPLOYMENT)
    assert deployment.service_name == "poc-inventory-service"
    assert deployment.facts["version"] == "1.1.0"
    assert deployment.facts["category"] == "Deployment"

    change_call = next(call for call in collector.gateway.calls if call[0] == "list_change_events")
    assert change_call[1]["entity_guid"] == "guid-inventory"
    assert change_call[1]["history_period_hours"] == 1
    assert "entity_name" not in change_call[1]


@pytest.mark.asyncio
async def test_query_disclosures_contain_tool_name_and_non_secret_arguments():
    gateway = FakeGateway(change={"events": []})
    collector = NewRelicEvidenceCollector(gateway, account_id=8292460)
    context = CorrelationContext(
        request_id="req-1",
        trace_id="trace-1",
        services=["poc-api-gateway"],
        entity_guids={"poc-api-gateway": "guid-api"},
    )
    latest = datetime(2026, 9, 3, 6, 5, tzinfo=timezone.utc)

    result = await collector.collect(context, latest - timedelta(minutes=10), latest)

    operations = [query.operation for query in result.queries]
    assert operations.count("execute_nrql_query") == 2
    assert "list_change_events" in operations
    serialized = str([query.arguments for query in result.queries]).lower()
    assert "password" not in serialized
    assert "api_key" not in serialized
    assert "token" not in serialized


@pytest.mark.asyncio
async def test_gateway_exception_raises_unavailable_without_secret_arguments():
    class BrokenGateway:
        async def call_tool(self, name, arguments):
            raise RuntimeError("password=super-secret token=abc")

    collector = NewRelicEvidenceCollector(BrokenGateway(), account_id=8292460)
    context = CorrelationContext(request_id="req-1", trace_id="trace-1")
    now = datetime.now(timezone.utc)

    with pytest.raises(NewRelicEvidenceUnavailable) as exc:
        await collector.collect(context, now - timedelta(minutes=5), now)

    message = str(exc.value).lower()
    assert "super-secret" not in message
    assert "token=abc" not in message


@pytest.mark.asyncio
async def test_unsupported_transaction_payload_is_rejected():
    collector = NewRelicEvidenceCollector(FakeGateway(transaction="not-a-dict"), account_id=8292460)
    context = CorrelationContext(request_id="req-1", trace_id="trace-1")
    now = datetime.now(timezone.utc)

    with pytest.raises(NewRelicEvidenceUnavailable, match="execute_nrql_query"):
        await collector.collect(context, now - timedelta(minutes=5), now)


def test_account_id_must_be_positive():
    with pytest.raises(ValueError, match="account_id"):
        NewRelicEvidenceCollector(FakeGateway(), account_id=0)

REAL_CHANGE_FALLBACK_RESPONSE = {
    "ok": True,
    "account_id": 8292460,
    "nrql_query": "SELECT ... FROM ChangeTrackingEvent, Deployment",
    "results": [
        {
            "category": "Deployment",
            "categoryType": "DEPLOYMENT__BASIC",
            "changeTrackingId": "8ee34a1b-d460-4bab-b3a2-48b38c6a6555",
            "description": "UC05 deployment uc05-demo-deploy-001; service.version=1.1.0; git.sha=local-poc",
            "entity.domain": "APM",
            "entity.guid": "guid-inventory",
            "entity.name": "poc-inventory-service",
            "entity.type": "APPLICATION",
            "eventType()": "ChangeTrackingEvent",
            "gitSha": "local-poc",
            "groupId": "uc05-demo-deploy-001",
            "serviceVersion": "1.1.0",
            "shortDescription": "PoC inventory-service deployment 1.1.0",
            "timestamp": 1788409904810,
            "type": "Basic",
            "version": "1.1.0",
        }
    ],
}


class FallbackChangeGateway(FakeGateway):
    def __init__(self, *, change_failure=None, fallback=REAL_CHANGE_FALLBACK_RESPONSE):
        super().__init__(change={"ok": False, "error": "NewRelicAPIError"})
        self.change_failure = change_failure
        self.fallback = fallback

    async def call_tool(self, name, arguments):
        self.calls.append((name, arguments))
        if name == "list_change_events":
            if self.change_failure is not None:
                raise self.change_failure
            return self.change
        if name == "execute_nrql_query":
            query = str(arguments.get("nrql_query", ""))
            if "ChangeTrackingEvent" in query:
                return self.fallback
            return self.span if "FROM Span" in query else self.transaction
        raise AssertionError(name)


@pytest.mark.asyncio
async def test_change_tool_error_payload_falls_back_to_select_first_nrql():
    gateway = FallbackChangeGateway()
    collector = NewRelicEvidenceCollector(gateway, account_id=8292460)
    context = CorrelationContext(
        request_id="req-1",
        trace_id="trace-1",
        services=["poc-inventory-service"],
        entity_guids={"poc-inventory-service": "guid-inventory"},
    )
    latest = datetime(2026, 9, 3, 6, 5, tzinfo=timezone.utc)

    result = await collector.collect(context, latest - timedelta(hours=1), latest)

    fallback_call = next(
        call
        for call in gateway.calls
        if call[0] == "execute_nrql_query"
        and "ChangeTrackingEvent" in str(call[1].get("nrql_query", ""))
    )
    nrql = str(fallback_call[1]["nrql_query"])
    assert nrql.startswith("SELECT ")
    assert "FROM ChangeTrackingEvent, Deployment" in nrql
    assert "entity.guid = 'guid-inventory'" in nrql
    assert fallback_call[1]["account_id"] == 8292460

    deployment = next(
        item for item in result.evidence if item.category is EvidenceCategory.DEPLOYMENT
    )
    assert deployment.service_name == "poc-inventory-service"
    assert deployment.entity_guid == "guid-inventory"
    assert deployment.facts["version"] == "1.1.0"
    assert deployment.facts["groupId"] == "uc05-demo-deploy-001"
    assert deployment.facts["changeTrackingId"] == "8ee34a1b-d460-4bab-b3a2-48b38c6a6555"
    assert deployment.observed_at == datetime.fromtimestamp(
        1788409904810 / 1000, tz=timezone.utc
    )

    operations = [query.operation for query in result.queries]
    assert "list_change_events" in operations
    assert operations.count("execute_nrql_query") == 3


@pytest.mark.asyncio
async def test_change_tool_exception_uses_same_nrql_fallback():
    gateway = FallbackChangeGateway(
        change_failure=RuntimeError("NerdGraph fragment type mismatch")
    )
    collector = NewRelicEvidenceCollector(gateway, account_id=8292460)
    context = CorrelationContext(
        request_id="req-1",
        trace_id="trace-1",
        entity_guids={"poc-inventory-service": "guid-inventory"},
    )
    latest = datetime(2026, 9, 3, 6, 5, tzinfo=timezone.utc)

    result = await collector.collect(context, latest - timedelta(hours=1), latest)

    assert any(
        item.category is EvidenceCategory.DEPLOYMENT for item in result.evidence
    )
    assert any(
        call[0] == "execute_nrql_query"
        and "ChangeTrackingEvent" in str(call[1].get("nrql_query", ""))
        for call in gateway.calls
    )


@pytest.mark.asyncio
async def test_change_fallback_failure_becomes_newrelic_unavailable_without_leaking_server_error():
    gateway = FallbackChangeGateway(
        fallback={"ok": False, "error": "password=secret token=abc"}
    )
    collector = NewRelicEvidenceCollector(gateway, account_id=8292460)
    context = CorrelationContext(
        request_id="req-1",
        trace_id="trace-1",
        entity_guids={"poc-inventory-service": "guid-inventory"},
    )
    latest = datetime(2026, 9, 3, 6, 5, tzinfo=timezone.utc)

    with pytest.raises(NewRelicEvidenceUnavailable) as exc:
        await collector.collect(context, latest - timedelta(hours=1), latest)

    message = str(exc.value).lower()
    assert "password=secret" not in message
    assert "token=abc" not in message
    assert "change tracking" in message
