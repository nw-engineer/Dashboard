from __future__ import annotations

import asyncio
import os
import time
import uuid
from datetime import UTC, datetime, timedelta

import httpx
import pytest

from agent.analysis.openai_adapter import OpenAIIncidentAnalyzer
from agent.evidence.correlation import CorrelationNotFound, CorrelationResolver, TraceIdNotFound
from agent.evidence.correlator import EvidenceCorrelator
from agent.evidence.models import CorrelationContext, EvidenceCategory, EvidenceSource
from agent.evidence.newrelic_collector import NewRelicEvidenceCollector
from agent.evidence.newrelic_transport import StreamableHttpNewRelicMcpGateway
from agent.evidence.splunk_collector import SplunkEvidenceCollector
from agent.orchestrator import InvestigationOrchestrator
from agent.splunk.client import SplunkSearchClient


SPLUNK_PASSWORD = os.getenv("SPLUNK_SEARCH_PASSWORD")
SPLUNK_URL = os.getenv("SPLUNK_SEARCH_URL", "https://localhost:8089")
SPLUNK_USERNAME = os.getenv("SPLUNK_SEARCH_USERNAME", "ai_search")
SPLUNK_VERIFY_SSL = os.getenv("SPLUNK_SEARCH_VERIFY_SSL", "false").lower() in {
    "1", "true", "yes", "on"
}
NEW_RELIC_MCP_URL = os.getenv("NEW_RELIC_MCP_URL")
NEW_RELIC_ACCOUNT_ID = os.getenv("NEW_RELIC_ACCOUNT_ID")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
API_GATEWAY_URL = os.getenv("API_GATEWAY_URL", "http://localhost:8085")


@pytest.mark.asyncio
@pytest.mark.skipif(
    not (
        SPLUNK_PASSWORD
        and NEW_RELIC_MCP_URL
        and NEW_RELIC_ACCOUNT_ID
        and OPENAI_API_KEY
    ),
    reason=(
        "SPLUNK_SEARCH_PASSWORD, NEW_RELIC_MCP_URL, NEW_RELIC_ACCOUNT_ID, "
        "and OPENAI_API_KEY are required"
    ),
)
async def test_live_phase4_real_sources_to_real_llm_incident_analysis():
    request_id = f"phase4-llm-e2e-{uuid.uuid4()}"
    latest = datetime.now(UTC)
    earliest = latest - timedelta(minutes=10)

    async with httpx.AsyncClient(timeout=10.0) as http:
        response = await http.post(
            f"{API_GATEWAY_URL.rstrip('/')}/orders",
            headers={"X-Request-ID": request_id},
            json={"product_id": "SKU-001", "quantity": 1, "amount": 1200},
        )
    assert response.status_code < 500, response.text

    splunk_client = SplunkSearchClient(
        base_url=SPLUNK_URL,
        username=SPLUNK_USERNAME,
        password=SPLUNK_PASSWORD or "",
        verify_ssl=SPLUNK_VERIFY_SSL,
        poll_interval=0.25,
        timeout_seconds=20.0,
    )
    resolver = CorrelationResolver(splunk_client)

    context = None
    deadline = time.monotonic() + 20.0
    while time.monotonic() < deadline:
        try:
            context = await resolver.resolve_request(
                request_id, earliest, datetime.now(UTC)
            )
            break
        except (CorrelationNotFound, TraceIdNotFound):
            await asyncio.sleep(1.0)
    assert context is not None, f"Splunk did not resolve trace.id for {request_id}"

    newrelic_collector = NewRelicEvidenceCollector(
        StreamableHttpNewRelicMcpGateway(NEW_RELIC_MCP_URL or ""),
        account_id=int(NEW_RELIC_ACCOUNT_ID or "0"),
    )

    transaction_context = CorrelationContext(
        request_id=context.request_id,
        trace_id=context.trace_id,
        services=context.services,
        entity_guids={},
    )
    deadline = time.monotonic() + 30.0
    while time.monotonic() < deadline:
        newrelic = await newrelic_collector.collect(
            transaction_context, earliest, datetime.now(UTC)
        )
        if any(
            item.category is EvidenceCategory.TRANSACTION
            and item.trace_id == context.trace_id
            for item in newrelic.evidence
        ):
            break
        await asyncio.sleep(1.0)
    else:
        pytest.fail(f"New Relic MCP did not return traceId={context.trace_id}")

    orchestrator = InvestigationOrchestrator(
        resolver=resolver,
        splunk_collector=SplunkEvidenceCollector(splunk_client),
        newrelic_collector=newrelic_collector,
        correlator=EvidenceCorrelator(),
        analyzer=OpenAIIncidentAnalyzer.from_env(),
    )

    result = await orchestrator.investigate_request_id(
        request_id, earliest, datetime.now(UTC)
    )

    assert any(
        item.source is EvidenceSource.SPLUNK for item in result.bundle.evidence
    )
    assert any(
        item.source is EvidenceSource.NEW_RELIC for item in result.bundle.evidence
    )
    assert result.analysis.incident_summary
    assert result.analysis.impact
    assert result.analysis.likely_cause
