from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from agent.evidence.models import (
    CorrelationContext,
    EvidenceCategory,
    EvidenceGap,
    EvidenceItem,
    EvidenceSource,
    QueryDisclosure,
)
from agent.splunk.client import SplunkSearchClient
from agent.splunk.models import SplunkSearchRequest


_FACT_KEYS = {
    "event_type",
    "service.version",
    "scenario.id",
    "http.method",
    "http.route",
    "http.status_code",
    "duration_ms",
    "db.system",
    "db.query_name",
    "db.duration_ms",
    "dependency.name",
    "dependency.type",
    "dependency.status_code",
    "dependency.duration_ms",
    "retry_count",
    "error.type",
    "error.message",
    "operation",
    "queue_wait_ms",
    "active_workers",
    "inflight_requests",
    "order.id",
    "product.id",
}

_CATEGORY_BY_EVENT = {
    "db.query": EvidenceCategory.DB,
    "dependency.call": EvidenceCategory.DEPENDENCY,
    "exception": EvidenceCategory.EXCEPTION,
    "capacity.snapshot": EvidenceCategory.CAPACITY,
    "deployment": EvidenceCategory.DEPLOYMENT,
    "application.request": EvidenceCategory.APPLICATION,
    "application.response": EvidenceCategory.APPLICATION,
}


class SplunkEvidenceUnavailable(RuntimeError):
    pass


class SplunkEvidenceResult(BaseModel):
    evidence: list[EvidenceItem]
    query: QueryDisclosure
    gaps: list[EvidenceGap] = Field(default_factory=list)


def _parse_observed_at(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


class SplunkEvidenceCollector:
    def __init__(self, splunk: SplunkSearchClient) -> None:
        self.splunk = splunk

    async def collect(
        self,
        context: CorrelationContext,
        earliest: datetime,
        latest: datetime,
    ) -> SplunkEvidenceResult:
        query_text = f'trace.id="{context.trace_id}"'
        disclosure = QueryDisclosure(
            disclosure_id="query-splunk-001",
            source=EvidenceSource.SPLUNK,
            operation="search",
            arguments={
                "query": query_text,
                "earliest": earliest.isoformat(),
                "latest": latest.isoformat(),
                "max_results": 200,
            },
        )
        try:
            rows = await self.splunk.search(
                SplunkSearchRequest(
                    query=query_text,
                    earliest=earliest,
                    latest=latest,
                    max_results=200,
                )
            )
        except Exception:
            raise SplunkEvidenceUnavailable("Splunk evidence search was unavailable") from None

        evidence: list[EvidenceItem] = []
        for index, row in enumerate(rows, start=1):
            event_type = str(row.get("event_type") or "unknown")
            category = _CATEGORY_BY_EVENT.get(event_type, EvidenceCategory.APPLICATION)
            facts = {key: row[key] for key in _FACT_KEYS if key in row}
            service_name = str(row["service.name"]) if row.get("service.name") else None
            request_id = str(row["request.id"]) if row.get("request.id") else None
            trace_id = str(row["trace.id"]) if row.get("trace.id") else None
            entity_guid = str(row["entity.guid"]) if row.get("entity.guid") else None
            summary = f"Splunk observed {event_type}"
            if service_name:
                summary += f" for {service_name}"

            evidence.append(
                EvidenceItem(
                    evidence_id=f"splunk-{index:03d}",
                    source=EvidenceSource.SPLUNK,
                    category=category,
                    summary=summary,
                    facts=facts,
                    query_or_tool=disclosure.disclosure_id,
                    service_name=service_name,
                    observed_at=_parse_observed_at(row.get("_time")),
                    request_id=request_id,
                    trace_id=trace_id,
                    entity_guid=entity_guid,
                )
            )

        return SplunkEvidenceResult(evidence=evidence, query=disclosure)
