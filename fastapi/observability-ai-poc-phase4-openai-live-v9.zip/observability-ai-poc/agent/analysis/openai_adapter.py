from __future__ import annotations

import copy
import json
import os

import httpx
from pydantic import ValidationError

from agent.analysis.models import IncidentAnalysis
from agent.analysis.prompt import ANALYSIS_CONTRACT
from agent.evidence.models import EvidenceBundle


class OpenAIConfigurationError(RuntimeError):
    pass


class OpenAIAnalysisError(RuntimeError):
    pass


class OpenAIIncidentAnalyzer:
    def __init__(
        self,
        *,
        api_key: str,
        model: str = "gpt-5.6-luna",
        client: httpx.AsyncClient | None = None,
        base_url: str = "https://api.openai.com/v1",
        timeout_seconds: float = 60.0,
        max_output_tokens: int = 2500,
    ) -> None:
        self.api_key = api_key
        self.model = model
        self.client = client
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.max_output_tokens = max_output_tokens

    @classmethod
    def from_env(cls) -> "OpenAIIncidentAnalyzer":
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise OpenAIConfigurationError("OPENAI_API_KEY is required")
        raw_max_output_tokens = os.getenv("OPENAI_MAX_OUTPUT_TOKENS", "2500")
        try:
            max_output_tokens = int(raw_max_output_tokens)
        except ValueError:
            raise OpenAIConfigurationError(
                "OPENAI_MAX_OUTPUT_TOKENS must be an integer"
            ) from None
        return cls(
            api_key=api_key,
            model=os.getenv("OPENAI_MODEL", "gpt-5.6-luna"),
            base_url=os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"),
            max_output_tokens=max_output_tokens,
        )

    async def analyze(self, bundle: EvidenceBundle) -> IncidentAnalysis:
        payload = {
            "model": self.model,
            "store": False,
            "max_output_tokens": self.max_output_tokens,
            "instructions": ANALYSIS_CONTRACT,
            "input": bundle.model_dump_json(),
            "text": {
                "format": {
                    "type": "json_schema",
                    "name": "incident_analysis",
                    "schema": build_incident_analysis_schema(),
                    "strict": True,
                }
            },
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        try:
            if self.client is not None:
                response = await self.client.post(
                    f"{self.base_url}/responses",
                    headers=headers,
                    json=payload,
                )
            else:
                async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
                    response = await client.post(
                        f"{self.base_url}/responses",
                        headers=headers,
                        json=payload,
                    )
        except httpx.RequestError:
            raise OpenAIAnalysisError("OpenAI Responses API request failed") from None
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise OpenAIAnalysisError(
                f"OpenAI Responses API returned HTTP {exc.response.status_code}"
            ) from None
        try:
            body = response.json()
        except json.JSONDecodeError:
            raise OpenAIAnalysisError("OpenAI returned an invalid JSON response") from None
        status = body.get("status")
        if status != "completed":
            raise OpenAIAnalysisError(f"OpenAI response status was {status or 'unknown'}")
        output_text = _extract_output_text(body)
        try:
            return IncidentAnalysis.model_validate(json.loads(output_text))
        except (json.JSONDecodeError, ValidationError, TypeError) as exc:
            raise OpenAIAnalysisError("OpenAI returned invalid structured output") from exc


def _extract_output_text(body: dict) -> str:
    for item in body.get("output", []):
        if item.get("type") != "message":
            continue
        for content in item.get("content", []):
            if content.get("type") == "refusal":
                raise OpenAIAnalysisError("OpenAI model refused the analysis request")
            if content.get("type") == "output_text":
                text = content.get("text")
                if isinstance(text, str) and text:
                    return text
    raise OpenAIAnalysisError("OpenAI response did not contain output_text")


def build_incident_analysis_schema() -> dict:
    schema = copy.deepcopy(IncidentAnalysis.model_json_schema())
    _make_object_properties_required(schema)
    return schema


def _make_object_properties_required(node) -> None:
    if isinstance(node, dict):
        properties = node.get("properties")
        if node.get("type") == "object" and isinstance(properties, dict):
            node["additionalProperties"] = False
            node["required"] = list(properties)
        for value in node.values():
            _make_object_properties_required(value)
    elif isinstance(node, list):
        for item in node:
            _make_object_properties_required(item)
