# AG-UI + A2UI Python PoC

A2UI / AG-UIの調査・検証タスク向けに、Python SDKを使って段階的に確認できる最小PoCです。

## 構成

```text
agui-a2ui-python-poc/
├── agui_poc/
│   └── main.py               # AG-UIだけを確認するFastAPI/SSE server
├── a2ui_poc/
│   ├── main.py               # A2UI JSONL stream
│   └── prompt_builder.py     # a2ui-agent-sdkによるsystem prompt生成
├── integrated_poc/
│   └── main.py               # AG-UI + A2UI protocol-level PoC
├── common/
│   ├── agui_input.py
│   └── a2ui_ops.py           # ag-ui-a2ui-toolkitでoperation生成
├── client/
│   └── index.html            # 検証用簡易Browser client
├── examples/
│   └── agui-request.json
├── docs/
│   ├── investigation.md
│   ├── production-notes.md
│   └── report-template.md
├── scripts/
│   ├── setup.sh
│   ├── run_agui.sh
│   ├── run_a2ui.sh
│   ├── run_integrated.sh
│   └── smoke_test.py
├── tests/
│   └── test_a2ui_ops.py
├── requirements.txt
├── requirements-dev.txt
└── pyproject.toml
```

## 使用SDK

このZIP作成時点では以下を固定しています。

```text
ag-ui-protocol==0.1.20
ag-ui-a2ui-toolkit==0.0.4
a2ui-agent-sdk==0.5.0
```

Python 3.10以上を推奨します。

---

# 1. セットアップ

Linux / macOS:

```bash
cd agui-a2ui-python-poc
bash scripts/setup.sh
source .venv/bin/activate
```

Windows PowerShell:

```powershell
cd agui-a2ui-python-poc
.\scripts\setup.ps1
```

手動で行う場合:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-dev.txt
```

---

# 2. AG-UIだけを確認

Terminal 1:

```bash
source .venv/bin/activate
python -m uvicorn agui_poc.main:app --port 8000 --reload
```

Terminal 2:

```bash
curl -N \
  -H 'Content-Type: application/json' \
  -H 'Accept: text/event-stream' \
  --data @examples/agui-request.json \
  http://127.0.0.1:8000/agent
```

期待するevent sequence:

```text
RUN_STARTED
TEXT_MESSAGE_START
TEXT_MESSAGE_CONTENT
TEXT_MESSAGE_CONTENT
TEXT_MESSAGE_CONTENT
TEXT_MESSAGE_END
RUN_FINISHED
```

Python smoke test:

```bash
python scripts/smoke_test.py agui
```

---

# 3. A2UIだけを確認

Terminal 1:

```bash
source .venv/bin/activate
python -m uvicorn a2ui_poc.main:app --port 8001 --reload
```

Terminal 2:

```bash
curl -N http://127.0.0.1:8001/a2ui
```

A2UI messageがJSON Linesで返ります。

```text
createSurface
updateComponents
updateDataModel
```

Python smoke test:

```bash
python scripts/smoke_test.py a2ui
```

## A2UI Agent SDKのprompt生成

LLM API keyなしで実行できます。

```bash
python -m a2ui_poc.prompt_builder > /tmp/a2ui-system-prompt.txt
```

このファイルは `A2uiSchemaManager` とBasic Catalogを使い、LLMへ渡すA2UI-aware system promptを組み立てる例です。

---

# 4. AG-UI + A2UIをまとめて確認

最もおすすめの確認方法です。

```bash
source .venv/bin/activate
python -m uvicorn integrated_poc.main:app --port 8002 --reload
```

ブラウザで開きます。

```text
http://127.0.0.1:8002/demo
```

`Send` を押すと、1回のrequestで以下を確認できます。

```text
Browser
   |
   | POST /agent
   v
FastAPI / Python
   |
   | AG-UI SSE
   |-- RUN_STARTED
   |-- TEXT_MESSAGE_*
   |-- CUSTOM: a2ui.operations
   |     `-- a2ui_operations
   |          |-- createSurface
   |          |-- updateComponents
   |          `-- updateDataModel
   `-- RUN_FINISHED
   |
   v
Diagnostic Client
   |-- text stream表示
   `-- A2UI surface簡易描画
```

CLIから確認する場合:

```bash
python scripts/smoke_test.py integrated
```

---

# 5. integrated_pocについて重要な点

`integrated_poc/main.py` では、理解しやすさを優先してAG-UI `CUSTOM` eventにA2UI operation envelopeを格納しています。

```python
CustomEvent(
    type=EventType.CUSTOM,
    name="a2ui.operations",
    value=envelope,
)
```

これは **protocol-levelの検証用bridge** です。

現行の本格的なA2UI + AG-UI構成では、Agent/toolが `a2ui_operations` envelopeを返し、AG-UI側のA2UI middleware/runtimeがそれをRenderer向けのactivityとして処理する構成を採用します。

したがって、今回のPoCでは以下を分けて評価してください。

```text
確認できること
- Python AG-UI SDK
- RunAgentInput
- SSE streaming
- AG-UI lifecycle/text/custom event
- Python A2UI toolkit
- A2UI operation生成
- A2UI structure/data binding
- AG-UI経由でstructured UI payloadを運ぶ流れ

次フェーズ
- official A2UI Renderer
- official A2UI middleware/runtime
- user action往復
- dynamic LLM UI generation
- schema validation/retry
```

---

# 6. 固定UIと動的UI

このPoCのmonitoring UIは固定schemaです。

```text
Column
├── Text: Server Monitoring
├── Card
│   └── Host / Status / Message
└── Card
    └── CPU / Memory / Requests
```

値だけ `updateDataModel` で変えています。

最初の8時間程度の検証では、この方式をおすすめします。Transportの問題とLLM生成品質の問題を分離できるためです。

その後、`a2ui_poc/prompt_builder.py` のsystem promptをLLMへ渡し、dynamic schema generationへ進めます。

---

# 7. テスト

依存packageのinstall後に実行します。

```bash
pytest -q
```

構文チェックだけなら:

```bash
python -m compileall agui_poc a2ui_poc integrated_poc common scripts tests
```

---

# 8. 8〜16時間タスクでの使い方

おすすめの順序:

```text
1〜2h   docs/investigation.mdを読みながら公式docs確認
1〜2h   agui_pocを起動しSSE/eventを確認
1〜2h   a2ui_pocを起動しA2UI JSONを確認
2〜3h   integrated_pocをbrowserで確認
1〜2h   sourceを変更してCPU/Memory/UI structureを変更
1〜2h   official Renderer / middlewareとの差分調査
1h      docs/report-template.mdで結果整理
```

16時間使える場合は、後半で以下を追加するとよいです。

- Button/action
- user input
- state update
- tool call
- LLMによるdynamic A2UI generation
- LangGraph / ADK / Strandsなど実Agent frameworkへの接続

---

# 9. 参考URL

- A2UI: https://a2ui.org/
- A2UI Agent Development: https://a2ui.org/guides/agent-development/
- A2UI + AG-UI: https://a2ui.org/guides/a2ui-with-any-agent-framework/
- AG-UI: https://docs.ag-ui.com/introduction
- AG-UI Python SDK: https://docs.ag-ui.com/sdk/python/core/overview

---

# 10. 注意

このリポジトリは調査・PoC用です。Productionへ移す場合は `docs/production-notes.md` を参照してください。
